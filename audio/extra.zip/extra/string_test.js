	static createstring1(sndfreq,freq,volume,pluck,inharm,decay) {
		// Jason Pelc
		// http://large.stanford.edu/courses/2007/ph210/pelc2/
		if (freq===undefined) {freq=220;}
		if (pluck===undefined) {pluck=0.3;}
		pluck=pluck>0?pluck:0;
		pluck=pluck<1?pluck:1;
		if (volume===undefined) {volume=1;}
		//let inharm=0.008;  // inharmonicity factor
		//let decay=1.7;
		//let sndfreq=44100;
		// Generate coefficients.
		let c0=inharm*inharm;
		let c1=pluck*Math.PI;
		let c2=(2*volume)/(Math.PI*c1*(1-pluck));
		let c3=freq*2*Math.PI;
		let coefs=Math.floor(sndfreq/(2*freq));
		let freqcoef=new Array(coefs);
		let sincoef =new Array(coefs);
		let sumcoef =0;
		for (let i=0;i<coefs;i++) {
			let n=i+1,n2=n*n;
			freqcoef[i]=n*c3*Math.sqrt(1+n2*c0);
			sincoef[i]=Math.sin(n*c1)*c2/n2;
			sumcoef+=Math.abs(sincoef[i]);
		}
		// Generate the waveform.
		// Stop when sumcoef*e^(-decay*time/sndfreq)<=1e-4
		let stop=Math.floor(-Math.log(1e-4/sumcoef)*sndfreq/decay);
		let snd=new Audio.Sound(stop,sndfreq);
		let data=snd.data;
		let time=0.0,timeinc=1/sndfreq;
		//let decay0=1.0,decay1=Math.exp(-decay*timeinc);
		for (let i=0;i<stop;i++) {
			let mul=1,sum=0;
			for (let c=0;c<coefs;c++) {
				//mul*=decay0;
				//sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
				mul=Math.exp(-decay*(c+1)*time);
				sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
			}
			data[i]+=sum;
			time+=timeinc;
			//decay0*=decay1;
		}
		return snd;
	}


	static createstring2(sndfreq,freq,volume,pos,inharm,decay) {
		// Jason Pelc
		// http://large.stanford.edu/courses/2007/ph210/pelc2/
		if (freq===undefined) {freq=220;}
		if (pos===undefined) {pos=0.3;}
		pos=pos>0?pos:0;
		pos=pos<1?pos:1;
		if (volume===undefined) {volume=1;}
		const cutoff=1e-4;
		//let inharm=0.008;  // inharmonicity factor
		//let decay=1.7;
		//let sndfreq=44100;
		// Generate coefficients.
		let c0=inharm*inharm;
		let c1=pos*Math.PI;
		let c2=(2*volume)/(Math.PI*c1*(1-pos));
		let c3=freq*2*Math.PI;
		let coefs=Math.floor(sndfreq/(2*freq));
		// Stop when e^(-decay*time/sndfreq)<=1e-4
		let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
		let snd=new Audio.Sound(sndlen,sndfreq);
		let snddata=snd.data;
		for (let c=coefs-1;c>=0;c--) {
			// Calculate coefficients for the n'th harmonic.
			let n=c+1,n2=n*n;
			let harmmul=Math.sin(n*c1)*c2/n2;
			if (Math.abs(harmmul)<=cutoff) {continue;}
			let harmlen=Math.ceil(-Math.log(cutoff/Math.abs(harmmul))*sndfreq/decay);
			if (harmlen>sndlen) {harmlen=sndlen;}
			let harmfreq=n*c3*Math.sqrt(1+n2*c0)/sndfreq;
			let harmfreq0=n*c3*Math.sqrt(1+n2*c0);
			let harmmul0=harmmul;
			// Generate the waveform.
			let harmphase=0,harmdecay=Math.exp(-decay*n/sndfreq);
			/*for (let i=0;i<harmlen;i++) {
				let time0=i/sndfreq;
				let mul0=Math.exp(-decay*(c+1)*time0);
				let sum0=mul0*harmmul0*Math.sin(harmfreq0*time0);
				snddata[i]+=sum0;
				if (Math.abs(harmphase-harmfreq0*time0)>1e-5) {
					console.log(harmphase,harmfreq0*time0);
					throw "x";
				}
				if (Math.abs(harmmul-mul0*harmmul0)>1e-5) {
					console.log(harmmul,mul0*harmmul0);
					throw "y";
				}
				let sum1=harmmul*Math.sin(harmphase);
				if (Math.abs(sum1-sum0)>1e-5) {
					console.log(sum1,sum0);
					throw "z";
				}
				harmmul*=harmdecay;
				harmphase+=harmfreq;
				//snddata[i]+=harmmul*Math.sin(harmphase);
			}*/
			for (let i=0;i<harmlen;i++) {
				snddata[i]+=harmmul*Math.sin(harmphase);
				harmmul*=harmdecay;
				harmphase+=harmfreq;
			}
		}
		return snd;
	}
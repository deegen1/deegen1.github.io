class _AudioEnvelope {
	// Envelope/gain filter.

	constructor(arr) {
		// [ target, time, type, target, time, type, ... ]
		// type = lin, con, exp
		this.last=null;
		this.stop=0;
		this.envarr=[];
		for (let i=0;arr && i<arr.length;i+=3) {
			this.add(arr[i],arr[i+1],arr[i+2]);
		}
	}


	add(target,time,type) {
		if (time<0 || isNaN(time)) {
			throw "envelope invalid time: "+time.toString();
		}
		if (target<0) {
			throw "envelope invalid target: "+target.toString();
		}
		let envarr=this.envarr;
		let prev=envarr.length>0?envarr[envarr.length-1]:null;
		let prevtar=prev?prev.target:0;
		let prevstop=prev?prev.stop:0;
		let env={};
		env.start=prevstop;
		env.stop=prevstop+time;
		if (type==="con") {
			env.type=0;
			env.rate=0;
			env.con=target;
		} else if (type==="lin") {
			env.type=1;
			env.rate=(target-prevtar)/time;
			env.con=prevtar-env.rate*prevstop;
		} else if (type==="exp") {
			env.type=2;
			if (target <1e-4) {target =1e-4;}
			if (prevtar<1e-4) {prevtar=1e-4;}
			let lp=Math.log(prevtar),ln=Math.log(target);
			env.rate=(ln-lp)/time;
			env.con=lp-env.rate*prevstop;
		} else {
			throw "envelope type '"+type.toString()+"' invalid: con, lin, exp";
		}
		env.target=target;
		envarr.push(env);
		this.stop=env.stop;
		return this;
	}


	get(time) {
		let env=this.last;
		// If we're in a new time segment.
		if (env===null || time<env.start || time>=env.stop) {
			env=null;
			if (time>=0 && time<this.stop) {
				let envarr=this.envarr;
				let i=0,len=envarr.length;
				while (i<len && time>=envarr[i].stop) {i++;}
				env=i<len?envarr[i]:null;
			}
			this.last=env;
			if (env===null) {return 0;}
		}
		let u=time*env.rate+env.con;
		if (env.type<2) {return u;}
		else {return Math.exp(u);}
	}

}

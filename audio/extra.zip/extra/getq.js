// Biquad

	getq() {
		let ang=2*Math.PI*this.rate;
		let sn =Math.sin(ang);
		let q  =0.5/Math.sinh(Math.log(2)*0.5*this.bandwidth*ang/sn);
		return q;
	}

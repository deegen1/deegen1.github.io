/*------------------------------------------------------------------------------


test.js - v1.05

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint test.js -c ../../../standards/eslint.js */
/* global Random */


//---------------------------------------------------------------------------------
// Misc Sounds


function MeasureVolume(snd) {
	let data=snd.data;
	let len=snd.len;
	let eps=1e-3;
	let sum0=0,max0=0,den0=0;
	let sum1=0,max1=0,den1=0;
	let prev=0;
	for (let i=0;i<len;i++) {
		let x=data[i];
		let y=Math.abs(x);
		if (y>eps) {sum0+=y;den0++;}
		if (max0<y) {max0=y;}
		y=Math.abs(x-prev);
		prev=x;
		if (y>eps) {sum1+=y;den1++;}
		if (max1<y) {max1=y;}
	}
	sum0/=den0;
	// sum1=Math.sqrt(sum1/den1);
	console.log("abs avg: "+sum0.toFixed(6)+", abs max: "+max0.toFixed(6)+", rel avg: "+sum1.toFixed(6)+", rel max: "+max1.toFixed(6));
	return snd;
}
/*Audio.prototype.play=function(snd,volume,pan,freq) {
	MeasureVolume(snd);
	return new _AudioInstance(snd,volume,pan,freq);
};*/


function PlayPhoneDial1() {
	let freq=44100,len=freq*2;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=Audio.sin(t*350)+Audio.sin(t*440);
		data[i]+=note;
	}
	snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayPhoneRing1() {
	let freq=44100,len=freq*2;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=Audio.sin(t*440)+Audio.sin(t*480);
		data[i]+=note;
	}
	snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayAlarm2() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	let lp7=new Audio.Biquad("lowpass",70/freq);
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let n0 =(Audio.sqr(t)+1)*0.5;
		let n1 =lp7.process(n0);
		let n20=Audio.sin(t*600)*(1-n1);
		let n21=Audio.sin(t*800)*n1;
		data[i]+=(n20+n21)*0.2;
	}
	// snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayHiHat2() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let rate=40;
	let ratio=[2,3,4.16,5.43,6.79,8.21];
	let ratios=ratio.length;
	let bp=new Audio.Biquad("bandpass",10000/freq);
	let hp=new Audio.Biquad("highpass",7000/freq);
	let voldecay=Math.log(1e-4)/0.3;
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=0;
		for (let j=0;j<ratios;j++) {
			note+=Audio.sqr(t*rate*ratio[j]);
		}
		note=bp.process(note);
		note=hp.process(note);
		let mul=Math.exp(voldecay*t);
		data[i]+=Audio.clip(note,-1,1)*mul;
	}
	// snd.scale(1/snd.getvolume());
	snd.play();
}

/*
static createelectricity(freq=99.8,volume=0.5,time=5.5) {
	// Pitch should increase slightly with force.
	let sndfreq=44100,len=Math.ceil(time*sndfreq);
	let tail=(time-0.01)*sndfreq,tailden=1/(len-1-tail);
	let snd=new Audio.Sound(sndfreq,len);
	let data=snd.data;
	let freq0=freq/sndfreq,freq1=freq0*1.004;
	let lp1=new Audio.Biquad("lowpass",2/sndfreq);
	let lp2=new Audio.Biquad("lowpass",2/sndfreq);
	let lp3=new Audio.Biquad("lowpass",3000/sndfreq);
	let del=new Audio.Delay(sndfreq,0.1);
	for (let i=0;i<len;i++) {
		let x0=Audio.saw1(i*freq0)+Audio.saw1(i*freq1);
		x0=Audio.clip(x0-1,-0.5,0.5);
		let x1=Audio.noise(i);
		x1=lp1.process(x1);
		x1=lp2.process(x1);
		x1=x1*x1;
		x0*=x1*1000;
		x0=lp3.process(x0);
		del.add(x0);
		let y=del.get(x1*4+0.02);
		if (i>=tail) {y*=(len-1-i)*tailden;}
		data[i]=y;
	}
	snd.scale(volume/(snd.getvolume()+1e-10));
	return snd;
}
*/

function PlayMaraca() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let beadlen=Math.floor(0.02*freq),beadfreq=5000,beaddec=Math.log(1e-5)/0.02;
	let beadsnd=new Array(beadlen);
	for (let i=0;i<beadlen;i++) {
		let t=i/freq;
		beadsnd[i]=Math.sin(t*beadfreq*Math.PI*2)*Math.exp(t*beaddec);
	}
	let data=snd.data;
	let volmul=Math.log(1e-4)/5;
	let next=Math.random()*0.04;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		if (t>=next) {
			let mul=Math.exp(t*volmul);
			next=t+Math.random()*0.03*t;
			for (let j=0;j<beadlen;j++) {
				data[i+j]+=beadsnd[j]*mul;
			}
		}
	}
	snd.scalevol(1,true);
	snd.play();
}


function PlayStringPhysical() {
	// Physically based string modelling.
	let freq=44100,sndtime=3,sndlen=Math.floor(freq*sndtime);
	let snd=new Audio.Sound(freq,sndlen);
	let samples=100;
	let pluckheight=1.0,pluckpos=0.5;
	let stringpos=new Float64Array(samples);
	let stringvel=new Float64Array(samples);
	for (let i=0;i<samples;i++) {
		let u=i/(samples-1);
		let v=u<pluckpos?u/pluckpos:(1-u)/(1-pluckpos);
		stringpos[i]=v*pluckheight;
		stringvel[i]=0;
	}
	let data=snd.data;
	let dt0=400*(1/freq);
	let dt1=400*(1/freq);
	let decay=0.9999;
	let listen=Math.floor(samples*0.5);
	let bp=new Audio.Biquad("bandpass",400/freq,1);
	for (let i=0;i<sndlen;i++) {
		let t=i/freq;
		for (let s=1;s<samples-1;s++) {
			stringvel[s]+=dt0*2.0*(stringpos[s-1]+stringpos[s+1]-2*stringpos[s]);
		}
		for (let s=1;s<samples-1;s++) {
			// stringpos[s]+=dt*stringvel[s];
			let vel=stringvel[s];
			stringpos[s]+=vel*dt1;
			stringvel[s] =vel*decay;
		}
		data[i]=bp.process(stringpos[listen]);
	}
	snd.scalevol(1,true);
	// snd.savefile("wve.wav");
	snd.play();
}


function PlayComb() {
	let sndfreq=44100,sndtime=3,sndlen=Math.floor(sndfreq*sndtime);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let del=new Audio.Delay(sndfreq,0.2);
	let fil=new Audio.Biquad("highpass",200/sndfreq);
	let fb=0.95;
	for (let i=0;i<del.len;i++) {
		let u=i/del.len;
		del.data[i]=Math.abs(u-0.5)*2;
		del.data[i]=Audio.noise(i)*1.0;
	}
	for (let i=0;i<del.len*4;i++) {
		let n0=del.get();
		n0=fil.process(n0);
		del.add(n0);
	}
	fil.clear();
	let data=snd.data;
	for (let i=0;i<sndlen;i++) {
		let n0=del.get();
		data[i]=n0;
		n0=n0*fb;
		del.add(n0);
	}
	snd.scalevol(1,true);
	// snd.savefile("wve.wav");
	snd.play();
}


//---------------------------------------------------------------------------------
// Guitar


function generatestringtri(volume=1,freq=200,pos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2,sndfreq=44100) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let listen=pos;// 0.16;
	let c0=listen*Math.PI;
	let c1=(2*volume)/(Math.PI*Math.PI*pos*(1-pos));
	let c2=inharm; // *inharm;
	let c3=freq;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	let ramp=Math.floor(0.01*sndfreq);
	let rampmul=1/ramp;
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		let ramplen=ramp<harmlen?ramp:harmlen;
		let bp=new Audio.Biquad("bandpass",harmfreq,2);
		for (let i=0;i<ramplen;i++) {
			snddata[i]+=harmmul*bp.process(Audio.tri(harmphase))*i*rampmul;
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
		for (let i=ramplen;i<harmlen;i++) {
			snddata[i]+=harmmul*bp.process(Audio.tri(harmphase));
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function generatestringwave(volume=1,freq=200,pluckpos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2,sndfreq=44100) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let listen=pluckpos;// 0.16;
	let c0=listen*Math.PI;
	let c1=(2*1)/(Math.PI*Math.PI*pluckpos*(1-pluckpos));
	let c2=inharm; // *inharm;
	let c3=freq;// *2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pluckpos<0.0001 || pluckpos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	let excite=new Float32Array(sndlen);
	let wavelen=Math.round(0.5*sndfreq/freq),wavepos=0;
	let wave=new Float64Array(wavelen);
	let wavemul=-0.995;
	for (let i=0;i<wavelen;i++) {
		let u=i/(wavelen-1);
		let v=u<pluckpos?u/pluckpos:(1-u)/(1-pluckpos);
		// let v=u<0.5?1:0;
		wave[i]=v;
	}
	for (let i=0;i<sndlen;i++) {
		let j=i%wavelen;
		let l=(i+75)%wavelen;
		excite[i]=wave[l];
		wave[j]*=wavemul;
	}
	// Process highest to lowest for floating point accuracy.
	let ramp=Math.floor(0.01*sndfreq);
	let rampmul=1/ramp;
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		// let harmphase=0;
		let harmdecay=Math.exp(dscale);
		let ramplen=ramp<harmlen?ramp:harmlen;
		let filter=new Audio.Biquad("bandpass",harmfreq,1);
		for (let i=0;i<ramplen;i++) {
			snddata[i]+=harmmul*filter.process(wave[i])*i*rampmul;
			harmmul*=harmdecay;
			// harmphase+=harmfreq;
		}
		for (let i=ramplen;i<harmlen;i++) {
			snddata[i]+=harmmul*filter.process(wave[i]);
			harmmul*=harmdecay;
			// harmphase+=harmfreq;
		}
	}
	snd.scalevol(volume,true);
	// snd.savefile("wve.wav");
	// snd.play();
	return snd;
}


function Trippy80sGuitar(sndfreq,freq=200,volume=1,pos=0.5,inharm=0.008,harmexp=1.0,decay=1.7) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let c0=pos*Math.PI;
	let c1=(2*volume)/(Math.PI*c0*(1-pos));
	let c2=inharm*inharm;
	let c3=freq*2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		harmmul*=5;
		let filter=new Audio.Biquad("bandpass",harmfreq,50/1000);
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*filter.process(Audio.noise(i));
			// snddata[i]+=harmmul*filter.process(Audio.noise(i*0.05));//Math.sin(harmphase);
			// snddata[i]+=harmmul*filter.process(Audio.sqr(harmphase));//Math.sin(harmphase);
			// snddata[i]+=Audio.clip(Math.tanh(Math.sin(harmphase)),-harmmul,harmmul);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function createstring1(sndfreq,freq,volume,pluck,inharm,decay) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	if (freq===undefined) {freq=220;}
	if (pluck===undefined) {pluck=0.3;}
	pluck=pluck>0?pluck:0;
	pluck=pluck<1?pluck:1;
	if (volume===undefined) {volume=1;}
	// let inharm=0.008;  // inharmonicity factor
	// let decay=1.7;
	// let sndfreq=44100;
	// Generate coefficients.
	let c0=inharm*inharm;
	let c1=pluck*Math.PI;
	let c2=(2*volume)/(Math.PI*c1*(1-pluck));
	let c3=freq*2*Math.PI;
	let coefs=Math.floor(sndfreq/(2*freq));
	let freqcoef=new Array(coefs);
	let sincoef =new Array(coefs);
	let sumcoef =0;
	for (let i=0;i<coefs;i++) {
		let n=i+1,n2=n*n;
		freqcoef[i]=n*c3*Math.sqrt(1+n2*c0);
		sincoef[i]=Math.sin(n*c1)*c2/n2;
		sumcoef+=Math.abs(sincoef[i]);
	}
	// Generate the waveform.
	// Stop when sumcoef*e^(-decay*time/sndfreq)<=1e-4
	let stop=Math.floor(-Math.log(1e-4/sumcoef)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,stop);
	let data=snd.data;
	let time=0.0,timeinc=1/sndfreq;
	// let decay0=1.0,decay1=Math.exp(-decay*timeinc);
	for (let i=0;i<stop;i++) {
		let mul=1,sum=0;
		for (let c=0;c<coefs;c++) {
			// mul*=decay0;
			// sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
			mul=Math.exp(-decay*(c+1)*time);
			sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
		}
		data[i]+=sum;
		time+=timeinc;
		// decay0*=decay1;
	}
	return snd;
}


function createstring2(sndfreq,freq,volume,pos,inharm,decay) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	if (freq===undefined) {freq=220;}
	if (pos===undefined) {pos=0.3;}
	pos=pos>0?pos:0;
	pos=pos<1?pos:1;
	if (volume===undefined) {volume=1;}
	const cutoff=1e-4;
	// let inharm=0.008;  // inharmonicity factor
	// let decay=1.7;
	// let sndfreq=44100;
	// Generate coefficients.
	let c0=inharm*inharm;
	let c1=pos*Math.PI;
	let c2=(2*volume)/(Math.PI*c1*(1-pos));
	let c3=freq*2*Math.PI;
	let coefs=Math.floor(sndfreq/(2*freq));
	// Stop when e^(-decay*time/sndfreq)<=1e-4
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	for (let c=coefs-1;c>=0;c--) {
		// Calculate coefficients for the n'th harmonic.
		let n=c+1,n2=n*n;
		let harmmul=Math.sin(n*c1)*c2/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		let harmlen=Math.ceil(-Math.log(cutoff/Math.abs(harmmul))*sndfreq/decay);
		if (harmlen>sndlen) {harmlen=sndlen;}
		let harmfreq=n*c3*Math.sqrt(1+n2*c0)/sndfreq;
		let harmfreq0=n*c3*Math.sqrt(1+n2*c0);
		let harmmul0=harmmul;
		// Generate the waveform.
		let harmphase=0,harmdecay=Math.exp(-decay*n/sndfreq);
		/*for (let i=0;i<harmlen;i++) {
			let time0=i/sndfreq;
			let mul0=Math.exp(-decay*(c+1)*time0);
			let sum0=mul0*harmmul0*Math.sin(harmfreq0*time0);
			snddata[i]+=sum0;
			if (Math.abs(harmphase-harmfreq0*time0)>1e-5) {
				console.log(harmphase,harmfreq0*time0);
				throw "x";
			}
			if (Math.abs(harmmul-mul0*harmmul0)>1e-5) {
				console.log(harmmul,mul0*harmmul0);
				throw "y";
			}
			let sum1=harmmul*Math.sin(harmphase);
			if (Math.abs(sum1-sum0)>1e-5) {
				console.log(sum1,sum0);
				throw "z";
			}
			harmmul*=harmdecay;
			harmphase+=harmfreq;
			//snddata[i]+=harmmul*Math.sin(harmphase);
		}*/
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*Math.sin(harmphase);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function createstring3(sndfreq,freq=200,volume=1,pos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let c0=pos*Math.PI;
	let c1=(2*volume)/(Math.PI*c0*(1-pos));
	let c2=inharm; // *inharm;
	let c3=freq*2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*Math.sin(harmphase);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


//---------------------------------------------------------------------------------
// Try stretching the input vector to a power of 2 to maintain frequencies and
// allow use of the FFT.


function _dctresize(dst,src) {
	let dlen=dst.length,dinc=dlen-1,drem=0;
	let slen=src.length,sinc=slen-1,srem=0;
	if (dlen<slen) {
		let s1=src[0],s0=s1,j0=0;
		dst[0]=s1;
		for (let i=1;i<dlen;i++) {
			// dst[i-1]+x=src[j]
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0<j) {j0=j;s0=src[j];s1=src[j+1];}
			dst[i]=(s1-s0)*(1-u+1e-10)/(u+1e-10)+s0;// s0*(u)+s1*(1-u);
			dst[i]=s0*(1-u)+s1*(u);
		}
	} else if (dlen>slen) {
		let s1,s0=src[sinc],j0=sinc;
		dst[dinc]=s0;
		for (let i=dinc-1;i>=0;i--) {
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0>j) {j0=j;s1=s0;s0=src[j0];}
			dst[i]=s0*(1-u)+s1*u;
		}
	} else if (!Object.is(dst,src)) {
		for (let i=0;i<dlen;i++) {dst[i]=src[i];}
	}
}


function dct1(arr,start,len) {
	// Computes the discrete cosine transform. Converts an array into a sum of
	// cosines.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("dct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Swap array elements to reproduce
	// the recursion of the standard FFT algorithm.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	Audio._dctresize(imag,arr);
	for (let i=0;i<nlen;i++) {
		let rev=0,j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		for (let b=0;b<bits;b++) {rev+=rev+((j>>>b)&1);}
		// real[i]=rev<len?arr[rev]:0;
		real[i]=imag[rev];
		// real[i]=arr[rev<len?rev:rev-nlen+len];
	}
	for (let i=0;i<nlen;i++) {imag[i]=0;}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert FFT output to DCT and scale it.
	real[0]/=nlen;
	let inc=Math.PI/(2*nlen),ang=0,norm=2/nlen;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	return real;
	/*real[0]/=len;
	let inc=Math.PI/(2*len),ang=0,norm=2/len;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	let ret=new Array(len);
	for (let i=0;i<len;i++) {
		ret[i]=real[i];
	}
	//return real;
	return ret;*/
}


function idct1(arr,start,len) {
	// Inverse discrete cosine transform. Converts coefficients of cosines into the
	// original array.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("idct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Undo the final rotation of the
	// DCT and swap the array elements to reproduce recursion.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	let inc=Math.PI/(2*len);
	for (let i=0;i<nlen;i++) {
		let rev=0;
		for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
		let val=rev<len?arr[start+rev]:0,ang=rev*inc;
		real[i]=val*Math.cos(ang);
		imag[i]=val*Math.sin(ang);
	}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert undo initial DCT permutation.
	for (let i=0;i<len;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		let ang=i*Math.PI*2/len;
		let cs=Math.cos(ang),sn=Math.sin(ang);
		console.log((i&1)?-i:i,real[j],imag[j],imag[j]*sn);
	}
	for (let i=0;i<nlen;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		imag[i]=real[j];
	}
	return imag;
}


//---------------------------------------------------------------------------------
// Delay Filter


function DelayFilterTest() {
	// To keep error under 1%, sound frequency needs to be 16x wave frequency.
	// Ex: sound at 44100 hz = sin(2774 hz) or slower.
	console.log("testing delay filter 1");
	let sndfreq=44100;
	for (let wavfreq=1;wavfreq<=sndfreq;wavfreq<<=1) {
		let sumerr=0;
		let sumden=0;
		let freqmul=Math.PI*2*wavfreq;
		for (let i=0;i<=100;i++) {
			let dt=i/1000;
			let del=new Audio.Delay(sndfreq,dt);
			for (let j=0;j<sndfreq*2;j++) {
				let t=j/sndfreq;
				del.add(Math.sin(t*freqmul));
				if (t>=dt) {
					let err=Math.sin((t-dt)*freqmul)-del.get();
					sumerr+=err*err;
					sumden+=1.0;
				}
			}
		}
		sumerr=Math.sqrt(sumerr/sumden);
		console.log(wavfreq,sumerr);
	}
	console.log("passed");
}
// DelayFilterTest();


//---------------------------------------------------------------------------------
// Scaling


function ScalingTest() {
	// Scale a sine waveform and compare it with the sin() function.
	console.log("testing sound scaling");
	for (let trials=0;trials<100;trials++) {
		let sndfreq=44100;
		let freq=Math.random()*200+100;
		let oldlen=Math.ceil(Math.random()*100000+1);
		let newlen=Math.ceil(Math.random()*100000+1);
		let snd=new Audio.Sound(sndfreq,oldlen);
		let data=snd.data;
		let mul=Math.PI*2*freq/sndfreq;
		for (let i=0;i<oldlen;i++) {data[i]=Math.sin(i*mul);}
		// snd.savefile("test1.wav");
		snd.scalelen(newlen);
		// snd.savefile("test2.wav");
		data=snd.data;
		mul=(oldlen/newlen)*Math.PI*2*freq/sndfreq;
		let err=0;
		for (let i=0;i<newlen;i++) {
			let x0=data[i];
			let x1=Math.sin(i*mul);
			let dif=Math.abs(x0-x1);
			err+=dif*dif;
		}
		console.log(String(oldlen).padStart(6," ")+" "+String(newlen).padStart(6," ")+" "+Math.sqrt(err/newlen).toFixed(8));
	}
	console.log("passed");
}
// ScalingTest();


//---------------------------------------------------------------------------------
// Envelopes


function EnvelopeTest() {
	let sndfreq=44100;
	let sndtime=2.0;
	let sndlen=Math.ceil(sndfreq*sndtime);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let data=snd.data;
	let env=new Audio.Envelope();
	env.add("con",0.1, 0.0);
	env.add("con",0.1,-0.5);
	env.add("lin",0.6, 1.0);
	env.add("lin",0.1,-0.9);
	env.add("exp",0.5, 0.5);
	env.add("exp",0.4,-0.9);
	for (let i=0;i<sndlen;i++) {
		let t=i/sndfreq;
		data[i]=env.get(t);
	}
	snd.savefile("envelope.wav");
}


//---------------------------------------------------------------------------------
// Expression Parser


function RPNPrint(oparr,ops,data) {
	let str="";
	for (let o=0;o<ops;o++) {
		let tmp=oparr[o],op=tmp>>>24,src=tmp&0xffffff;
		if (src) {str+=data[src].toFixed(6)+" ";}
		if (op) {str+=" ~+-*%/^<>"[op]+" ";}
	}
	return str;
}


function RPNEval1(oparr,ops,data,stack) {
	let s=0;
	for (let o=0;o<ops;o++) {
		let tmp=oparr[o],op=tmp>>>24,src=tmp&0xffffff;
		if (src<0 || src>=data.length) {throw "bad src "+src;}
		if (src) {stack[s++]=data[src];}
		if (op===1) {
			if (!s) {throw "neg 0 stack";}
			stack[s-1]=-stack[s-1];
		} else if (op>1) {
			if (s<2) {throw "op stack size "+s;}
			s-=2;
			let a=stack[s],b=stack[s+1];
			switch (op) {
				case 0: throw "c0";
				case 1: throw "c1";
				case 2: a+=b;break;
				case 3: a-=b;break;
				case 4: a*=b;break;
				case 5: a%=b;break;
				case 6: a/=b;break;
				case 7: a=Math.pow(a,b);break;
				case 8: a=a<b?a:b;break;
				case 9: a=a>b?a:b;break;
				default: throw "def";
			}
			stack[s++]=a;
		} else if (op) {
			throw "bad op "+op;
		}
	}
	return stack[0];
}


function RPNEval2(oparr,ops,data,stack) {
	// Process the expression. Memory IO is expensive so try to minimize it.
	let s=0;
	// let oparr=[];
	// let stack=[];
	// The first element will always be [x] or ~[x].
	let tmp=oparr[0];
	let val=data[tmp&0xffffff];
	if (tmp>>>24) {val=-val;}
	for (let o=1;o<ops;o++) {
		tmp=oparr[o];let op=tmp>>>24,src=tmp&0xffffff;
		let x=src?data[src]:val;
		if (src) {if (op<2) {stack[s++]=val;}}
		else if (op>1) {val=stack[--s];}
		switch (op) {
			case 0: val= x;break;
			case 1: val=-x;break;
			case 2: val+=x;break;
			case 3: val-=x;break;
			case 4: val*=x;break;
			case 5: val%=x;break;
			case 6: val/=x;break;
			case 7: val=Math.pow(val,x);break;
			case 8: val=val<x?val:x;break;
			case 9: val=val>x?val:x;break;
		}
	}
	return val;
}


function RPNEval3(oparr,ops,data,stack) {
	// Process the expression. Memory IO is expensive so try to minimize it.
	let s=0;
	// let oparr=[];
	// let stack=[];
	// The first element will always be [x] or ~[x].
	let tmp=oparr[0];
	let val=data[tmp&0xffffff];
	if (tmp>>>24) {val=-val;}
	for (let o=1;o<ops;o++) {
		tmp=oparr[o];let op=tmp>>>24,src=tmp&0xffffff;
		let x=val;
		if (src) {x=data[src];if (op<2) {stack[s++]=val;}}
		else if (op>1) {val=stack[--s];}
		switch (op) {
			case 0: val= x;break;
			case 1: val=-x;break;
			case 2: val+=x;break;
			case 3: val-=x;break;
			case 4: val*=x;break;
			case 5: val%=x;break;
			case 6: val/=x;break;
			case 7: val=Math.pow(val,x);break;
			case 8: val=val<x?val:x;break;
			case 9: val=val>x?val:x;break;
		}
	}
	return val;
}


function RPNEvalTest() {
	console.log("testing RPN evaluation");
	let opsmax=16;
	let datamax=8;
	let oparr=new Int32Array(opsmax*2);
	let data=new Float32Array(datamax);
	let stack=new Float64Array(opsmax*2);
	data[0]=NaN;
	let rnd=new Random();
	function flteq(a,b) {
		let na=isNaN(a),nb=isNaN(b);
		if (na || nb) {return na===nb;}
		if (Math.abs(a)>=Infinity) {return a===b;}
		return Math.abs(a-b)<=1e-10;
	}
	for (let trial=0;trial<10000;trial++) {
		let ops=rnd.modu32(opsmax)+1;
		let h=0,half=ops>>>1;
		for (let i=1;i<datamax;i++) {data[i]=rnd.getf()*10-5;}
		for (let o=0;o<ops;o++) {
			let type,src,tmp;
			do {
				tmp=rnd.getu32();
				if (tmp&0x80000000) {type=0;}
				else {type=((tmp&255)%9)+1;}
				if (tmp&0x40000000) {src=0;}
				else {src=(((tmp>>>8)&255)%(datamax-1))+1;}
				tmp=h+(src>0)-(type>1);
			} while (tmp<=0);
			h=tmp;
			oparr[o]=(type<<24)|src;
		}
		while (h-->1) {oparr[ops++]=(rnd.modu32(8)+2)<<24;}
		let val1=RPNEval1(oparr,ops,data,stack);
		let val2=RPNEval2(oparr,ops,data,stack);
		let val3=RPNEval3(oparr,ops,data,stack);
		if (!(trial&255)) {
			console.log(RPNPrint(oparr,ops,data)+"= ",val1,val2,val3);
		}
		if (!flteq(val1,val2) || !flteq(val1,val3)) {
			console.log(RPNPrint(oparr,ops,data));
			console.log(val1);
			console.log(val2);
			console.log(val3);
			throw "mismatch";
		}
	}
}


function RPNSpeedTest() {
	console.log("testing RPN speed");
	let rnd=new Random();
	let opsmax=256;
	let datamax=20;
	let sets=256;
	let opset=new Array(sets);
	let dataset=new Array(sets);
	for (let s=0;s<sets;s++) {
		let oparr=new Int32Array(opsmax*2);
		let data=new Float32Array(datamax);
		data[0]=NaN;
		let ops=rnd.modu32(opsmax)+1;
		let h=0,half=ops>>>1;
		for (let i=1;i<datamax;i++) {data[i]=rnd.getf()*10-5;}
		for (let o=0;o<ops;o++) {
			let type,src,tmp;
			do {
				tmp=rnd.getu32();
				if (tmp&0x80000000) {type=0;}
				else {type=((tmp&255)%9)+1;}
				if (tmp&0x40000000) {src=0;}
				else {src=(((tmp>>>8)&255)%(datamax-1))+1;}
				tmp=h+(src>0)-(type>1);
			} while (tmp<=0);
			h=tmp;
			oparr[o]=(type<<24)|src;
		}
		while (h-->1) {oparr[ops++]=(rnd.modu32(8)+2)<<24;}
		opset[s]=oparr.slice(0,ops);
		dataset[s]=data;
	}
	let stack=new Float64Array(opsmax*2);
	let trials=1000000;
	// Base
	let t0=performance.now();
	let val1=0;
	for (let trial=0;trial<trials;trial++) {
		let s=trial%sets,oparr=opset[s],data=dataset[s];
		val1+=RPNEval1(oparr,oparr.length,data,stack);
	}
	// Temp var 1
	let t1=performance.now();
	let val2=0;
	for (let trial=0;trial<trials;trial++) {
		let s=trial%sets,oparr=opset[s],data=dataset[s];
		val2+=RPNEval2(oparr,oparr.length,data,stack);
	}
	// Temp var 2
	let t2=performance.now();
	let val3=0;
	for (let trial=0;trial<trials;trial++) {
		let s=trial%sets,oparr=opset[s],data=dataset[s];
		val3+=RPNEval3(oparr,oparr.length,data,stack);
	}
	let t3=performance.now();
	t3-=t2;
	t2-=t1;
	t1-=t0;
	console.log("time 1:",t1);
	console.log("time 2:",t2);
	console.log("time 3:",t3);
}


//---------------------------------------------------------------------------------
// Sound Effects


function SFXStateStr(sfx) {
	const TBL=2,NOI=8,DEL=9;
	const VBITS=24,VMASK=(1<<VBITS)-1;
	let di32=sfx.di32;
	let df32=sfx.df32;
	let end=di32.length;
	let namemap=sfx.namemap;
	let addrmap=new Array(end+1);
	let valstr=new Array(end+1);
	let oparr=["NOP","~","+","-","*","%","/","^","<",">"];
	let typearr=["expr","asr","tri","saw","sqr","pulse","sin","osc","noise",
	             "del","lpf","hpf","bpf","npf","apf","pkf","lsf","hsf"];
	for (let [k,v] of Object.entries(namemap)) {
		if (v<0 || v>=end) {throw "namemap OOB";}
		addrmap[v]=k;
	}
	addrmap[end]="end";
	valstr[end]="end";
	for (let i=0;i<end;i++) {
		valstr[i]=di32[i].toString();
	}
	// First pass to resolve address names and values.
	let n=0;
	while (n<end) {
		let name=addrmap[n]+".";
		let next=di32[n];
		let istop=di32[n+1];
		addrmap[n+1]=name+"in_stop";
		n+=2;
		let srcid=0;
		while (n<istop) {
			addrmap[n]=name+"src_"+srcid;
			let sstop=di32[n++];
			let iid=0;
			while (n<sstop) {
				addrmap[n]=name+"src_"+srcid+"_"+iid;
				let od=di32[n];
				let dst=(od&VMASK)>>>0;
				valstr[n]="["+oparr[od>>>VBITS]+","+dst+"]";
				n++;
				if (dst===n) {
					addrmap[n]=name+"con_"+srcid+"_"+iid;
					valstr[n]=df32[n].toFixed(6);
					n++;
				}
				iid++;
			}
			addrmap[n++]=name+"dst_"+srcid;
			srcid++;
		}
		let type=di32[n];
		valstr[n]=typearr[type];
		n++;
		for (let p=0;n<next;n++,p++) {
			if ((type===NOI && p>2) || (type===DEL && p>3 && p<5)) {}
			else {valstr[n]=df32[n].toFixed(6);}
			if (!addrmap[n]) {
				addrmap[n]=name+"data"+p;
			}
		}
	}
	// Final output
	let orig=sfx.orig;
	let addrpad=Math.max(4,(end-1).toString().length);
	let namepad=0,valpad=0;
	for (let n of addrmap) {namepad=Math.max(namepad,n.length);}
	for (let n of valstr ) {valpad =Math.max(valpad ,n.length);}
	let out="  Addr  |    Data    |  *  |  Description\n"+
	        "--------+------------+-----+--------------------------\n";
	let parsed=0;
	function addline(addr,msg) {
		parsed++;
		out+=addr.toString().padStart(addrpad+2)+"  |  "+
		     (di32[addr]>>>0).toString(16).padStart(8,"0")+"  |  "+
		     (orig[addr]!==di32[addr]?"*":" ")+"  |  "+
		     addrmap[addr].padEnd(namepad)+"  =  "+valstr[addr].padEnd(valpad)+
		     (msg?"  ->  "+msg:"")+"\n";
	}
	n=0;
	while (n<end) {
		let next=di32[n];
		addline(n,addrmap[next]);
		let istop=di32[n+1];
		addline(n+1,addrmap[istop]);
		n+=2;
		while (n<istop) {
			let sstop=di32[n++];
			addline(n-1,addrmap[sstop]);
			while (n<sstop) {
				let od=di32[n];
				let dst=(od&VMASK)>>>0;
				addline(n,addrmap[dst]);
				n++;
				if (dst===n) {
					addline(n);
					n++;
				}
			}
			let dst=di32[n];
			addline(n,addrmap[dst]);
			n++;
		}
		while (n<next) {addline(n++);}
	}
	if (parsed!==di32.length) {
		throw "missing data: "+parsed+" / "+di32.length;
	}
	return out;
}


function SFXTestRun() {
	/*let sfx=new Audio.SFX("#out: sin f 113 h 2");
	let freq=44100;
	let trials=100000;
	let maxdif=-Infinity;
	let sumdif=0;
	for (let i=0;i<trials;i++) {
		let t=i/freq;
		let exp=Math.sin(t*113*Math.PI*2)*2;
		let calc=sfx.next();
		let dif=Math.abs(exp-calc);
		sumdif+=dif;
		if (maxdif<dif || isNaN(dif)) {
			maxdif=dif;
		}
	}
	console.log("dif: "+maxdif.toFixed(8)+", "+sumdif.toFixed(8));*/
	// dif: 0.01312171, 417.74517281
	// Table
	/*let sintbl=[],points=32;
	for (let i=0;i<points;i++) {let x=i/(points-1);sintbl.push(x,Math.sin(x*Math.PI*2));}
	let sfx=new Audio.SFX("#out: tbl f 113 h 2 t "+sintbl.map((x)=>x.toFixed(8)).join(" "));
	let freq=44100;
	let trials=100000;
	let maxdif=-Infinity;
	let sumdif=0;
	let t=performance.now();
	for (let i=0;i<trials;i++) {
		let t=i/freq;
		let exp=Math.sin(t*113*Math.PI*2)*2;
		let calc=sfx.next();
		let dif=Math.abs(exp-calc);
		sumdif+=dif;
		if (maxdif<dif || isNaN(dif)) {
			maxdif=dif;
		}
	}
	console.log("time: ",performance.now()-t);
	console.log("dif : "+maxdif.toFixed(8)+", "+sumdif.toFixed(8));*/
	//  16 dif: 0.04558976, 1937.79614964
	//  32 dif: 0.01662166, 645.05231497
	//  64 dif: 0.01333448, 441.97985743
	// 256 dif: 0.01312228, 417.92087308
	// Noise
	/*let sfx=new Audio.SFX("noise");
	let trials=100;
	for (let i=0;i<trials;i++) {
		let v=sfx.next();
		console.log(v);
	}*/
	// Delay
	let sndfreq=44100,freq=113,delay=0.001;
	let sfx=new Audio.SFX("#osc: sin "+freq+" #out: del t "+delay+" i #osc");
	let trials=100000;
	let maxdif=-Infinity;
	let sumdif=0;
	let t0=performance.now();
	for (let i=0;i<trials;i++) {
		let t=i/sndfreq;
		let calc=sfx.next();
		if (t>=delay) {
			let exp=Math.sin((t-delay)*freq*Math.PI*2);
			// console.log(exp,calc);
			let dif=Math.abs(exp-calc);
			sumdif+=dif;
			if (maxdif<dif || isNaN(dif)) {
				maxdif=dif;
			}
		}
	}
	console.log("time:",((performance.now()-t0)/1000).toFixed(6));
	console.log("dif: "+maxdif.toFixed(8)+", "+sumdif.toFixed(8));
	// Biquad Filter
	/*let sfx=new Audio.SFX("#osc: noise #out: hpf f 200 i #osc");
	let trials=100;
	for (let i=0;i<trials;i++) {
		let v=sfx.next();
		console.log(v);
	}*/
	console.log(SFXStateStr(sfx));
}


function BinarySearch(arr,l,h,x) {
	h-=2;
	while (l<h) {
		let m=l+(((h-l+2)>>>2)<<1);
		if (arr[m]>x) {h=m-2;} else {l=m;}
	}
	if (l!==h) {throw "l!==h: "+l+", "+h;}
	return l;
}


function SFXBinarySearchTest() {
	console.log("testing binary search");
	let rnd=new Random();
	let maxlen=64;
	let arr=new Float32Array(maxlen*2);
	for (let trial=0;trial<10000;trial++) {
		let off=rnd.modu32(4);
		let len=(rnd.modu32(64-off)+1)*2;
		let p0=off,p1=off+len;
		let x=0;
		for (let i=0;i<len;i+=2) {
			let y=rnd.getf()*10-5;
			arr[off+i+0]=x;
			arr[off+i+1]=y;
			x+=rnd.modu32(4)?rnd.getf():0;
		}
		let mul=(arr[p1-2]-arr[p0])*1.5;
		let min=arr[p0]-mul*0.1;
		for (let i=0;i<len+1000;i++) {
			let f=i<len?arr[p0+i]:(rnd.getf()*mul+min);
			let exp=p0;
			while (exp+2<p1 && arr[exp+2]<=f) {exp+=2;}
			let calc=BinarySearch(arr,p0,p1,f);
			if (calc!==exp) {
				console.log("find: ",f);
				console.log("exp : ",exp ,(arr[exp ]??-Infinity),(arr[exp +2]??Infinity));
				console.log("calc: ",calc,(arr[calc]??-Infinity),(arr[calc+2]??Infinity));
				throw "error";
			}
		}
	}
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	// RPNEvalTest();
	// RPNSpeedTest();
	// SFXTestRun();
	// SFXBinarySearchTest();
	console.log("done");
}
// TestMain();

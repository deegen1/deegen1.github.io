/* jshint esversion: 11  */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */


//---------------------------------------------------------------------------------
// Misc Sounds


function MeasureVolume(snd) {
	let data=snd.data;
	let len=snd.len;
	let eps=1e-3;
	let sum0=0,max0=0,den0=0;
	let sum1=0,max1=0,den1=0;
	let prev=0;
	for (let i=0;i<len;i++) {
		let x=data[i];
		let y=Math.abs(x);
		if (y>eps) {sum0+=y;den0++;}
		if (max0<y) {max0=y;}
		y=Math.abs(x-prev);
		prev=x;
		if (y>eps) {sum1+=y;den1++;}
		if (max1<y) {max1=y;}
	}
	sum0/=den0;
	// sum1=Math.sqrt(sum1/den1);
	console.log("abs avg: "+sum0.toFixed(6)+", abs max: "+max0.toFixed(6)+", rel avg: "+sum1.toFixed(6)+", rel max: "+max1.toFixed(6));
	return snd;
}
/*Audio.prototype.play=function(snd,volume,pan,freq) {
	MeasureVolume(snd);
	return new _AudioInstance(snd,volume,pan,freq);
};*/


function PlayPhoneDial1() {
	let freq=44100,len=freq*2;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=Audio.sin(t*350)+Audio.sin(t*440);
		data[i]+=note;
	}
	snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayPhoneRing1() {
	let freq=44100,len=freq*2;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=Audio.sin(t*440)+Audio.sin(t*480);
		data[i]+=note;
	}
	snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayAlarm2() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let data=snd.data;
	let lp7=new Audio.Biquad("lowpass",70/freq);
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let n0 =(Audio.sqr(t)+1)*0.5;
		let n1 =lp7.process(n0);
		let n20=Audio.sin(t*600)*(1-n1);
		let n21=Audio.sin(t*800)*n1;
		data[i]+=(n20+n21)*0.2;
	}
	// snd.scale(0.2/snd.getvolume());
	snd.play();
}


function PlayHiHat2() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let rate=40;
	let ratio=[2,3,4.16,5.43,6.79,8.21];
	let ratios=ratio.length;
	let bp=new Audio.Biquad("bandpass",10000/freq);
	let hp=new Audio.Biquad("highpass",7000/freq);
	let voldecay=Math.log(1e-4)/0.3;
	let data=snd.data;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		let note=0;
		for (let j=0;j<ratios;j++) {
			note+=Audio.sqr(t*rate*ratio[j]);
		}
		note=bp.process(note);
		note=hp.process(note);
		let mul=Math.exp(voldecay*t);
		data[i]+=Audio.clip(note,-1,1)*mul;
	}
	// snd.scale(1/snd.getvolume());
	snd.play();
}

/*
static createelectricity(freq=99.8,volume=0.5,time=5.5) {
	// Pitch should increase slightly with force.
	let sndfreq=44100,len=Math.ceil(time*sndfreq);
	let tail=(time-0.01)*sndfreq,tailden=1/(len-1-tail);
	let snd=new Audio.Sound(sndfreq,len);
	let data=snd.data;
	let freq0=freq/sndfreq,freq1=freq0*1.004;
	let lp1=new Audio.Biquad("lowpass",2/sndfreq);
	let lp2=new Audio.Biquad("lowpass",2/sndfreq);
	let lp3=new Audio.Biquad("lowpass",3000/sndfreq);
	let del=new Audio.Delay(sndfreq,0.1);
	for (let i=0;i<len;i++) {
		let x0=Audio.saw1(i*freq0)+Audio.saw1(i*freq1);
		x0=Audio.clip(x0-1,-0.5,0.5);
		let x1=Audio.noise(i);
		x1=lp1.process(x1);
		x1=lp2.process(x1);
		x1=x1*x1;
		x0*=x1*1000;
		x0=lp3.process(x0);
		del.add(x0);
		let y=del.get(x1*4+0.02);
		if (i>=tail) {y*=(len-1-i)*tailden;}
		data[i]=y;
	}
	snd.scale(volume/(snd.getvolume()+1e-10));
	return snd;
}
*/

function PlayMaraca() {
	let freq=44100,len=freq*3;
	let snd=new Audio.Sound(freq,len);
	let beadlen=Math.floor(0.02*freq),beadfreq=5000,beaddec=Math.log(1e-5)/0.02;
	let beadsnd=new Array(beadlen);
	for (let i=0;i<beadlen;i++) {
		let t=i/freq;
		beadsnd[i]=Math.sin(t*beadfreq*Math.PI*2)*Math.exp(t*beaddec);
	}
	let data=snd.data;
	let volmul=Math.log(1e-4)/5;
	let next=Math.random()*0.04;
	for (let i=0;i<len;i++) {
		let t=i/freq;
		if (t>=next) {
			let mul=Math.exp(t*volmul);
			next=t+Math.random()*0.03*t;
			for (let j=0;j<beadlen;j++) {
				data[i+j]+=beadsnd[j]*mul;
			}
		}
	}
	snd.scalevol(1,true);
	snd.play();
}


function PlayStringPhysical() {
	// Physically based string modelling.
	let freq=44100,sndtime=3,sndlen=Math.floor(freq*sndtime);
	let snd=new Audio.Sound(freq,sndlen);
	let samples=100;
	let pluckheight=1.0,pluckpos=0.5;
	let stringpos=new Float64Array(samples);
	let stringvel=new Float64Array(samples);
	for (let i=0;i<samples;i++) {
		let u=i/(samples-1);
		let v=u<pluckpos?u/pluckpos:(1-u)/(1-pluckpos);
		stringpos[i]=v*pluckheight;
		stringvel[i]=0;
	}
	let data=snd.data;
	let dt0=400*(1/freq);
	let dt1=400*(1/freq);
	let decay=0.9999;
	let listen=Math.floor(samples*0.5);
	let bp=new Audio.Biquad("bandpass",400/freq,1);
	for (let i=0;i<sndlen;i++) {
		let t=i/freq;
		for (let s=1;s<samples-1;s++) {
			stringvel[s]+=dt0*2.0*(stringpos[s-1]+stringpos[s+1]-2*stringpos[s]);
		}
		for (let s=1;s<samples-1;s++) {
			// stringpos[s]+=dt*stringvel[s];
			let vel=stringvel[s];
			stringpos[s]+=vel*dt1;
			stringvel[s] =vel*decay;
		}
		data[i]=bp.process(stringpos[listen]);
	}
	snd.scalevol(1,true);
	// snd.savefile("wve.wav");
	snd.play();
}


function PlayComb() {
	let sndfreq=44100,sndtime=3,sndlen=Math.floor(sndfreq*sndtime);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let del=new Audio.Delay(sndfreq,0.2);
	let fil=new Audio.Biquad("highpass",200/sndfreq);
	let fb=0.95;
	for (let i=0;i<del.len;i++) {
		let u=i/del.len;
		del.data[i]=Math.abs(u-0.5)*2;
		del.data[i]=Audio.noise(i)*1.0;
	}
	for (let i=0;i<del.len*4;i++) {
		let n0=del.get();
		n0=fil.process(n0);
		del.add(n0);
	}
	fil.clear();
	let data=snd.data;
	for (let i=0;i<sndlen;i++) {
		let n0=del.get();
		data[i]=n0;
		n0=n0*fb;
		del.add(n0);
	}
	snd.scalevol(1,true);
	// snd.savefile("wve.wav");
	snd.play();
}


//---------------------------------------------------------------------------------
// Guitar


function generatestringtri(volume=1,freq=200,pos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2,sndfreq=44100) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let listen=pos;// 0.16;
	let c0=listen*Math.PI;
	let c1=(2*volume)/(Math.PI*Math.PI*pos*(1-pos));
	let c2=inharm; // *inharm;
	let c3=freq;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	let ramp=Math.floor(0.01*sndfreq);
	let rampmul=1/ramp;
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		let ramplen=ramp<harmlen?ramp:harmlen;
		let bp=new Audio.Biquad("bandpass",harmfreq,2);
		for (let i=0;i<ramplen;i++) {
			snddata[i]+=harmmul*bp.process(Audio.tri(harmphase))*i*rampmul;
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
		for (let i=ramplen;i<harmlen;i++) {
			snddata[i]+=harmmul*bp.process(Audio.tri(harmphase));
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function generatestringwave(volume=1,freq=200,pluckpos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2,sndfreq=44100) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let listen=pluckpos;// 0.16;
	let c0=listen*Math.PI;
	let c1=(2*1)/(Math.PI*Math.PI*pluckpos*(1-pluckpos));
	let c2=inharm; // *inharm;
	let c3=freq;// *2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pluckpos<0.0001 || pluckpos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	let excite=new Float32Array(sndlen);
	let wavelen=Math.round(0.5*sndfreq/freq),wavepos=0;
	let wave=new Float64Array(wavelen);
	let wavemul=-0.995;
	for (let i=0;i<wavelen;i++) {
		let u=i/(wavelen-1);
		let v=u<pluckpos?u/pluckpos:(1-u)/(1-pluckpos);
		// let v=u<0.5?1:0;
		wave[i]=v;
	}
	for (let i=0;i<sndlen;i++) {
		let j=i%wavelen;
		let l=(i+75)%wavelen;
		excite[i]=wave[l];
		wave[j]*=wavemul;
	}
	// Process highest to lowest for floating point accuracy.
	let ramp=Math.floor(0.01*sndfreq);
	let rampmul=1/ramp;
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		// let harmphase=0;
		let harmdecay=Math.exp(dscale);
		let ramplen=ramp<harmlen?ramp:harmlen;
		let filter=new Audio.Biquad("bandpass",harmfreq,1);
		for (let i=0;i<ramplen;i++) {
			snddata[i]+=harmmul*filter.process(wave[i])*i*rampmul;
			harmmul*=harmdecay;
			// harmphase+=harmfreq;
		}
		for (let i=ramplen;i<harmlen;i++) {
			snddata[i]+=harmmul*filter.process(wave[i]);
			harmmul*=harmdecay;
			// harmphase+=harmfreq;
		}
	}
	snd.scalevol(volume,true);
	// snd.savefile("wve.wav");
	// snd.play();
	return snd;
}


function Trippy80sGuitar(sndfreq,freq=200,volume=1,pos=0.5,inharm=0.008,harmexp=1.0,decay=1.7) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let c0=pos*Math.PI;
	let c1=(2*volume)/(Math.PI*c0*(1-pos));
	let c2=inharm*inharm;
	let c3=freq*2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		harmmul*=5;
		let filter=new Audio.Biquad("bandpass",harmfreq,50/1000);
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*filter.process(Audio.noise(i));
			// snddata[i]+=harmmul*filter.process(Audio.noise(i*0.05));//Math.sin(harmphase);
			// snddata[i]+=harmmul*filter.process(Audio.sqr(harmphase));//Math.sin(harmphase);
			// snddata[i]+=Audio.clip(Math.tanh(Math.sin(harmphase)),-harmmul,harmmul);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function createstring1(sndfreq,freq,volume,pluck,inharm,decay) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	if (freq===undefined) {freq=220;}
	if (pluck===undefined) {pluck=0.3;}
	pluck=pluck>0?pluck:0;
	pluck=pluck<1?pluck:1;
	if (volume===undefined) {volume=1;}
	// let inharm=0.008;  // inharmonicity factor
	// let decay=1.7;
	// let sndfreq=44100;
	// Generate coefficients.
	let c0=inharm*inharm;
	let c1=pluck*Math.PI;
	let c2=(2*volume)/(Math.PI*c1*(1-pluck));
	let c3=freq*2*Math.PI;
	let coefs=Math.floor(sndfreq/(2*freq));
	let freqcoef=new Array(coefs);
	let sincoef =new Array(coefs);
	let sumcoef =0;
	for (let i=0;i<coefs;i++) {
		let n=i+1,n2=n*n;
		freqcoef[i]=n*c3*Math.sqrt(1+n2*c0);
		sincoef[i]=Math.sin(n*c1)*c2/n2;
		sumcoef+=Math.abs(sincoef[i]);
	}
	// Generate the waveform.
	// Stop when sumcoef*e^(-decay*time/sndfreq)<=1e-4
	let stop=Math.floor(-Math.log(1e-4/sumcoef)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,stop);
	let data=snd.data;
	let time=0.0,timeinc=1/sndfreq;
	// let decay0=1.0,decay1=Math.exp(-decay*timeinc);
	for (let i=0;i<stop;i++) {
		let mul=1,sum=0;
		for (let c=0;c<coefs;c++) {
			// mul*=decay0;
			// sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
			mul=Math.exp(-decay*(c+1)*time);
			sum+=mul*sincoef[c]*Math.sin(freqcoef[c]*time);
		}
		data[i]+=sum;
		time+=timeinc;
		// decay0*=decay1;
	}
	return snd;
}


function createstring2(sndfreq,freq,volume,pos,inharm,decay) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	if (freq===undefined) {freq=220;}
	if (pos===undefined) {pos=0.3;}
	pos=pos>0?pos:0;
	pos=pos<1?pos:1;
	if (volume===undefined) {volume=1;}
	const cutoff=1e-4;
	// let inharm=0.008;  // inharmonicity factor
	// let decay=1.7;
	// let sndfreq=44100;
	// Generate coefficients.
	let c0=inharm*inharm;
	let c1=pos*Math.PI;
	let c2=(2*volume)/(Math.PI*c1*(1-pos));
	let c3=freq*2*Math.PI;
	let coefs=Math.floor(sndfreq/(2*freq));
	// Stop when e^(-decay*time/sndfreq)<=1e-4
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	for (let c=coefs-1;c>=0;c--) {
		// Calculate coefficients for the n'th harmonic.
		let n=c+1,n2=n*n;
		let harmmul=Math.sin(n*c1)*c2/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		let harmlen=Math.ceil(-Math.log(cutoff/Math.abs(harmmul))*sndfreq/decay);
		if (harmlen>sndlen) {harmlen=sndlen;}
		let harmfreq=n*c3*Math.sqrt(1+n2*c0)/sndfreq;
		let harmfreq0=n*c3*Math.sqrt(1+n2*c0);
		let harmmul0=harmmul;
		// Generate the waveform.
		let harmphase=0,harmdecay=Math.exp(-decay*n/sndfreq);
		/*for (let i=0;i<harmlen;i++) {
			let time0=i/sndfreq;
			let mul0=Math.exp(-decay*(c+1)*time0);
			let sum0=mul0*harmmul0*Math.sin(harmfreq0*time0);
			snddata[i]+=sum0;
			if (Math.abs(harmphase-harmfreq0*time0)>1e-5) {
				console.log(harmphase,harmfreq0*time0);
				throw "x";
			}
			if (Math.abs(harmmul-mul0*harmmul0)>1e-5) {
				console.log(harmmul,mul0*harmmul0);
				throw "y";
			}
			let sum1=harmmul*Math.sin(harmphase);
			if (Math.abs(sum1-sum0)>1e-5) {
				console.log(sum1,sum0);
				throw "z";
			}
			harmmul*=harmdecay;
			harmphase+=harmfreq;
			//snddata[i]+=harmmul*Math.sin(harmphase);
		}*/
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*Math.sin(harmphase);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


function createstring1(sndfreq,freq=200,volume=1,pos=0.5,inharm=0.00006,harmexp=1.0,decay=1.2) {
	// Jason Pelc
	// http://large.stanford.edu/courses/2007/ph210/pelc2/
	// Stop when e^(-decay*time/sndfreq)<=cutoff
	const cutoff=1e-4;
	let harmonics=Math.ceil(sndfreq/(2*freq));
	let sndlen=Math.ceil(-Math.log(cutoff)*sndfreq/decay);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let snddata=snd.data;
	// Generate coefficients.
	let c0=pos*Math.PI;
	let c1=(2*volume)/(Math.PI*c0*(1-pos));
	let c2=inharm; // *inharm;
	let c3=freq*2*Math.PI;
	// Close to 0, sin(x)/x = 1.
	if (pos<0.0001 || pos>0.9999) {
		harmonics=1;
		c0=Math.PI*0.5;
		c1=volume;
	}
	// Process highest to lowest for floating point accuracy.
	for (let n=harmonics;n>0;n--) {
		// Calculate coefficients for the n'th harmonic.
		let n2=n*n;
		let harmmul=Math.sin(n*c0)*c1/n2;
		if (Math.abs(harmmul)<=cutoff) {continue;}
		// Correct n2 by -1 so the fundamental = freq.
		// let harmfreq=n*c3*Math.sqrt(1+n2*c2)/sndfreq;
		let harmfreq=n*c3*Math.sqrt(1+(n2-1)*c2)/sndfreq;
		let dscale=-decay*Math.pow(n,harmexp)/sndfreq;
		let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmmul))/dscale);
		if (harmlen>sndlen) {harmlen=sndlen;}
		// Generate the waveform.
		let harmphase=0;
		let harmdecay=Math.exp(dscale);
		for (let i=0;i<harmlen;i++) {
			snddata[i]+=harmmul*Math.sin(harmphase);
			harmmul*=harmdecay;
			harmphase+=harmfreq;
		}
	}
	return snd;
}


//---------------------------------------------------------------------------------
// Try stretching the input vector to a power of 2 to maintain frequencies and
// allow use of the FFT.


function _dctresize(dst,src) {
	let dlen=dst.length,dinc=dlen-1,drem=0;
	let slen=src.length,sinc=slen-1,srem=0;
	if (dlen<slen) {
		let s1=src[0],s0=s1,j0=0;
		dst[0]=s1;
		for (let i=1;i<dlen;i++) {
			// dst[i-1]+x=src[j]
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0<j) {j0=j;s0=src[j];s1=src[j+1];}
			dst[i]=(s1-s0)*(1-u+1e-10)/(u+1e-10)+s0;// s0*(u)+s1*(1-u);
			dst[i]=s0*(1-u)+s1*(u);
		}
	} else if (dlen>slen) {
		let s1,s0=src[sinc],j0=sinc;
		dst[dinc]=s0;
		for (let i=dinc-1;i>=0;i--) {
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0>j) {j0=j;s1=s0;s0=src[j0];}
			dst[i]=s0*(1-u)+s1*u;
		}
	} else if (!Object.is(dst,src)) {
		for (let i=0;i<dlen;i++) {dst[i]=src[i];}
	}
}


function dct1(arr,start,len) {
	// Computes the discrete cosine transform. Converts an array into a sum of
	// cosines.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("dct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Swap array elements to reproduce
	// the recursion of the standard FFT algorithm.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	Audio._dctresize(imag,arr);
	for (let i=0;i<nlen;i++) {
		let rev=0,j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		for (let b=0;b<bits;b++) {rev+=rev+((j>>>b)&1);}
		// real[i]=rev<len?arr[rev]:0;
		real[i]=imag[rev];
		// real[i]=arr[rev<len?rev:rev-nlen+len];
	}
	for (let i=0;i<nlen;i++) {imag[i]=0;}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert FFT output to DCT and scale it.
	real[0]/=nlen;
	let inc=Math.PI/(2*nlen),ang=0,norm=2/nlen;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	return real;
	/*real[0]/=len;
	let inc=Math.PI/(2*len),ang=0,norm=2/len;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	let ret=new Array(len);
	for (let i=0;i<len;i++) {
		ret[i]=real[i];
	}
	//return real;
	return ret;*/
}


function idct1(arr,start,len) {
	// Inverse discrete cosine transform. Converts coefficients of cosines into the
	// original array.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("idct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Undo the final rotation of the
	// DCT and swap the array elements to reproduce recursion.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	let inc=Math.PI/(2*len);
	for (let i=0;i<nlen;i++) {
		let rev=0;
		for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
		let val=rev<len?arr[start+rev]:0,ang=rev*inc;
		real[i]=val*Math.cos(ang);
		imag[i]=val*Math.sin(ang);
	}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert undo initial DCT permutation.
	for (let i=0;i<len;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		let ang=i*Math.PI*2/len;
		let cs=Math.cos(ang),sn=Math.sin(ang);
		console.log((i&1)?-i:i,real[j],imag[j],imag[j]*sn);
	}
	for (let i=0;i<nlen;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		imag[i]=real[j];
	}
	return imag;
}


//---------------------------------------------------------------------------------
// Delay Filter


function DelayFilterTest() {
	// To keep error under 1%, sound frequency needs to be 16x wave frequency.
	// Ex: sound at 44100 hz = sin(2774 hz) or slower.
	console.log("testing delay filter 1");
	let sndfreq=44100;
	for (let wavfreq=1;wavfreq<=sndfreq;wavfreq<<=1) {
		let sumerr=0;
		let sumden=0;
		let freqmul=Math.PI*2*wavfreq;
		for (let i=0;i<=100;i++) {
			let dt=i/1000;
			let del=new Audio.Delay(sndfreq,dt);
			for (let j=0;j<sndfreq*2;j++) {
				let t=j/sndfreq;
				del.add(Math.sin(t*freqmul));
				if (t>=dt) {
					let err=Math.sin((t-dt)*freqmul)-del.get();
					sumerr+=err*err;
					sumden+=1.0;
				}
			}
		}
		sumerr=Math.sqrt(sumerr/sumden);
		console.log(wavfreq,sumerr);
	}
	console.log("passed");
}
// DelayFilterTest();


//---------------------------------------------------------------------------------
// Scaling


function ScalingTest() {
	// Scale a sine waveform and compare it with the sin() function.
	console.log("testing sound scaling");
	for (let trials=0;trials<100;trials++) {
		let sndfreq=44100;
		let freq=Math.random()*200+100;
		let oldlen=Math.ceil(Math.random()*100000+1);
		let newlen=Math.ceil(Math.random()*100000+1);
		let snd=new Audio.Sound(sndfreq,oldlen);
		let data=snd.data;
		let mul=Math.PI*2*freq/sndfreq;
		for (let i=0;i<oldlen;i++) {data[i]=Math.sin(i*mul);}
		// snd.savefile("test1.wav");
		snd.scalelen(newlen);
		// snd.savefile("test2.wav");
		data=snd.data;
		mul=(oldlen/newlen)*Math.PI*2*freq/sndfreq;
		let err=0;
		for (let i=0;i<newlen;i++) {
			let x0=data[i];
			let x1=Math.sin(i*mul);
			let dif=Math.abs(x0-x1);
			err+=dif*dif;
		}
		console.log(String(oldlen).padStart(6," ")+" "+String(newlen).padStart(6," ")+" "+Math.sqrt(err/newlen).toFixed(8));
	}
	console.log("passed");
}
// ScalingTest();


//---------------------------------------------------------------------------------
// Envelopes


function EnvelopeTest() {
	let sndfreq=44100;
	let sndtime=2.0;
	let sndlen=Math.ceil(sndfreq*sndtime);
	let snd=new Audio.Sound(sndfreq,sndlen);
	let data=snd.data;
	let env=new Audio.Envelope();
	env.add("con",0.1, 0.0);
	env.add("con",0.1,-0.5);
	env.add("lin",0.6, 1.0);
	env.add("lin",0.1,-0.9);
	env.add("exp",0.5, 0.5);
	env.add("exp",0.4,-0.9);
	for (let i=0;i<sndlen;i++) {
		let t=i/sndfreq;
		data[i]=env.get(t);
	}
	snd.savefile("envelope.wav");
}

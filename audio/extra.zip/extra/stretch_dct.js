/*

Try stretching the input vector to a power of 2 to maintain frequencies and
allow use of the FFT.

*/

static _dctresize(dst,src) {
	let dlen=dst.length,dinc=dlen-1,drem=0;
	let slen=src.length,sinc=slen-1,srem=0;
	if (dlen<slen) {
		let s1=src[0],s0=s1,j0=0;
		dst[0]=s1;
		for (let i=1;i<dlen;i++) {
			// dst[i-1]+x=src[j]
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0<j) {j0=j;s0=src[j];s1=src[j+1];}
			dst[i]=(s1-s0)*(1-u+1e-10)/(u+1e-10)+s0;// s0*(u)+s1*(1-u);
			dst[i]=s0*(1-u)+s1*(u);
		}
	} else if (dlen>slen) {
		let s1,s0=src[sinc],j0=sinc;
		dst[dinc]=s0;
		for (let i=dinc-1;i>=0;i--) {
			let u=(i/dinc)*sinc;
			// console.log(u);
			let j=Math.floor(u);
			u-=j;
			if (j0>j) {j0=j;s1=s0;s0=src[j0];}
			dst[i]=s0*(1-u)+s1*u;
		}
	} else if (!Object.is(dst,src)) {
		for (let i=0;i<dlen;i++) {dst[i]=src[i];}
	}
}


static dct1(arr,start,len) {
	// Computes the discrete cosine transform. Converts an array into a sum of
	// cosines.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("dct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Swap array elements to reproduce
	// the recursion of the standard FFT algorithm.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	Audio._dctresize(imag,arr);
	for (let i=0;i<nlen;i++) {
		let rev=0,j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		for (let b=0;b<bits;b++) {rev+=rev+((j>>>b)&1);}
		// real[i]=rev<len?arr[rev]:0;
		real[i]=imag[rev];
		// real[i]=arr[rev<len?rev:rev-nlen+len];
	}
	for (let i=0;i<nlen;i++) {imag[i]=0;}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert FFT output to DCT and scale it.
	real[0]/=nlen;
	let inc=Math.PI/(2*nlen),ang=0,norm=2/nlen;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	return real;
	/*real[0]/=len;
	let inc=Math.PI/(2*len),ang=0,norm=2/len;
	for (let i=1;i<nlen;i++) {
		ang+=inc;
		let wr=Math.cos(ang),wi=Math.sin(ang);
		real[i]=(real[i]*wr-imag[i]*wi)*norm;
	}
	let ret=new Array(len);
	for (let i=0;i<len;i++) {
		ret[i]=real[i];
	}
	//return real;
	return ret;*/
}


static idct1(arr,start,len) {
	// Inverse discrete cosine transform. Converts coefficients of cosines into the
	// original array.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("idct indices out of bounds:",start,len);
		return [];
	}
	if (len<=0) {return [];}
	// If len isn't a power of 2, pad it with 0's. Undo the final rotation of the
	// DCT and swap the array elements to reproduce recursion.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let real=new Array(nlen);
	let imag=new Array(nlen);
	let inc=Math.PI/(2*len);
	for (let i=0;i<nlen;i++) {
		let rev=0;
		for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
		let val=rev<len?arr[start+rev]:0,ang=rev*inc;
		real[i]=val*Math.cos(ang);
		imag[i]=val*Math.sin(ang);
	}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
		for (let h=0;h<hpart;h++) {
			let wr=Math.cos(ang),wi=Math.sin(ang);
			ang+=inc;
			for (let i=h;i<nlen;i+=part) {
				let j=i+hpart;
				let ur=real[i],ui=imag[i];
				let vr=real[j],vi=imag[j];
				let tr=wr*vr-wi*vi;
				let ti=wi*vr+wr*vi;
				real[i]=ur+tr;
				imag[i]=ui+ti;
				real[j]=ur-tr;
				imag[j]=ui-ti;
			}
		}
	}
	// Convert undo initial DCT permutation.
	for (let i=0;i<len;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		let ang=i*Math.PI*2/len;
		let cs=Math.cos(ang),sn=Math.sin(ang);
		console.log((i&1)?-i:i,real[j],imag[j],imag[j]*sn);
	}
	for (let i=0;i<nlen;i++) {
		let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
		imag[i]=real[j];
	}
	return imag;
}

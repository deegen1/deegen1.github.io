static fft(arr,start,len) {
	// Takes a real input and returns a complex array.
	if (arr.data!==undefined) {arr=arr.data;}
	if (start===undefined) {start=0;}
	if (len===undefined) {len=arr.length-start;}
	if (start<0 || start+len>arr.length) {
		console.log("fft indices out of bounds:",start,len);
		return null;
	}
	// Copy the array. If len isn't a power of 2, pad it with 0's.
	let bits=0,nlen=1;
	while (nlen<len) {nlen+=nlen;bits++;}
	let comp=new Array(nlen);
	for (let i=0;i<nlen;i++) {comp[i]={r:0,i:0};}
	for (let i=0;i< len;i++) {comp[i].r=arr[start+i];}
	// Swap the array elements to reproduce the recursion of the standard algorithm.
	for (let i=1;i<nlen;i++) {
		let rev=0;
		for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
		if (i<rev) {
			let tmp=comp[i];
			comp[i]=comp[rev];
			comp[rev]=tmp;
		}
	}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,ang=Math.PI/hpart;
		let pr=Math.cos(ang),pi=Math.sin(ang);
		let wr=1,wi=0;
		for (let h=0;h<hpart;h++) {
			for (let i=h;i<nlen;i+=part) {
				// w*v
				let j=i+hpart;
				let u=comp[i],v=comp[j];
				let tr=wr*v.r-wi*v.i;
				let ti=wi*v.r+wr*v.i;
				v.r=u.r-tr;
				v.i=u.i-ti;
				u.r=u.r+tr;
				u.i=u.i+ti;
			}
			// w*p
			let tr=wr,ti=wi;
			wr=pr*tr-pi*ti;
			wi=pi*tr+pr*ti;
		}
	}
	return comp;
}


static ifft(arr) {
	// Takes a complex input and returns a real array.
	let nlen=arr.length,bits=0;
	while ((1<<bits)<nlen) {bits++;}
	let comp=new Array(nlen);
	for (let i=0;i<nlen;i++) {comp[i]={r:arr[i].r,i:arr[i].i};}
	// Swap the array elements to reproduce the recursion of the standard algorithm.
	for (let i=1;i<nlen;i++) {
		let rev=0;
		for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
		if (i<rev) {
			let tmp=comp[i];
			comp[i]=comp[rev];
			comp[rev]=tmp;
		}
	}
	// Butterfly transform.
	for (let part=2;part<=nlen;part+=part) {
		let hpart=part>>>1,ang=-Math.PI/hpart;
		let pr=Math.cos(ang),pi=Math.sin(ang);
		let wr=1,wi=0;
		for (let h=0;h<hpart;h++) {
			for (let i=h;i<nlen;i+=part) {
				// w*v
				let j=i+hpart;
				let u=comp[i],v=comp[j];
				let tr=wr*v.r-wi*v.i;
				let ti=wi*v.r+wr*v.i;
				v.r=u.r-tr;
				v.i=u.i-ti;
				u.r=u.r+tr;
				u.i=u.i+ti;
			}
			// w*p
			let tr=wr,ti=wi;
			wr=pr*tr-pi*ti;
			wi=pi*tr+pr*ti;
		}
	}
	let real=new Array(nlen);
	let norm=1.0/nlen;
	for (let i=0;i<nlen;i++) {real[i]=comp[i].r*norm;}
	return real;
}


static dft(real,idx) {
	// Given a real array, compute fft(real)[idx].
	// e^i*x = cos(x) + i*sin(x)
	let len=real.length;
	let rsum=0,isum=0;
	let ang=0,inc=Math.PI*2*idx/len;
	for (let i=0;i<len;i++) {
		let sr=Math.cos(ang),si=Math.sin(ang);
		let xr=real[i];
		rsum+=xr*sr;
		isum+=xr*si;
		ang+=inc;
	}
	return {r:rsum,i:isum};
}


static idft(comp,idx) {
	// Given the output from fft(arr), compute arr[idx].
	// e^i*x = cos(x) + i*sin(x)
	let len=comp.length;
	let rsum=0;
	let ang=0,inc=-Math.PI*2*idx/len;
	for (let i=0;i<len;i++) {
		let sr=Math.cos(ang),si=Math.sin(ang);
		let xr=comp[i].r,xi=comp[i].i;
		rsum+=xr*sr-xi*si;
		ang+=inc;
	}
	return rsum/len;
}

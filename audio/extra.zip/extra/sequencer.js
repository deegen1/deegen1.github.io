	static sequencer(seq) {
		// Converts a shorthand script into music.
		// Everything is processed top to bottom, left to right.
		// Instruments, functions, etc are separated by commas.
		// ~ variables can be a number, note, or sequence.
		// Non ~ variables can be a number, note, or single element sequence.
		// Note format: [CDEFGAB][#b][octave]. Ex: A4  B#12  C-1.2
		//
		//  Symbol |      Parameters
		// --------+--------------------------------
		// BPM     | [BPM=0]
		// CUT     | [time1=0] [time2]
		// NUM     | <X~>
		//         |
		// ADD SUB | <X~>
		// MUL DIV |
		// MIN MAX |
		// CLIP    | [X~=1.0]
		//         |
		// LIN EXP | <len> [val1~] [val2~]
		//         |
		// SAW SIN | <len> <freq~> [val1~=1] [val2~]
		// SQR TRI |
		// NOI     | <len> [val1~=1] [val2~]
		//         |
		// LPF HPF | <freq~> [bandwidth~=1] [gain~=1]
		// BPF NPF |
		// APF PKF |
		// LSF HSF |
		// COMB    | <delay~> <mul~>
		//         |
		// AG      | [note=A3] [vol~=1] [len=4]
		// XY      | [note=C4] [vol~=1] [len=2]
		// MR      | [note=C4] [vol~=1] [len=2]
		// GS      | [note=A6] [vol~=1] [len=1]
		// KD      | [note=B2] [vol~=1] [len=.2]
		// SD      | [note=G2] [vol~=1] [len=.2]
		// HH      | [note=A8] [vol~=1] [len=.1]
		//
		let seqpos=0,seqlen=seq.length;
		let bpm=0,subidx=0,sndfreq=44100;
		let sepdelta=0;
		let argmax=7,args=0;
		let argarr=new Array(argmax);
		for (let i=0;i<argmax;i++) {
			argarr[i]={str:"",val:NaN,snd:null,buf:new Audio.Sound(sndfreq,1)};
		}
		let tmpsnd=new Audio.Sound(sndfreq);
		let unitsnd=new Audio.Sound(sndfreq,1);
		unitsnd.data[0]=1;
		let subsnd=tmpsnd,nextsnd=subsnd;
		let rand=[Audio.randacc,Audio.randinc];
		[Audio.randacc,Audio.randinc]=[0,0xcadffab1];
		// ,:'"
		let stoptoken={44:true,58:true,39:true,34:true};
		let sequences={
			"BPM":1,
			"CUT":2,
			"NUM":3,
			// Arithmetic
			"ADD":10, "SUB":11, "MUL":12, "DIV":13,
			"MIN":14, "MAX":15, "CLIP":16,
			// Envelopes
			"LIN":20, "EXP":21,
			// Oscillators
			"NOI":30, "SAW":31, "SIN":32, "SQR":33, "TRI":34,
			// Filters
			"LPF":40, "HPF":41, "BPF":42, "NPF":43, "APF":44,
			"PKF":45, "LSF":46, "HSF":47,
			"COMB":50,
			// Instruments
			"AG":60,
			"XY":61, "MR":62, "GS":63,
			"KD":64, "SD":65, "HH":66
		};
		function resize(snd,len) {
			if (snd.data.length<len) {snd.resizelen(len);}
			else {snd.len=len;snd.time=len/snd.freq;}
		}
		function error(msg) {
			[Audio.randacc,Audio.randinc]=rand;
			let line=1;
			for (let i=0;i<seqpos;i++) {line+=seq.charCodeAt(i)===10;}
			let argstr=argarr.slice(0,args).map((x)=>x.str).join(" ");
			throw "Sequencer error:\n\tError: "+msg+"\n\tLine : "+line+"\n\targs : "+argstr;
		}
		function parsenum(str) {
			// Parse numbers in format: [+-]\d*(\.\d*)?
			let len=str.length,i=0,d=0;
			let c=i<len?str.charCodeAt(i):0;
			let neg=c===45;
			if (c===45 || c===43) {i++;}
			let num=0,den=1;
			while (i<len && (c=str.charCodeAt(i)-48)>=0 && c<=9) {d=1;i++;num=num*10+c;}
			if (c===-2) {i++;}
			while (i<len && (c=str.charCodeAt(i)-48)>=0 && c<=9) {d=1;i++;den*=0.1;num+=c*den;}
			return (i===len && d)?(neg?-num:num):NaN;
		}
		function parsenote(str) {
			// Convert a piano note to a frequency. Ex: A4 = 440hz
			// Format: sign + BAGFEDC + #b + octave.
			let slen=str.length,i=0;
			let c=i<slen?str.charCodeAt(i):0;
			let mag=c===45?-440:440;
			if (c===45 || c===43) {i++;}
			c=(i<slen?str.charCodeAt(i++):0)-65;
			if (c<0 || c>6) {return NaN;}
			let n=[48,46,57,55,53,52,50][c];
			c=i<slen?str.charCodeAt(i):0;
			if (c===35 || c===98) {n+=c===98?1:-1;i++;}
			let oct=parsenum(str.substring(i));
			return mag*Math.pow(2,-n/12+oct);
		}
		function parseargs(start,params) {
			// [name,flags,def,...]
			// flags: 1, req, 2 number
			for (let i=0;i<params.length;i+=3,start++) {
				let arg=argarr[start];
				let str=arg.str?arg.str:params[i+2],miss=`'${str}' for ${params[i]}`;
				let snd=arg.buf,dat=snd.data;
				snd.len=1;
				dat[0]=parsenum(str);
				if (isNaN(dat[0])) {dat[0]=parsenote(str);}
				if (isNaN(dat[0])) {snd=sequences[str];}
				if (!snd || snd.len===undefined) {
					if (str) {error("Could not parse "+miss);}
					if (params[i+1]&1) {error(params[i]+" is required");}
					snd=arg.buf;
					snd.len=0;
				}
				else if (!snd.len) {error("Sequence "+miss+" is empty");}
				else if (snd.len>1 && (params[i+1]&2)) {error("Sequence "+miss+" must be length 1: "+snd.len);}
				arg.val=snd.len?snd.data[0]:NaN;
				arg.snd=snd;
			}
			if (start<args) {error("Too many parameters");}
		}
		while (seqpos<seqlen || args>0) {
			// We've changed sequences.
			if (!Object.is(subsnd,nextsnd)) {
				subsnd=nextsnd;
				subidx=0;
				sepdelta=0;
			}
			// Read through whitespace and comments.
			let c=0;
			while (seqpos<seqlen && (c=seq.charCodeAt(seqpos))<33) {seqpos++;}
			if (c===39 || c===34) {
				// If " stop at ". If ' stop at \n.
				let eoc=c===34?34:10;
				while (seqpos<seqlen && seq.charCodeAt(++seqpos)!==eoc) {}
				seqpos++;
				continue;
			}
			c=seqpos<seqlen?seq[seqpos]:"";
			if (c===",") {
				seqpos++;
			} else if (c===":") {
				// Sequence definition.
				seqpos++;
				if (!args) {error("Invalid label");}
				let name=argarr[--args].str;
				argarr[args].str="";
				if (!name || sequences[name]) {error("'"+name+"' already defined");}
				nextsnd=new Audio.Sound(sndfreq);
				sequences[name]=nextsnd;
			} else if (seqpos<seqlen) {
				// Read the next token.
				if (args>=argmax) {error("Too many arguments");}
				let start=seqpos;
				while (seqpos<seqlen && (c=seq.charCodeAt(seqpos))>32 && !stoptoken[c]) {seqpos++;}
				argarr[args++].str=seq.substring(start,seqpos);
				continue;
			}
			// Parse current tokens. Check for a time delta.
			let p=0;
			let delta=parsenum(argarr[p++].str)*sndfreq;
			if (isNaN(delta)) {delta=sepdelta;p--;}
			if (bpm) {sepdelta=sndfreq;subidx+=delta*60/bpm;}
			else {sepdelta=0;subidx+=delta;}
			subidx=subidx>0?Math.floor(subidx):0;
			if (p>=args) {continue;}
			// Find the instrument or sequence to play.
			let inst=sequences[argarr[p++].str];
			if (inst===undefined) {error("Unrecognized instrument");}
			let type=inst;
			let addsnd=null,rate=unitsnd,maxvol=unitsnd,minvol=null;
			if (isNaN(type)) {
				parseargs(p,["volume",0,"1","rate",0,"1"]);
				maxvol=argarr[p].snd;
				rate=argarr[p+1].snd;
				addsnd=inst;
			} else if (type<10) {
				// Operators
				if (type===1) {
					parseargs(p,["val",2,"0"]);
					bpm=argarr[p].val;
				} else if (type===2) {
					parseargs(p,["time0",2,"0","time1",2,""]);
					let start=Math.floor(Audio.clip(subidx+argarr[p].val*sndfreq,0,subsnd.len));
					let stop=Math.floor(Audio.clip(subidx+argarr[p+1].val*sndfreq,0,subsnd.len));
					if (stop<start) {let tmp=start;start=stop;stop=tmp;}
					Object.assign(subsnd,subsnd.slicelen(start,stop-start));
					subidx=subidx>start?subidx-start:0;
				} else if (type===3) {
					parseargs(p,["val",1,""]);
					resize(tmpsnd,1);
					addsnd=tmpsnd;
					addsnd.data[0]=argarr[p].val;
				}
			} else if ((type-=10)<10) {
				// Arithmetic
				parseargs(p,["val",1,(type<6?"":"1")]);
				let addlen=argarr[p].snd.len,sublen=subsnd.len;
				let adddata=argarr[p].snd.data,subdata=subsnd.data;
				for (let i=0;i<sublen;i++) {
					let a=subdata[i],b=adddata[i%addlen];
					switch (type) {
						case 0: a+=b;break;
						case 1: a-=b;break;
						case 2: a*=b;break;
						case 3: a/=b;break;
						case 4: a=a<b?a:b;break;
						case 5: a=a>b?a:b;break;
						case 6: b=Math.abs(b);a=a>-b?(a<b?a:b):-b;break;
					}
					subdata[i]=a;
				}
			} else if ((type-=10)<10) {
				// Envelopes
				parseargs(p,["length",3,"","val1",2,"","val2",2,""]);
				let len=Math.floor(argarr[p++].val*sndfreq);
				if (len<0) {error("len must be positive");}
				resize(tmpsnd,len);
				addsnd=tmpsnd;
				let adddata=addsnd.data;
				let val1=argarr[p  ].val;
				let val2=argarr[p+1].val;
				let last=(subidx>0 && subidx-1<subsnd.len)?subsnd.data[subidx-1]:0;
				if (isNaN(val1)) {val2=last;val1=last;}
				if (isNaN(val2)) {val2=val1;val1=last;}
				if (!type) {
					let inc=(val2-val1)/len;
					for (let i=0;i<len;i++) {val1+=inc;adddata[i]=val1;}
				} else {
					// Want: decay^len=eps, a+b*decay^0=val1, a+b*decay^len=val2
					let eps=0.01,dif=Math.abs(val2-val1)/(1-eps);
					let decay=Math.exp(Math.log(eps)/len);
					let j=0,dir=1;
					if (val2>val1) {j=len-1;dir=-1;}
					val1-=dif*(j?eps+decay-1:1);
					for (let i=0;i<len;i++,j+=dir) {dif*=decay;adddata[j]=dif+val1;}
				}
			} else if ((type-=10)<10) {
				// Oscillators
				if (type===0) {parseargs(p,["length",3,"","val1",0,"1","val2",0,""]);}
				else {parseargs(p,["length",3,"","frequency",1,"","val1",0,"1","val2",0,""]);}
				let len=Math.floor(argarr[p].val*sndfreq),flen=argarr[p+1].snd.len;
				if (len<0) {error("len must be positive");}
				resize(tmpsnd,len);
				addsnd=tmpsnd;
				let fdata=argarr[p+1].snd.data,adddata=addsnd.data;
				p+=type?2:1;
				maxvol=argarr[p++].snd;
				minvol=argarr[p].snd;
				let f=0,fmul=1/sndfreq,v;
				for (let i=0;i<len;i++) {
					switch (type) {
						case 0: v=Audio.noise();break;
						case 1: v=Audio.saw(f);break;
						case 2: v=Audio.sin(f);break;
						case 3: v=Audio.sqr(f);break;
						case 4: v=Audio.tri(f);break;
					}
					adddata[i]=v;
					f+=fdata[i%flen]*fmul;
				}
			} else if ((type-=10)<10) {
				// Filters
				parseargs(p,["frequency",1,"","bandwidth",0,"1","gain",0,"1"]);
				let filter=new Audio.Biquad(type+1,sndfreq,1,1);
				let sublen=subsnd.len,freqlen=argarr[p].snd.len,bwlen=argarr[p+1].snd.len,gainlen=argarr[p+2].snd.len;
				let subdata=subsnd.data,freqdata=argarr[p].snd.data,bwdata=argarr[p+1].snd.data,gaindata=argarr[p+2].snd.data;
				for (let i=0;i<sublen;i++) {
					filter.updatecoefs(type+1,freqdata[i%freqlen]/sndfreq,bwdata[i%bwlen],gaindata[i%gainlen]);
					subdata[i]=filter.process(subdata[i]);
				}
			} else if ((type-=10)<10) {
				// Comb
				parseargs(p,["delay",1,"","mul",1,""]);
				let sublen=subsnd.len,dellen=argarr[p].snd.len,mullen=argarr[p+1].snd.len;
				let subdata=subsnd.data,deldata=argarr[p].snd.data,muldata=argarr[p+1].snd.data;
				for (let i=0;i<sublen;i++) {
					let t=i-deldata[i%dellen]*sndfreq;
					if (t>=0 && t<i) {subdata[i]+=subsnd.get(t)*muldata[i%mullen];}
				}
			} else if ((type-=10)<10) {
				// Instruments
				let note=["A3","C4","C4","A6","B2","G2","A8"][type];
				let len=["4","2","2","1","0.2","0.2","0.1"][type];
				parseargs(p,["note",2,note,"volume",0,"1","length",2,len]);
				let freq=argarr[p].val;
				maxvol=argarr[p+1].snd;
				len=argarr[p+2].val;
				if (len<0) {error("len must be positive");}
				if      (type===0) {addsnd=Audio.createguitar(1,freq,0.2);}
				else if (type===1) {addsnd=Audio.createxylophone(1,freq);}
				else if (type===2) {addsnd=Audio.createmarimba(1,freq);}
				else if (type===3) {addsnd=Audio.createglockenspiel(1,freq);}
				else if (type===4) {addsnd=Audio.createdrumkick(1,freq,len);}
				else if (type===5) {addsnd=Audio.createdrumsnare(1,freq,len);}
				else if (type===6) {addsnd=Audio.createdrumhihat(1,freq,len);}
			}
			// Add the new sound to the sub sequence. Scale to be between [minvol,maxvol].
			if (addsnd) {
				if (!minvol || !minvol.len) {minvol=null;}
				else {let tmp=minvol;minvol=maxvol;maxvol=tmp;}
				let subdata=subsnd.data;
				let sublen=subdata.length,addlen=addsnd.len,i=subidx;
				let t=0;
				while (t>-addlen && t<addlen) {
					if (i>=sublen) {
						subsnd.resizelen(i+1);
						subdata=subsnd.data;
						sublen=subdata.length;
					}
					let max=maxvol.get(t);
					let min=minvol?minvol.get(t):-max;
					subdata[i++]+=(addsnd.get(t)*(max-min)+max+min)*0.5;
					subsnd.len=subsnd.len>i?subsnd.len:i;
					t+=rate.get(i-subidx-1);
				}
				subsnd.time=subsnd.len/sndfreq;
				if (!bpm) {sepdelta=i-subidx;}
			}
			while (args>0) {argarr[--args].str="";}
		}
		[Audio.randacc,Audio.randinc]=rand;
		subsnd=sequences["OUT"];
		if (!subsnd) {throw "OUT not defined";}
		return subsnd;
	}

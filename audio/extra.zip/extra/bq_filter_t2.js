class BiQuadFilter {
	// Biquad filter type 2.

	constructor(type,fc,q,peakgain) {
		this.type=type;
		this.fc=fc;
		this.q=q||(1/Math.sqrt(2));
		this.peakgain=peakgain||0;
		this.z1=0;
		this.z2=0;
		this.calccoefs();
	}


	process(x) {
		let   y=this.a0*x+this.z1;
		this.z1=this.a1*x-this.b1*y+this.z2;
		this.z2=this.a2*x-this.b2*y;
		return y;
	}


	calccoefs() {
		// https://shepazu.github.io/Audio-EQ-Cookbook/audio-eq-cookbook.html
		let a2=0,a1=0,a0=1;
		let b2=0,b1=0;
		let norm=1;
		let peak=this.peakgain;
		let k=Math.tan(Math.PI*this.fc),kk=k*k,kq=k/this.q,kr2=Math.sqrt(2)*k;
		let v=Math.exp(Math.abs(peak)/(Math.log(10)*20)),vr=Math.sqrt(v);
		let cs=2*(kk-1);
		let type=this.type;
		if (type==="none") {
		} else if (type==="lowpass") {
			norm=1+kq+kk;
			a0=kk;
			a1=2*a0;
			a2=a0;
			b1=cs;
			b2=1-kq+kk;
		} else if (type==="highpass") {
			norm=1+kq+kk;
			a0=1;
			a1=-2*a0;
			a2=a0;
			b1=cs;
			b2=1-kq+kk;
		} else if (type==="bandpass") {
			norm=1+kq+kk;
			a0=kq;
			a1=0;
			a2=-a0;
			b1=cs;
			b2=1-kq+kk;
		} else if (type==="notch") {
			norm=1+kq+kk;
			a0=1+kk;
			a1=cs;
			a2=a0;
			b1=a1;
			b2=1-kq+kk;
		} else if (type==="peak") {
			if (peak>=0) {
				norm=1+kq+kk;
				a0=1+v*kq+kk;
				a1=cs;
				a2=1-v*kq+kk;
				b1=a1;
				b2=1-kq+kk;
			} else {
				norm=1+v*kq+kk;
				a0=1+kq+kk;
				a1=cs;
				a2=1-kq+kk;
				b1=a1;
				b2=1-v*kq+kk;
			}
		} else if (type==="lowshelf") {
			if (peak>=0) {
				norm=1+kr2+kk;
				a0=1+vr*kr2+v*kk;
				a1=2*(v*kk-1);
				a2=1-vr*kr2+v*kk;
				b1=cs;
				b2=1-kr2+kk;
			} else {
				norm=1+vr*kr2+v*kk;
				a0=1+kr2+kk;
				a1=cs;
				a2=1-kr2+kk;
				b1=2*(v*kk-1);
				b2=1-vr*kr2+v*kk;
			}
		} else if (type==="highshelf") {
			if (peak>=0) {
				norm=1+kr2+kk;
				a0=v+vr*kr2+kk;
				a1=2*(kk-v);
				a2=v-vr*kr2+kk;
				b1=cs;
				b2=1-kr2+kk;
			} else {
				norm=v+vr*kr2+kk;
				a0=1+kr2+kk;
				a1=cs;
				a2=1-kr2+kk;
				b1=2*(kk-v);
				b2=v-vr*kr2+kk;
			}
		} else {
			throw "type should be none, lowpass, highpass, bandpass, notch, peak, lowshelf, or highshelf: "+type;
		}
		norm=1/norm;
		this.a0=a0*norm;
		this.a1=a1*norm;
		this.a2=a2*norm;
		this.b1=b1*norm;
		this.b2=b2*norm;
	}

}

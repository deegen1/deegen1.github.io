/*

https://flothesof.github.io/Karplus-Strong-algorithm-Python.html

' String
#freq: 100
#rate: 1 #freq /
#slide: 0.5
#sig1: NOISE H 10 L -10
#sig : ENV A 0 S #rate R 0 I #sig1 -1 > 1 <
#line: DEL M 0.1 T #rate I #val
#val : #line #sig + #val - #slide * #val +
#out : ENV A 0 S 0 R 3 I #val


' Negative String
#freq: 100
#rate: 1 #freq /
#slide: 0.5
#sig1: NOISE H 10 L -10
#sig : ENV A 0 S #rate R 0 I #sig1 -1 > 1 <
#line: DEL M 0.1 T #rate I #val
#val : #sig #line - #val - #slide * #val +
#out : ENV A 0 S 0 R 3 I #val


' Snare
#freq: 100
#rate: 1 #freq /
#slide: 0.75
#sig1: NOISE
#sig : ENV A 0 S #rate R 0 I #sig1
#t: NOISE H 1.15 L 0.85
#line: DEL M 0.1 T #rate #t * I #val
#val : #line #sig + #val - #slide * #val +
#out : ENV A 0 S 0 R 3 I #val

*/

	static generatestring2(volume=1.0,freq=200,pos=0.5,inharm=0.00006,time=3,sndfreq=44100) {
		// Stop when e^(-decay*time/sndfreq)<=cutoff
		const cutoff=1e-3;
//time=3;
		let sndlen=Math.ceil(sndfreq*time);
		let snd=new Audio.Sound(sndfreq,sndlen);
		let data=snd.data;
		let tablen=Math.round(sndfreq/freq);
		let table=new Float32Array(tablen);
		let rnd=new Random();
		for (let i=0;i<tablen;i++) {table[i]=(rnd.getu32()&2)-1;}
		let bpf=new Audio.Biquad(Audio.Biquad.BANDPASS,freq/sndfreq);
		// Generate coefficients.
		let del=new _AudioDelay(sndfreq,1/freq);
		//let del=new DelayLineFloat(sndfreq/freq);
		let ddat=del.data,dlen=ddat.length;
		//for (let i=0;i<dlen;i++) {ddat[i]=rnd.getf()*2-1;}//(rnd.getu32()&2)-1;}
		for (let i=0;i<dlen;i++) {ddat[i]=(rnd.getu32()&2)-1;}
		let stretch=1;
		let sprob=time/2;
		let prev=0;
		let decay=Math.exp(Math.log(0.01)/sndlen);
console.log(Math.exp(Math.log(0.01)/sndlen));
		for (let i=0;i<sndlen;i++) {
			let t=i%tablen;
			let val=table[t];
			if (rnd.getf()<sprob) {
				val=(val+prev)*0.5;
				table[t]=val;
			}
			data[i]+=bpf.process(val)*volume;
			volume*=decay;
			prev=val;
		}
		/*for (let i=0;i<sndlen;i++) {
			let val=(del.get()+prev)*0.5;
			del.add(val);
			data[i]+=val*vol;
			vol*=decay;
			prev=val;
		}*/
		// Taper the ends.
		let end=Math.ceil(0.1*sndfreq);
		end=end<sndlen?end:sndlen;
		for (let i=0;i<end;i++) {data[sndlen-1-i]*=i/end;}
//snd.savefile(`guitar_${freq.toFixed(3)}.wav`);
		return snd;
	}


	static generatestring3(volume=1.0,freq=200,pos=0.5,inharm=0.00006,time=3,sndfreq=44100) {
		// Stop when e^(-decay*time/sndfreq)<=cutoff
		const cutoff=1e-3;
		freq/=sndfreq;
		let harmonics=Math.ceil(0.5/freq);
		let sndlen=Math.ceil(sndfreq*time);
		let snd=new Audio.Sound(sndfreq,sndlen);
		let data=snd.data;
		let tablen=Math.round(1/freq);
		let table=new Float32Array(tablen);
		let rnd=new Random();
		//for (let i=0;i<tablen;i++) {table[i]=rnd.getf()*2-1;}
		for (let i=0;i<tablen;i++) {table[i]=(rnd.getu32()&2)-1;}
		let excite=new Float32Array(sndlen);
		let prev=0;
		let slide=0.5;
		for (let i=0;i<sndlen;i++) {
			let t=i%tablen;
			let val=(table[t]-prev)*slide+prev;
//if (rnd.getf()<0.75) {val=prev;}
//if (rnd.getf()<0.75) {val=-val;}
			table[t]=val;
			excite[i]=val;
			prev=val;
		}
		// Generate coefficients.
		if (pos<0.0001) {pos=0.0001;}
		if (pos>0.9999) {pos=0.9999;}
//volume=1;
		let listen=pos;
		let c0=listen*Math.PI;
		let c1=2/(Math.PI*Math.PI*pos*(1-pos));
		let decay=Math.log(0.01)/sndlen;
		// Process highest to lowest for floating point accuracy.
		for (let n=harmonics;n>0;n--) {
			// Calculate coefficients for the n'th harmonic.
			let n2=n*n;
			let harmvol=Math.sin(n*c0)*c1/n2;
			if (Math.abs(harmvol)<=cutoff) {continue;}
			// Correct n2 by -1 so the fundamental = freq.
			let ihscale=n*Math.sqrt(1+(n2-1)*inharm);
			let harmdecay=decay*ihscale;
			let harmmul=Math.exp(harmdecay);
			let harmlen=Math.ceil(Math.log(cutoff/Math.abs(harmvol))/harmdecay);
			if (harmlen>sndlen) {harmlen=sndlen;}
			// Generate the waveform.
			let harmfreq=freq*ihscale;
			let bpf=new Audio.Biquad(Audio.Biquad.BANDPASS,harmfreq,0.1);
			for (let i=0;i<harmlen;i++) {
				data[i]+=bpf.process(excite[i])*harmvol;
				harmvol*=harmmul;
			}
		}
		snd.scalevol(volume,true);
		// Taper the ends.
		let end=Math.ceil(0.1*sndfreq);
		end=end<sndlen?end:sndlen;
		for (let i=0;i<end;i++) {data[sndlen-1-i]*=i/end;}
//snd.savefile(`guitar_${(freq*sndfreq).toFixed(3)}.wav`);
//console.log(snd.getvol());
		return snd;
	}


	static generatestring4(volume=1.0,freq=200,pos=0.5,inharm=0.00006,time=3,sndfreq=44100) {
		// Stop when e^(-decay*time/sndfreq)<=cutoff
		const cutoff=1e-3;
//time=3;
		let sndlen=Math.ceil(sndfreq*time);
		let snd=new Audio.Sound(sndfreq,sndlen);
		let data=snd.data;
		let tablen=Math.round(sndfreq/freq);
		let table=new Float32Array(tablen);
		let rnd=new Random();
		//for (let i=0;i<tablen;i++) {table[i]=(rnd.getu32()&2)-1;}
		for (let i=0;i<tablen;i++) {table[i]=Math.sin(freq*i*Math.PI*2/sndfreq)*rnd.getf();}
		let bpf=new Audio.Biquad(Audio.Biquad.BANDPASS,freq/sndfreq);
		// Generate coefficients.
		let stretch=1;
		let sprob=time/2;
		let prev=0;
		let decay=Math.exp(Math.log(0.01)/sndlen);
		let slide=0.5;
//lerp between next and prev to hit target rate
//mfreq=data.length/sndfreq
//while time<0
// time+=freq
// table=...
//data[i]=next/prev
//time-=freq
//
//record next-prev differential?
		for (let i=0;i<sndlen;i++) {
			let t=i%tablen;
			let val=(table[t]-prev)*slide+prev;
			table[t]=val;
			data[i]+=val*volume;
			volume*=decay;
			prev=val;
		}
		/*for (let i=0;i<sndlen;i++) {
			let val=(del.get()+prev)*0.5;
			del.add(val);
			data[i]+=val*vol;
			vol*=decay;
			prev=val;
		}*/
		// Taper the ends.
		let end=Math.ceil(0.1*sndfreq);
		end=end<sndlen?end:sndlen;
		for (let i=0;i<end;i++) {data[sndlen-1-i]*=i/end;}
//snd.savefile(`guitar_${freq.toFixed(3)}.wav`);
		return snd;
	}
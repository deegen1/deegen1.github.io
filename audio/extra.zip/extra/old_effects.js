class Audio {

	// ----------------------------------------
	// User Interface


	static generateui(volume=0.04,freq=200,time=0.2,noise=0.5,sndfreq=44100) {
		let len=Math.ceil(time*sndfreq);
		let snd=new Audio.Sound(sndfreq,len);
		let data=snd.data;
		let attack=0.01,sustain=time*0.25;
		let scale=freq/5000;
		let bp1=new Audio.Biquad(Audio.Biquad.BANDPASS,freq/sndfreq,6*scale);
		// let bp2=new Audio.Biquad(Audio.Biquad.BANDPASS, 700/sndfreq,3*scale);
		// let del=new Audio.Delay(sndfreq,time*0.25);
		let seed=Math.floor(Audio.noise1()*0xffffff);
		for (let i=0;i<len;i++) {
			let t=i/sndfreq;
			let x=0;
			if (t<attack) {x=t/attack;}
			else if (t-attack<sustain) {x=1-(t-attack)/sustain;}
			x*=x;
			x*=bp1.process(Audio.tri(t*freq)*(1-noise)+Audio.noise(seed+i)*noise);
			// x+=del.get();
			// This bandpass adds low frequency vibrations from the hypothetical console.
			// del.add(bp2.process(x)*0.25);
			data[i]=x;
		}
		snd.scalevol(volume,true);
		return snd;
	}


	static createuiincrease(volume=0.05) {
		return Audio.generateui(volume,2000,0.2,0.5);
	}


	static createuidecrease(volume=0.05) {
		return Audio.generateui(volume,1500,0.2,0.5);
	}


	static createuiconfirm(volume=0.05) {
		return Audio.generateui(volume,4000,2.0,0.25);
	}


	static createuierror(volume=0.05) {
		return Audio.generateui(volume,800,1.0,0.5);
	}


	static createuiclick(volume=0.05) {
		return Audio.generateui(volume,800,0.2,0.75);
	}


	// ----------------------------------------
	// Misc


	static generatethud(volume=1.0,freq=8000,time=0.02,sndfreq=44100) {
		// Pitch should increase slightly with force.
		let decay=Math.log(1e-4)/(time*sndfreq);
		let len=Math.ceil(Math.log(1e-4)/decay);
		let snd=new Audio.Sound(sndfreq,len);
		let data=snd.data;
		let vmul=Math.exp(decay),vtmp=1;
		freq/=sndfreq;
		let seed=Math.floor(Audio.noise1()*0xffffff);
		let bp1=new Audio.Biquad(Audio.Biquad.BANDPASS,freq,2);
		let bp2=new Audio.Biquad(Audio.Biquad.BANDPASS,freq,2);
		let del=new Audio.Delay(sndfreq,0.003),delmul=0.9;
		for (let i=0;i<len;i++) {
			let x=Audio.noise(seed+i)*vtmp;
			vtmp*=vmul;
			x=bp1.process(x);
			x=bp2.process(x);
			x+=del.process(x)*delmul;
			data[i]=x;
		}
		snd.scalevol(volume,true);
		return snd;
	}


	static createmarble(volume=0.5) {
		return Audio.generatethud(volume,8000,0.02);
	}


	static createthud(volume=1.0) {
		return Audio.generatethud(volume,100,0.2);
	}


	static createelectricity(volume=0.15,freq=159.8,time=1.5) {
		let sndfreq=44100,len=Math.ceil(time*sndfreq);
		let ramp=0.01*sndfreq,rampden=1/ramp,tail=len-ramp;
		let snd=new Audio.Sound(sndfreq,len);
		let data=snd.data;
		let seed=Math.floor(Audio.noise1()*0xffffff);
		let freq0=freq/sndfreq,freq1=freq0*1.002;
		let lp3=new Audio.Biquad(Audio.Biquad.LOWPASS,3000/sndfreq);
		for (let i=0;i<len;i++) {
			let x=Audio.saw((seed+i)*freq0)+Audio.saw((seed+i)*freq1);
			x=Audio.clip(x*0.5,-0.5,0.5);
			x=lp3.process(x);
			if (i<ramp || i>tail) {x*=(i<ramp?i:len-1-i)*rampden;}
			data[i]=x;
		}
		snd.scalevol(volume,true);
		return snd;
	}


	static createlaser(volume=0.5,freq=10000,time=0.25) {
		let sndfreq=44100,len=Math.ceil(time*sndfreq);
		let ramp=0.01*sndfreq,rampden=1/ramp,tail=len-ramp;
		let snd=new Audio.Sound(sndfreq,len);
		let data=snd.data;
		freq*=Math.PI*2/sndfreq;
		let phase=Audio.noise()*3.141592654;
		let vmul=Math.exp(Math.log(1e-4)/len),vol=1;
		// Instead of a delay constant, use a delay multiplier. Scales sum < 1.
		// Array format: delay, scale, delay, scale, ...
		let deltable=[0.99,-0.35,0.90,-0.28,0.80,-0.21,0.40,-0.13];
		let delays=deltable.length;
		for (let i=0;i<len;i++) {
			let x=Math.sin(phase+i*freq)*vol;
			if (i<ramp) {x*=i*rampden;}
			vol*=vmul;
			for (let j=0;j<delays;j+=2) {
				let u=i*deltable[j],k=Math.floor(u);
				if (k>=0 && k+1<i) {
					u-=k;
					x+=(data[k]*(1-u)+data[k+1]*u)*deltable[j+1];
				}
			}
			if (i>tail) {x*=(len-1-i)*rampden;}
			data[i]=x;
		}
		snd.scalevol(volume,true);
		return snd;
	}


	static generateexplosion(volume=0.75,freq=1000,time=0.25,sndfreq=44100) {
		let len=Math.ceil(time*sndfreq);
		let ramp=0.01*sndfreq,rampden=1/ramp,tail=len-ramp;
		let snd=new Audio.Sound(sndfreq,len);
		let data=snd.data;
		let vmul=Math.exp(Math.log(1e-4)*3/len),vol=1;
		let f=freq/(freq+1000);
		let lpcoef=1-f,bpcoef=f,del=0.75+0.15*f,delmul=-0.9+0.5*f;
		let seed=Math.floor(Audio.noise1()*0xffffff);
		let lp=new Audio.Biquad(Audio.Biquad.LOWPASS,freq/sndfreq,1);
		let bp=new Audio.Biquad(Audio.Biquad.BANDPASS,freq/sndfreq,2);
		for (let i=0;i<len;i++) {
			let x=Audio.noise(seed+i)*vol;
			vol*=vmul;
			x=lp.process(x)*lpcoef+bp.process(x)*bpcoef;
			let u=i*del,k=Math.floor(u);
			if (k>=0 && k+1<i) {
				u-=k;
				x+=(data[k]*(1-u)+data[k+1]*u)*delmul;
			}
			if (i<ramp || i>tail) {x*=(i<ramp?i:len-1-i)*rampden;}
			data[i]=x;
		}
		snd.scalevol(volume,true);
		return snd;
	}


	static createexplosion1(volume=0.5) {
		return Audio.generateexplosion(volume,100,5.0);
	}


	static createexplosion2(volume=1.0) {
		return Audio.generateexplosion(volume,300,5.0);
	}


	static creategunshot1(volume=0.25) {
		return Audio.generateexplosion(volume,500,0.25);
	}


	static creategunshot2(volume=0.5) {
		return Audio.generateexplosion(volume,1000,1.0);
	}


	static creategunhit(volume=0.25) {
		return Audio.generateexplosion(volume,200,0.10);
	}

}

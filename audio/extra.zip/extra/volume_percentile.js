// Fails when there is a lot of silence.

	getvol(percentile=1.0) {
		let data=this.data,len=data.length;
		let v=0,x;
		let discard=Math.floor((1-percentile)*len);
		if (discard<=0) {
			for (let i=0;i<len;i++) {
				x=Math.abs(data[i]);
				v=v<x?x:v;
			}
		} else if (discard<len) {
			let sort=new Float32Array(len);
			for (let i=0;i<len;i++) {sort[i]=Math.abs(data[i]);}
			// Linear time heap construction.
			for (let p=(len>>1)-1;p>=0;p--) {
				let i=p,j;
				v=sort[p];
				while ((j=i+i+1)<len) {
					if (j+1<len && sort[j+1]>sort[j]) {j++;}
					if (sort[j]<=v) {break;}
					sort[i]=sort[j];
					i=j;
				}
				sort[i]=v;
			}
			// Heap sort down.
			for (let d=0;d<discard;d++) {
				let i=0,j;
				v=sort[--len];
				while ((j=i+i+1)<len) {
					if (j+1<len && sort[j+1]>sort[j]) {j++;}
					if (sort[j]<=v) {break;}
					sort[i]=sort[j];
					i=j;
				}
				sort[i]=v;
			}
			v=sort[0];
		}
		return v;
	}


	scalevol(mul,normalize=false,percentile=0.99) {
		let data=this.data,len=data.length;
		if (normalize) {
			let norm=this.getvol(percentile);
			mul=norm>1e-10?mul/norm:0;
		}
		for (let i=0;i<len;i++) {data[i]*=mul;}
		return this;
	}

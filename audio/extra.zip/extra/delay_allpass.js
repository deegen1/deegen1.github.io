class DelayLineFloat {
	// Delay line with an allpass filter.
    
	constructor(frames) {
		let iframes=Math.floor(frames);
		this.buf=new Float32Array(iframes);
		this.idx=0;
		this.prevout=0;
		this.previn=0;
		let delta=frames-iframes;
		this.apcoef=(1-delta)/(1+delta);
	}


	read() {
		// allpass
		let inp=this.buf[this.idx];
		let out=this.apcoef*(inp-this.prevout)+this.previn;
		this.prevout=out;
		this.previn=inp;
		return out;
	}


	write(x) {
		let idx=this.idx;
		this.buf[idx]=x;
		this.idx=(idx+1)%this.buf.length;
	}

}
	parse(seqstr) {
		// Last node is returned. Node names must start with #.
		// Node format:
		//      0 [u32 type]
		//      4 [f32 output]
		//      8 [u32 input stop]
		//     12 [u32 src stop 1] [u32 src 1] [u32 src 2] ... [dst 1]
		//      x [u32 src stop 2] [u32 src 1] [u32 src 2] ... [dst 2]
		//      x ...
		//     .. data
		console.log("parsing:",seqstr);
		// capital = special
		let nodetypes=[
			{str:"expr" ,id: 0,size: 1,params:""},
			{str:"asr"  ,id: 1,size: 1,params:""},
			{str:"tri"  ,id: 2,size: 4,params:"fxhl"},
			{str:"saw"  ,id: 3,size: 4,params:"fxhl"},
			{str:"sqr"  ,id: 4,size: 4,params:"fxhl"},
			{str:"pulse",id: 5,size: 4,params:"fxhlw"},
			{str:"sin"  ,id: 6,size: 4,params:"fxhl"},
			{str:"osc"  ,id: 7,size: 4,params:"fxhlp"},
			{str:"noise",id: 8,size: 4,params:"hl"},
			{str:"del"  ,id: 9,size: 1,params:"xm"},
			{str:"lpf"  ,id:10,size:14,params:"fbg"},
			{str:"hpf"  ,id:11,size:14,params:"fbg"},
			{str:"bpf"  ,id:12,size:14,params:"fbg"},
			{str:"npf"  ,id:13,size:14,params:"fbg"},
			{str:"apf"  ,id:14,size:14,params:"fbg"},
			{str:"pkf"  ,id:15,size:14,params:"fbg"},
			{str:"lsf"  ,id:16,size:14,params:"fbg"},
			{str:"hsf"  ,id:17,size:14,params:"fbg"}
		];
		function error(msg,s0,s1) {
			let line=1;
			for (let i=0;i<s0;i++) {line+=seqstr.charCodeAt(i)===10;}
			let argsum=seqstr.substring(s0,s1);
			throw "Sequencer error:\n\tError: "+msg+"\n\tLine : "+line+"\n\targs : "+argsum;
		}
		seqstr=seqstr.toLowerCase();
		let s=0,seqlen=seqstr.length;
		let naddr=new Int32Array(seqlen>>1);
		let node=null,nparam=-1,nodes=0;
		let paramarr=new Array(5);
		let dpos=0;
		let di32=new Int32Array(0);
		let df32=new Float32Array(di32.buffer);
		const symrange=10,prmrange=19,noderange=prmrange+nodetypes.length;
		let strmap={};
		for (let i=0;i<10;i++) {strmap["+-~*%/*^<>"[i]]=i;}
		for (let i=0;i<9;i++) {strmap["fxhlwpmbg"[i]]=i+symrange;}
		for (let i=0;i<nodetypes.length;i++) {strmap[nodetypes[i].str]=i+prmrange;}
		function getc() {return s<seqlen?seqstr.charCodeAt(s):0;}
		function addparam(type,val,s0,s1) {
			// types: 0 num, 1 node, 2 expr
			if (nparam<0) {error("no parameter defined",s0,s1+1);}
			console.log("adding",type,val);
			paramarr[nparam].push({type:type,val:val});
		}
		let dbg=-1;// ////////////////////////////////////
		while (s<seqlen || node) {
			// Read through whitespace and comments.
			if (dbg>=s) {throw "no movement";} dbg=s;
			let c=0;
			while ((c=getc())<33 && c>0) {s++;}
			if (c===39 || c===34) {
				// If " stop at ". If ' stop at \n.
				let eoc=c===34?34:10;
				do {s++;} while ((c=getc())!==eoc && c>0);
				s++;
				continue;
			}
			// Stop at :'"
			let c0=getc(),s0=s++;
			while ((c=getc())>32 && c!==34 && c!==39 && c!==58) {s++;}
			let tid=strmap[seqstr.substring(s0,s)]??-1;
			if (c0===35) {
				// Find the node's ID.
				console.log("node: ["+seqstr.substring(s0,s)+"]");
				// If we have a new node name or a definition.
				if (tid<0) {
					tid=nodes++;naddr[tid]=-s;
					strmap[seqstr.substring(s0,s)]=tid;
				}
				while ((c=getc())<33 && c>0) {s++;}
				if (c!==58) {addparam(1,tid,s0,s+1);continue;}
				if (naddr[tid]>=0) {error("node already defined",s0,s);}
				s++;
			} else if (tid>=prmrange) {
				// Node type.
				if (node) {error("node type already defined",s0,s);}
				node=nodetypes[tid-prmrange];
				console.log("found type:",node);
				let params=node.params?node.params.length:1;
				for (let i=0;i<params;i++) {paramarr[i]=new Array();}
				nparam=node.id<3?0:-1;
				continue;
			} else if (!node) {
				error("invalid node type",s0,s);
			} else if (tid>=symrange) {
				// Parameter.
				let prm=node.params;
				for (nparam=0;nparam<prm.length && prm.charCodeAt(nparam)!==c0;nparam++) {}
				if (nparam>=prm.length) {error("invalid parameter",s0,s);}
				continue;
			} else if (tid>=0) {
				// Symbol.
				addparam(2,tid,s0,s+1);
				continue;
			} else if (s0<seqlen) {
				// Parse numbers in format: [+-]\d*(\.\d*)?
				console.log("num : ["+seqstr.substring(s0,s)+"]");
				let i=s0,d=0;
				c=i<s?seqstr.charCodeAt(i):0;
				let neg=c===45?-1:1;
				if (c===45 || c===43) {i++;}
				let num=0,den=1;
				while (i<s && (c=seqstr.charCodeAt(i)-48)>=0 && c<=9) {d=1;i++;num=num*10+c;}
				if (c===-2) {i++;}
				while (i<s && (c=seqstr.charCodeAt(i)-48)>=0 && c<=9) {d=1;i++;den*=0.1;num+=c*den;}
				if (i<s || !d) {error("invalid token",s0,s);}
				addparam(0,neg*num,s0,s+1);
				continue;
			}
			// Process the node.
			console.log("processing");
			if (node) {
				/*if (len<di32.length) {return;}
				let tmp=new Int32Array(len*2+1);
				tmp.fill(di32);
				di32=tmp;
				df32=new Float32Array(di32.buffer);*/
				node=null;
			}
			if (tid>=0) {naddr[tid]=dpos;}
		}
		// Find any undefined nodes.
		for (let i=0;i<nodes;i++) {
			let a=-naddr[i];
			if (a>0) {
				let s=a;while (seqstr[--s]!=="#") {}
				error("undefined node",s,a);
			}
		}
		// Convert node numbers to output addresses.
		// When adding inputs, if top of stack is constants, eval ahead of time
		// If stack is empty use default, If only 1 input left, set value.
	}

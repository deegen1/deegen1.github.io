	// ----------------------------------------
	// DCT


	static dct(arr,start,len) {
		// Computes the discrete cosine transform. Converts an array into a sum of
		// cosines.
		if (arr.data!==undefined) {arr=arr.data;}
		if (start===undefined) {start=0;}
		if (len===undefined) {len=arr.length-start;}
		if (start<0 || start+len>arr.length) {
			console.log("dct indices out of bounds:",start,len);
			return [];
		}
		if (len<=0) {return [];}
		// If len isn't a power of 2, pad it with 0's. Swap array elements to reproduce
		// the recursion of the standard FFT algorithm.
		let bits=0,nlen=1;
		while (nlen<len) {nlen+=nlen;bits++;}
		let real=new Array(nlen);
		let imag=new Array(nlen);
		for (let i=0;i<nlen;i++) {
			let rev=0,j=(i&1)?(nlen-1-(i>>1)):(i>>1);
			for (let b=0;b<bits;b++) {rev+=rev+((j>>>b)&1);}
			real[i]=rev<len?arr[start+rev]:0;
			imag[i]=0;
		}
		// Butterfly transform.
		for (let part=2;part<=nlen;part+=part) {
			let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
			for (let h=0;h<hpart;h++) {
				let wr=Math.cos(ang),wi=Math.sin(ang);
				ang+=inc;
				for (let i=h;i<nlen;i+=part) {
					let j=i+hpart;
					let ur=real[i],ui=imag[i];
					let vr=real[j],vi=imag[j];
					let tr=wr*vr-wi*vi;
					let ti=wi*vr+wr*vi;
					real[i]=ur+tr;
					imag[i]=ui+ti;
					real[j]=ur-tr;
					imag[j]=ui-ti;
				}
			}
		}
		// Convert FFT output to DCT and scale it.
		real[0]/=nlen;
		let inc=Math.PI/(2*nlen),ang=0,norm=2/nlen;
		for (let i=1;i<nlen;i++) {
			ang+=inc;
			let wr=Math.cos(ang),wi=Math.sin(ang);
			real[i]=(real[i]*wr-imag[i]*wi)*norm;
		}
		return real;
	}


	static idct(arr,start,len) {
		// Inverse discrete cosine transform. Converts coefficients of cosines into the
		// original array.
		if (arr.data!==undefined) {arr=arr.data;}
		if (start===undefined) {start=0;}
		if (len===undefined) {len=arr.length-start;}
		if (start<0 || start+len>arr.length) {
			console.log("idct indices out of bounds:",start,len);
			return [];
		}
		if (len<=0) {return [];}
		// If len isn't a power of 2, pad it with 0's. Undo the final rotation of the
		// DCT and swap the array elements to reproduce recursion.
		let bits=0,nlen=1;
		while (nlen<len) {nlen+=nlen;bits++;}
		let real=new Array(nlen);
		let imag=new Array(nlen);
		let inc=Math.PI/(2*nlen);
		for (let i=0;i<nlen;i++) {
			let rev=0;
			for (let b=0;b<bits;b++) {rev+=rev+((i>>>b)&1);}
			let val=rev<len?arr[start+rev]:0,ang=rev*inc;
			real[i]=val*Math.cos(ang);
			imag[i]=val*Math.sin(ang);
		}
		// Butterfly transform.
		for (let part=2;part<=nlen;part+=part) {
			let hpart=part>>>1,inc=Math.PI/hpart,ang=0;
			for (let h=0;h<hpart;h++) {
				let wr=Math.cos(ang),wi=Math.sin(ang);
				ang+=inc;
				for (let i=h;i<nlen;i+=part) {
					let j=i+hpart;
					let ur=real[i],ui=imag[i];
					let vr=real[j],vi=imag[j];
					let tr=wr*vr-wi*vi;
					let ti=wi*vr+wr*vi;
					real[i]=ur+tr;
					imag[i]=ui+ti;
					real[j]=ur-tr;
					imag[j]=ui-ti;
				}
			}
		}
		// Convert undo initial DCT permutation.
		for (let i=0;i<nlen;i++) {
			let j=(i&1)?(nlen-1-(i>>1)):(i>>1);
			imag[i]=real[j];
		}
		return imag;
	}


	static dctsample(arr,idx) {
		// Computes an individual coefficient of the DCT.
		let len=arr.length;
		let sum=0;
		if (idx===0) {
			for (let i=0;i<len;i++) {sum+=arr[i];}
			return sum/len;
		}
		let inc=Math.PI*(idx/len),ang=inc*0.5;
		for (let i=0;i<len;i++) {
			sum+=Math.cos(ang)*arr[i];
			ang+=inc;
		}
		return sum*2/len;
	}


	static idctsample(arr,idx) {
		// Computes an element of the original array given DCT coefficients.
		let len=arr.length;
		let inc=Math.PI*(idx+0.5)/len,ang=0,sum=0;
		for (let i=0;i<len;i++) {
			sum+=Math.cos(ang)*arr[i];
			ang+=inc;
		}
		return sum;
	}

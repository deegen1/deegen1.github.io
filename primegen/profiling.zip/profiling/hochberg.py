#Tim Hochberg
#License: https://docs.python.org/3/license.html

def primegen():
	yield 2
	D = {}
	q = 3
	while True:
		p = D.pop(q, 0)
		if p:
			x = q + p
			while x in D: x += p
			D[x] = p
		else:
			yield q
			D[q*q] = 2*q
		q += 2

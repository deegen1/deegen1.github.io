#Will Ness
#License: https://docs.python.org/3/license.html

def postponed_sieve():                    # postponed sieve, by Will Ness      
  yield 2; yield 3; yield 5; yield 7;     #        http://ideone.com/WFv4f
  D = {}                                  # based on original code by
  c = 9                                   #   David Eppstein, UC Irvine, 28 Feb 2002
  ps = (p for p in postponed_sieve())     #   from http://code.activestate.com/
  p = ps.next() and ps.next()             # 3       recipes/117119-sieve-of-eratosthenes/
  q = p*p                                 # 9
  while True:
    if c not in D:
        if c < q: yield c
        else:
            add(D,c + 2*p,2*p)
            p=ps.next()
            q=p*p
    else:
        s = D.pop(c)
        add(D,c + s,s)
    c += 2

def add(D,x,s):
  while x in D: x += s
  D[x] = s

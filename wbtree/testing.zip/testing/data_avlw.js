/*


data.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
History


1.00
     Added weight balanced tree.
1.01
     Added linked list.
     Simplified find() branching.
     Replaced Object.is() with === since it's slightly faster.


--------------------------------------------------------------------------------
Notes


A weight balanced search tree implementation.

Balancing is performed by keeping the weights of children within a ratio of 2.5.

Because weights are used, we can lexicographically index nodes. Ex: tree[0] will
return the smallest node in the tree.

Adding and removing values are stable with respect to sorting.

weight(null) = 0

Tree height < 2.07 * log2(nodes+1)


--------------------------------------------------------------------------------
TODO


Unit tests.
Performance test. Unroll rebalance()?
Remake as AVL tree but track height and weight.
	tinder metrics - we track height and weight
Red-black stored in bottom bit?
Debug
	Use weight=0 to mark if node is in a tree.
	Add sanity checks when adding or removing nodes.
	tree.clear() sets weight=0 for all nodes.
Add double linked list.


let tree=new Tree((l,r)=>l[0]-r[0]);
tree.add([5,"Friday"]);
tree.add([5,"Friday2"]);
tree.add([3,"Wednesday"]);
tree.add([1,"Monday"]);
tree.add([6,"Saturday"]);
tree.add([2,"Tuesday"]);
tree.add([4,"Thursday"]);
tree.remove([6,"Saturday"]);
console.log("iter:");
for (let node of tree.iter()) {
	console.log(node.value);
}
console.log("index:");
for (let i=0;i<tree.length();i++) {
	console.log(tree.get(i).value);
}


*/
/* npx eslint data.js -c ../../standards/eslint.js */


//---------------------------------------------------------------------------------
// Data - v1.00


class ListLink {

	constructor(obj) {
		this.prev=null;
		this.next=null;
		this.list=null;
		this.obj=obj??null;
		this.idx=null;
	}


	release() {
		this.remove();
	}


	add(list) {
		if (this.list!==list) {list.add(this);}
	}


	remove(clear=false) {
		if (this.list!==null) {this.list.remove(this,clear);}
	}

}


export class List {

	static Link=ListLink;


	constructor(ptr=null) {
		this.head=null;
		this.tail=null;
		this.ptr=ptr;
		this.count=0;
	}


	release(clear=false) {
		let link=this.head;
		while (link!==null) {
			let next=link.next;
			link.prev=null;
			link.next=null;
			link.list=null;
			if (clear) {link.obj=null;}
			link=next;
		}
		this.count=0;
	}


	first() {return this.head;}
	last() {return this.tail;}


	*iter() {
		let link=null,next=this.head;
		while ((link=next)!==null) {
			next=link.next;
			yield link.obj;
		}
	}


	add(link) {
		this.addafter(link);
	}


	addafter(link,prev=null) {
		// Inserts the link after prev.
		link.remove();
		let next=null;
		if (prev!==null) {
			next=prev.next;
			prev.next=link;
		} else {
			next=this.head;
			this.head=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (next!==null) {
			next.prev=link;
		} else {
			this.tail=link;
		}
		this.count++;
	}


	addbefore(link,next=null) {
		// Inserts the link before next.
		link.remove();
		let prev=null;
		if (next!==null) {
			prev=next.prev;
			next.prev=link;
		} else {
			prev=this.tail;
			this.tail=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (prev!==null) {
			prev.next=link;
		} else {
			this.head=link;
		}
		this.count++;
	}


	remove(link,clear) {
		if (link===null) {
			return;
		}
		let prev=link.prev;
		let next=link.next;
		if (prev!==null) {
			prev.next=next;
		} else {
			this.head=next;
		}
		if (next!==null) {
			next.prev=prev;
		} else {
			this.tail=prev;
		}
		this.count--;
		link.prev=null;
		link.next=null;
		link.list=null;
		if (clear) {link.obj=null;}
	}

}


const HBITS=6;
//const MAXNODES=1<<(32-HBITS);
const WMASK=0xffffffc0;
const HMASK=0x0000003f;


class TreeNode {

	constructor(value) {
		this.weight=1;
		this.parent=null;
		this.left=null;
		this.right=null;
		this.value=value;
	}


	next() {
		// Given a node N, find the next ordered node. Ex: next(3)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a right child, R, the left-most child of R is the next node.
		// Otherwise, the nearest parent of N with N on the left is the next node.
		let node=this,child=this.right;
		if (child) {
			while (child) {node=child;child=child.left;}
		} else {
			while (node && node.right===child) {
				child=node;node=node.parent;
			}
		}
		return node;
	}


	prev() {
		// Given a node N, find the previous ordered node. Ex: prev(5)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a left child, L, the right-most child of L is the next node.
		// Otherwise, the nearest parent of N with N on the right is the next node.
		let node=this,child=this.left;
		if (child) {
			while (child) {node=child;child=child.right;}
		} else {
			while (node && node.left===child) {
				child=node;node=node.parent;
			}
		}
		return node;
	}


	rotleft() {
		// Raise z, lower x, and maintain the sorted order of the nodes.
		//
		//        A                B
		//       / \              / \
		//      x   B     ->     A   z
		//         / \          / \
		//        y   z        x   y
		//
		let a=this;
		let b=a.right;
		let r=b.left;
		b.parent=a.parent;
		b.left=a;
		a.parent=b;
		a.right=r;
		if (r) {r.parent=a;}
		a.calcweight();
		b.calcweight();
		return b;
	}


	rotright() {
		// Raise x, lower z, and maintain the sorted order of the nodes.
		//
		//          A            B
		//         / \          / \
		//        B   z   ->   x   A
		//       / \              / \
		//      x   y            y   z
		//
		let a=this;
		let b=a.left;
		let l=b.right;
		b.parent=a.parent;
		b.right=a;
		a.parent=b;
		a.left=l;
		if (l) {l.parent=a;}
		a.calcweight();
		b.calcweight();
		return b;
	}


	calcweight() {
		let l=this.left,r=this.right;
		let weight=1,height=0,w=0;
		if (l) {w=l.weight;weight+=w>>>HBITS;height=w&HMASK;}
		if (r) {w=r.weight;weight+=w>>>HBITS;w&=HMASK;height=height>w?height:w;}
		this.weight=(weight<<HBITS)|(height+1);
	}


	index() {
		// Returns the node's index within the tree. Ex: tree[node.index()]=node
		let idx=-1;
		let node=this,prev=this.right;
		while (node) {
			if (node.right===prev) {
				idx+=node.left?(node.left.weight>>>HBITS)+1:1;
			}
			prev=node;
			node=node.parent;
		}
		return idx;
	}

}


export class Tree {

	static Node=TreeNode;

	// Searching constants.
	static EQ=0;
	static EQG=1;
	static LT=2;
	static LE=3;
	static GT=4;
	static GE=5;

	// Duplicate behavior.
	static ADD    =0;
	static REPLACE=1;
	static DISCARD=2;


	static defcmp(l,r) {
		if (l<r) {return -1;}
		return r<l?1:0;
	}


	constructor(cmp=Tree.defcmp,duplicate=Tree.ADD) {
		// cmp(l,r) is expected to be a function where
		//
		//      cmp(l,r)<0 if l<r
		//      cmp(l,r)=0 if l=r
		//      cmp(l,r)>0 if l>r
		//
		this.cmp=cmp;
		this.duplicate=duplicate;
		this.root=null;
		this.length=0;
	}


	clear() {this.root=null;}


	get(i) {
		// Index nodes like an array.
		let node=this.root;
		let weight=node?(node.weight>>>HBITS):0;
		if (i<0) {i+=weight;}
		if (i<0 || i>=weight) {return null;}
		while (true) {
			let left=node.left;
			let lw=left?(left.weight>>>HBITS):0;
			if (i>lw) {
				i-=lw+1;
				node=node.right;
			} else if (i===lw) {
				break;
			} else {
				node=left;
			}
		}
		return node;
	}


	*iter() {
		// Iterate over all nodes in ascending order.
		let node=this.first();
		while (node) {
			yield node;
			node=node.next();
		}
	}


	first() {
		// Return the smallest node in the tree.
		let node=this.root,ret=null;
		while (node) {ret=node;node=node.left;}
		return ret;
	}


	last() {
		// Return the greatest node in the tree.
		let node=this.root,ret=null;
		while (node) {ret=node;node=node.right;}
		return ret;
	}


	find(value,mode=Tree.EQ) {
		// Search for a specific value or inequality.
		//
		//      EQ : Return the least    node=value.
		//      EQG: Return the greatest node=value.
		//      LT : Return the greatest node<value.
		//      LE : Return the greatest node<=value.
		//      GT : Return the least    node>value.
		//      GE : Return the least    node>=value.
		//
		let node=this.root,ret=null;
		let cmp=this.cmp;
		let set=(0x34652>>>(mode*3))&7;
		let right=1|((0x34>>>mode)&2);
		while (node!==null) {
			let c=cmp(node.value,value);
			let bit=1<<(1+(c>0)-(c<0));
			ret=(set&bit)?node:ret;
			node=(right&bit)?node.right:node.left;
		}
		return ret;
	}


	addnode(orig) {
		// Find a leaf node to add the new value to. Then rebalance from the new node on
		// up. By traversing right when cmp<=0, this algorithm is stable.
		let value=orig.value;
		let node=this.root,prev=null;
		let cmp=this.cmp;
		let dup=this.duplicate,c=0;
		while (node) {
			c=cmp(node.value,value);
			if (c===0 && dup) {
				if (dup===Tree.DISCARD) {return null;}
				node.value=value;
				return node;
			}
			prev=node;
			node=c>0?node.left:node.right;
		}
		this.length++;
		orig.weight=(1<<HBITS)|1;
		orig.left=null;
		orig.right=null;
		orig.parent=prev;
		if (prev===null) {
			this.root=orig;
		} else {
			if (c>0) {prev.left=orig;}
			else     {prev.right=orig;}
			this.rebalance(prev);
		}
		return orig;
	}


	add(value) {
		return this.addnode(new TreeNode(value));
	}


	removenode(node) {
		// Remove a specific node. We can remove a node by swapping it with its successor
		// to maintain order and stability sorting-wise. Then, rebalance from the successor
		// on up.
		//
		//           Case 1          |          Case 2           |          Case 3
		//                           |                           |
		//   N is the right-most     |  X is a distant child of  |  X is the right child of
		//   child in the tree.      |  N. Balance from C up.    |  N. Balance from X up.
		//   Balance from D up.      |                           |
		//                           |                           |
		//     B              B      |    N              X       |     N              X
		//    / \            / \     |   / \            / \      |    / \            / \
		//   A   D     ->   A   D    |  A   C          A   C     |   A   X     ->   A   B
		//      / \            / \   |     / \    ->      / \    |      / \
		//     C   N          C   X  |    X   D          B   D   |     *   B
		//        / \                |   / \                     |
		//       X   *               |  *   B                    |
		//
		let p=node.parent;
		let l=node.left,r=node.right;
		let next=null,bal=null;
		if (r===null) {
			// Case 1
			bal=p;next=l;l=null;
		} else if (r.left) {
			// Case 2
			next=r;
			while (next.left) {bal=next;next=next.left;}
			let c=next.right;
			bal.left=c;
			if (c) {c.parent=bal;}
		} else {
			// Case 3
			bal=r;next=r;r=null;
		}
		this.length--;
		// Replace node with next.
		if (p===null) {this.root=next;}
		else if (p.left===node) {p.left=next;}
		else {p.right=next;}
		if (next) {
			next.parent=p;
			if (l) {next.left=l;l.parent=next;}
			if (r) {next.right=r;r.parent=next;}
		}
		this.rebalance(bal);
	}


	remove(value) {
		// Remove a node given a value.
		let node=this.find(value);
		if (node) {this.removenode(node);}
		return node;
	}


	rebalance(next) {
		// Rebalance from next upward. If 2 children differ in weight by a ratio of 2.5 or
		// more, we can rotate to rebalance.
		function Weight(n) {return n?(n.weight>>>HBITS):0;}
		function Height(n) {return n?(n.weight&HMASK):0;}
		while (next!==null) {
			let node=next,orig=next;
			next=node.parent;
			let l=node.left,r=node.right;
			let lh=Height(l),rh=Height(r);
			if (rh+1<lh) {
				// Leaning to the left.
				if (Height(l.left)+1<lh) {node.left=l.rotleft();}
				node=node.rotright();
			} else if (lh+1<rh) {
				// Leaning to the right.
				if (Height(r.right)+1<rh) {node.right=r.rotright();}
				node=node.rotleft();
			} else {
				// Balanced.
				let lw=Weight(l),rw=Weight(r);
				node.weight=((lw+rw+1)<<HBITS)|((lh>rh?lh:rh)+1);
				continue;
			}
			if (next===null) {this.root=node;}
			else if (next.left===orig) {next.left=node;}
			else {next.right=node;}
		}
	}

}


"""
AVLTree.py - v1.07

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


An AVL search tree implementation.

Balancing is performed by keeping the heights of children within +-1 of
eachother (AVL).

Adding and removing are stable with respect to sorting.

height(null) = 0

Tree height < 1.44 * log2(nodes+1)


"""

class AVLTree(object):
	# Searching constants.
	EQ,EQG,LT,LE,GT,GE=0,1,2,3,4,5


	class Node(object):
		def __init__(self,value):
			self.value=value
			self.parent=None
			self.left=None
			self.right=None
			self.height=0


		def next(node):
			# Given a node N, find the next ordered node. Ex: next(3)=4.
			#
			#            4
			#           / \
			#          /   \
			#         2     6
			#        / \   / \
			#       1   3 5   7
			#
			# If N has a right child, R, the left-most child of R is the next node.
			# Otherwise, the nearest parent of N with N on the left is the next node.
			child=node.right
			if child:
				while child: node,child=child,child.left
			else:
				while node and node.right is child:
					child,node=node,node.parent
			return node


		def prev(node):
			# Given a node N, find the previous ordered node. Ex: prev(5)=4.
			#
			#            4
			#           / \
			#          /   \
			#         2     6
			#        / \   / \
			#       1   3 5   7
			#
			# If N has a left child, L, the right-most child of L is the next node.
			# Otherwise, the nearest parent of N with N on the right is the next node.
			child=node.left
			if child:
				while child: node,child=child,child.right
			else:
				while node and node.left is child:
					child,node=node,node.parent
			return node


		def rotleft(a):
			# Raise z, lower x, and maintain the sorted order of the nodes.
			#
			#        A                B
			#       / \              / \
			#      x   B     ->     A   z
			#         / \          / \
			#        y   z        x   y
			#
			b=a.right
			r=b.left
			b.parent=a.parent
			b.left=a
			a.parent=b
			a.right=r
			if r: r.parent=a
			a.calcheight()
			b.calcheight()
			return b


		def rotright(a):
			# Raise x, lower z, and maintain the sorted order of the nodes.
			#
			#          A            B
			#         / \          / \
			#        B   z   ->   x   A
			#       / \              / \
			#      x   y            y   z
			#
			b=a.left
			l=b.right
			b.parent=a.parent
			b.right=a
			a.parent=b
			a.left=l
			if l: l.parent=a
			a.calcheight()
			b.calcheight()
			return b


		def calcheight(self):
			l,r=self.left,self.right
			lh=l.height if l else 0
			rh=r.height if r else 0
			self.height=(lh if lh>rh else rh)+1


	def __init__(self,cmp=None,unique=False):
		# If unique is True, then duplicate values will overwrite eachother.
		def defcmp(l,r):
			if r<l: return 1
			if l<r: return -1
			return 0
		self.cmp=defcmp if cmp is None else cmp
		self.unique=unique
		self.root=None


	def clear(self):
		self.root=None


	def __iter__(self):
		# Iterate over all nodes.
		node=self.first()
		while node:
			yield node
			node=node.next()


	def first(self):
		# Return the smallest node of the tree.
		node,ret=self.root,None
		while node: ret,node=node,node.left
		return ret


	def last(self):
		# Return the greatest node of the tree.
		node,ret=self.root,None
		while node: ret,node=node,node.right
		return ret


	def find(self,value,flag=EQ):
		# Search for a specific value or inequality.
		#
		#      EQ : Return the least    node=value.
		#      EQG: Return the greatest node=value.
		#      LT : Return the greatest node<value.
		#      LE : Return the greatest node<=value.
		#      GT : Return the least    node>value.
		#      GE : Return the least    node>=value.
		#
		node,ret=self.root,None
		unique,cmp=self.unique,self.cmp
		lset  =(False,False,True ,True ,False,False)[flag]
		rset  =(False,False,False,False,True ,True )[flag]
		eset  =(True ,True ,False,True ,False,True )[flag]
		eright=(False,True ,False,True ,True ,False)[flag]
		while node:
			c=cmp(node.value,value)
			if c<0:
				if lset: ret=node
				node=node.right
			elif c>0:
				if rset: ret=node
				node=node.left
			else:
				if eset:
					ret=node
					if unique: break
				node=node.right if eright else node.left
		return ret


	def add(self,value):
		# Find a leaf node to add the new key to. Then rebalance from the new node on up.
		# By traversing left when cmp<0, this algorithm is stable.
		prev,node=None,self.root
		unique=0 if self.unique else None
		c,cmp=0,self.cmp
		while node:
			prev=node
			c=cmp(value,node.value)
			if c==unique:
				node.value=value
				return node
			if c<0: node=node.left
			else  : node=node.right
		node=AVLTree.Node(value)
		node.parent=prev
		if c<0: prev.left=node
		self.rebalance(node)
		return node


	def remove(self,value):
		# Remove a node given a value.
		node=self.find(value)
		if node is None: raise KeyError("Value not in tree: "+str(value))
		self.removenode(node)
		return node


	def removenode(self,node):
		# Remove a specific node. We can remove a node by swapping it with its successor
		# to maintain order and stability sorting-wise. Then, rebalance from the successor
		# on up.
		#
		#           Case 1          |          Case 2           |          Case 3
		#                           |                           |
		#   N is the right-most     |  X is a distant child of  |  X is the right child of
		#   child in the tree.      |  N. Balance from C up.    |  N. Balance from X up.
		#   Balance from D up.      |                           |
		#                           |                           |
		#     B              B      |    N              X       |     N              X
		#    / \            / \     |   / \            / \      |    / \            / \
		#   A   D     ->   A   D    |  A   C          A   C     |   A   X     ->   A   B
		#      / \            / \   |     / \    ->      / \    |      / \
		#     C   N          C   X  |    X   D          B   D   |     *   B
		#        / \                |   / \                     |
		#       X   *               |  *   B                    |
		#
		p=node.parent
		l,r=node.left,node.right
		if r is None:
			# Case 1
			bal,next,l=p,l,None
		elif r.left:
			# Case 2
			next=r
			while next.left: bal,next=next,next.left
			c=next.right
			bal.left=c
			if c: c.parent=bal
			next.height=node.height
		else:
			# Case 3
			bal,next,r=r,r,None
			next.height=node.height
		# Replace node with next.
		if p is None: self.root=next
		elif p.left is node: p.left=next
		else: p.right=next
		if next:
			next.parent=p
			if l: next.left,l.parent=l,next
			if r: next.right,r.parent=r,next
		self.rebalance(bal)


	def rebalance(self,node):
		# Rebalance from node upward. If 2 children differ in height by 2 or more, we can
		# rotate to rebalance. If a node's height hasn't changed, we can stop balancing.
		def H(n): return n.height if n else 0
		while node:
			orig,p=node,node.parent
			l,r=node.left,node.right
			lh,rh,nh=H(l),H(r),node.height
			if rh+1<lh:
				if H(l.left)+1<lh: node.left=l.rotleft()
				node=node.rotright()
			elif lh+1<rh:
				if H(r.right)+1<rh: node.right=r.rotright()
				node=node.rotleft()
			else:
				node.height=(lh if lh>rh else rh)+1
			if p is None: self.root=node
			elif p.left is orig: p.left=node
			else: p.right=node
			if node.height==nh: break
			node=p


if __name__=="__main__":
	# Example usage.

	tree=AVLTree()
	tree.add((5,"Friday"))
	tree.add((3,"Wednesday"))
	tree.add((1,"Monday"))
	tree.add((6,"Saturday"))
	tree.add((2,"Tuesday"))
	tree.add((4,"Thursday"))
	tree.remove((6,"Saturday"))

	for node in tree:
		print("{0}: {1}".format(*node.value))


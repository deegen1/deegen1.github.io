mulx,muly=40,60
r,stroke=17,2
nodearr=(
	(0,0,"1",None),
	(-2,1,"0",0),(2,1,"2",0),
	(3,2,"3",2),
	(4,3,"4",3)
)
offx,offy=10000,10000
for node in nodearr:
	offx=min(offx,node[0])
	offy=min(offy,node[1])
offx=-offx*mulx+r+stroke
offy=-offy*muly+r+stroke
nodes=len(nodearr)
circles=[]
lines=[]
strings=[]
nulls=[]
for i in range(nodes):
	x,y,s,p=nodearr[i]
	x=x*mulx+offx
	y=y*muly+offy
	circles+=[(x,y,r)]
	if p!=None:
		x1,y1,s1,p1=nodearr[p]
		x1=x1*mulx+offx
		y1=y1*muly+offy
		lines+=[(x,y,x1,y1)]
	add=[(x,y+1,s)]
	if s=="NUL": nulls+=add
	else: strings+=add
print("<svg version=\"1.1\" viewBox=\"0 0 1000 300\" class=\"treesvg\">")
print("<g transform=\"translate(0,0)\">")
for line in lines:
	print("\t<line x1=\"{0}\" y1=\"{1}\" x2=\"{2}\" y2=\"{3}\"/>".format(*line))
print("\t<g class=\"bgfill highstroke\">")
for circle in circles:
	print("\t\t<circle cx=\"{0}\" cy=\"{1}\" r=\"{2}\"/>".format(*circle))
print("\t</g>")
print("\t<g text-anchor=\"middle\">")
for string in strings:
	x,y,s=string
	if s: print("\t\t<text x=\"{0}\" y=\"{1}\" dy=\"0.3em\">{2}</text>".format(x,y,s))
print("\t</g>")
if nulls:
	print("\t<g text-anchor=\"middle\" style=\"font-size:80%\">")
	for string in nulls:
		x,y,s=string
		if s: print("\t\t<text x=\"{0}\" y=\"{1}\" dy=\"0.3em\">{2}</text>".format(x,y,s))
	print("\t</g>")
print("</g>")
print("</svg>")
"""
#Large tree
offx,offy=350,27
nodearr=(
	(0,0,"7",None),
	(-4,1,"3",0),(4,1,"11",0),
	(-6,2,"1",1),(-2,2,"5",1),(2,2,"9",2),(6,2,"13",2),
	(-7,3,"0",3),(-5,3,"2",3),(-3,3,"4",4),(-1,3,"6",4),
	(1,3,"8",5),(3,3,"10",5),(5,3,"12",6),(7,3,"14",6)
)

#Left rotation 1
offx,offy=58,18
nodearr=(
	(0,0,"A",None),
	(-1,1,"x",0),(1,1,"B",0),
	(0,2,"y",2),(2,2,"z",2)
)

#Left rotation 2
offx,offy=98,18
nodearr=(
	(0,0,"B",None),
	(-1,1,"A",0),(1,1,"z",0),
	(-2,2,"x",1),(0,2,"y",1)
)

#Left leaning
nodearr=(
	(0,0,"5",None),
	(-2,1,"3",0),(2,1,"6",0),
	(-3,2,"2",1),(-1,2,"4",1),
	(-4,3,"1",3)
)

#Right rotation 1
nodearr=(
	(0,0,"3",None),
	(-2,1,"2",0),(2,1,"5",0),
	(-3,2,"1",1),(1,2,"4",2),(3,2,"6",2)
)

#Left incorrect
nodearr=(
	(0,0,"5",None),
	(-3,1,"2",0),(3,1,"6",0),
	(-5,2,"1",1),(-1,2,"3",1),
	(0,3,"4",4)
)

#Right incorrect
nodearr=(
	(0,0,"2",None),
	(-3,1,"1",0),(3,1,"5",0),
	(1,2,"3",2),(5,2,"6",2),
	(2,3,"4",3)
)

#Middle correct
nodearr=(
	(0,0,"5",None),
	(-3,1,"3",0),(3,1,"6",0),
	(-5,2,"2",1),(-1,2,"4",1),
	(-6,3,"1",3),
)

#Right correct
nodearr=(
	(0,0,"3",None),
	(-3,1,"2",0),(3,1,"5",0),
	(-4,2,"1",1),(1,2,"4",2),(5,2,"6",2)
)

#Searching
nodearr=(
	(0,0,"3",None),
	(-3,1,"2",0),(3,1,"5",0),
	(-4,2,"1",1),(1,2,"4",2),(5,2,"6",2),
)

#Adding left
nodearr=(
	(0,0,"1",None),
	(-2,1,"0",0),(2,1,"2",0),
	(3,2,"3",2),
	(4,3,"NUL",3)
)

#Adding right
nodearr=(
	(0,0,"1",None),
	(-2,1,"0",0),(2,1,"2",0),
	(-3,2,"NUL",1),(-1,2,"NUL",1),(1,2,"NUL",2),(3,2,"3",2),
	(2,3,"NUL",6),(4,3,"4",6),
	(3,4,"NUL",8),(5,4,"NUL",8)
)

#Adding balanced
nodearr=(
	(0,0,"1",None),
	(-3,1,"0",0),(3,1,"3",0),
	(-4,2,"NUL",1),(-2,2,"NUL",1),(1,2,"2",2),(5,2,"4",2),
	(0,3,"NUL",5),(2,3,"NUL",5),(4,3,"NUL",6),(6,3,"NUL",6)
)

#Traversal
nodearr=(
	(0,0,"4",None),
	(-2,1,"2",0),(2,1,"6",0),
	(-3,2,"1",1),(-1,2,"3",1),(1,2,"5",2),(3,2,"7",2)
)

#Remove case 1
nodearr=(
	(0,0,"1",None),
	(-1,1,"0",0),(1,1,"4",0),
	(0,2,"3",2),(2,2,"NUL",2),
	(-1,3,"1",3),(1,3,"2",3)
)

#Remove case 2
nodearr=(
	(0,0,"1",None),
	(-1,1,"0",0),(1,1,"3",0),
	(0,2,"2",2),(2,2,"4",2),
	(1,3,"NUL",4),(3,3,"5",4)
)
"""


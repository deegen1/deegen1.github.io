/*


data.js - v2.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
History


1.00
     Added weight balanced tree.
2.00
     Added linked list.
     Simplified Tree.find() branching.
     Node attributes are now nullified on removal.
     Added checks for re-adding or re-removing nodes.
     Replaced Object.is() with === since it's slightly faster.
     Using explicit null comparisons if(node!==null) is 7% faster.
     Unrolling rotations in Tree.rebalance() is 8% faster.
     Using w*5+2 instead of w*5+0 for the second invariant has 2% fewer
     rotations and similar heights.


--------------------------------------------------------------------------------
Notes


Tree balancing is performed by keeping child weights within a ratio of 2.5.

Weight balancing allows indexing nodes. Ex: tree[0] returns the smallest node.

Adding and removing values are stable with respect to sorting.

weight(null) = 0

Tree height < 2.07 * log2(nodes+1)


--------------------------------------------------------------------------------
TODO


Retry perfect balancing.


*/
/* npx eslint data.js -c ../../standards/eslint.js */


//---------------------------------------------------------------------------------
// Data - v2.00


class ListLink {

	constructor(obj) {
		this.prev=null;
		this.next=null;
		this.list=null;
		this.obj=obj??null;
		this.idx=null;
	}


	release() {this.remove();}


	add(list) {list.add(this);}


	remove(clear=false) {
		let list=this.list;
		if (list!==null) {list.remove(this,clear);}
		return list;
	}

}


export class List {

	static Link=ListLink;


	constructor(ptr=null) {
		this.head=null;
		this.tail=null;
		this.ptr=ptr;
		this.count=0;
	}


	release(clear=false) {
		let link=this.head;
		while (link!==null) {
			let next=link.next;
			link.prev=null;
			link.next=null;
			link.list=null;
			if (clear) {link.obj=null;}
			link=next;
		}
		this.count=0;
	}


	first() {return this.head;}


	last() {return this.tail;}


	*iter() {
		let link=null,next=this.head;
		while ((link=next)!==null) {
			next=link.next;
			yield link.obj;
		}
	}


	add(value) {
		let link=new ListLink(value);
		this.addafter(link);
		return link;
	}


	addlink(link) {
		this.addafter(link);
	}


	addafter(link,prev=null) {
		// Inserts the link after prev.
		if (link.list!==null) {throw "link already in list";}
		let next=null;
		if (prev!==null) {
			next=prev.next;
			prev.next=link;
		} else {
			next=this.head;
			this.head=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (next!==null) {
			next.prev=link;
		} else {
			this.tail=link;
		}
		this.count++;
	}


	addbefore(link,next=null) {
		// Inserts the link before next.
		if (link.list!==null) {throw "link already in list";}
		let prev=null;
		if (next!==null) {
			prev=next.prev;
			next.prev=link;
		} else {
			prev=this.tail;
			this.tail=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (prev!==null) {
			prev.next=link;
		} else {
			this.head=link;
		}
		this.count++;
	}


	remove(link,clear) {
		if (link===null) {return;}
		let list=link.list;
		if (list===null) {return;}
		if (list!==this) {throw "removing from wrong list";}
		let prev=link.prev;
		let next=link.next;
		if (prev!==null) {
			prev.next=next;
		} else {
			this.head=next;
		}
		if (next!==null) {
			next.prev=prev;
		} else {
			this.tail=prev;
		}
		this.count--;
		link.prev=null;
		link.next=null;
		link.list=null;
		if (clear) {link.obj=null;}
	}

}


class TreeNode {

	constructor(value) {
		this.weight=0;
		this.parent=null;
		this.left=null;
		this.right=null;
		this.value=value;
	}


	next() {
		// Given a node N, find the next ordered node. Ex: next(3)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a right child, R, the left-most child of R is the next node.
		// Otherwise, the nearest parent of N with N on the left is the next node.
		let node=this,child=this.right;
		if (child!==null) {
			do {node=child;child=child.left;} while (child!==null);
		} else {
			do {child=node;node=node.parent;} while (node!==null && node.right===child);
		}
		return node;
	}


	prev() {
		// Given a node N, find the previous ordered node. Ex: prev(5)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a left child, L, the right-most child of L is the next node.
		// Otherwise, the nearest parent of N with N on the right is the next node.
		let node=this,child=this.left;
		if (child!==null) {
			do {node=child;child=child.right;} while (child!==null);
		} else {
			do {child=node;node=node.parent;} while (node!==null && node.left===child);
		}
		return node;
	}


	index() {
		// Returns the node's index within the tree. Ex: tree[node.index()]=node
		let idx=-1;
		let node=this,prev=this.right;
		do {
			if (node.right===prev) {
				let l=node.left;
				idx+=l!==null?l.weight+1:1;
			}
			prev=node;
			node=node.parent;
		} while (node!==null);
		return idx;
	}

}


export class Tree {

	static Node=TreeNode;

	// Searching constants.
	static EQ=0;
	static EQG=1;
	static LT=2;
	static LE=3;
	static GT=4;
	static GE=5;

	// Duplicate behavior.
	static ADD    =0;
	static REPLACE=1;
	static DISCARD=2;


	static defcmp(l,r) {
		if (l<r) {return -1;}
		return r<l?1:0;
	}


	constructor(cmp=null,duplicate=Tree.ADD) {
		// cmp(l,r) is expected to be a function where
		//
		//      cmp(l,r)<0 if l<r
		//      cmp(l,r)=0 if l=r
		//      cmp(l,r)>0 if l>r
		//
		this.cmp=cmp??Tree.defcmp;
		this.duplicate=duplicate;
		this.root=null;
		this.length=0;
	}


	release() {
		let node=null;
		while ((node=this.root)!==null) {
			this.removenode(node);
		}
	}


	first() {
		// Return the smallest node in the tree.
		let node=this.root,ret=null;
		while (node!==null) {ret=node;node=node.left;}
		return ret;
	}


	last() {
		// Return the greatest node in the tree.
		let node=this.root,ret=null;
		while (node!==null) {ret=node;node=node.right;}
		return ret;
	}


	*iter() {
		// Iterate over all nodes in ascending order.
		let node=this.first();
		while (node!==null) {
			let next=node.next();
			yield node;
			node=next;
		}
	}


	get(i) {
		// Index nodes like an array.
		let node=this.root;
		let weight=node!==null?node.weight:0;
		if (i<0) {i+=weight;}
		if (i<0 || i>=weight) {return null;}
		while (true) {
			let l=node.left;
			let lw=l!==null?l.weight:0;
			if (i>=lw) {
				i-=lw+1;
				if (i<0) {break;}
				node=node.right;
			} else {
				node=l;
			}
		}
		return node;
	}


	find(value,mode=Tree.EQ) {
		// Search for a specific value or inequality.
		//
		//      EQ : Return the least    node=value.
		//      EQG: Return the greatest node=value.
		//      LT : Return the greatest node<value.
		//      LE : Return the greatest node<=value.
		//      GT : Return the least    node>value.
		//      GE : Return the least    node>=value.
		//
		let node=this.root,ret=null;
		let cmp=this.cmp;
		let set=0x34652>>>(mode*3);
		let right=1|((0x34>>>mode)&2);
		while (node!==null) {
			let c=cmp(node.value,value);
			let bit=1<<(1+(c>0)-(c<0));
			ret=(set&bit)?node:ret;
			node=(right&bit)?node.right:node.left;
		}
		return ret;
	}


	add(value) {
		return this.addnode(new TreeNode(value));
	}


	remove(value) {
		// Remove a node given a value.
		let node=this.find(value);
		if (node!==null) {this.removenode(node);}
		return node;
	}


	addnode(node) {
		// Find a leaf node to add the new value to. Then rebalance from the new node on
		// up. By traversing right when cmp<=0, this algorithm is stable.
		if (node.weight) {throw "node already in tree";}
		let value=node.value;
		let trav=this.root,prev=null;
		let cmp=this.cmp;
		let dup=this.duplicate,c=0;
		while (trav!==null) {
			c=cmp(trav.value,value);
			if (c===0 && dup) {
				if (dup===Tree.DISCARD) {return null;}
				trav.value=value;
				return trav;
			}
			prev=trav;
			trav=c>0?trav.left:trav.right;
		}
		this.length++;
		node.weight=1;
		node.parent=prev;
		if (prev!==null) {
			if (c>0) {prev.left=node;}
			else     {prev.right=node;}
			this.rebalance(prev);
		} else {
			this.root=node;
		}
		return node;
	}


	removenode(node) {
		// Remove a specific node. We can remove a node by swapping it with its successor
		// to maintain order and stability sorting-wise. Then, rebalance from the successor
		// on up.
		//
		//           Case 1          |          Case 2           |          Case 3
		//                           |                           |
		//   N is the right-most     |  X is a distant child of  |  X is the right child of
		//   child in the tree.      |  N. Balance from C up.    |  N. Balance from X up.
		//   Balance from D up.      |                           |
		//                           |                           |
		//     B              B      |    N              X       |     N              X
		//    / \            / \     |   / \            / \      |    / \            / \
		//   A   D     ->   A   D    |  A   C          A   C     |   A   X     ->   A   B
		//      / \            / \   |     / \    ->      / \    |      / \
		//     C   N          C   X  |    X   D          B   D   |     *   B
		//        / \                |   / \                     |
		//       X   *               |  *   B                    |
		//
		if (!node.weight) {throw "double removal";}
		let p=node.parent,l=node.left,r=node.right;
		node.weight=0;
		node.parent=null;
		node.left=null;
		node.right=null;
		let next=null,bal=null;
		if (r===null) {
			// Case 1
			bal=p;next=l;l=null;
		} else if (r.left!==null) {
			// Case 2
			next=r;
			while (next.left!==null) {bal=next;next=next.left;}
			let c=next.right;
			bal.left=c;
			if (c!==null) {c.parent=bal;}
		} else {
			// Case 3
			bal=r;next=r;r=null;
		}
		this.length--;
		// Replace node with next.
		if (p===null) {this.root=next;}
		else if (p.left===node) {p.left=next;}
		else {p.right=next;}
		if (next!==null) {
			next.parent=p;
			if (l!==null) {next.left=l;l.parent=next;}
			if (r!==null) {next.right=r;r.parent=next;}
		}
		this.rebalance(bal);
	}


	rebalance(next) {
		// Rebalance from next upward. If 2 children differ in weight by a ratio of 2.5 or
		// more, we can rotate to rebalance.
		while (next!==null) {
			let n=next,orig=next;
			next=next.parent;
			let l=n.left,r=n.right;
			let lw=l!==null?l.weight:0;
			let rw=r!==null?r.weight:0;
			if (rw*5+2<lw*2) {
				// Leaning to the left.
				r=l.right;
				let a=l.left;
				let aw=a!==null?a.weight:0,nw=rw;
				if (aw*5+2<lw*2) {
					// Left rotate L, then right rotate N.
					//
					//          N                N               R
					//         / \              / \             / \
					//        L   d            R   d           /   \
					//       / \      ->      / \      ->     L     N
					//      a   R            L   c           / \   / \
					//         / \          / \             a   b c   d
					//        b   c        a   b
					//
					let b=r.left;
					l.parent=r;
					l.right=b;
					if (b!==null) {
						b.parent=l;
						aw+=b.weight;
					}
					l.weight=aw+1;
					r.left=l;l=r;
					r=r.right;
				}
				// Right rotate N.
				//
				//          N            L
				//         / \          / \
				//        L   c   ->   a   N
				//       / \              / \
				//      a   b            b   c
				//
				n.parent=l;
				n.left=r;
				if (r!==null) {
					r.parent=n;
					nw+=r.weight;
				}
				n.weight=nw+1;
				l.parent=next;
				l.right=n;
				n=l;
			} else if (lw*5+2<rw*2) {
				// Leaning to the right.
				l=r.left;
				let d=r.right;
				let dw=d!==null?d.weight:0,nw=lw;
				if (dw*5+2<rw*2) {
					// Right rotate R, then left rotate N.
					let c=l.right;
					r.parent=l;
					r.left=c;
					if (c!==null) {
						c.parent=r;
						dw+=c.weight;
					}
					r.weight=dw+1;
					l.right=r;r=l;
					l=l.left;
				}
				// Left rotate N.
				n.parent=r;
				n.right=l;
				if (l!==null) {
					l.parent=n;
					nw+=l.weight;
				}
				n.weight=nw+1;
				r.parent=next;
				r.left=n;
				n=r;
			}
			n.weight=lw+rw+1;
			if (n===orig) {continue;}
			if (next===null) {this.root=n;}
			else if (next.left===orig) {next.left=n;}
			else {next.right=n;}
		}
	}

}


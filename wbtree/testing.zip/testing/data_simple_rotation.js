/*


data.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
History


1.00
     Added weight balanced tree.
2.00
     Added linked list.
     Simplified Tree.find() branching.
     Replaced Object.is() with === since it's slightly faster.
     Added explicit null comparisons instead of if(node).
     Removing a node nullifies attributes. Added checks for double removal.


--------------------------------------------------------------------------------
Notes


A weight balanced search tree implementation.

Balancing is performed by keeping the weights of children within a ratio of 2.5.

Because weights are used, we can lexicographically index nodes. Ex: tree[0] will
return the smallest node in the tree.

Adding and removing values are stable with respect to sorting.

weight(null) = 0

Tree height < 2.07 * log2(nodes+1)


--------------------------------------------------------------------------------
TODO


add logic for double removenode() error
use x*5+2 for second invariant, measure avg height
Retry perfect balancing.


*/
/* npx eslint data.js -c ../../standards/eslint.js */


//---------------------------------------------------------------------------------
// Data - v1.00


class ListLink {

	constructor(obj) {
		this.prev=null;
		this.next=null;
		this.list=null;
		this.obj=obj??null;
		this.idx=null;
	}


	release() {
		this.remove();
	}


	add(list) {
		if (this.list!==list) {list.add(this);}
	}


	remove(clear=false) {
		if (this.list!==null) {this.list.remove(this,clear);}
	}

}


export class List {

	static Link=ListLink;


	constructor(ptr=null) {
		this.head=null;
		this.tail=null;
		this.ptr=ptr;
		this.count=0;
	}


	release(clear=false) {
		let link=this.head;
		while (link!==null) {
			let next=link.next;
			link.prev=null;
			link.next=null;
			link.list=null;
			if (clear) {link.obj=null;}
			link=next;
		}
		this.count=0;
	}


	first() {return this.head;}
	last() {return this.tail;}


	*iter() {
		let link=null,next=this.head;
		while ((link=next)!==null) {
			next=link.next;
			yield link.obj;
		}
	}


	add(link) {
		this.addafter(link);
	}


	addafter(link,prev=null) {
		// Inserts the link after prev.
		link.remove();
		let next=null;
		if (prev!==null) {
			next=prev.next;
			prev.next=link;
		} else {
			next=this.head;
			this.head=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (next!==null) {
			next.prev=link;
		} else {
			this.tail=link;
		}
		this.count++;
	}


	addbefore(link,next=null) {
		// Inserts the link before next.
		link.remove();
		let prev=null;
		if (next!==null) {
			prev=next.prev;
			next.prev=link;
		} else {
			prev=this.tail;
			this.tail=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (prev!==null) {
			prev.next=link;
		} else {
			this.head=link;
		}
		this.count++;
	}


	remove(link,clear) {
		if (link===null) {
			return;
		}
		let prev=link.prev;
		let next=link.next;
		if (prev!==null) {
			prev.next=next;
		} else {
			this.head=next;
		}
		if (next!==null) {
			next.prev=prev;
		} else {
			this.tail=prev;
		}
		this.count--;
		link.prev=null;
		link.next=null;
		link.list=null;
		if (clear) {link.obj=null;}
	}

}


class TreeNode {

	constructor(value) {
		this.weight=0;
		this.parent=null;
		this.left=null;
		this.right=null;
		this.value=value;
	}


	next() {
		// Given a node N, find the next ordered node. Ex: next(3)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a right child, R, the left-most child of R is the next node.
		// Otherwise, the nearest parent of N with N on the left is the next node.
		let node=this,child=this.right;
		if (child!==null) {
			do {node=child;child=child.left;} while (child!==null);
		} else {
			do {child=node;node=node.parent;} while (node!==null && node.right===child);
		}
		return node;
	}


	prev() {
		// Given a node N, find the previous ordered node. Ex: prev(5)=4.
		//
		//            4
		//           / \
		//          /   \
		//         2     6
		//        / \   / \
		//       1   3 5   7
		//
		// If N has a left child, L, the right-most child of L is the next node.
		// Otherwise, the nearest parent of N with N on the right is the next node.
		let node=this,child=this.left;
		if (child!==null) {
			do {node=child;child=child.right;} while (child!==null);
		} else {
			do {child=node;node=node.parent;} while (node!==null && node.left===child);
		}
		return node;
	}


	rotleft() {
		// Raise z, lower x, and maintain the sorted order of the nodes.
		//
		//        A                B
		//       / \              / \
		//      x   B     ->     A   z
		//         / \          / \
		//        y   z        x   y
		//
		let a=this;
		let b=a.right;
		let r=b.left;
		b.parent=a.parent;
		b.left=a;
		a.parent=b;
		a.right=r;
		if (r!==null) {r.parent=a;}
		a.calcweight();
		b.calcweight();
		return b;
	}


	rotright() {
		// Raise x, lower z, and maintain the sorted order of the nodes.
		//
		//          A            B
		//         / \          / \
		//        B   z   ->   x   A
		//       / \              / \
		//      x   y            y   z
		//
		let a=this;
		let b=a.left;
		let l=b.right;
		b.parent=a.parent;
		b.right=a;
		a.parent=b;
		a.left=l;
		if (l!==null) {l.parent=a;}
		a.calcweight();
		b.calcweight();
		return b;
	}


	calcweight() {
		let l=this.left,r=this.right;
		this.weight=(l!==null?l.weight:0)+(r!==null?r.weight:0)+1;
	}


	index() {
		// Returns the node's index within the tree. Ex: tree[node.index()]=node
		let idx=-1;
		let node=this,prev=this.right;
		do {
			if (node.right===prev) {
				let l=node.left;
				idx+=l!==null?l.weight+1:1;
			}
			prev=node;
			node=node.parent;
		} while (node!==null);
		return idx;
	}

}


export class Tree {

	static Node=TreeNode;

	// Searching constants.
	static EQ=0;
	static EQG=1;
	static LT=2;
	static LE=3;
	static GT=4;
	static GE=5;

	// Duplicate behavior.
	static ADD    =0;
	static REPLACE=1;
	static DISCARD=2;


	static defcmp(l,r) {
		if (l<r) {return -1;}
		return r<l?1:0;
	}


	constructor(cmp=null,duplicate=Tree.ADD) {
		// cmp(l,r) is expected to be a function where
		//
		//      cmp(l,r)<0 if l<r
		//      cmp(l,r)=0 if l=r
		//      cmp(l,r)>0 if l>r
		//
		this.cmp=cmp??Tree.defcmp;
		this.duplicate=duplicate;
		this.root=null;
		this.length=0;
	}


	release() {
		let node=null;
		while ((node=this.root)!==null) {
			this.removenode(node);
		}
	}


	first() {
		// Return the smallest node in the tree.
		let node=this.root,ret=null;
		while (node!==null) {ret=node;node=node.left;}
		return ret;
	}


	last() {
		// Return the greatest node in the tree.
		let node=this.root,ret=null;
		while (node!==null) {ret=node;node=node.right;}
		return ret;
	}


	*iter() {
		// Iterate over all nodes in ascending order.
		let node=this.first();
		while (node!==null) {
			let next=node.next();
			yield node;
			node=next;
		}
	}


	get(i) {
		// Index nodes like an array.
		let node=this.root;
		let weight=node!==null?node.weight:0;
		if (i<0) {i+=weight;}
		if (i<0 || i>=weight) {return null;}
		while (true) {
			let l=node.left;
			let lw=l!==null?l.weight:0;
			if (i>=lw) {
				i-=lw+1;
				if (i<0) {break;}
				node=node.right;
			} else {
				node=l;
			}
		}
		return node;
	}


	find(value,mode=Tree.EQ) {
		// Search for a specific value or inequality.
		//
		//      EQ : Return the least    node=value.
		//      EQG: Return the greatest node=value.
		//      LT : Return the greatest node<value.
		//      LE : Return the greatest node<=value.
		//      GT : Return the least    node>value.
		//      GE : Return the least    node>=value.
		//
		let node=this.root,ret=null;
		let cmp=this.cmp;
		let set=0x34652>>>(mode*3);
		let right=1|((0x34>>>mode)&2);
		while (node!==null) {
			let c=cmp(node.value,value);
			let bit=1<<(1+(c>0)-(c<0));
			ret=(set&bit)?node:ret;
			node=(right&bit)?node.right:node.left;
		}
		return ret;
	}


	addnode(orig) {
		// Find a leaf node to add the new value to. Then rebalance from the new node on
		// up. By traversing right when cmp<=0, this algorithm is stable.
		let value=orig.value;
		let node=this.root,prev=null;
		let cmp=this.cmp;
		let dup=this.duplicate,c=0;
		while (node!==null) {
			c=cmp(node.value,value);
			if (c===0 && dup) {
				if (dup===Tree.DISCARD) {return null;}
				node.value=value;
				return node;
			}
			prev=node;
			node=c>0?node.left:node.right;
		}
		this.length++;
		orig.weight=1;
		orig.left=null;
		orig.right=null;
		orig.parent=prev;
		if (prev!==null) {
			if (c>0) {prev.left=orig;}
			else     {prev.right=orig;}
			this.rebalance(prev);
		} else {
			this.root=orig;
		}
		return orig;
	}


	add(value) {
		return this.addnode(new TreeNode(value));
	}


	removenode(node) {
		// Remove a specific node. We can remove a node by swapping it with its successor
		// to maintain order and stability sorting-wise. Then, rebalance from the successor
		// on up.
		//
		//           Case 1          |          Case 2           |          Case 3
		//                           |                           |
		//   N is the right-most     |  X is a distant child of  |  X is the right child of
		//   child in the tree.      |  N. Balance from C up.    |  N. Balance from X up.
		//   Balance from D up.      |                           |
		//                           |                           |
		//     B              B      |    N              X       |     N              X
		//    / \            / \     |   / \            / \      |    / \            / \
		//   A   D     ->   A   D    |  A   C          A   C     |   A   X     ->   A   B
		//      / \            / \   |     / \    ->      / \    |      / \
		//     C   N          C   X  |    X   D          B   D   |     *   B
		//        / \                |   / \                     |
		//       X   *               |  *   B                    |
		//
		if (!node.weight) {throw "double removal";}
		let p=node.parent,l=node.left,r=node.right;
		node.weight=0;
		node.parent=null;
		node.left=null;
		node.right=null;
		let next=null,bal=null;
		if (r===null) {
			// Case 1
			bal=p;next=l;l=null;
		} else if (r.left!==null) {
			// Case 2
			next=r;
			while (next.left!==null) {bal=next;next=next.left;}
			let c=next.right;
			bal.left=c;
			if (c!==null) {c.parent=bal;}
		} else {
			// Case 3
			bal=r;next=r;r=null;
		}
		this.length--;
		// Replace node with next.
		if (p===null) {this.root=next;}
		else if (p.left===node) {p.left=next;}
		else {p.right=next;}
		if (next!==null) {
			next.parent=p;
			if (l!==null) {next.left=l;l.parent=next;}
			if (r!==null) {next.right=r;r.parent=next;}
		}
		this.rebalance(bal);
	}


	remove(value) {
		// Remove a node given a value.
		let node=this.find(value);
		if (node!==null) {this.removenode(node);}
		return node;
	}


	rebalance(next) {
		// Rebalance from next upward. If 2 children differ in weight by a ratio of 2.5 or
		// more, we can rotate to rebalance.
		function Weight(n) {return n!==null?n.weight:0;}
		while (next!==null) {
			let node=next,orig=next;
			next=node.parent;
			let l=node.left,r=node.right;
			let lw=Weight(l),rw=Weight(r);
			if (rw*5+2<lw*2) {
				// Leaning to the left.
				if (Weight(l.left)*5+2<lw*2) {node.left=l.rotleft();}
				node=node.rotright();
			} else if (lw*5+2<rw*2) {
				// Leaning to the right.
				if (Weight(r.right)*5+2<rw*2) {node.right=r.rotright();}
				node=node.rotleft();
			} else {
				// Balanced.
				node.weight=lw+rw+1;
				continue;
			}
			if (next===null) {this.root=node;}
			else if (next.left===orig) {next.left=node;}
			else {next.right=node;}
		}
	}

}


/*


treetest.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


L*5+2<R*2
max ratio : 1.503215
sum height: 308519

L*17+7<R*7
max ratio : 1.493219
sum height: 307552


The second invariant can have con={3,4,5,6,7}.
con=4 creates the fewest rebalances with near-minimum heights.

L*17+7<R*7, L.L*17+7<L*7
max ratio : 1.503215
sum height: 667345
rebalance : 341786

L*17+7<R*7, L.L*17+6<L*7
max ratio : 1.503215
sum height: 667331
rebalance : 341720

L*17+7<R*7, L.L*17+5<L*7
max ratio : 1.503215
sum height: 667414
rebalance : 341693

L*17+7<R*7, L.L*17+4<L*7
max ratio : 1.503215
sum height: 667198
rebalance : 341630

L*17+7<R*7, L.L*17+3<L*7
max ratio : 1.535670
sum height: 666376
rebalance : 346814


*/
/* npx eslint treetest.js -c ../../../standards/eslint.js */


import {Random} from "../../misc/library.js";
import {Tree} from "../data.js";


function Example() {
	let tree=new Tree((l,r)=>l[0]-r[0]);
	tree.add([5,"Friday"]);
	tree.add([5,"Friday2"]);
	tree.add([3,"Wednesday"]);
	tree.add([1,"Monday"]);
	tree.add([6,"Saturday"]);
	tree.add([2,"Tuesday"]);
	tree.add([4,"Thursday"]);
	tree.remove([6,"Saturday"]);
	console.log("iter:");
	for (let node of tree.iter()) {
		console.log(node.value);
	}
	console.log("index:");
	for (let i=0;i<tree.length;i++) {
		console.log(tree.get(i).value);
	}
}


function TreeTest() {
	let rnd=new Random(0);
	let tests=200;
	let maxnodes=1000;
	let maxval=32;
	let valarr=(new Array(maxnodes)).fill(null);
	let nodearr=(new Array(maxnodes)).fill(null);
	let travarr=(new Array(maxnodes)).fill(null);
	function cmp(l,r) {
		let lv=l.val,rv=r.val;
		if (lv===rv) {return 0;}
		return lv<rv?-1:1;
	}
	function invariant(l,r) {
		//return l*5+2<r*2;
		return l*17+7<r*7;
	}
	let sumheight=0;
	let maxratio=0;
	let rebalance=0;
	for (let test=0;test<tests;test++) {
		console.log("test:",test);
		let stopnodes=maxnodes;//rnd.mod(maxnodes+1);
		let tree=new Tree(cmp);
		// If the tree uses a zero node with weight=0.
		let zero=tree.zero;
		if (zero) {zero._height=0;} else {zero=null;}
		let nodes=0;
		for (let s=0;s<stopnodes || tree.length;s++) {
			// Check the zero node.
			if (zero!==null) {
				if (tree.zero!==zero) {
					console.log("Tree.ZERO changed");
					throw "error";
				}
				if (zero.weight!==0 || zero._height!==0) {
					console.log("zero weight set",zero.weight,zero._height);
					throw "error";
				}
				if (zero.value!==tree) {
					console.log("zero value set");
					throw "error";
				}
				if (zero.left!==null || zero.right!==null) {
					console.log("zero null child:",zero.left,zero.right);
					throw "error";
				}
				//if (zero.parent!==null) {
				//	console.log("zero null parent:",zero.parent);
				//	throw "error";
				//}
			}
			// Remove, add, or do nothing.
			let act=rnd.mod(s<stopnodes?6:3);
			if (act<2) {
				// Remove
				if (nodes) {
					let i=rnd.mod(nodes);
					let node=nodearr[i];
					if (rnd.getu32()&1) {
						tree.removenode(node);
					} else {
						node.remove();
					}
					nodes--;
					for (;i<nodes;i++) {
						valarr[i]=valarr[i+1];
						nodearr[i]=nodearr[i+1];
					}
					valarr[i]=null;
					nodearr[i]=null;
				}
			} else if (act<5) {
				// Add
				if (nodes<maxnodes) {
					let val={val:rnd.mod(maxval),idx:s};
					let node=tree.add(val);
					node._left=zero;
					node._right=zero;
					let i=nodes++;
					while (i>0 && cmp(valarr[i-1],val)>0) {
						valarr[i]=valarr[i-1];
						nodearr[i]=nodearr[i-1];
						i--;
					}
					valarr[i]=val;
					nodearr[i]=node;
				}
			}
			// Sanity checks.
			if (tree.length!==nodes) {
				console.log("tree length:",tree.length,nodes);
				throw "error";
			}
			let first=tree.first();
			let last=tree.last();
			let afirst=nodes?nodearr[0]:null;
			let alast=nodes?nodearr[nodes-1]:null;
			if (first!==afirst || last!==alast) {
				console.log("first/last",first,last);
				console.log(nodearr.slice(0,nodes));
				throw "error";
			}
			// Check iter.
			let pval={val:-Infinity,idx:-Infinity};
			let root=tree.root;
			let idx=0;
			for (let node=first;node!==null;) {
				if (idx>=nodes) {
					console.log("iter too far");
					throw "error";
				}
				// Value sorting
				let val=valarr[idx];
				if (!Object.is(node.value,val)) {
					console.log("val not matching");
					throw "error";
				}
				if (pval.val>val.val || (pval.val===val.val && pval.idx>=val.idx)) {
					console.log("val not sorted",pval,val);
					throw "error";
				}
				pval=val;
				// Walking order
				let anode=nodearr[idx];
				if (!Object.is(node,anode)) {
					console.log("node out of order");
					throw "error";
				}
				let aidx=node.index();
				if (aidx!==idx) {
					console.log("node wrong index:",aidx,idx);
					throw "error";
				}
				let prev=node.prev();
				let next=node.next();
				let aprev=idx?nodearr[idx-1]:null;
				let anext=idx+1<nodes?nodearr[idx+1]:null;
				if (!Object.is(aprev,prev) || !Object.is(anext,next)) {
					console.log("prev/next out of order",idx,nodes);
					console.log("prev:",aprev,prev);
					console.log("next:",anext,next);
					throw "error";
				}
				// check relationships
				let p=node.parent;
				if (p===zero) {
					if (!Object.is(node,root)) {
						console.log("null parent");
						throw "error";
					}
					root=zero;
				} else if (Object.is(node,p.l)!==Object.is(node,p.r)) {
					console.log("not a child of parent");
					throw "error";
				}
				let l=node.left,r=node.right;
				let lw=0,rw=0;
				if (l!==zero) {
					if (!Object.is(l.parent,node)) {
						console.log("left not child");
						throw "error";
					}
					lw=l.weight;
				}
				if (r!==zero) {
					if (!Object.is(r.parent,node)) {
						console.log("right not child");
						throw "error";
					}
					rw=r.weight;
				}
				// count rebalances
				if (node._left!==l) {
					node._left=l;
					rebalance++;
				}
				if (node._right!==r) {
					node._right=r;
					rebalance++;
				}
				// check balance
				let weight=lw+rw+1;
				let nweight=node.weight;
				if (nweight!==weight) {
					console.log("weight:",nweight,weight);
					throw "error";
				}
				if (invariant(lw,rw) || invariant(rw,lw)) {
					console.log("imbalanced:",lw,rw);
					throw "error";
				}
				// next node
				node=next;
				idx++;
			}
			if (idx!==nodes) {
				console.log("walk too short");
				throw "error";
			}
			if (root!==zero) {
				console.log("root not found");
				throw "error";
			}
			// Check heights.
			let trav=nodes?1:0;
			travarr[0]=tree.root;
			for (let i=0;i<nodes;i++) {
				let node=travarr[i];
				let l=node.left,r=node.right;
				if (l!==zero) {travarr[trav++]=l;}
				if (r!==zero) {travarr[trav++]=r;}
			}
			for (let i=nodes-1;i>=0;i--) {
				let node=travarr[i];
				let l=node.left,r=node.right;
				let lh=l!==null?l._height:0;
				let rh=r!==null?r._height:0;
				let h=(lh>rh?lh:rh)+1;
				node._height=h;
				let log2=Math.log(node.weight+1)/Math.log(2);
				if (h>log2*2.0101) {
					console.log("node height:",h,log2,node.weight);
					throw "error";
				}
				if (log2>1e-10) {
					let ratio=h/log2;
					maxratio=maxratio>ratio?maxratio:ratio;
				}
			}
			// Check indexing.
			for (let i=0;i<nodes+2;i++) {
				idx=rnd.mod(nodes+2);
				let node=tree.get(idx);
				let anode=idx<nodes?nodearr[idx]:null;
				if (!Object.is(node,anode)) {
					console.log("incorrect index");
					throw "error";
				}
			}
			// Search
			// Perform a regular linear search for a value.
			let search=rnd.mod(6);
			let val={val:rnd.mod(maxval),idx:null};
			let pos=-1;
			if (search===Tree.EQ) {
				for (let i=0;i<nodes;i++) {
					if (cmp(valarr[i],val)===0) {pos=i;break;}
				}
			} else if (search===Tree.EQG) {
				for (let i=nodes-1;i>=0;i--) {
					if (cmp(valarr[i],val)===0) {pos=i;break;}
				}
			} else if (search===Tree.LT) {
				for (let i=0;i<nodes;i++) {
					if (cmp(valarr[i],val)>=0) {break;}
					pos=i;
				}
			} else if (search===Tree.LE) {
				for (let i=0;i<nodes;i++) {
					if (cmp(valarr[i],val)>0) {break;}
					pos=i;
				}
			} else if (search===Tree.GT) {
				for (let i=nodes-1;i>=0;i--) {
					if (cmp(valarr[i],val)<=0) {break;}
					pos=i;
				}
			} else if (search===Tree.GE) {
				for (let i=nodes-1;i>=0;i--) {
					if (cmp(valarr[i],val)<0) {break;}
					pos=i;
				}
			}
			let node=tree.find(val,search);
			let anode=pos>=0?nodearr[pos]:null;
			if (!Object.is(node,anode)) {
				console.log("could not search");
				throw "error";
			}
			if (node!==null) {sumheight+=node._height;}
		}
	}
	console.log("max ratio :",maxratio.toFixed(6));
	console.log("sum height:",sumheight);
	console.log("rebalance :",rebalance>>>1);
}


function SpeedTest() {
	// pypy
	// insert: 5.684066
	// search: 4.612764
	// delete: 3.629820
	//
	// python3
	// insert: 79.122885
	// search: 43.640018
	// delete: 24.880355
	//
	//
	// simple rotation
	// FF
	// insert: 20.509280
	// search: 12.161880
	// delete: 14.276120
	//
	// CR
	// insert: 12.559585
	// search: 10.599390
	// delete: 8.120250
	//
	//
	// unrolled rotations, no explicit node!==null comparisons
	// FF
	// insert: 19.794380
	// search: 13.272420
	// delete: 13.900980
	//
	// CR
	// insert: 13.902790
	// search: 10.957645
	// delete: 9.032020
	//
	//
	// unrolled rotations
	// FF
	// insert: 18.258620
	// search: 12.100600
	// delete: 12.490800
	//
	// CR
	// insert: 12.668140
	// search: 10.519035
	// delete: 8.115980
	//
	//
	// zero nodes, L*5+2<R*2
	// FF
	// insert: 18.788340
	// search: 11.972620
	// delete: 11.942040
	//
	// CR
	// insert: 12.307520
	// search: 9.043775
	// delete: 7.542485
	//
	//
	// zero nodes, L*17+{7,4}<R*7
	// FF
	// insert: 18.508960
	// search: 12.116320
	// delete: 12.030580
	//
	// CR
	// insert: 12.277475
	// search: 9.126705
	// delete: 7.625880
	console.log("Testing tree speed");
	let rnd=new Random(0);
	function shuffle(arr) {
		let len=arr.length;
		for (let i=1;i<len;i++) {
			let j=rnd.mod(i+1);
			let x=arr[i];
			arr[i]=arr[j];
			arr[j]=x;
		}
	}
	let timeinsert=0;
	let timesearch=0;
	let timedelete=0;
	let parity=0;
	let trials=500;
	let nodes=100000;
	let valarr=new Array(nodes);
	for (let i=0;i<nodes;i++) {valarr[i]=i>>>4;}
	let nodearr=(new Array(nodes)).fill(null);
	for (let trial=0;trial<trials;trial++) {
		let tree=new Tree();
		// Time insertion.
		shuffle(valarr);
		let time=performance.now();
		for (let i=0;i<nodes;i++) {
			nodearr[i]=tree.add(valarr[i]);
		}
		timeinsert+=performance.now()-time;
		// Time searching.
		shuffle(valarr);
		time=performance.now();
		for (let i=0;i<nodes;i++) {
			parity^=(tree.find(valarr[i],rnd.getu32()%6)===null);
		}
		timesearch+=performance.now()-time;
		// Time deletion.
		shuffle(nodearr);
		time=performance.now();
		for (let i=0;i<nodes;i++) {
			tree.removenode(nodearr[i]);
		}
		timedelete+=performance.now()-time;
	}
	rnd.seed(parity);
	timeinsert/=1000;
	timesearch/=1000;
	timedelete/=1000;
	console.log(`insert: ${timeinsert.toFixed(6)}`);
	console.log(`search: ${timesearch.toFixed(6)}`);
	console.log(`delete: ${timedelete.toFixed(6)}`);
}


function main() {
	Example();
	//TreeTest();
	//SpeedTest();
	console.log("done");
}
main();

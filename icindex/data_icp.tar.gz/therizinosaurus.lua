-- Therizinosaurus

limbattributes = {
isFromExcel = {1,1.0},

["endurance_bonus"]={1,0},
["size"]={1,7},
["sight_radius1"]={4,40},
["night_sight_radius"]={4,0},
["stocktype"]={1,1},

["armour-head"]={4,0.020},
["armour-front"]={2,0.045},
["armour-back"]={3,0.045},
["armour-torso"]={6,0.15},

["exp_armour"]={1,0},
["exp_dodge"]={1,-0.125},

["hitpoints-head"]={4,20},
["hitpoints-front"]={2,50},
["hitpoints-back"]={3,50},
["hitpoints-torso"]={6,210},
["exp_hitpoints"]={1,1.1},

["speed_mid-front"]={2,2.1},
["speed_mid-torso"]={6,2.8},
["speed_mid-back"]={3,2.1},
["exp_speed_mid"]={1,0.025},

["speed_max-front"]={2,6},
["speed_max-torso"]={6,6},
["speed_max-back"]={3,12},
["exp_speed_max"]={1,-0.10},

["airspeed_max-torso"]={6,0},
["airspeed_max-wings"]={7,0},
["exp_airspeed_max"]={1,-0.16},

["waterspeed_max-torso"]={6,0},
["waterspeed_max-tail"]={5,0},
["exp_waterspeed_max"]={1,-0.1},

["melee2_number"]={2,1},
["melee2_dmgtype"]={2,2},
["melee2_damage"]={2,15},
["melee2_rate"]={2,1.4},
["melee2_contact"]={2,0.5},

["melee2_name"]={2,5490},
["melee2_shortdesc"]={2,63294},
["melee2_longdesc"]={2,63294},

["melee4_number"]={4,2},
["melee4_dmgtype"]={4,0},
["melee4_damage"]={4,4},
["melee4_rate"]={4,1.7},
["melee4_contact"]={4,0.5},

["melee4_name"]={4,5495},
["melee4_shortdesc"]={4,63293},
["melee4_longdesc"]={4,63293},

["melee_damage"]={1,19},
["exp_melee2_damage"]={1,0.65},
["exp_melee4_damage"]={1,0.65},

["stink_attack"]={5,0},
["electric_burst"]={5,0},
["charge_attack"]={3,0},
["frenzy_attack"]={0,0},
["plague_attack"]={4,0},
["quill_burst"]={6,0},
["can_dig"]={2,0},
["pack_hunter"]={0,0},
["herding"]={0,0},
["leap_attack"]={3,0},
["poison_touch"]={5,0},
["is_stealthy"]={5,0},
["is_immune"]={0,1},
["regeneration"]={0,0},
["keen_sense"]={4,0},
["sonar_pulse"]={4,0},
["end_bonus"]={6,0},
["bipedal"] = {3,1},

["end_penalty"]={6,0},

["front_foot_type"]={2,1},
["rear_foot_type"]={3,1},
["vocal_type"]={4,19},
["Hide_type"]={6,3},

["actbeselect"]={0,1},
["selection_sloppyness"]={6,0.5},
["boneblobshadow"]={0,1},
["simvis_occludee"]={0,1},
["singleselectonly"]={0,0},
["isvisible"]={0,1},
["fadeAndDeleteWhenDead"]={0,1},
["stayInPathfindingAfterDead"]={0,0},
["min_triangle_count"]={1,175},
["simterrain"]={0,0},
["simcollides"]={0,1},
["simfogged"]={0,1},
["combinervisible"]={0,1},
["minimap_enable"]={0,1},
["minimap_teamcolour"]={0,1},
["ghost_enable"]={0,0},

["tag_desc"]={1,59503},
["lefthalf_name"]={1,63301},
["righthalf_name"]={1,63302},

["disable_cheap_skinning"] = {0,1},
}

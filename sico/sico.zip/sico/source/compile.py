#!/usr/bin/python3
"""
Compiles:

     Master library
     Demos
     Tests
     Interpreters

Everything is placed in output.
"""


import os,re,sys,shutil,gzip,base64


# Directory helpers
pydir =os.path.dirname(os.path.abspath(__file__))
outdir=os.path.realpath(os.path.join(pydir,"./output"))
libdir=os.path.realpath(os.path.join(pydir,"./"))
intdir=os.path.realpath(os.path.join(pydir,"./interpreters"))

def  pyjoin(path): return os.path.join(pydir ,path)
def outjoin(path): return os.path.join(outdir,path)
def libjoin(path): return os.path.join(libdir,path)
def demjoin(path): return os.path.join(libdir+"/demos",path)
def tstjoin(path): return os.path.join(libdir+"/tests",path)
def intjoin(path): return os.path.join(intdir,path)

def loadfile(path):
	with open(path,"r") as f:
		return "".join(f.readlines())
	raise "failed to load file"

def concat(input,output):
	text=""
	for file in input: text+=loadfile(file)
	with open(output,"w") as f: f.write(text)


# Compile the master library. Add line numbers to the index.
if not os.path.isdir(outdir):
	print("Creating "+outdir)
	os.mkdir(outdir)
print("Compiling library master.sico")
master=loadfile(libjoin("master_header.sico"))
files=("uint.sico","int.sico","random.sico","string.sico","memory.sico")
for file in files:
	path=libjoin(file)
	data=loadfile(path)
	idx="{0:s}  |  {1:>4d}".format(file,master.count("\n")+1)
	master=re.sub(re.escape("$"+file+"  |"),idx,master,1)
	master+=data
with open(outjoin("master.sico"),"w") as f:
	f.write(master)


# Compile demos
print("Compiling library demos")
concat([demjoin("demo_hello.sico")]                        ,outjoin("demo_hello.sico"))
concat([demjoin("demo_memory.sico"),outjoin("master.sico")],outjoin("demo_memory.sico"))
concat([demjoin("demo_random.sico"),outjoin("master.sico")],outjoin("demo_random.sico"))
concat([demjoin("demo_string.sico"),outjoin("master.sico")],outjoin("demo_string.sico"))
concat([demjoin("demo_uint.sico")  ,outjoin("master.sico")],outjoin("demo_uint.sico"))
concat([libjoin("graphics.sico")   ,outjoin("master.sico")],outjoin("graphics.sico"))
concat([demjoin("demo_graphics.sico"),outjoin("graphics.sico")],outjoin("demo_graphics.sico"))


# Compile tests
print("Compiling library tests")
concat([tstjoin("test_int.sico")   ,outjoin("master.sico")],outjoin("test_int.sico"))
concat([tstjoin("test_memory.sico"),outjoin("master.sico")],outjoin("test_memory.sico"))
concat([tstjoin("test_random.sico"),outjoin("master.sico")],outjoin("test_random.sico"))
concat([tstjoin("test_uint.sico")  ,outjoin("master.sico")],outjoin("test_uint.sico"))


# Compile sico.cpp
print("Compiling sico.cpp")
if os.name!="nt":
	outpath=outjoin("sico")
	comp="g++ -Wall -Wextra -O3 "+intjoin("sico.cpp")+" -o "+outpath+" -lSDL2"
else:
	outpath=outjoin("sico.exe")
	comp="cl /W4 /O2 /DSDL_MAIN_HANDLED sico.cpp /I \"C:\\SDL2\\include\" /link /LIBPATH:\"C:\\SDL2\\lib\\x64\" SDL2.lib SDL2main.lib /SUBSYSTEM:CONSOLE"
if os.path.isfile(outpath): os.remove(outpath)
print(comp)
os.system(comp)


# Compile WebAssembly
print("Compiling WASM")
outpath=outjoin("sico.wasm")
comp="clang "+intjoin("sico_wasm.c")+" --target=wasm32 -O3 -nostdlib -Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined --output "+outpath
if os.path.isfile(outpath): os.remove(outpath)
print(comp)
os.system(comp)
if os.path.isfile(outpath):
	wasmdata=open(outpath,"rb").read()
	wasmcomp=gzip.compress(wasmdata)
	out64=outjoin("sico_wasm_64.txt")
	str64=base64.b64encode(wasmcomp).decode("utf-8")
	l=len(str64)
	str64="\n".join([str64[i:min(i+80,l)] for i in range(0,l,80)])
	with open(out64,"w") as f: f.write(str64)

print("\nFiles written to "+outdir)

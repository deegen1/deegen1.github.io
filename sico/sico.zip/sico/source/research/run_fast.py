def run_fast(self,insts=float("inf")):
	if self.state!=self.RUNNING: return
	mod  =self.mod
	ip   =self.ip
	mem  =self.mem
	alloc=self.alloc
	while insts>0:
		insts-=1
		if ip+2<alloc:
			a=mem[ip  ]
			b=mem[ip+1]
			c=mem[ip+2]
		else:
			a=self.getmem(ip  )
			b=self.getmem(ip+1)
			c=self.getmem(ip+2)
		mb=mem[b] if b<alloc else self.getmem(b)
		if a<alloc:
			ma=mem[a]
			ip=c if ma<=mb else ip+3
			mem[a]=(ma-mb)%mod
		else:
			ma=self.getmem(a)
			ip=c if ma<=mb else ip+3
			self.setmem(a,ma-mb)
			mem=self.mem
			alloc=self.alloc
			if self.state!=self.RUNNING: break
	self.ip=ip%mod

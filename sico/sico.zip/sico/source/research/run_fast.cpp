void run(s32 insts) {
	// Run the SICO program.
	// Unrolling the main loop is about 2 times as fast.
	if (state_!=RUNNING) {return;}
	u64 ip=ip_,mod=mod_;
	u64 alloc=alloc_,*mem=mem_;
	u64 a,b,ma,mb;
	s32 dec=insts>0;
	for (;insts;insts-=dec) {
		a=ip<alloc?mem[ip]:getmem(ip);
		if (++ip>=mod) {ip-=mod;}
		b=ip<alloc?mem[ip]:getmem(ip);
		if (++ip>=mod) {ip-=mod;}
		ma=a<alloc?mem[a]:getmem(a);
		mb=b<alloc?mem[b]:getmem(b);
		if (ma<=mb) {
			ip=ip<alloc?mem[ip]:getmem(ip);
		} else if (++ip>=mod) {
			ip-=mod;
		}
		ma=ma<mb?ma-mb+mod:ma-mb;
		if (a<alloc) {
			mem[a]=ma;
		} else {
			setmem(a,ma);
			if (state_!=RUNNING) {break;}
			mem=mem_;
			alloc=alloc_;
		}
	}
	ip_=ip;
}
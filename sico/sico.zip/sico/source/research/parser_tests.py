"""-----------------------------------------------------------------------------


parser_tests.py - v1.02

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Testing


We have a list of test cases which include

     SICO source code
     Expected console output
     Expected state value
     Expected state message

Tests make sure that the interpreter catches expected syntax errors, reports
errors correctly, and processes SICO programs correctly.


--------------------------------------------------------------------------------
TODO


"""


import random,sys
sys.path.insert(1,"../..")
from sico import SICO


#---------------------------------------------------------------------------------
# Test Cases


sicotests=[
	# Make sure that the tester won't run forever.
	["","",SICO.RUNNING,""],
	# [0,"",SICO.RUNNING,""],
	# Invalid character ranges.
	["\x01","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x08","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x0b","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x0c","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x0e","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x1f","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t \n\t^\n\n"],
	["\x21","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t!\n\t^\n\n"],
	["\x22","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t\"\n\t^\n\n"],
	["\x24","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t$\n\t^\n\n"],
	["\x2a","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t*\n\t^\n\n"],
	["\x2c","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t,\n\t^\n\n"],
	["\x2f","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t/\n\t^\n\n"],
	["\x3b","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t;\n\t^\n\n"],
	["\x3e","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t>\n\t^\n\n"],
	["\x40","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t@\n\t^\n\n"],
	["\x5b","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t[\n\t^\n\n"],
	["\x5e","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t^\n\t^\n\n"],
	["\x60","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t`\n\t^\n\n"],
	["\x7b","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t{\n\t^\n\n"],
	["\x7f","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t\x7f\n\t^\n\n"],
	# Numbers
	["18446744073709551615 0x8000 0","",SICO.COMPLETE,""],
	["0xffffffffffffffff 8000 0","",SICO.COMPLETE,""],
	# Arithmetic
	["0-1 1-2+0x21 0","",SICO.COMPLETE,""],
	["0-1 1+2 0","",SICO.COMPLETE,""],
	["+","",SICO.ERROR_PARSER,"Parser: Leading operator\nLine  : 1\n\n\t+\n\t^\n\n"],
	["+1","",SICO.ERROR_PARSER,"Parser: Leading operator\nLine  : 1\n\n\t+1\n\t^\n\n"],
	["1+","",SICO.ERROR_PARSER,"Parser: Trailing operator\nLine  : 1\n\n\t1+\n\t ^\n\n"],
	["1+ ","",SICO.ERROR_PARSER,"Parser: Trailing operator\nLine  : 1\n\n\t1+\n\t ^\n\n"],
	["1 + ","",SICO.ERROR_PARSER,"Parser: Trailing operator\nLine  : 1\n\n\t1 +\n\t  ^\n\n"],
	["1 - #comment\n","",SICO.ERROR_PARSER,"Parser: Trailing operator\nLine  : 1\n\n\t1 - #comment\n\t  ^\n\n"],
	["1 - #comment\n2","",SICO.COMPLETE,""],
	["1 - #comment\n+ 2","",SICO.ERROR_PARSER,"Parser: Double operator\nLine  : 2\n\n\t+ 2\n\t^\n\n"],
	["1 - #||#2","",SICO.COMPLETE,""],
	# "0x"="0x0"
	["6 7 0\n0-1 0 0\n1 0x","",SICO.COMPLETE,""],
	["7 6 0\n0-1 0 0\n0x 1","",SICO.COMPLETE,""],
	# Test if writing to 1 will print to stdout.
	["0-2 15 ?+1 0-2 16 ?+1 0-2 17 ?+1 0-2 15 ?+1 0-1 0 0 65 66 67","ABCA",SICO.COMPLETE,""],
	# Test hex lower and upper case.
	[
		"30 31  3 37 30 27 0-2 34 ?+1\n"
		"31 32 12 37 31 27 0-2 35 ?+1\n"
		"32 33 21 37 32 27 0-2 36 ?+1\n"
		"0-1 0 0\n"
		"0xabcdef 0xAbCdEf 0Xabcdef 0XAbCdEf\n"
		"48 49 50 1",
		"012",SICO.COMPLETE,""
	],
	["12 13 3 12 7 9 0-1 0 0 0-2 14 6 0x25ce2189F743D60Ba 6692939069355024570 90","Z",SICO.COMPLETE,""],
	["12 13 3 12 7 9 0-1 0 0 0-2 14 6 0x25ce2189F743D60Ba 6692939069355024571 90","",SICO.COMPLETE,""],
	["0xefg","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\t0xefg\n\t    ^\n\n"],
	# ASCII Literals
	["0-2 char ?+1 0-1 0 0 char:'x","x",SICO.COMPLETE,""],
	["'A'b","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\t'A'b\n\t  ^^\n\n"],
	# Labels
	["lbl","",SICO.ERROR_PARSER,"Parser: Unable to find label\nLine  : 1\n\n\tlbl\n\t^^^\n\n"],
	["lbl: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl:lbl2: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl: lbl-1 0 lbl","",SICO.COMPLETE,""],
	[":","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t:\n\t^\n\n"],
	["0+lbl:0","",SICO.ERROR_PARSER,"Parser: Operating on declaration\nLine  : 1\n\n\t0+lbl:0\n\t  ^^^^\n\n"],
	["0 lbl:+0","",SICO.ERROR_PARSER,"Parser: Operating on declaration\nLine  : 1\n\n\t0 lbl:+0\n\t      ^\n\n"],
	["?-1 0 0","",SICO.COMPLETE,""],
	["?-1 ?-1 0","",SICO.COMPLETE,""],
	["0-1+? 0 ?-2","",SICO.COMPLETE,""],
	["0?","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\t0?\n\t ^\n\n"],
	["?0","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\t?0\n\t ^\n\n"],
	["lbl?","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\tlbl?\n\t   ^\n\n"],
	["?lbl","",SICO.ERROR_PARSER,"Parser: Unseparated tokens\nLine  : 1\n\n\t?lbl\n\t ^^^\n\n"],
	["?:","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t?:\n\t ^\n\n"],
	["lbl: :","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\tlbl: :\n\t     ^\n\n"],
	["zero:zero-one one:one-one zero","",SICO.COMPLETE,""],
	["lbl: lbl: 0-1 0 0","",SICO.ERROR_PARSER,"Parser: Duplicate label declaration\nLine  : 1\n\n\tlbl: lbl: 0-1 0 0\n\t     ^^^^\n\n"],
	["lbl: LBL: 0-1 0 0","",SICO.COMPLETE,""],
	# Sublabels
	[".x","",SICO.ERROR_PARSER,"Parser: Unable to find label\nLine  : 1\n\n\t.x\n\t^^\n\n"],
	[".","",SICO.ERROR_PARSER,"Parser: Unable to find label\nLine  : 1\n\n\t.\n\t^\n\n"],
	["lbl: .","",SICO.ERROR_PARSER,"Parser: Unable to find label\nLine  : 1\n\n\tlbl: .\n\t     ^\n\n"],
	["lbl: .: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl: ..: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl:..x: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl:...x: 0-1 0 0","",SICO.COMPLETE,""],
	[".: 0-1 0 0","",SICO.COMPLETE,""],
	["..: 0-1 0 0","",SICO.COMPLETE,""],
	["lbl.x:0-1 0 0","",SICO.COMPLETE,""],
	["lbl: .1:0-1 1 lbl.1","",SICO.COMPLETE,""],
	["lbl: .x-2 lbl.x:0 0","",SICO.COMPLETE,""],
	["lbl.tmp: .x-2 lbl.tmp.x:0 0","",SICO.COMPLETE,""],
	["lbl: .x:0-1 lbl.x:0 0","",SICO.ERROR_PARSER,"Parser: Duplicate label declaration\nLine  : 1\n\n\tlbl: .x:0-1 lbl.x:0 0\n\t            ^^^^^^\n\n"],
	["lbl.x:0-1 lbl: .x:0 0","",SICO.ERROR_PARSER,"Parser: Duplicate label declaration\nLine  : 1\n\n\tlbl.x:0-1 lbl: .x:0 0\n\t               ^^^\n\n"],
	["lbl0: .x:0-1 lbl1: .y:0 0","",SICO.COMPLETE,""],
	# {"lbl: .x:.x.y-2 ..y:0 0 lbl.x.y","",SICO.COMPLETE,""],
	# Comments
	["#","",SICO.RUNNING,""],
	["#\n0-2 4 ?+1 0-1 65 0","A",SICO.COMPLETE,""],
	["#Hello\n0-1 0 0","",SICO.COMPLETE,""],
	["#||#0-1 0 0","",SICO.COMPLETE,""],
	["##|\n0-1 0 0","",SICO.COMPLETE,""],
	["|#0-1 0 0","",SICO.ERROR_PARSER,"Parser: Unexpected token\nLine  : 1\n\n\t|#0-1 0 0\n\t^\n\n"],
	["0-2 6 ?+1 0-1 0 0 65\n#","A",SICO.COMPLETE,""],
	["0-2 6 ?+1 0-1 0 0 65\n#abc","A",SICO.COMPLETE,""],
	["#|\ncomment\n|#\n0-1 0 0","",SICO.COMPLETE,""],
	["lbl1: 0-1 lbl2: lbl1#|comment|#lbl1 0","",SICO.COMPLETE,""],
	["#|","",SICO.ERROR_PARSER,"Parser: Unterminated block quote\nLine  : 1\n\n\t#|\n\t^^\n\n"],
	["# |#\n0-2 6 ?+1 0-1 0 0 66","B",SICO.COMPLETE,""],
	["#|#0-1 0 0","",SICO.ERROR_PARSER,"Parser: Unterminated block quote\nLine  : 1\n\n\t#|#0-1 0 0\n\t^^^^^^^^^^\n\n"],
	# Self modification test. Make sure that we can modify A, B, and C as expected.
	# Tests if an instruction can modify its jump operand without affecting its jump.
	[
		"?+2 neg+0  ?+1\n"
		"0-2 char+0 ?+1\n"
		"?+2 neg+1  ?+1\n"
		"0-2 char+1 ?+1\n"
		"?+2 neg+2  ?+1\n"
		"0-2 char+2 ?+1\n"
		"?+2 neg+3  ?+1\n"
		"0-2 char+3 ?+1\n"
		"0-1 0 0\n"
		" neg:4 10 16 22\n"
		"char:65 'B 67 10",
		"ABC\n",SICO.COMPLETE,""
	],
	# Prints "Hello, World!". Also tests UTF-8 support.
	[
		"m\xc3\xa5in:\n"
		"       .len  one neg #if len=0, abort\n"
		"       0-2   .data ?+1 #print a letter \xc2\xaf\\_(\xe3\x83\x84)_/\xc2\xaf\n"
		"       0-2+? neg m\xc3\xa5in   #increment pointer and loop\n"
		".data: 'H 'e 108 108 111 44 0x20  #Hello,\n"
		"       87 111 114 108 100 '! 10   #World!\n"
		"m\xc3\xa5in.len: m\xc3\xa5in.len-m\xc3\xa5in.data+1\n"
		"neg:0-1 one:1 0",
		"Hello, World!\n",SICO.COMPLETE,""
	],
	# Memory
	# Writing 0 to a high memory cell should do nothing.
	["0x7fffffffffffffff val 3 0-1 0 val:0","",SICO.COMPLETE,""],
	# The memory allocation in sico.c should safely fail if we write to a high
	# address.
	["0x7fffffffffffffff val 3 0-1 0 val:1","",SICO.ERROR_MEMORY,"Failed to allocate memory.\nIndex: 9223372036854775807\n"],
	# Parser whitespace trimming.
	[
		"   \r \t  \n"
		"   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  \n"
		"   #end",
		"",SICO.ERROR_PARSER,
		"Parser: Unable to find label\nLine  : 2\n\n\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\t^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n"
	],
	[
		"   \r \t  \n"
		"   b aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  \n"
		"   b: #end",
		"",SICO.ERROR_PARSER,
		"Parser: Unable to find label\nLine  : 2\n\n\tb aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\t  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n"
	],
	[
		"   \r \t  \n"
		"   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa b  \n"
		"   b: #end",
		"",SICO.ERROR_PARSER,
		"Parser: Unable to find label\nLine  : 2\n\n\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\t^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n"
	],
	[
		"   \r \t  \n"
		"   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa b  \n"
		"   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: #end\n",
		"",SICO.ERROR_PARSER,
		"Parser: Unable to find label\nLine  : 2\n\n\taaaaaaaaaaaaaaaaaaaaaaaaaaaaa b\n\t                              ^\n\n"
	]
]


#---------------------------------------------------------------------------------
# Testing


# Capture stdout.
setmem1=SICO.setmem
def setmem2(self,addr,val):
	mod=self.mod
	if (addr+2)%mod==0:
		SICO.outstr+=chr(((-val)%mod)&255)
		return
	setmem1(self,addr,val)
SICO.setmem=setmem2


def SicoEscape(src):
	# Print a string and show escaped characters.
	if not src: return ""
	esc={
		"\n":"\\n",
		"\r":"\\r",
		"\t":"\\t",
		"\b":"\\b",
		"\"":"\\\""
	}
	ret=""
	for c in src:
		v=ord(c)
		if c in esc:
			ret+=esc[c]
		elif v<32 or v>127:
			ret+="\\x{0:02x}".format(v)
		else:
			ret+=c
	return ret


def SicoStateStr(val):
	statemap={
		SICO.COMPLETE:    "SICO.COMPLETE",
		SICO.RUNNING:     "SICO.RUNNING",
		SICO.ERROR_PARSER:"SICO.ERROR_PARSER",
		SICO.ERROR_MEMORY:"SICO.ERROR_MEMORY"
	}
	return statemap.get(val,"UNKNOWN")


if __name__=="__main__":
	print("Testing SICO interpreter")
	if len(sys.argv)>1:
		# Load a file and run it.
		print("Loading "+sys.argv[1]+"\n")
		SICO.outstr=""
		st=SICO()
		st.parsefile(sys.argv[1])
		while st.state==st.RUNNING:
			st.run(random.randomrange(128))
		print(SICO.outstr,end="")
		print(st.statestr)
	else:
		# Run syntax tests.
		tests=len(sicotests);
		print("Tests: "+str(tests)+"\n")
		for i in range(tests):
			# Load our next test.
			test=sicotests[i]
			print("Test "+str(i+1))
			print("source  : {0}".format(SicoEscape(test[0])))
			# Run the test code.
			SICO.outstr=""
			st=SICO(test[0])
			j=0
			while j<1024:
				insts=random.randrange(16)
				st.run(insts)
				j+=insts
			# Print what we expect.
			print("expected: {0}, {1}, {2}".format(SicoEscape(test[1]),SicoStateStr(test[2]),SicoEscape(test[3])))
			# Print what we actually got.
			print("returned: {0}, {1}, {2}\n".format(SicoEscape(SICO.outstr),SicoStateStr(st.state),SicoEscape(st.statestr)))
			# Compare the two.
			if SICO.outstr!=test[1] or st.state!=test[2] or st.statestr!=test[3]:
				print("Failed")
				exit()
	print("Passed")


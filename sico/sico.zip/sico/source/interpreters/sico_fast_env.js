/*------------------------------------------------------------------------------


sico_fast.js - v1.03

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for SICO.
SICO.run() will call SICOFastRun() automatically if it's detected.


          Mode     |   Time
     --------------+-----------
       JS BigInt   |  2282.20
       JS Fast     |    42.62
       WASM        |    18.83
       WASM + HLI  |     0.20


Memory layout:


     +-----+-----+-----+
     | env | mem | HLI |
     +-----+-----+-----+


Environment variables:


     0 envlen
     1 memlen
     2 hlilen
     3 mod
     4 IO start
     5 ip
     6 instruction limit
     7 IO 1
     8 IO 2


--------------------------------------------------------------------------------
TODO


don't use volatile memory, use functions
getmemjs1
getmemjs2


*/
/* jshint esversion: 11  */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */


//---------------------------------------------------------------------------------
// Javascript Fallback


function SICOFastJSRun(sico,insts,time) {
	// This version of run() unrolls several operations to speed things up.
	// It's 53 times faster than using bigint functions, but slower than wasm.
	if (sico.state!==sico.RUNNING) {return;}
	var fast=sico.fast;
	if (fast===undefined) {sico.fast=fast={};}
	var big=Object.is(fast.mem,sico.mem)-1;
	var iphi=Number(sico.ip>>32n),iplo=Number(sico.ip&0xffffffffn);
	var modhi=Number(sico.mod>>32n),modlo=Number(sico.mod&0xffffffffn);
	var memh=fast.memh,meml=fast.meml;
	var memlen=Number(sico.alloc),memlen2=memlen-2;
	var ahi,alo,chi,clo;
	var bhi,blo,mbhi,mblo;
	var ip,a,b,ma,mb,mem;
	var i,timeiters=0;
	while (insts>0) {
		// Periodically check if we've run for too long.
		if (--timeiters<=0) {
			if (performance.now()>=time) {break;}
			timeiters=2048;
		}
		// Execute using bigints.
		if (big!==0) {
			big=0;
			ip=(BigInt(iphi)<<32n)+BigInt(iplo);
			a =sico.getmem(ip++);
			b =sico.getmem(ip++);
			ma=sico.getmem(a);
			mb=sico.getmem(b);
			ip=ma<=mb?sico.getmem(ip):((ip+1n)%sico.mod);
			sico.setmem(a,ma-mb);
			mem=sico.mem;
			if (!Object.is(fast.mem,mem)) {
				fast.mem=mem;
				var endian=(new Uint32Array((new BigUint64Array([4n])).buffer))[0];
				fast.memh=memh=new Uint32Array(mem.buffer,mem.byteOffset+  endian);
				fast.meml=meml=new Uint32Array(mem.buffer,mem.byteOffset+4-endian);
				memlen=Number(sico.alloc);
				memlen2=memlen-2;
			}
			iphi=Number(ip>>32n);
			iplo=Number(ip&0xffffffffn);
			insts--;
			if (sico.state!==sico.RUNNING) {break;}
			continue;
		}
		// Load a, b, and c.
		if (iphi>0 || iplo>=memlen2) {big=1;continue;}
		i=iplo+iplo;
		ahi=memh[i];
		alo=meml[i];
		i+=2;
		bhi=memh[i];
		blo=meml[i];
		i+=2;
		chi=memh[i];
		clo=meml[i];
		// Input
		if (bhi>0 || blo>=memlen) {big=1;continue;}
		i=blo+blo;
		mbhi=memh[i];
		mblo=meml[i];
		// Output
		if (ahi>0 || alo>=memlen) {big=1;continue;}
		i=alo+alo;
		mblo=meml[i]-mblo;
		mbhi=memh[i]-mbhi;
		if (mblo<0) {
			mblo+=0x100000000;
			mbhi--;
		}
		if (mbhi===0 && mblo===0) {
			iphi=chi;
			iplo=clo;
		} else if (mbhi<0) {
			mblo+=modlo;
			mbhi+=modhi;
			if (mblo>=0x100000000) {
				mblo-=0x100000000;
				mbhi++;
			}
			iphi=chi;
			iplo=clo;
		} else {
			iplo+=3;
		}
		meml[i]=mblo;
		memh[i]=mbhi;
		insts--;
	}
	sico.ip=(BigInt(iphi)<<32n)+BigInt(iplo);
}


//---------------------------------------------------------------------------------
// WASM


function SICOFastInit(st) {
	st.wasm={
		reth:  null,
		hli16: null,
		module:null,
		oldlbl:null,
		oldmem:null
	};
	SICOFastLoadHLI(st);
	SICOFastLoadWASM(st);
}


function SICOFastLoadHLI(st) {
	// Find high-level intercepts.
	var hlitable=[
		// 00xx - none
		// 01xx - uint
		// 02xx - int
		// 03xx - mem
		// 04xx - rand
		// 05xx - string
		// 06xx - image
		// 07xx - audio
		["uint.cmp",0x0100],
		["uint.min",0x0101],
		["uint.max",0x0102],
		["uint.set",0x0103],
		["uint.neg",0x0104],
		["uint.add",0x0105],
		["uint.sub",0x0106],
		["uint.mul",0x0107],
		["uint.div",0x0108],
		["uint.gcd",0x0109],
		["uint.shl",0x010a],
		["uint.shr",0x010b],
		["uint.not",0x010c],
		["uint.and",0x010d],
		["uint.or" ,0x010e],
		["uint.xor",0x010f],
		["image.setpixel",0x060a]
	];
	var hlilen=0;
	for (var i=hlitable.length-1;i>=0;i--) {
		var hliobj=hlitable[i];
		var addr=Number(st.findlabel(hliobj[0]));
		if (addr<0x100000000 && hlilen<=addr) {
			hlilen=addr+1;
		}
	}
	var hlimap=new Uint16Array(hlilen);
	for (var i=hlitable.length-1;i>=0;i--) {
		var hliobj=hlitable[i];
		var addr=Number(st.findlabel(hliobj[0]));
		if (addr>=0 && addr<hlilen) {
			hlimap[addr]=hliobj[1];
		}
	}
	st.wasm.hli16=hlimap;
	st.wasm.oldlbl=st.lblroot;
}


async function SICOFastLoadWASM(st) {
	// Attempt to load the WebAssembly program.
	// sico_wasm.c -> compile -> gzip -> base64
	var wasmstr=`
H4sIALK+lGUC/5VWzW4jRRDuv+kZu+2Ns1xgfWkbDkFoowStNjl6RkLKbSNkVisuk7E9JM4648geAyts
j5eEVYTEM3DMKWcO3DkingIh8RBQ1T3jeDexBJbcXdVV/VV1/XQPicZnlBBCnz04YllGjmhGsyMCf55l
SDIzisxyBBTmRmkOkjmsUNiD1Bw2zHHByWCeE3YkeZx8Xe51js9H/SQ9HROCC6XjOIVpADxd4U+AZ8h7
Y8MDywvxWXyG6qIQAw+sw1VZul6pXFaVqhQOPaeUOpwSJj9xM+ovroTKiL/w7oxWQHCgyv2TPpSAOBy9
YmQzDL+BgITdaDAIu+lwNCbSK05AXGl9JZ60TpKSN+53h/2kn5KyIXvDJCZKWqdJRVpvSdU5mwyePiEP
+GiSkI0PwrCf9PqjuJuGX02SbtofJmEadQYxJZUw7I2H4UmU9AYxp2VgozQK46THWTUMjwfDTjQIO9E4
5lyF4UkcnVtOgNSew/IOIBlMy8ryL9UyI2qTaBLoq2tNrmsL+BH1CFZqr5FskNr3ON8E+o0mN5fqPRBp
atTpde3CqP9NGYP0+8Ueavc0GKr6PH3KakAxg0FvLpt8j6NJonkwm8Ig2vU97vm02K5XjcKGPf6+z9YL
tc/XC7d8sV644zvrhOjkvkYXFwvPjuhlS31K4aRCk4/5TvPtODzyHVzef3dZPYMtrIUyiMeLKgzXEBXg
NlQAUbKiLU2fV1dCe3lf+BtMaaZ+p5RndwE1g7j6AMpaIGQB+bwKbIMv0SlIlgZAAQl2XfsBLXwGuv/r
VD7dUIi+zLrIsw7qWiyz7hjXBQSUFlmnmHWaZ11prv6i3JnjBYKOG+cJnEl8F7C29ZkdgnsQKgf+soIx
0GLWcLXQbNbwgkXxyxol1EBN3tIyoG/AnNDyUEucZu1Rs1yfoYIuNZUu17UzbThgALy4OKwSoKT22mDc
0Qok2tVyChapgnUGlNIqoFeNEkzgG6sQpbQIMihizeYXVhNDiQeH45p4I0u1RFb9Jh2aMTirgP+Hptn8
P8jLJvnI0Jr43mntRyRtelvBP/BzsTDg/FDqJrdwNoLSA7CMYT0wacUKhSjBVJRUC3K23E+D16jATfsu
Ft+anfm+fHcd8LDCCFbSgS9tYm1aR1Vm68rUAsOp9qU5KAv4FHuFYQ02OdQkdBOHgyAlgKoZylSRZ0JU
4HhNiCqWL8v7oUFBGphuhELUDP1elqltCL7SEBwaIkcDoIBOmyIwgdkCB6E22vVZ00V8t8AXFt8WujZx
cQ2+uw5fFPgu4ruAz6Aq7oF2LLTz36EdjLSFxfghqgkoEDNYKAzTF02+cmc0mDXErKH7Lg1vxZBnLo0c
SqDHogCSFkhaIIFAwgCJdUDSNKOWz4sK31cm3CYqsl3HcTY15cffupVMX0BJQCOw2k/5fQONrOydAwVV
ZHl557x7iWrslFPbJ4r8SkUSncX0Z1ojKx8U9PZbgt1+RvDlF4S4/Xhwlt8N8u4b7y6feC9/4Uv5A19e
vu9q+bxX8te9mj/uD+zbvoFPu/uQko0wHKdR92V4DhvTeET2S+ejYW/SjUdjWgGyG4/Hce9x5xWtfNGZ
JOlEdwdRcry5+2R7Z3vn8e7ELO5u7/4L8ez9I5wJAAA=
	`;
	var gzipbytes=Uint8Array.from(atob(wasmstr),(c)=>c.codePointAt(0));
	var gzipstream=new Blob([gzipbytes]).stream();
	var decstream=gzipstream.pipeThrough(new DecompressionStream("gzip"));
	var decblob=await new Response(decstream).blob();
	var wasmbytes=new Uint8Array(await decblob.arrayBuffer());
	// Set up IO functions.
	function dbgprintjs(h,l) {
		st.print("Debug: "+((BigInt(h>>>0)<<32n)+BigInt(l>>>0))+"\n");
	}
	function getenvljs(addr) {
		if (addr<0 || addr>6 || st.wasm.reth!==null) {
			st.print("getenvl error: "+addr+"\n");
			st.state=st.COMPLETE;
			return 0;
		}
		var l=0;
		switch (addr) {
			case 0: l=st.alloc; break;
			case 1: l=st.wasm.hli16.length; break;
			case 2: l=st.mod; break;
			case 3: l=st.io; break;
			case 4: l=st.ip; break;
			case 5: l=st.instlimit; break;
			case 6: l=Number(performance.now()>=st.timelimit); break;
			default: break;
		}
		if ((typeof l)==="bigint") {
			st.wasm.reth=Number(l>>32n);
			l=Number(l&0xffffffffn);
		} else {
			st.wasm.reth=0;
		}
		return l>>>0;
	}
	function getenvhjs() {
		var ret=st.wasm.reth;
		if (ret===null) {
			st.print("getenvh error\n");
			st.state=st.COMPLETE;
			return 0;
		}
		st.wasm.reth=null;
		return ret>>>0;
	}
	function setenvjs(addr,vh,vl) {
		vh>>>=0;
		vl>>>=0;
		switch (addr) {
			case 4:
				st.ip=(BigInt(vh)<<32n)+BigInt(vl);
				break;
			case 5:
				st.instlimit=vl;
				break;
			default:
				break;
		}
		return Number(st.state!==st.RUNNING);
	}
	function getmemljs(ah,al) {
		if (st.wasm.reth!==null) {
			st.print("getmeml error: "+ah+", "+al+"\n");
			st.state=st.COMPLETE;
			return 0;
		}
		var addr=(BigInt(ah>>>0)<<32n)+BigInt(al>>>0);
		var ret=st.getmem(addr);
		st.wasm.reth=Number(ret>>32n);
		return Number(ret&0xffffffffn);
	}
	function setmemjs(ah,al,vh,vl) {
		var addr=(BigInt(ah>>>0)<<32n)+BigInt(al>>>0);
		var val =(BigInt(vh>>>0)<<32n)+BigInt(vl>>>0);
		st.setmem(addr,val);
		if (!Object.is(st.wasm.oldmem,st.mem)) {
			SICOFastResize(st);
		}
		return Number(st.state!==st.RUNNING);
	}
	var imports={dbgprintjs,getenvljs,getenvhjs,setenvjs,getmemljs,setmemjs};
	WebAssembly.instantiate(wasmbytes,{env:imports}).then(
		(mod)=>st.wasm.module=mod,
	);
}


function SICOFastResize(st) {
	// wasm has its own sandboxed memory, so allocate memory in wasm and remap our
	// IO buffer and SICO memory into it. If mem.byteOffset=0, SICO's memory has been
	// reallocated.
	var module=st.wasm.module;
	var wasmmem=module.instance.exports.memory;
	var hlilen=st.wasm.hli16.length,memlen=Number(st.alloc);
	var pagebytes=65536;
	var pages=Math.ceil((memlen*8+hlilen*2)/pagebytes);
	pages-=Math.floor(wasmmem.buffer.byteLength/pagebytes);
	if (pages>0) {wasmmem.grow(pages);}
	var off=0,newhli,newmem;
	newmem=new BigUint64Array(wasmmem.buffer,off,memlen); off+=newmem.byteLength;
	newhli=new    Uint16Array(wasmmem.buffer,off,hlilen); off+=newhli.byteLength;
	//newhli.set(st.wasm.hli16);
	//if (st.mem.length!==0) {newmem.set(st.mem);}
	//console.log(wasmmem.buffer[wasmmem.buffer.length-1]);
	//console.log(wasmmem);
	console.log(memlen*8,newmem.byteLength);
	newmem.set(st.mem,0,memlen);
	//var s="";
	//for (var i=0;i<16;i++) {s+=st.mem[i]+" ";}
	//console.log(s);
	st.mem=newmem;
	st.wasm.oldmem=st.mem;
}


function SICOFastRun(st,insts,time) {
	// On first run load the wasm module.
	if (st.wasm===undefined || !Object.is(st.wasm.oldlbl,st.lblroot)) {
		SICOFastInit(st);
	}
	var module=st.wasm.module;
	if (module===null) {
		// If wasm fails to load, use a backup.
return;
		return SICOFastJSRun(st,insts,time);
	}
	if (st.state!==st.RUNNING) {
		return;
	}
	if (insts<0 || insts>0xffffffff) {insts=0xffffffff;}
	st.instlimit=insts;
	if (!Object.is(st.wasm.oldmem,st.mem)) {
		SICOFastResize(st);
	}
	module.instance.exports.run();
}


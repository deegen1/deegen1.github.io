/*------------------------------------------------------------------------------


sico.js - v2.08

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
The Single Instruction COmputer


pass stack to hli
memh[0]=iphi
meml[0]=iplo
fci(mem,memh,meml)


*/
/* jshint esversion: 11  */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */


//---------------------------------------------------------------------------------
// 64-bit Math


function U64Cmp(u,v) {
	if (u.hi!==v.hi) {
		return u.hi<v.hi?-1:1;
	}
	if (u.lo!==v.lo) {
		return u.lo<v.lo?-1:1;
	}
	return 0;
}


function U64Add(r,u,v) {
	r.lo=u.lo+v.lo;
	if (r.lo>=0x100000000) {
		r.hi=(u.hi+v.hi+1)>>>0;
		r.lo>>>=0;
	} else {
		r.hi=(u.hi+v.hi)>>>0;
	}
}


function U64Sub(r,u,v) {
	r.lo=u.lo-v.lo;
	if (r.lo<0) {
		r.hi=(u.hi-v.hi-1)>>>0;
		r.lo>>>=0;
	} else {
		r.hi=(u.hi-v.hi)>>>0;
	}
}


function U64Mul(rh,rl,u,v) {
	// rh = (u*v)>>64
	// rl = (u*v)&2^64-1
	if (rh===null || rh===undefined) {
	} else {
	}
}


function U64Div(q,r,u,v) {
	// q = u/v
	// r = u%v
}


//---------------------------------------------------------------------------------
// SICO architecture interpreter.


class SICOFast {

	constructor(sico) {
		this.sico=sico;
		this.hlilen=0;
		this.hlimap=[];
		this.meml=[];
		this.memh=[];
	}


	hliinit() {
		let hlinames=[
			// 00xx - none
			// 01xx - uint
			// 02xx - int
			// 03xx - mem
			// 04xx - rand
			// 05xx - string
			// 06xx - image
			// 07xx - audio
			["uint.cmp",0x0100,null],
			["uint.min",0x0101,null],
			["uint.max",0x0102,null],
			["uint.set",0x0103,null],
			["uint.neg",0x0104,null],
			["uint.add",0x0105,null],
			["uint.sub",0x0106,null],
			["uint.mul",0x0107,null],
			["uint.div",0x0108,null],
			["uint.gcd",0x0109,null],
			["uint.shl",0x010a,null],
			["uint.shr",0x010b,null],
			["uint.not",0x010c,null],
			["uint.and",0x010d,null],
			["uint.or" ,0x010e,null],
			["uint.xor",0x010f,null],
			["image.setpixel",0x060a,null]
		];
		let sico=this.sico;
		let hlilen=0;
		for (let i=hlinames.length-1;i>=0;i--) {
			let hli=hlinames[i];
			let addr=Number(sico.findlabel(hli[0]));
			if (addr>=0 && addr<0x100000000) {
				if (hlilen<=addr) {hlilen=addr+1;}
				hli[2]=addr;
			}
		}
		let hlimap=new Uint32Array(hlilen);
		for (let i=hlinames.length-1;i>=0;i--) {
			let hli=hlinames[i];
			if (hli[2]!==null) {
				hlimap[hli[2]]=hli[1];
			}
		}
		this.hlilen=hlilen;
		this.hlimap=hlimap;
	}


	getsplit(h,l) {
		let addr=(BigInt(h)<<32n)+BigInt(l);
		let ret=this.sico.getmem(addr);
		return [Number(ret>>32n),Number(ret&0xffffffffn)];
	}


	hlicmp(memh,meml) {
		let alloc2=memh.length,alloc=alloc2>>>1,i;
		let shi,slo,rhi,rlo;
		let ahi,alo,avhi,avlo;
		let bhi,blo,bvhi,bvlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		i=slo+slo;
		if (shi!==0) {i=Infinity;}
		if (i<alloc2) {ahi=memh[i];alo=meml[i];} else {[ahi,alo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {bhi=memh[i];blo=meml[i];} else {[bhi,blo]=this.getsplit(shi,slo);} slo++;
		memh[0]=0;
		meml[0]=0;
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		if (avhi>bvhi) {
			slo+=2;
		} else if (avhi===bvhi) {
			if (avlo>bvlo) {
				slo+=2;
			} else if (avlo===bvlo) {
				slo+=1;
			}
		}
		if (slo>=0x100000000) {
			shi++;
			slo>>>=32;
		}
		shi>>>=32;
		if (shi===0 && slo<alloc) {i=slo+slo;return [memh[i],meml[i]];} else {return this.getsplit(shi,slo);}
	}


	hliand(memh,meml) {
		/*let iphi,iplo;
		let call=this.uint(2n-this.getmem(0));
		let r=this.getmem(call++);
		let a=this.getmem(call++);
		let b=this.getmem(call++);
		let v=this.getmem(a)&this.getmem(b);
		this.setmem(r,v);
		memh[0]=0;
		meml[0]=0;
		iphi=Number(call>>32n);
		iplo=Number(call&0xffffffffn);
		return [iphi,iplo];*/
		let alloc2=memh.length,alloc=alloc2>>>1,i;
		let shi,slo,rhi,rlo;
		let ahi,alo,avhi,avlo;
		let bhi,blo,bvhi,bvlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		i=slo+slo;
		if (shi!==0) {i=Infinity;}
		if (i<alloc2) {rhi=memh[i];rlo=meml[i];} else {[rhi,rlo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {ahi=memh[i];alo=meml[i];} else {[ahi,alo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {bhi=memh[i];blo=meml[i];} else {[bhi,blo]=this.getsplit(shi,slo);} slo++;
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		avlo&=bvlo;
		avhi&=bvhi;
		if (rhi===0 && rlo<alloc) {i=rlo+rlo;memh[i]=avhi;meml[i]=avlo;} else {this.setsplit(rhi,rlo,avhi,avlo);}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	hlior(memh,meml) {
		let alloc2=memh.length,alloc=alloc2>>>1,i;
		let shi,slo,rhi,rlo;
		let ahi,alo,avhi,avlo;
		let bhi,blo,bvhi,bvlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		i=slo+slo;
		if (shi!==0) {i=Infinity;}
		if (i<alloc2) {rhi=memh[i];rlo=meml[i];} else {[rhi,rlo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {ahi=memh[i];alo=meml[i];} else {[ahi,alo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {bhi=memh[i];blo=meml[i];} else {[bhi,blo]=this.getsplit(shi,slo);} slo++;
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		avlo|=bvlo;
		avhi|=bvhi;
		if (rhi===0 && rlo<alloc) {i=rlo+rlo;memh[i]=avhi;meml[i]=avlo;} else {this.setsplit(rhi,rlo,avhi,avlo);}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	hlixor(memh,meml) {
		let alloc2=memh.length,alloc=alloc2>>>1,i;
		let shi,slo,rhi,rlo;
		let ahi,alo,avhi,avlo;
		let bhi,blo,bvhi,bvlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		i=slo+slo;
		if (shi!==0) {i=Infinity;}
		if (i<alloc2) {rhi=memh[i];rlo=meml[i];} else {[rhi,rlo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {ahi=memh[i];alo=meml[i];} else {[ahi,alo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {bhi=memh[i];blo=meml[i];} else {[bhi,blo]=this.getsplit(shi,slo);} slo++;
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		avlo^=bvlo;
		avhi^=bvhi;
		if (rhi===0 && rlo<alloc) {i=rlo+rlo;memh[i]=avhi;meml[i]=avlo;} else {this.setsplit(rhi,rlo,avhi,avlo);}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	hliadd(memh,meml) {
		let alloc2=memh.length,alloc=alloc2>>>1,i;
		let shi,slo,rhi,rlo;
		let ahi,alo,avhi,avlo;
		let bhi,blo,bvhi,bvlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		i=slo+slo;
		if (shi!==0) {i=Infinity;}
		if (i<alloc2) {rhi=memh[i];rlo=meml[i];} else {[rhi,rlo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {ahi=memh[i];alo=meml[i];} else {[ahi,alo]=this.getsplit(shi,slo);} slo++;i+=2;
		if (i<alloc2) {bhi=memh[i];blo=meml[i];} else {[bhi,blo]=this.getsplit(shi,slo);} slo++;
		if (ahi===0 && alo<alloc) {i=alo+alo;avhi=memh[i];avlo=meml[i];} else {[avhi,avlo]=this.getsplit(ahi,alo);}
		if (bhi===0 && blo<alloc) {i=blo+blo;bvhi=memh[i];bvlo=meml[i];} else {[bvhi,bvlo]=this.getsplit(bhi,blo);}
		avlo+=bvlo;
		if (avlo>=0x100000000) {
			avhi++;
			avlo>>>=32;
		}
		avhi=(avhi+bvhi)>>>32;
		if (rhi===0 && rlo<alloc) {i=rlo+rlo;memh[i]=avhi;meml[i]=avlo;} else {this.setsplit(rhi,rlo,avhi,avlo);}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	hlimul(memh,meml) {
		let alloc=memh.length>>>1,i;
		let shi,slo;
		let hhi,hlo,lhi,llo;
		let ahi,alo,val;
		let bhi,blo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		if (shi!==0 || slo>=alloc) {[hhi,hlo]=this.getsplit(shi,slo);} else {i=slo+slo;hhi=memh[i];hlo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[lhi,llo]=this.getsplit(shi,slo);} else {i=slo+slo;lhi=memh[i];llo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[ahi,alo]=this.getsplit(shi,slo);} else {i=slo+slo;ahi=memh[i];alo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[bhi,blo]=this.getsplit(shi,slo);} else {i=slo+slo;bhi=memh[i];blo=meml[i];} slo++;
		if (ahi!==0 || alo>=alloc) {val =this.getmem(alo);} else {val =this.sico.mem[alo];}
		if (bhi!==0 || blo>=alloc) {val*=this.getmem(blo);} else {val*=this.sico.mem[blo];}
		if (hhi!==0 || hlo!==0) {
			if (hhi!==0 || hlo>=alloc) {} else {this.sico.mem[hlo]=val>>64n;}
		}
		if (lhi!==0 || llo>=alloc) {} else {this.sico.mem[llo]=val&0xffffffffffffffffn;}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	hlisetpixel(memh,meml) {
		let alloc=memh.length>>>1,i;
		let shi,slo;
		let phi,plo;
		let xhi,xlo;
		let yhi,ylo;
		let ihi,ilo;
		let whi,wlo;
		let hhi,hlo;
		let dhi,dlo;
		shi=0x0ffffffff-memh[0];
		slo=0x100000002-meml[0];
		if (shi!==0 || slo>=alloc) {[ihi,ilo]=this.getsplit(shi,slo);} else {i=slo+slo;ihi=memh[i];ilo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[xhi,xlo]=this.getsplit(shi,slo);} else {i=slo+slo;xhi=memh[i];xlo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[yhi,ylo]=this.getsplit(shi,slo);} else {i=slo+slo;yhi=memh[i];ylo=meml[i];} slo++;
		if (shi!==0 || slo>=alloc) {[phi,plo]=this.getsplit(shi,slo);} else {i=slo+slo;phi=memh[i];plo=meml[i];} slo++;
		if (ihi!==0 || ilo>=alloc) {[ihi,ilo]=this.getsplit(ihi,ilo);} else {i=ilo+ilo;ihi=memh[i];ilo=meml[i];}
		if (xhi!==0 || xlo>=alloc) {[xhi,xlo]=this.getsplit(xhi,xlo);} else {i=xlo+xlo;xhi=memh[i];xlo=meml[i];}
		if (yhi!==0 || ylo>=alloc) {[yhi,ylo]=this.getsplit(yhi,ylo);} else {i=ylo+ylo;yhi=memh[i];ylo=meml[i];}
		if (phi!==0 || plo>=alloc) {[phi,plo]=this.getsplit(phi,plo);} else {i=plo+plo;phi=memh[i];plo=meml[i];}
		if (ihi!==0 || ilo>=alloc) {[whi,wlo]=this.getsplit(ihi,ilo);} else {i=ilo+ilo;whi=memh[i];wlo=meml[i];} ilo++;
		if (ihi!==0 || ilo>=alloc) {[hhi,hlo]=this.getsplit(ihi,ilo);} else {i=ilo+ilo;hhi=memh[i];hlo=meml[i];} ilo++;
		if (ihi!==0 || ilo>=alloc) {[dhi,dlo]=this.getsplit(ihi,ilo);} else {i=ilo+ilo;dhi=memh[i];dlo=meml[i];}
		if ((xhi<whi || (xhi===whi && xlo<wlo)) && (yhi<hhi || (yhi===hhi && ylo<hlo))) {
			dlo+=ylo*wlo+xlo;
			if (dlo<alloc) {
				i=dlo+dlo;
				memh[i]=phi;
				meml[i]=plo;
			} else {
				this.setsplit(dhi,dlo,phi,plo);
			}
		}
		memh[0]=0;
		meml[0]=0;
		if (slo>0xffffffff) {shi=(shi+1)>>>32;slo>>>=32;}
		return [shi,slo];
	}


	run(insts,time) {
		// This version of run() unrolls several operations to speed things up.
		// It's 53 times faster than using bigint functions, but slower than wasm.
		let sico=this.sico;
		if (sico.state!==sico.RUNNING) {return;}
		let big=0;
		if (!Object.is(this.oldmem,this.mem)) {
			big=1;
			this.hliinit();
		}
		let iphi=Number(sico.ip>>32n),iplo=Number(sico.ip&0xffffffffn);
		let modhi=Number(sico.mod>>32n),modlo=Number(sico.mod&0xffffffffn);
		let memh=this.memh,meml=this.meml;
		let memlen=Number(sico.memlen),memlen2=memlen-2;
		let hlilen=this.hlilen,hlimap=this.hlimap;
		let ahi,alo,chi,clo;
		let bhi,blo,mbhi,mblo;
		let ip,a,b,ma,mb,mem;
		let i,timeiters=0;
		while (insts>0) {
			// Periodically check if we've run for too long.
			if (--timeiters<=0) {
				if (performance.now()>=time) {break;}
				timeiters=2048;
			}
			// Execute using bigints.
			if (big!==0) {
				big=0;
				ip=(BigInt(iphi)<<32n)+BigInt(iplo);
				a =sico.getmem(ip++);
				b =sico.getmem(ip++);
				ma=sico.getmem(a);
				mb=sico.getmem(b);
				ip=ma<=mb?sico.getmem(ip):((ip+1n)%sico.mod);
				sico.setmem(a,ma-mb);
				mem=sico.mem;
				if (!Object.is(this.oldmem,mem)) {
					this.oldmem=mem;
					let endian=(new Uint32Array((new BigUint64Array([4n])).buffer))[0];
					this.memh=memh=new Uint32Array(mem.buffer,mem.byteOffset+  endian);
					this.meml=meml=new Uint32Array(mem.buffer,mem.byteOffset+4-endian);
					memlen=Number(sico.memlen);
					memlen2=memlen-2;
				}
				iphi=Number(ip>>32n);
				iplo=Number(ip&0xffffffffn);
				insts--;
				if (sico.state!==sico.RUNNING) {break;}
				continue;
			}
			if (iphi===0 && iplo<hlilen && (i=hlimap[iplo])!==0) {
				switch (i) {
					case 0x0105:
						// add
						[iphi,iplo]=this.hliadd(memh,meml);break;
					case 0x0100:
						// cmp
						[iphi,iplo]=this.hlicmp(memh,meml);break;
					case 0x0107:
						// Multiply
						[iphi,iplo]=this.hlimul(memh,meml);break;
					case 0x010d:
						// And
						[iphi,iplo]=this.hliand(memh,meml);break;
					case 0x010e:
						// Or
						[iphi,iplo]=this.hlior( memh,meml);break;
					case 0x010f:
						// xor
						[iphi,iplo]=this.hlixor(memh,meml);break;
					case 0x060a:
						[iphi,iplo]=this.hlisetpixel(memh,meml);break;
					default:
						i=0;
						break;
				}
				if (!Object.is(this.oldmem,sico.mem)) {big=1;continue;}
				if (i!==0) {continue;}
			}
			// Load a, b, and c.
			if (iphi>0 || iplo>=memlen2) {big=1;continue;}
			i=iplo+iplo;
			ahi=memh[i];
			alo=meml[i];
			i+=2;
			bhi=memh[i];
			blo=meml[i];
			i+=2;
			chi=memh[i];
			clo=meml[i];
			// Input
			if (bhi>0 || blo>=memlen) {big=1;continue;}
			i=blo+blo;
			mbhi=memh[i];
			mblo=meml[i];
			// Output
			if (ahi>0 || alo>=memlen) {big=1;continue;}
			i=alo+alo;
			mblo=meml[i]-mblo;
			mbhi=memh[i]-mbhi;
			if (mblo<0) {
				mblo+=0x100000000;
				mbhi--;
			}
			if (mbhi===0 && mblo===0) {
				iphi=chi;
				iplo=clo;
			} else if (mbhi<0) {
				mblo+=modlo;
				mbhi+=modhi;
				if (mblo>=0x100000000) {
					mblo-=0x100000000;
					mbhi++;
				}
				iphi=chi;
				iplo=clo;
			} else {
				iplo+=3;
			}
			meml[i]=mblo;
			memh[i]=mbhi;
			insts--;
		}
		sico.ip=(BigInt(iphi)<<32n)+BigInt(iplo);
	}

}


function SICOFastRun(sico,insts,time) {
	if (sico.fast===undefined) {
		sico.fast=new SICOFast(sico);
	}
	sico.fast.run(insts,time);
}


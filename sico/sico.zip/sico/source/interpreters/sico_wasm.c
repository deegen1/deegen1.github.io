/*------------------------------------------------------------------------------


sico_wasm.c - v1.05

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for SICO.
The stack and heap share memory. --stack-first keeps the stack at 0.
Some variables are marked as volatile to prevent compiler reordering.

Memory layout:


     +-------+-----+-----+-----+
     | stack | env | mem | HLI |
     +-------+-----+-----+-----+


Environment variables:


     0 envlen
     1 memlen
     2 hlilen
     3 mod
     4 IO start
     5 ip
     6 instruction limit
     7 IO 1
     8 IO 2


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang sico_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--stack-first \
-Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined --output sico.wasm


--------------------------------------------------------------------------------
TODO


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	#pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
	#pragma clang diagnostic ignored "-Wreserved-identifier"
#endif

#include <stdint.h>

typedef unsigned char u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;


//---------------------------------------------------------------------------------
// Javascript helper functions


extern void getmemjs(void);
extern void setmemjs(void);
extern int  timelimitjs(void);
extern void dbgprintjs(int h,int l);


void dbgprint(u64 x) {
	dbgprintjs((int)(x>>32),(int)(x&0xffffffff));
}


extern const uint8_t __heap_base;
__attribute__((used)) int getheapbase(void) {
	return (int)&__heap_base;
}


//---------------------------------------------------------------------------------
// SICO helper functions


// Use volatile to prevent reordering.
#define env     ((volatile u64*)&__heap_base)
#define envlen  9
#define mem     (((volatile u64*)&__heap_base)+envlen)
#define stopint 0x20000


// __attribute__((noinline))
u64 getmem(u64 addr) {
	env[7]=addr;
	env[8]=0;
	getmemjs();
	return env[8];
}


// __attribute__((noinline))
u32 setmem(u64 addr,u64 val) {
	env[7]=addr;
	env[8]=val;
	setmemjs();
	return env[8]!=0;
}


void mul64(u64* hi,u64* lo,u64 a,u64 b,u64 mod) {
	u64 rh=0,rl=0;
	if (!hi && !(mod&(mod-1))) {
		rl=(a*b)&(mod-1);
	} else {
		#define add(x) if (x && rl>=mod-x) {rl+=x-mod;rh+=i;} else {rl+=x;}
		for (u64 i=1ULL<<63;i;i>>=1) {
			add(rl)
			if (b&i) {add(a)}
		}
		#undef add
		if (hi) {*hi=rh;}
	}
	if (lo) {*lo=rl;}
}


//---------------------------------------------------------------------------------
// Main Loop


__attribute__((used)) void run(void) {
	// Copied from sico_hli.cpp.
	// Run the SICO program.
	#define hliinit()           \
		{                      \
		ip=mod-mem[0]+2;       \
		mem[0]=0;
	#define hlidone()           \
		}                      \
		break;
	#define getmem0(addr)       \
		(addr<memlen?mem[addr]:getmem(addr))
	#define getip1(ret)         \
		ret=ip<memlen?mem[ip]:getmem(ip); \
		if (++ip>=mod) {ip-=mod;}
	#define getip2(ret)         \
		ret=ip<memlen?mem[ip]:getmem(ip); \
		ret=ret<memlen?mem[ret]:getmem(ret); \
		if (++ip>=mod) {ip-=mod;}
	#define setres(addr,val)    \
		if (addr<memlen) {     \
			mem[addr]=val;    \
		} else {               \
			memlen =env[1];   \
			memlen3=memlen<4?0:(memlen-3); \
			hlimap =(volatile u16*)(mem+memlen); \
			if (setmem(addr,val)) {hli=0xffff;break;} \
		}
	if (env[0]!=envlen) {return;}
	u64 memlen   =env[1];
	u64 memlen3  =memlen<4?0:(memlen-3);
	volatile u16* hlimap=(volatile u16*)(mem+memlen);
	u64 hlilen   =env[2];
	u16 hli      =0;
	u64 mod      =env[3];
	// u64 io     =env[4];
	u64 ip       =env[5];
	u64 instlimit=env[6];
	u64 stopcheck=instlimit<stopint?instlimit:stopint;
	u64 a,b,c,ma,mb;
	// If we want to run for a finite amount of instructions, disable HLI.
	if (instlimit<0x80000000) {hlilen=0;}
	while (1) {
		// Check if we need to stop.
		if (--stopcheck>=stopint) {
			if (instlimit>=0x80000000) {
				stopcheck=stopint;
			} else {
				if (instlimit<=stopint) {break;}
				instlimit-=stopint;
				stopcheck=(instlimit<stopint?instlimit:stopint)-1;
			}
			if (timelimitjs()) {break;}
		}
		// High-level intercept
		if (ip<hlilen && (hli=hlimap[ip])!=0) {
			u64 hret,lret,tmp;
			switch (hli) {
				case 0x0100:
					// uint.cmp a b lt eq gt
					hliinit()
					getip2(a)
					getip2(b)
					ip+=(a>=b)+(a>b);
					ip=getmem0(ip);
					hlidone()
				case 0x0101:
					// uint.min r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a<b?a:b;
					setres(lret,a)
					hlidone()
				case 0x0102:
					// uint.max r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a>b?a:b;
					setres(lret,a)
					hlidone()
				case 0x0103:
					// uint.set r a
					hliinit()
					getip1(lret)
					getip2(a)
					setres(lret,a)
					hlidone()
				case 0x0104:
					// uint.neg r a
					hliinit()
					getip1(lret)
					getip2(a)
					a=a?mod-a:0;
					setres(lret,a)
					hlidone()
				case 0x0105:
					// uint.add r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a>=mod-b?(a+b-mod):(a+b);
					setres(lret,a)
					hlidone()
				case 0x0106:
					// uint.sub r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a<b?(mod+a-b):(a-b);
					setres(lret,a)
					hlidone()
				case 0x0107:
					// uint.mul h l a b
					hliinit()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					mul64(hret?&a:0,&b,a,b,mod);
					setres(hret,a)
					setres(lret,b)
					hlidone()
				case 0x0108:
					// uint.div quot rem a b
					hliinit()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					if (!b) {setres(mod-1,0)}
					tmp=a/b;
					a%=b;
					setres(hret,tmp)
					setres(lret,a)
					hlidone()
				case 0x0109:
					// uint.gcd r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (b) {
						tmp=a%b;
						a=b;
						b=tmp;
					}
					setres(lret,a)
					hlidone()
				case 0x010a:
					// uint.shl r a s
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {
						a=a>=mod-a?(a+a-mod):(a+a);
					}
					setres(lret,a)
					hlidone()
				case 0x010b:
					// uint.shr r a s
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {a>>=1;}
					setres(lret,a)
					hlidone()
				case 0x010c:
					// uint.not r a
					hliinit()
					getip1(lret)
					getip2(a)
					a=mod-1-a;
					setres(lret,a)
					hlidone()
				case 0x010d:
					// uint.and r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a&=b;
					setres(lret,a)
					hlidone()
				case 0x010e:
					// uint.or r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a|=b;
					if (a>=mod) {a-=mod;}
					setres(lret,a)
					hlidone()
				case 0x010f:
					// uint.xor r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a^=b;
					if (a>=mod) {a-=mod;}
					setres(lret,a)
					hlidone()
				case 0x060a:
					// image.setpixel img x y argb
					hliinit()
					u64 img,x,y,w,h,argb,data;
					getip2(img)
					getip2(x)
					getip2(y)
					getip2(argb)
					w=getmem0(img); img++;
					h=getmem0(img); img++;
					if (x<w && y<h) {
						data=getmem0(img)+y*w+x;
						setres(data,argb)
					}
					hlidone()
				default:
					hli=0;
					break;
			}
			if (hli) {
				if (memlen) {mem[0]=0;}
				if (hli==0xffff) {break;}
			}
		}
		// Normal instruction
		if (ip<memlen3) {
			a=mem[ip++];
			b=mem[ip++];
			c=mem[ip++];
		} else {
			getip1(a)
			getip1(b)
			getip1(c)
		}
		ma=getmem0(a);
		mb=getmem0(b);
		if (ma<=mb) {ip=c;}
		ma=ma<mb?ma-mb+mod:ma-mb;
		setres(a,ma)
	}
	env[5]=ip;
	env[6]=instlimit;
}

/*------------------------------------------------------------------------------


sico_wasm.c - v1.00

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for SICO.
Memory is sandboxed, so it starts at 0.
Some variables are marked as volatile to prevent compiler reordering.


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang sico_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--export-all \
-Wl,--no-entry -Wl,--allow-undefined --output sico.wasm


--------------------------------------------------------------------------------
TODO


Allow sleeping
env | mem | IO | HLI
use envlen, memlen, iolen, hlilen
Speed up drawimage byte shifting, add another IO buffer, simd


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
#endif


#include <stdint.h>


typedef unsigned char u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;


extern void getmem(void);
extern void setmem(void);
extern void gettime(void);


#define getmem_(ret,addr) \
	if (addr<alloc) {    \
		ret=mem[addr];  \
	} else {             \
		io[6]=addr;     \
		getmem();       \
		ret=io[7];      \
	}


#define setmem_(addr,val) \
	if (addr<alloc) {    \
		mem[addr]=val;  \
	} else {             \
		io[6]=addr;     \
		io[7]=val;      \
		setmem();       \
		alloc=io[2];    \
		alloc3=alloc<4?0:(alloc-3); \
		hlimap=(u16*)(mem+alloc);   \
		if (io[7]) {    \
			break;     \
		}               \
	}


#define setip0()          \
	ip=mod-mem[0]+2;     \
	mem[0]=0;


#define getip1(ret)       \
	if (ip<alloc) {      \
		ret=mem[ip];    \
	} else {             \
		io[6]=ip;       \
		getmem();       \
		ret=io[7];      \
	}                    \
	if (++ip>=mod) {ip-=mod;}


#define getip2(ret)       \
	if (ip<alloc) {      \
		tmp=mem[ip];    \
	} else {             \
		io[6]=ip;       \
		getmem();       \
		tmp=io[7];      \
	}                    \
	if (tmp<alloc) {     \
		ret=mem[tmp];   \
	} else {             \
		io[6]=tmp;      \
		getmem();       \
		ret=io[7];      \
	}                    \
	if (++ip>=mod) {ip-=mod;}


#define setres(addr,val)  \
	if (addr<alloc) {    \
		mem[addr]=val;  \
		mem[0]=0;       \
	} else {             \
		io[6]=addr;     \
		io[7]=val;      \
		setmem();       \
		mem[0]=0;       \
		alloc=io[2];    \
		alloc3=alloc<4?0:(alloc-3); \
		hlimap=(u16*)(mem+alloc);   \
		if (io[7]) {    \
			hli=0;     \
			break;     \
		}               \
	}


void mul64(u64* hi,u64* lo,u64 a,u64 b,u64 mod) {
	u64 rh=0,rl=0;
	if (!hi && !(mod&(mod-1))) {
		rl=(a*b)&(mod-1);
	} else {
		#define add(x) if (x && rl>=mod-x) {rl+=x-mod;rh+=i;} else {rl+=x;}
		for (u64 i=1ULL<<63;i;i>>=1) {
			add(rl)
			if (b&i) {add(a)}
		}
		#undef add
		if (hi) {*hi=rh;}
	}
	if (lo) {*lo=rl;}
}


__attribute__((used)) void run(void) {
	// WASM memory is sandboxed, so it starts at 0.
	// Use volatile to prevent reordering.
	volatile u64* io=0;
	u64* mem   =((u64*)0)+8;
	u64  mod   =io[0];
	u64  ip    =io[1];
	u64  alloc =io[2];
	u64  alloc3=alloc<4?0:(alloc-3);
	u32  insts =(u32)io[3];
	u64  time  =io[4];
	u64  hlilen=io[5];
	u16* hlimap=(u16*)(mem+alloc);
	u64  time0 =0;
	#define stopint 0x20000
	u32  stopcheck=insts<stopint?insts:stopint;
	u16  hli;
	u64  a,b,c,ma,mb;
	// If we want to run for a finite amount of instructions, disable HLI.
	if (insts<0x80000000) {hlilen=0;}
	while (1) {
		// Check if we need to stop.
		if (--stopcheck>=stopint) {
			if (insts>=0x80000000) {
				stopcheck=stopint;
			} else {
				if (insts<=stopint) {break;}
				insts-=stopint;
				stopcheck=(insts<stopint?insts:stopint)-1;
			}
			gettime();
			if (io[7]>=time || io[7]<time0) {break;}
			time0=io[7];
		}
		// High-level intercept.
		if (ip<hlilen && (hli=hlimap[ip])!=0) {
			u64 hret,lret,tmp;
			switch (hli) {
				case 0x0100:
					// uint.cmp a b lt eq gt
					setip0()
					getip2(a)
					getip2(b)
					ip+=(a==b)+(a>b);
					getmem_(ip,ip)
					break;
				case 0x0101:
					// uint.min r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a<b?a:b)
					break;
				case 0x0102:
					// uint.max r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a>b?a:b)
					break;
				case 0x0103:
					// uint.set r a
					setip0()
					getip1(lret)
					getip2(a)
					setres(lret,a)
					break;
				case 0x0104:
					// uint.neg r a
					setip0()
					getip1(lret)
					getip2(a)
					setres(lret,a?mod-a:0)
					break;
				case 0x0105:
					// uint.add r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a>=mod-b?(a+b-mod):(a+b);
					setres(lret,a)
					break;
				case 0x0106:
					// uint.sub r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a<b?(mod+a-b):(a-b);
					setres(lret,a)
					break;
				case 0x0107:
					// uint.mul h l a b
					setip0()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					mul64(hret?&a:0,&b,a,b,mod);
					setres(hret,a)
					setres(lret,b)
					break;
				case 0x0108:
					// uint.div quot rem a b
					setip0()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(hret,a/b)
					setres(lret,a%b)
					break;
				case 0x0109:
					// uint.gcd r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (b) {
						tmp=a;
						a%=b;
						b=tmp;
					}
					setres(lret,a)
					break;
				case 0x010a:
					// uint.shl r a s
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {
						a=a>=mod-a?(a+a-mod):(a+a);
					}
					setres(lret,a)
					break;
				case 0x010b:
					// uint.shr r a s
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {a>>=1;}
					setres(lret,a)
					break;
				case 0x010c:
					// uint.not r a
					setip0()
					getip1(lret)
					getip2(a)
					setres(lret,mod-1-a)
					break;
				case 0x010d:
					// uint.and r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a&b)
					break;
				case 0x010e:
					// uint.or r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a|b)
					break;
				case 0x010f:
					// uint.xor r a b
					setip0()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a^b)
					break;
				case 0x040a:
					// image.setpixel img x y argb
					{
						u64 img,x,y,w,h,argb,data;
						setip0()
						getip2(img)
						getip2(x)
						getip2(y)
						getip2(argb)
						getmem_(w,img) img++;
						getmem_(h,img) img++;
						if (x<w && y<h) {
							getmem_(data,img)
							data+=y*w+x;
							setres(data,argb)
						}
						break;
					}
				default:
					break;
			}
			if (hli==0) {break;}
		}
		// Normal instruction
		if (ip<alloc3) {
			a=(mem+0)[ip];
			b=(mem+1)[ip];
			c=(mem+2)[ip];
			ip+=3;
		} else {
			getip1(a)
			getip1(b)
			getip1(c)
		}
		getmem_(ma,a)
		getmem_(mb,b)
		if (ma<=mb) {ip=c;}
		ma=ma<mb?ma-mb+mod:ma-mb;
		setmem_(a,ma)
	}
	io[3]=(u64)insts;
	io[1]=ip;
}

/*------------------------------------------------------------------------------


sico.cpp - v1.53

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
The Single Instruction COmputer


SICO is a Single Instruction COmputer that mimics the functionality of a normal
computer while using only one computing instruction. This is like going into a
forest with no tools and trying to build a house. Since we only have one
instruction, most modern conveniences are gone. Things like multiplying numbers
or memory allocation need to be built from scratch using SICO's instruction.

The instruction is simple: Given A, B, and C, compute mem[A]-=mem[B]. Then, if
mem[A] was less than or equal to mem[B], jump to C. Otherwise, jump by 3. We
use the instruction pointer to keep track of our place in memory. The pseudocode
below shows a SICO instruction:


     A = mem[IP+0]
     B = mem[IP+1]
     C = mem[IP+2]
     IP += 3
     if mem[A] <= mem[B]: IP = C
     mem[A] -= mem[B]


The instruction pointer and memory values are all 64 bit unsigned integers.
Interaction with the host environment is done by reading and writing from
special memory addresses. For example: writing anything to -1 will end the
program.


--------------------------------------------------------------------------------
SICO Assembly Language


Because there's only one instruction, we only need to define memory values. The
flow of the program will decide what gets executed.


A "Hello, World!" program in assembly:


     loop:  len  one  exit
            0-2  txt  ?+1
            ?-2  neg  loop

     exit:  0-1  0    0

     txt:   'H 'e 'l 'l 'o ', '
            'W 'o 'r 'l 'd '! 10
     len:   len-txt+1
     neg:   0-1
     one:   1


The syntax of the assembly language


     Line Comment       |  # comment
     Block Comment      |  #| comment |#
     Label Declaration  |  label:
     Label Recall       |  label
     Sublabel           |  label: .sub: is treated as 'label.sub:'
     Current Address    |  ?
     Number             |  123 or 0xabc
     ASCII Literal      |  'A 'B 'C evaluates to 65 66 67
     Operator           |  + or -. Ex: 1+2-3
     Input / Output     |  Read or write to addresses above 2^63


IO addresses (mod 2^64)


     -1  |  Writing ends execution
     -2  |  Write to stdout
     -3  |  Read from stdin
     -4  |  Read timing frequency
     -5  |  Read system time
     -6  |  Writing sleeps for mem[B]/freq seconds


To print the letter 'A' to stdout:


     0-2  chr  ?+1
     chr: 'A


--------------------------------------------------------------------------------
TODO


Linux: g++ -O3 sico.cpp -o sico -lSDL2

Debug: g++ -Wall -Wextra -Wpedantic -Wformat=1 -Wconversion -Winit-self -Wundef\
       -Wshadow -fsanitize=address -fsanitize=undefined sico.cpp -o sico -lSDL2

Windows: cl /W4 /O2 /DSDL_MAIN_HANDLED sico.cpp /I "C:\SDL2\include" /link\
         /LIBPATH:"C:\SDL2\lib\x64" SDL2.lib SDL2main.lib /SUBSYSTEM:CONSOLE


*/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <time.h>
#ifdef _MSC_VER
	#include <windows.h>
	#include <SDL.h>
	#define nanosleep(req,rem) Sleep((DWORD)((req)->tv_sec*1000+(req)->tv_nsec/1000000))
#else
	#include <SDL2/SDL.h>
#endif

typedef unsigned char u8;
typedef uint32_t u32;
typedef  int32_t s32;
typedef uint64_t u64;


//---------------------------------------------------------------------------------
// SICO architecture interpreter.


class SICO {
public:
	const u32 COMPLETE    =0;
	const u32 RUNNING     =1;
	const u32 ERROR_PARSER=2;
	const u32 ERROR_MEMORY=3;


	class Label {
	public:
		u64 addr;
		Label* child[16];
		Label(void) {
			addr=(u64)-1;
			for (u32 i=0;i<16;i++) {child[i]=0;}
		}
		~Label(void) {
			for (u32 i=0;i<16;i++) {delete child[i];}
		}
	};


	// State
	u32    state_;
	char   statestr_[256];
	u64    ip_;
	u64*   mem_;
	u64    alloc_;
	u64    mod_;
	u64    io_;
	Label* lblroot_;
	u8*    hlimap_;
	// Graphics
	SDL_Window*   window_;
	SDL_Renderer* render_;
	SDL_Texture*  texture_;


	SICO(const char* source=0,u64 mod=0) {
		state_   =0;
		statestr_[0]=0;
		ip_      =0;
		mem_     =0;
		alloc_   =0;
		mod_     =mod;
		io_      =(mod-1)/2+1;
		lblroot_ =0;
		hlimap_  =0;
		window_  =0;
		parseassembly(source);
	}


	~SICO(void) {
		clear();
		delete lblroot_;
	}


	void clear(void) {
		state_=COMPLETE;
		ip_=0;
		free(mem_);
		mem_=0;
		alloc_=0;
		delete lblroot_;
		free(hlimap_);
		hlimap_=0;
		lblroot_=new Label();
		closewindow();
	}


	// ----------------------------------------
	// Assembly


	void mul64(u64* hi,u64* lo,u64 a,u64 b) {
		u64 rh=0,rl=0,mod=mod_;
		if (!hi && !(mod&(mod-1))) {
			rl=(a*b)&(mod-1);
		} else {
			#define add(x) if (x && rl>=mod-x) {rl+=x-mod;rh+=i;} else {rl+=x;}
			for (u64 i=1ULL<<63;i;i>>=1) {
				add(rl);
				if (b&i) {add(a)}
			}
			#undef add
			if (hi) {*hi=rh;}
		}
		if (lo) {*lo=rl;}
	}


	Label* addlabel(Label* scope,const char* str,u32 len) {
		// If the label starts with a '.', make it a child of the last non '.' label.
		Label *prv,*lbl=str[0]=='.'?scope:lblroot_;
		for (u32 i=0;i<len;i++) {
			u8 c=(u8)str[i];
			for (u32 j=4;j<8;j-=4) {
				u32 val=(u32)((c>>j)&15);
				prv=lbl;
				lbl=prv->child[val];
				if (!lbl) {
					lbl=new Label();
					prv->child[val]=lbl;
				}
			}
		}
		return lbl;
	}


	u64 findlabel(const char* str) {
		// Returns the given label's address. Returns -1 if no label was found.
		u8 c;
		Label* lbl=lblroot_;
		for (u32 i=0;(c=(u8)str[i])!=0;i++) {
			for (u32 j=4;j<8;j-=4) {
				u32 val=(u32)((c>>j)&15);
				lbl=lbl->child[val];
				if (!lbl) {return (u64)-1;}
			}
		}
		return lbl->addr;
	}


	void parseassembly(const char* asmstr) {
		// Convert SICO assembly language into a SICO program.
		clear();
		u32 i=0,j=0,c;
		u32 l=asmstr?(u32)strlen(asmstr):0;
		const char* err=0;
		u64 mod=mod_;
		#define tonum(c) (c>='A'?(c>='a'?c-'a'+10:c-'A'+10):(c>='0' && c<='9'?c-'0':99))
		#define isspc(c) (c==' ' || c=='\r' || c=='\n' || c=='\t')
		#define islbl(c) (c>127 || tonum(c)<36 || c=='_' || c=='.')
		#define s(i)     ((i)<l?asmstr[i]:0)
		// Process the string in 2 passes. The first pass is needed to find label values.
		for (u32 pass=0;pass<2 && !err;pass++) {
			u64 addr=0,acc=0,val=0,base=0,n=0;
			u32 token=0;
			s32 op=0;
			Label *scope=lblroot_,*lbl=0;
			for (i=0;i<l && !err;) {
				j=i;
				c=s(i);
				if (isspc(c)) {
					// whitespace
					while (isspc(s(i))) {i++;}
					token=0;
				} else if (c=='#' && s(i+1)=='|') {
					// block comment
					while (i<l && (s(i+2)!='|' || s(i+3)!='#')) {i++;}
					i+=4;
					if (i>l) {err="Unterminated block quote";}
					token=0;
				} else if (c=='#') {
					// comment
					while (i<l && s(i)!='\n') {i++;}
					token=0;
				} else if (c=='+' || c=='-') {
					// operator
					if (!addr--) {err="Leading operator";}
					if (op<0)    {err="Operating on declaration";}
					else if (op) {err="Double operator";}
					op=i++;
					token=0;
				} else if (c>='0' && c<='9') {
					// hex number
					base=10;
					val=0;
					if (c=='0' && tonum(s(i+1))==33) {base=16;i+=2;}
					while ((n=(u64)tonum(s(i)))<base) {
						mul64(0,&val,val,base);
						val+=(n && val>=mod-n)?n-mod:n;
						i++;
					}
					token++;
				} else if (c=='\'') {
					// ASCII literal
					val=s(i+1);
					if (mod) {val%=mod;}
					i+=2;
					token++;
				} else if (c=='?') {
					// current address
					i++;
					val=addr;
					token++;
				} else if (islbl(c)) {
					// label
					while (i<l && islbl(s(i))) {i++;}
					lbl=addlabel(scope,asmstr+j,i-j);
					val=lbl->addr;
					u32 set=val!=((u64)-1);
					if (s(i)==':') {
						token+=token>0;
						lbl->addr=addr;
						if (s(j)!='.') {scope=lbl;}
						if (!pass && set) {err="Duplicate label declaration";}
						if (op>0) {err="Operating on declaration";}
						op=-(i++);
					} else {
						token++;
						if (pass && !set) {err="Unable to find label";}
					}
				} else {
					err="Unexpected token";
					i++;
				}
				if (token) {
					// Add a token to the previous value, or write to memory.
					if (token>=2) {err="Unseparated tokens";}
					if (op<=0) {
						setmem(addr-1,acc);
						acc=val;
					} else if (s((u32)op)=='+') {
						acc+=(val && acc>=mod-val)?val-mod:val;
					} else {
						acc-=acc<val?val-mod:val;
					}
					addr++;
					op=0;
				}
			}
			if (!err && op>0) {
				err="Trailing operator";
				j=(u32)op;
				i=j+1;
			}
			if (pass) {setmem(addr-1,acc);}
		}
		state_=RUNNING;
		if (err) {
			// Highlight any error we've encountered.
			state_=ERROR_PARSER;
			u32 line=1,lo=0,hi=i;
			for (u32 k=0;k<j;k++) {
				if (s(k)=='\n') {
					lo=k+1;
					line++;
				}
			}
			if (lo<j-30) {lo=j-30;}
			while (lo<j && isspc(s(lo))) {lo++;}
			for (u32 k=lo;k<j+30;k++) {
				if (s(k)=='\n') {break;}
				if (k<l && !isspc(s(k))) {hi=k+1;}
			}
			char win[62]={0},und[62]={0};
			for (u32 k=lo;k<hi;k++) {
				c=s(k);
				win[k-lo]=c>' '?(char)c:' ';
				if (k<i) {und[k-lo]=k>=j?'^':' ';}
			}
			snprintf(statestr_,sizeof(statestr_),"Parser: %s\nLine  : %u\n\n\t%s\n\t%s\n\n",err,line,win,und);
		}
		processhli();
	}


	void parsefile(const char* path) {
		// Load and parse a source file.
		state_=ERROR_PARSER;
		FILE* in=fopen(path,"rb");
		if (!in) {
			snprintf(statestr_,sizeof(statestr_),"Could not open file \"%s\"\n",path);
			return;
		}
		fseek(in,0,SEEK_END);
		size_t size=(size_t)ftell(in);
		char* str=(char*)malloc((size+1)*sizeof(char));
		if (!str) {
			snprintf(statestr_,sizeof(statestr_),"File \"%s\" too large: %zu bytes\n",path,size);
		} else {
			fseek(in,0,SEEK_SET);
			for (size_t i=0;i<size;i++) {str[i]=(char)getc(in);}
			str[size]=0;
			parseassembly(str);
			free(str);
		}
		fclose(in);
	}


	// ----------------------------------------
	// Input / Output


	void closewindow(void) {
		if (window_) {
			SDL_DestroyTexture(texture_);
			SDL_DestroyRenderer(render_);
			SDL_DestroyWindow(window_);
			window_=0;
			SDL_Quit();
		}
	}


	void drawwindow(u64 addr) {
		u64 width =getmem(addr+0);
		u64 height=getmem(addr+1);
		u64 data  =getmem(addr+2);
		if (width>alloc_ || height>alloc_ || data>alloc_ || data+width*height>alloc_) {
			return;
		}
		// If we already have a window, make sure it has the correct dimensions.
		if (window_) {
			int winwidth,winheight;
			SDL_GetWindowSize(window_,&winwidth,&winheight);
			if (winwidth!=(int)width || winheight!=(int)height) {closewindow();}
		}
		// If we don't have a window, create one.
		if (!window_) {
			SDL_Init(SDL_INIT_EVERYTHING);
			window_ =SDL_CreateWindow("SICO",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,(int)width,(int)height,SDL_WINDOW_SHOWN);
			render_ =SDL_CreateRenderer(window_,-1,SDL_RENDERER_ACCELERATED);
			texture_=SDL_CreateTexture(render_,SDL_PIXELFORMAT_ARGB32,SDL_TEXTUREACCESS_STREAMING,(int)width,(int)height);
		}
		// Copy the pixel data to the window texture.
		u64 argb,*mem=mem_+data;
		u8* pixels=0;
		int pitch;
		SDL_LockTexture(texture_,0,(void**)&pixels,&pitch);
		for (u64 y=0;y<height;y++) {
			u8* row=pixels+((int)y)*pitch;
			for (u64 x=0;x<width;x++) {
				argb=*mem++;
				*row++=(u8)(argb>>56);
				*row++=(u8)(argb>>40);
				*row++=(u8)(argb>>24);
				*row++=(u8)(argb>> 8);
			}
		}
		SDL_UnlockTexture(texture_);
		// Update the SDL window.
		SDL_RenderCopy(render_,texture_,0,0);
		SDL_RenderPresent(render_);
		// Process SDL events.
		SDL_Event event;
		while (SDL_PollEvent(&event)) {
			int key=event.key.keysym.scancode;
			if (event.type==SDL_QUIT) {
				state_=COMPLETE;
			} else if (event.type==SDL_KEYDOWN || event.type==SDL_KEYUP) {
				u32 down=event.type==SDL_KEYDOWN;
				if (key==SDL_SCANCODE_ESCAPE) {
					if (down) {state_=COMPLETE;}
				}
			}
		}
	}


	// ----------------------------------------
	// Main


	u64 getmem(u64 addr) {
		// Return the memory value at addr.
		u64 mod=mod_;
		if (mod) {addr%=mod;}
		if (addr<alloc_) {
			return mem_[addr];
		} else if (addr>=io_) {
			// This is a special IO address.
			if (addr==mod-3) {
				// Read from stdin.
				u64 c=(u64)getchar;
				return mod?c%mod:c;
			} else if (addr==mod-4) {
				// Timing frequency. 2^32 = 1 second.
				return 0x100000000ULL;
			} else if (addr==mod-5) {
				// Read time. time = (seconds since 1 Jan 1970) * 2^32.
				struct timespec ts;
				timespec_get(&ts,TIME_UTC);
				return (((u64)ts.tv_sec)<<32)+(((u64)ts.tv_nsec)*0x100000000ULL)/1000000000ULL;
			}
		}
		return 0;
	}


	void setmem(u64 addr,u64 val) {
		// Write val to the memory at addr.
		u64 mod=mod_;
		if (mod) {addr%=mod;}
		if (mod) {val %=mod;}
		if (addr>=io_) {
			// This is a special IO address.
			val=val?mod-val:val;
			if (addr==mod-1) {
				// Exit.
				state_=COMPLETE;
			} else if (addr==mod-2) {
				// Print to stdout.
				putchar((char)val);
			} else if (addr==mod-6) {
				// Sleep.
				struct timespec ts={
					(long)(val>>32),
					(long)((val&0xffffffffULL)*1000000000ULL/0x100000000ULL)
				};
				nanosleep(&ts,0);
			} else if (addr==mod-7) {
				drawwindow(val);
			}
			return;
		}
		if (addr>=alloc_) {
			// If we're writing to an address outside of our memory, attempt to resize it.
			if (!val) {return;}
			u64 alloc=io_;
			while ((alloc>>1)>addr) {alloc>>=1;}
			mem_=(u64*)realloc(mem_,((size_t)alloc)*sizeof(u64));
			hlimap_=(u8*)realloc(hlimap_,((size_t)alloc)*sizeof(u8));
			if (!mem_ || !hlimap_) {
				state_=ERROR_MEMORY;
				snprintf(statestr_,sizeof(statestr_),"Failed to allocate memory.\nIndex: %" PRIu64 "\n",addr);
				return;
			}
			memset(mem_+alloc_,0,((size_t)(alloc-alloc_))*sizeof(u64));
			memset(hlimap_+alloc_,0,((size_t)(alloc-alloc_))*sizeof(u8));
			alloc_=alloc;
		}
		mem_[addr]=val;
	}


	void processhli(void) {
		// Finds functions based on the source labels.
		struct fnobj {
			const char* lbl;
			u8 id;
		};
		fnobj funcarr[]={
			//  0 -  0 none
			//  1 - 32 uint
			// 33 - 64 int
			// 65 - 96 mem
			{"uint.cmp", 1},
			{"uint.min", 2},
			{"uint.max", 3},
			{"uint.set", 4},
			{"uint.neg", 5},
			{"uint.add", 6},
			{"uint.sub", 7},
			{"uint.mul", 8},
			{"uint.div", 9},
			{"uint.gcd",10},
			{"uint.shl",11},
			{"uint.shr",12},
			{"uint.not",13},
			{"uint.and",14},
			{"uint.or" ,15},
			{"uint.xor",16},
			{"image.setpixel",100}
		};
		u32 funcs=sizeof(funcarr)/sizeof(fnobj);
		for (u32 f=0;f<funcs;f++) {
			u64 addr=findlabel(funcarr[f].lbl);
			if (addr<alloc_) {
				hlimap_[addr]=funcarr[f].id;
			}
		}
	}


	void run(s32 insts) {
		// Run the SICO program.
		#define setip0() \
			ip=mod-mem[0]+2;\
			mem[0]=0;
		#define getip1(ret) \
			ret=ip<alloc?mem[ip]:getmem(ip); \
			if (++ip>=mod) {ip-=mod;}
		#define getip2(ret) \
			tmp=ip<alloc?mem[ip]:getmem(ip); \
			if (++ip>=mod) {ip-=mod;} \
			ret=tmp<alloc?mem[tmp]:getmem(tmp);
		#define setres(addr,val) \
			if (addr<alloc) {      \
				mem[addr]=val;    \
			} else {               \
				setmem(addr,val); \
				if (state_!=RUNNING) {goto hliend;} \
				mem=mem_;         \
				alloc=alloc_;     \
				hlimap=hlimap_;   \
			}
		if (state_!=RUNNING) {return;}
		u64 ip=ip_,mod=mod_;
		u64 alloc=alloc_,*mem=mem_;
		u64 a,b,ma,mb;
		u8 *hlimap=hlimap_,hli;
		s32 dec=insts>0;
		for (;insts;insts-=dec) {
			// High-level intercept
			if (ip<alloc && (hli=hlimap[ip])!=0) {
				u64 hret,lret,tmp;
				switch (hli) {
					case 1:
						// uint.cmp a b lt eq gt
						setip0()
						getip2(a)
						getip2(b)
						ip+=(a==b)+(a>b);
						ip=ip<alloc?mem[ip]:getmem(ip);
						break;
					case 2:
						// uint.min r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(lret,a<b?a:b)
						break;
					case 3:
						// uint.max r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(lret,a>b?a:b)
						break;
					case 4:
						// uint.set r a
						setip0()
						getip1(lret)
						getip2(a)
						setres(lret,a)
						break;
					case 5:
						// uint.neg r a
						setip0()
						getip1(lret)
						getip2(a)
						setres(lret,a?mod-a:0)
						break;
					case 6:
						// uint.add r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						a=a>=mod-b?(a+b-mod):(a+b);
						setres(lret,a)
						break;
					case 7:
						// uint.sub r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						a=a<b?(mod+a-b):(a-b);
						setres(lret,a)
						break;
					case 8:
						// uint.mul h l a b
						setip0()
						getip1(hret)
						getip1(lret)
						getip2(a)
						getip2(b)
						if (hret==0 && mod==0) {
							setres(lret,a*b)
						} else {
							mul64(&a,&b,a,b);
							setres(hret,a)
							setres(lret,b)
						}
						break;
					case 9:
						// uint.div quot rem a b
						setip0()
						getip1(hret)
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(hret,a/b)
						setres(lret,a%b)
						break;
					case 10:
						// uint.gcd r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						while (b) {
							tmp=a;
							a%=b;
							b=tmp;
						}
						setres(lret,a)
						break;
					case 11:
						// uint.shl r a s
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						while (a && b--) {
							a=a>=mod-a?(a+a-mod):(a+a);
						}
						setres(lret,a)
						break;
					case 12:
						// uint.shr r a s
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						while (a && b--) {a>>=1;}
						setres(lret,a)
						break;
					case 13:
						// uint.not r a
						setip0()
						getip1(lret)
						getip2(a)
						setres(lret,mod-1-a)
						break;
					case 14:
						// uint.and r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(lret,a&b)
						break;
					case 15:
						// uint.or r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(lret,a|b)
						break;
					case 16:
						// uint.xor r a b
						setip0()
						getip1(lret)
						getip2(a)
						getip2(b)
						setres(lret,a^b)
						break;
					case 100:
						// image.setpixel img x y argb
						{
							u64 img,x,y,w,h,argb,data;
							setip0()
							getip2(img)
							getip2(x)
							getip2(y)
							getip2(argb)
							w=img<alloc?mem[img]:getmem(img);img++;
							h=img<alloc?mem[img]:getmem(img);img++;
							if (x<w && y<h) {
								data=(img<alloc?mem[img]:getmem(img))+y*w+x;
								setres(data,argb)
							}
							break;
						}
					default:
						break;
				}
				mem[0]=0;
				continue;
			}
			// Normal instruction
			a=ip<alloc?mem[ip]:getmem(ip);
			if (++ip>=mod) {ip-=mod;}
			b=ip<alloc?mem[ip]:getmem(ip);
			if (++ip>=mod) {ip-=mod;}
			ma=a<alloc?mem[a]:getmem(a);
			mb=b<alloc?mem[b]:getmem(b);
			if (ma<=mb) {
				ip=ip<alloc?mem[ip]:getmem(ip);
			} else if (++ip>=mod) {
				ip-=mod;
			}
			ma=ma<mb?ma-mb+mod:ma-mb;
			if (a<alloc) {
				mem[a]=ma;
			} else {
				setmem(a,ma);
				if (state_!=RUNNING) {break;}
				mem=mem_;
				alloc=alloc_;
				hlimap=hlimap_;
			}
		}
		hliend:
		ip_=ip;
	}
};


//---------------------------------------------------------------------------------
// Example usage. Call "sico file.sico" to run a file.


int main(int argc,char** argv) {
	SICO st(0,0);
	if (argc<=1) {
		// Print usage message.
		st.parseassembly("\
			loop: len  ?     neg\
			      0-2  text  ?+1\
			      ?-2  neg   loop\
			text: 'U 's 'a 'g 'e ': '  's 'i 'c 'o\
			      '  'f 'i 'l 'e '. 's 'i 'c 'o 10\
			neg:  0-1\
			len:  len-text\
		");
	} else {
		st.parsefile(argv[1]);
	}
	// Main loop.
	st.run(-1);
	u32 ret=st.state_;
	if (ret!=st.COMPLETE) {printf("%s",st.statestr_);}
	return (int)ret;
}

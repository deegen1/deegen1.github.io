/*------------------------------------------------------------------------------


sico_wasm.c - v1.03

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for SICO.
Memory is sandboxed, so it starts at 0.
Some variables are marked as volatile to prevent compiler reordering.

Memory layout:


     +-----+-----+-----+
     | env | mem | HLI |
     +-----+-----+-----+


Environment variables:


     0 envlen
     1 memlen
     2 hlilen
     3 mod
     4 IO start
     5 ip
     6 instruction limit
     7 IO 1
     8 IO 2


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang sico_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--export-all \
-Wl,--no-entry -Wl,--allow-undefined --output sico.wasm


--------------------------------------------------------------------------------
TODO


*/
#error "use int instead of unsigned"
#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	#pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
#endif

#include <stdint.h>

typedef unsigned char u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

extern u32  getenvljs(u32 addr);
extern u32  getenvhjs(void);
extern u32  setenvjs( u32 addr,u32 vh,u32 vl);
extern u32  getmemljs(u32 ah,u32 al);
extern u32  setmemjs( u32 ah,u32 al,u32 vh,u32 vl);
extern void dbgprintjs(int h,int l);

void dbgprint(u64 x) {
	dbgprintjs((int)(x>>32),(int)(x&0xffffffff));
}

u64 getenv(u32 addr) {
	u64 ret=(u64)getenvljs(addr);
	ret|=((u64)getenvhjs())<<32;
	return ret;
}

u32 setenv(u32 addr,u64 val) {
	return setenvjs(addr,(u32)(val>>32),(u32)val);
}


//---------------------------------------------------------------------------------
// SICO State


// WASM memory is sandboxed, so it starts at 0.
// Use volatile to prevent reordering.
#define mem     ((volatile u64*)0)
#define stopint 0x20000


typedef struct SICOState {
	//u64* mem;
	u64  memlen;
	u64  memlen3;
	u16* hli;
	u64  hlilen;
	u64  mod;
	u64  io;
	u64  ip;
	u64  instlimit;
	u64  stopcheck;
} SICOState;


void sicoinit(SICOState* st) {
	//st->mem      =(volatile u64*)(st->env+st->envlen);
	st->memlen   =getenv(0);
	st->memlen3  =st->memlen<4?0:(st->memlen-3);
	st->hli      =(u16*)(mem+st->memlen);
	st->hlilen   =getenv(1);
	st->mod      =getenv(2);
	st->io       =getenv(3);
	st->ip       =getenv(4);
	st->instlimit=getenv(5);
	st->stopcheck=st->instlimit<stopint?st->instlimit:stopint;
}


void sicodone(SICOState* st) {
	setenv(4,st->ip);
	setenv(5,st->instlimit);
}


//__attribute__((noinline))
u64 getmem(SICOState* st,u64 addr) {
	if (addr<st->memlen) {
		return mem[addr];
	} else if (addr>=st->io) {
		u64 ret=(u64)getmemljs((u32)(addr>>32),(u32)addr);
		ret|=((u64)getenvhjs())<<32;
		return ret;
	}
	return 0;
}


//__attribute__((noinline))
u32 setmem(SICOState* st,u64 addr,u64 val) {
	if (addr<st->memlen) {
		mem[addr]=val;
	} else if (addr>=st->io || val) {
		if (setmemjs((u32)(addr>>32),(u32)addr,(u32)(val>>32),(u32)val)) {
			sicodone(st);
			return 1;
		}
		st->memlen =getenv(0);
		st->memlen3=st->memlen<4?0:(st->memlen-3);
		st->hli    =(u16*)(mem+st->memlen);
	}
	return 0;
}


void mul64(u64* hi,u64* lo,u64 a,u64 b,u64 mod) {
	u64 rh=0,rl=0;
	if (!hi && !(mod&(mod-1))) {
		rl=(a*b)&(mod-1);
	} else {
		#define add(x) if (x && rl>=mod-x) {rl+=x-mod;rh+=i;} else {rl+=x;}
		for (u64 i=1ULL<<63;i;i>>=1) {
			add(rl)
			if (b&i) {add(a)}
		}
		#undef add
		if (hi) {*hi=rh;}
	}
	if (lo) {*lo=rl;}
}


#define hliinit()          \
     {                     \
     st.ip=st.mod-mem[0]+2;\
     mem[0]=0;


#define hlidone()          \
     mem[0]=0;             \
     }                     \
     break;


#define getip1(ret)        \
     ret=getmem(&st,st.ip);\
     if (++st.ip>=st.mod) {st.ip-=st.mod;}


#define getip2(ret)        \
     ret=getmem(&st,st.ip);\
     ret=getmem(&st,ret);  \
     if (++st.ip>=st.mod) {st.ip-=st.mod;}


#define setres(addr,val)   \
     if (addr<st.memlen) { \
          mem[addr]=val;   \
     } else if (setmem(&st,addr,val)) {\
          mem[0]=0;        \
          return;          \
     }


//---------------------------------------------------------------------------------
// Main Loop


__attribute__((used)) void run(void) {
	SICOState st;
	sicoinit(&st);
	u16 hli;
	u64 a,b,c,ma,mb;
	// If we want to run for a finite amount of instructions, disable HLI.
	if (st.instlimit<0x80000000) {st.hlilen=0;}
	while (1) {
		// Check if we need to stop.
		if (--st.stopcheck>=stopint) {
			if (st.instlimit>=0x80000000) {
				st.stopcheck=stopint;
			} else {
				if (st.instlimit<=stopint) {break;}
				st.instlimit-=stopint;
				st.stopcheck=(st.instlimit<stopint?st.instlimit:stopint)-1;
			}
			if (getenv(6)) {break;}
		}
		// High-level intercept.
		/*if (st.ip<st.hlilen && (hli=st.hli[st.ip])!=0) {
			u64 hret,lret,tmp;
			switch (hli) {
				case 0x0100:
					// uint.cmp a b lt eq gt
					hliinit()
					getip2(a)
					getip2(b)
					st.ip+=(a==b)+(a>b);
					st.ip=getmem(&st,st.ip);
					hlidone()
				case 0x0101:
					// uint.min r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a<b?a:b)
					hlidone()
				case 0x0102:
					// uint.max r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a>b?a:b)
					hlidone()
				case 0x0103:
					// uint.set r a
					hliinit()
					getip1(lret)
					getip2(a)
					setres(lret,a)
					hlidone()
				case 0x0104:
					// uint.neg r a
					hliinit()
					getip1(lret)
					getip2(a)
					setres(lret,a?st.mod-a:0)
					hlidone()
				case 0x0105:
					// uint.add r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a>=st.mod-b?(a+b-st.mod):(a+b);
					setres(lret,a)
					hlidone()
				case 0x0106:
					// uint.sub r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					a=a<b?(st.mod+a-b):(a-b);
					setres(lret,a)
					hlidone()
				case 0x0107:
					// uint.mul h l a b
					hliinit()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					mul64(hret?&a:0,&b,a,b,st.mod);
					setres(hret,a)
					setres(lret,b)
					hlidone()
				case 0x0108:
					// uint.div quot rem a b
					hliinit()
					getip1(hret)
					getip1(lret)
					getip2(a)
					getip2(b)
					if (!b) {setres(st.mod-1,0)}
					setres(hret,a/b)
					setres(lret,a%b)
					hlidone()
				case 0x0109:
					// uint.gcd r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (b) {
						tmp=a%b;
						a=b;
						b=tmp;
					}
					setres(lret,a)
					hlidone()
				case 0x010a:
					// uint.shl r a s
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {
						a=a>=st.mod-a?(a+a-st.mod):(a+a);
					}
					setres(lret,a)
					hlidone()
				case 0x010b:
					// uint.shr r a s
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					while (a && b--) {a>>=1;}
					setres(lret,a)
					hlidone()
				case 0x010c:
					// uint.not r a
					hliinit()
					getip1(lret)
					getip2(a)
					setres(lret,st.mod-1-a)
					hlidone()
				case 0x010d:
					// uint.and r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a&b)
					hlidone()
				case 0x010e:
					// uint.or r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a|b)
					hlidone()
				case 0x010f:
					// uint.xor r a b
					hliinit()
					getip1(lret)
					getip2(a)
					getip2(b)
					setres(lret,a^b)
					hlidone()
				case 0x060a:
					// image.setpixel img x y argb
					hliinit()
					u64 img,x,y,w,h,argb,data;
					getip2(img)
					getip2(x)
					getip2(y)
					getip2(argb)
					w=getmem(&st,img++);
					h=getmem(&st,img++);
					if (x<w && y<h) {
						data=getmem(&st,img)+y*w+x;
						setres(data,argb)
					}
					hlidone()
				default:
					break;
			}
		}*/
		// Normal instruction
		if (st.ip<st.memlen3) {
			a=(mem+0)[st.ip];
			b=(mem+1)[st.ip];
			c=(mem+2)[st.ip];
			st.ip+=3;
		} else {
			getip1(a)
			getip1(b)
			getip1(c)
		}
		ma=getmem(&st,a);
		mb=getmem(&st,b);
		if (ma<=mb) {st.ip=c;}
		ma=ma<mb?ma-mb+st.mod:ma-mb;
		if (a<st.memlen) {
			mem[a]=ma;
		} else if (setmem(&st,a,ma)) {
			return;
		}
	}
	sicodone(&st);
}

void run(s32 insts) {
	// Run the SICO program.
	// Unrolling the main loop is about 3.2 times as fast.
	if (state_!=RUNNING) {return;}
	u64 ip=ip_,mod=mod_;
	u64 alloc=alloc_,*mem=mem_;
	u64 a,b,ma,mb;
	s32 dec=insts>0;
	for (;insts;insts-=dec) {
		if (ip<alloc) {
			a=mem[ip++];
		} else {
			a=getmem(ip++);
			if (ip>=mod) {ip-=mod;}
		}
		if (ip<alloc) {
			b=mem[ip++];
		} else {
			b=getmem(ip++);
			if (ip>=mod) {ip-=mod;}
		}
		mb=b<alloc?mem[b]:getmem(b);
		if (a<alloc) {
			ma=mem[a];
			if (ma<=mb) {ip=ip<alloc?mem[ip]:getmem(ip);}
			else if (++ip>=mod) {ip-=mod;}
			mem[a]=ma<mb?ma-mb+mod:ma-mb;
		} else {
			ip=getmem(ip);
			setmem(a,mb?mod-mb:mb);
			if (state_!=RUNNING) {break;}
			mem=mem_;
			alloc=alloc_;
		}
	}
	ip_=ip;
}
	parseassembly(str) {
		// Convert SICO assembly language into a SICO program.
		this.clear();
		var i=0,j=0,len=str.length;
		var c,op,err=null;
		function  CNUM(c) {return (c<=57?c+208:((c+191)&~32)+10)&255;}
		function ISLBL(c) {return CNUM(c)<36 || c===95 || c===46 || c>127;}
		function  ISOP(c) {return c===43 || c===45;}
		function   NEXT() {return (c=i++<len?str.charCodeAt(i-1):0);}
		if (len>=this.MAX_PARSE) {err="Input string too long";}
		// Process the string in 2 passes. The first pass is needed to find label values.
		for (var pass=0;pass<2 && err===null;pass++) {
			var scope=this.lblroot;
			var addr=0n,val=0n,acc=0n;
			var tmp0=0n,tmp1=0n;
			op=0;
			i=0;
			NEXT();
			j=i;
			while (c!==0 && err===null) {
				var n=0,token=0;
				if (c<=32 && (c===13 || c===10 || c===9 || c===32)) {
					// Whitespace.
					NEXT();
					continue;
				}
				if (c===35) {
					// Comment. If next='|', use the multi-line format.
					var mask=0,eoc=10,i0=i;
					if (NEXT()===124) {mask=255;eoc=31779;NEXT();}
					while (c!==0 && n!==eoc) {n=((n&mask)<<8)+c;NEXT();}
					if (mask!==0 && n!==eoc) {err="Unterminated block quote";j=i0;}
					continue;
				}
				j=i;
				if (ISOP(c)) {
					// Operator. Decrement addr since we're modifying the previous value.
					if (!addr--) {err="Leading operator";}
					if (op!==0 ) {err="Double operator";}
					if (op===58) {err="Operating on declaration";}
					op=c;
					NEXT();
				} else if (CNUM(c)<10) {
					// Number. If it starts with "0x", use hexadecimal.
					token=10;
					val=0n;
					if (c===48 && (NEXT()===120 || c===88)) {token=16;NEXT();}
					tmp0=BigInt(token);
					while ((tmp1=CNUM(c))<token) {
						val=this.toint(val*tmp0+BigInt(tmp1));
						NEXT();
					}
				} else if (c===39) {
					// ASCII literal. Ex: 'H 'e 'l 'l 'o
					token=1;
					val=BigInt(NEXT());
					NEXT();
				} else if (c===63) {
					// Current address token.
					token=1;
					val=addr;
					NEXT();
				} else if (ISLBL(c)) {
					// Label.
					while (ISLBL(c)) {NEXT();}
					var lbl=this.addlabel(scope,str,j-1,i-j);
					if (lbl===null) {err="Unable to allocate label";break;}
					val=lbl.addr;
					var isset=val>=0n;
					if (c===58) {
						// Label declaration.
						if (pass===0) {
							if (isset) {err="Duplicate label declaration";}
							lbl.addr=addr;
						}
						if (str[j-1]!=='.') {scope=lbl;}
						if (ISOP(op)) {err="Operating on declaration";}
						op=c;
						NEXT();
					} else {
						token=1;
						if (pass!==0 && !isset) {err="Unable to find label";}
					}
				} else {
					err="Unexpected token";
					i++;
				}
				if (token!==0) {
					// Add a new value to memory.
					if (pass!==0) {
						if (op===43) {acc+=val;}
						else if (op===45) {acc-=val;}
						else {this.setmem(addr-1n,acc);acc=val;}
					}
					addr++;
					op=0;
					if (ISLBL(c) || c===63 || c===39) {err="Unseparated tokens";}
				}
			}
			if (err===null && ISOP(op)) {err="Trailing operator";}
			if (pass!==0) {this.setmem(addr-1n,acc);}
		}
		this.state=this.RUNNING;
		if (err!==null) {
			// We've encountered a parsing error.
			this.state=this.ERROR_PARSER;
			this.statestr="Parser: "+err+"\n";
			if (i-- && j--) {
				var line=1;
				var window="",under="";
				// Find the boundaries of the line we're currently parsing.
				var s0=0,s1=j,k;
				for (k=0;k<j;k++) {
					if (str[k]==="\n") {
						line++;
						s0=k+1;
					}
				}
				while (s1<len && str[s1]!=="\n") {s1++;}
				// Trim whitespace.
				while (s0<s1 && str[s0  ]<=" ") {s0++;}
				while (s1>s0 && str[s1-1]<=" ") {s1--;}
				// Extract the line and underline the error.
				s0=j>s0+30?j-30:s0;
				for (k=0;k<61;k++,s0++) {
					c=s0<s1 && k<60?str[s0]:"";
					window+=c;
					under+=(c && s0>=j && s0<i)?"^":(c<=" "?c:" ");
				}
				this.statestr="Parser: "+err+"\nLine  : "+line+"\n\n\t"+window+"\n\t"+under+"\n\n";
			}
		}
	}
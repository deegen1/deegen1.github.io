#!/usr/bin/python3
"""-----------------------------------------------------------------------------


sico.py - v1.02

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
The Single Instruction COmputer


SICO is a Single Instruction COmputer that mimics the functionality of a normal
computer while using only one computing instruction. This is like going into a
forest with no tools and trying to build a house. Since we only have one
instruction, most modern conveniences are gone. Things like multiplying numbers
or memory allocation need to be built from scratch using SICO's instruction.

The instruction is simple: Given A, B, and C, compute mem[A]-=mem[B]. Then, if
mem[A] was less than or equal to mem[B], jump to C. Otherwise, jump by 3. We
use the instruction pointer to keep track of our place in memory. The pseudocode
below shows a SICO instruction:


     A = mem[IP+0]
     B = mem[IP+1]
     C = mem[IP+2]
     IP += 3
     if mem[A] <= mem[B]: IP = C
     mem[A] -= mem[B]


The instruction pointer and memory values are all 64 bit unsigned integers.
Interaction with the host environment is done by reading and writing from
special memory addresses. For example: writing anything to -1 will end the
program.


--------------------------------------------------------------------------------
SICO Assembly Language


Because there's only one instruction, we only need to define memory values. The
flow of the program will decide what gets executed.


A "Hello, World!" program in assembly:


     loop:  len  one  exit
            0-2  txt  ?+1
            ?-2  neg  loop

     exit:  0-1  0    0

     txt:   'H 'e 'l 'l 'o ', '
            'W 'o 'r 'l 'd '! 10
     len:   len-txt+1
     neg:   0-1
     one:   1


The syntax of the assembly language


     Line Comment       |  # comment
     Block Comment      |  #| comment |#
     Label Declaration  |  label:
     Label Recall       |  label
     Sublabel           |  label: .sub: is treated as 'label.sub:'
     Current Address    |  ?
     Number             |  123 or 0xabc
     ASCII Literal      |  'A 'B 'C evaluates to 65 66 67
     Operator           |  + or -. Ex: 1+2-3
     Input / Output     |  Read or write to addresses above 2^63


IO addresses (mod 2^64)


     -1  |  Writing ends execution
     -2  |  Write to stdout
     -3  |  Read from stdin
     -4  |  Read timing frequency
     -5  |  Read system time
     -6  |  Writing sleeps for mem[B]/freq seconds


To print the letter 'A' to stdout:


     0-2  chr  ?+1
     chr: 'A


--------------------------------------------------------------------------------
TODO


"""


import time,sys


class SICO:

	COMPLETE    =0
	RUNNING     =1
	ERROR_PARSER=2
	ERROR_MEMORY=3


	def __init__(self,source="",mod=2**64):
		self.state   =0
		self.statestr=""
		self.ip      =0
		self.mem     =[]
		self.alloc   =0
		self.mod     =mod
		self.io      =(mod+1)//2
		self.lblroot =None
		self.window  =None
		self.parseassembly(source)


	def clear(self):
		self.state   =self.COMPLETE
		self.statestr=""
		self.ip      =0
		self.mem     =[]
		self.alloc   =0
		self.lblroot =self.Label()


	# ----------------------------------------
	# Assembly


	class Label:
		def __init__(self):
			self.addr=-1
			self.child={}


	def addlabel(self,scope,asmstr,start,end):
		# Add a label if it's new.
		# If the label starts with a '.', make it a child of the last non '.' label.
		lbl=scope if asmstr[start]=="." else self.lblroot
		for i in range(start,end):
			c=asmstr[i]
			prv=lbl
			lbl=lbl.child.get(c,None)
			if lbl is None:
				lbl=self.Label()
				prv.child[c]=lbl
		return lbl


	def findlabel(self,label):
		# Returns the given label's address. Returns None if no label was found.
		lbl=self.lblroot
		for c in label:
			if lbl is None: break
			lbl=lbl.child.get(c,None)
		return None if lbl is None else lbl.addr


	def parseassembly(self,asmstr):
		# Convert SICO assembly language into a SICO program.
		self.clear()
		i,j,l=0,0,len(asmstr)
		err=""
		mod=self.mod
		def tonum(c):
			x=ord(c)
			if x>=65: return x-87 if x>=97 else x-55
			return x-48 if (x>=48 and x<=57) else 99
		def isspc(c): return c==" " or c=="\r" or c=="\n" or c=="\t"
		def islbl(c): return tonum(c)<36 or c=="_" or c=="." or ord(c)>127
		def s(i): return asmstr[i] if i<l else chr(0)
		# Process the string in 2 passes. The first pass is needed to find label values.
		for pas in range(2):
			if err: break
			scope,lbl,i=self.lblroot,None,0
			val,acc,addr,op,token=0,0,0,0,0
			while i<l and not err:
				j,c=i,s(i)
				if isspc(c):
					# whitespace
					while isspc(s(i)): i+=1
					token=0
				elif c=="#" and s(i+1)=="|":
					# block comment
					while i<l and (s(i+2)!="|" or s(i+3)!="#"): i+=1
					i+=4
					if i>l: err="Unterminated block quote"
					token=0
				elif c=="#":
					# comment
					while i<l and s(i)!="\n": i+=1
					token=0
				elif c=="+" or c=="-":
					# operator
					if addr<=0: err="Leading operator"
					if op<0: err="Operating on declaration"
					elif op: err="Double operator"
					addr-=1
					op,token=i,0
					i+=1
				elif c>="0" and c<="9":
					# hex number
					base,val,n=10,0,s(i+1)
					if c=="0" and (n=="x" or n=="X"): base,i=16,i+2
					while (n:=tonum(s(i)))<base:
						val=(val*base+n)%mod
						i+=1
					token+=1
				elif c=="'":
					# ASCII literal
					val=ord(s(i+1))%mod
					i+=2
					token+=1
				elif c=="?":
					# current address
					i+=1
					val=addr
					token+=1
				elif islbl(c):
					# label
					while i<l and islbl(s(i)): i+=1
					lbl=self.addlabel(scope,asmstr,j,i)
					val=lbl.addr
					set=val>=0
					if s(i)==":":
						token+=token>0
						lbl.addr=addr
						if s(j)!=".": scope=lbl
						if pas==0 and set: err="Duplicate label declaration"
						if op>0: err="Operating on declaration"
						op=-i
						i+=1
					else:
						token+=1
						if pas and set==0: err="Unable to find label"
				else:
					err="Unexpected token"
					i+=1
				if token:
					# Add a token to the previous value, or write to memory.
					if token>=2: err="Unseparated tokens"
					if op<=0:
						self.setmem(addr-1,acc)
						acc=val
					elif s(op)=="+": acc+=val
					else: acc-=val
					addr+=1
					op=0
			if err=="" and op>0:
				err="Trailing operator"
				j,i=op,op+1
			if pas: self.setmem(addr-1,acc)
		self.state=self.RUNNING
		if err:
			# Highlight any error we've encountered.
			self.state=self.ERROR_PARSER
			line,lo,hi=1,0,i
			for k in range(j):
				if s(k)=="\n":
					lo=k+1
					line+=1
			if lo<j-30: lo=j-30
			while lo<j and isspc(s(lo)): lo+=1
			for k in range(lo,j+30):
				if s(k)=="\n": break
				if k<l and not isspc(s(k)): hi=k+1
			win,und="",""
			for k in range(lo,hi):
				c=s(k)
				win+=c if c>" " else " "
				if k<i: und+="^" if k>=j else " "
			self.statestr="Parser: {0}\nLine  : {1}\n\n\t{2}\n\t{3}\n\n".format(err,line,win,und)


	def parsefile(self,path):
		source=""
		with open(path,"r") as f: source=f.read()
		self.parseassembly(source)


	# ----------------------------------------
	# Input / Output


	def drawimage(self,imgaddr):
		# Draw an image to the screen.
		assert(self.mod==2**64)
		imgwidth =self.getmem(imgaddr  )
		imgheight=self.getmem(imgaddr+1)
		imgdata  =self.getmem(imgaddr+2)
		if imgdata+imgwidth*imgheight>self.alloc: return
		if self.window is None:
			global pygame
			import pygame
			pygame.init()
			self.window=pygame.display.set_mode((imgwidth,imgheight))
		for event in pygame.event.get(): pass
		pixarr=pygame.PixelArray(self.window)
		mem=self.mem
		for x in range(imgwidth):
			col=pixarr[x]
			pos=imgdata+x
			for y in range(imgheight):
				pix=mem[pos]
				pos+=imgwidth
				col[y]=((pix>>24)&0xff0000)|((pix>>16)&0xff00)|((pix>>8)&0xff)
		pixarr.close()
		pygame.display.flip()


	# ----------------------------------------
	# Main


	def getmem(self,addr):
		# Return the memory value at addr.
		mod=self.mod
		addr%=mod
		if addr<self.alloc:
			return self.mem[addr]
		elif addr>=self.io:
			# This is a special IO address.
			addr-=mod
			if addr==-3:
				# stdin
				return sys.stdin.read(1)%mod
			elif addr==-4:
				# Timing frequency. 2^32 = 1 second.
				return 4294967296
			elif addr==-5:
				# Read time. time = (seconds since 1 Jan 1970) * 2^32.
				return int(time.time()*4294967296.0)%mod
		return 0


	def setmem(self,addr,val):
		# Write val to the memory at addr.
		mod=self.mod
		addr%=mod
		if addr>=self.io:
			# This is a special IO address.
			addr-=mod
			val=(-val)%mod
			if addr==-1:
				# Exit.
				self.state=self.COMPLETE
			elif addr==-2:
				# Print to stdout.
				sys.stdout.write(chr(val&255))
			elif addr==-6:
				# Sleep.
				time.sleep(val/4294967296.0)
			elif addr==-7:
				# Draw an image.
				self.drawimage(val)
			return
		val%=mod
		mem=self.mem
		if addr>=self.alloc:
			# If we're writing to an address outside of our memory, attempt to resize it.
			if val==0: return
			alloc=self.io
			while (alloc>>1)>addr: alloc>>=1
			# Attempt to allocate.
			try:
				mem=mem+[0]*(alloc-self.alloc)
			except:
				self.state=self.ERROR_MEMORY
				self.statestr="Failed to allocate memory.\nIndex: "+str(addr)+"\n"
				return
			self.mem=mem
			self.alloc=alloc
		mem[addr]=val


	def run(self,insts=float("inf")):
		# Run the SICO program.
		ip=self.ip
		while insts>0 and self.state==self.RUNNING:
			insts-=1
			a =self.getmem(ip  )
			b =self.getmem(ip+1)
			c =self.getmem(ip+2)
			ma=self.getmem(a)
			mb=self.getmem(b)
			ip=c if ma<=mb else ip+3
			self.setmem(a,ma-mb)
		self.ip=ip%self.mod


if __name__=="__main__":
	st=SICO()
	if len(sys.argv)>=2:
		st.parsefile(sys.argv[1])
	else:
		st.parseassembly("""
			loop: len  ?     neg
				 0-2  text  ?+1
				 ?-2  neg   loop
			text: 'U 's 'a 'g 'e ': '  's 'i 'c 'o '.
				 'p 'y '  'f 'i 'l 'e '. 's 'i 'c 'o 10
			neg:  0-1
			len:  len-text
		""")
	st.run()
	if st.state!=st.COMPLETE:
		print(st.statestr)


	run(insts,time) {
		// Run SICO while insts>0 and performance.now()<time.
		//
		// This version of run() unrolls several operations to speed things up.
		// Depending on the platform, it's 22 times faster than using bigint functions.
		if (this.state!==this.RUNNING) {return;}
		if (insts===undefined) {insts=Infinity;}
		if (time ===undefined) {time =Infinity;}
		// Performance testing.
		/*if (this.dbgtime===undefined) {
			this.dbgtime=performance.now();
			this.dbginst=0;
		}
		var dbginst=0;*/
		var big=Object.is(this.oldmem,this.mem)-1;
		var iphi=Number(this.ip>>32n),iplo=Number(this.ip&0xffffffffn);
		var memh=this.memh,meml=this.meml;
		var alloc=Number(this.alloc),alloc2=alloc-2;
		var ahi,alo,chi,clo;
		var bhi,blo,mbhi,mblo;
		var i,timeiters=0;
		while (insts>0) {
			// dbginst++;
			// Periodically check if we've run for too long.
			if (--timeiters<=0) {
				if (performance.now()>=time) {break;}
				timeiters=1024;
			}
			if (this.sleep!==null) {
				// If sleeping for longer than the time we have, abort.
				if (this.sleep>=time) {break;}
				// If we're sleeping for more than 4ms, defer until later.
				var sleep=this.sleep-performance.now();
				if (sleep>4 && time<Infinity) {
					setTimeout(this.run.bind(this,insts,time),sleep-2);
					break;
				}
				// Busy wait.
				while (performance.now()<this.sleep) {}
				this.sleep=null;
				timeiters=0;
			}
			// Execute using bigints.
			if (big!==0) {
				big=0;
				var ip,a,b,c,ma,mb;
				ip=this.uint((BigInt(iphi)<<32n)+BigInt(iplo));
				a =this.getmem(ip++);
				b =this.getmem(ip++);
				c =this.getmem(ip++);
				ma=this.getmem(a);
				mb=this.getmem(b);
				if (ma<=mb) {ip=c;}
				this.setmem(a,ma-mb);
				if (!Object.is(this.oldmem,this.mem)) {
					this.oldmem=this.mem;
					var endian=(new Uint32Array((new BigUint64Array([4n])).buffer))[0];
					this.memh=memh=new Uint32Array(this.mem.buffer,  endian);
					this.meml=meml=new Uint32Array(this.mem.buffer,4-endian);
					alloc=Number(this.alloc);
					alloc2=alloc-2;
				}
				iphi=Number(ip>>32n);
				iplo=Number(ip&0xffffffffn);
				insts--;
				if (this.state!==this.RUNNING) {break;}
				continue;
			}
			// Load a, b, and c.
			if (iphi>0 || iplo>=alloc2) {big=1;continue;}
			i=iplo+iplo;
			ahi=memh[i];
			alo=meml[i];
			i+=2;
			bhi=memh[i];
			blo=meml[i];
			i+=2;
			chi=memh[i];
			clo=meml[i];
			// Input
			if (bhi>0 || blo>=alloc) {big=1;continue;}
			i=blo+blo;
			mbhi=memh[i];
			mblo=meml[i];
			// Output
			if (ahi>0 || alo>=alloc) {big=1;continue;}
			i=alo+alo;
			mblo=meml[i]-mblo;
			mbhi=memh[i]-mbhi-(mblo<0);
			if (mbhi<0 || (mbhi===0 && mblo===0)) {
				iphi=chi;
				iplo=clo;
			} else {
				iplo+=3;
			}
			meml[i]=mblo;
			memh[i]=mbhi;
			insts--;
		}
		this.ip=this.uint((BigInt(iphi)<<32n)+BigInt(iplo));
		// Performance testing.
		/*this.dbginst+=dbginst;
		if (this.state!==this.RUNNING) {
			var time=(performance.now()-this.dbgtime)/1000;
			this.print("\n-----------------------\nDebug Stats:\n\n");
			this.print("inst: "+this.dbginst+"\n");
			this.print("sec : "+time+"\n");
			this.print("rate: "+(this.dbginst/time)+"\n");
			this.dbgtime=undefined;
		}*/
	}
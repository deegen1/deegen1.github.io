from random import randrange
# Python2 compatibility.
import sys
if sys.version_info[0]<=2:
	range=xrange
	input=raw_input

def RangeTest():
	print("testing range encoding")
	trials=10000
	maxsyms=256
	for trial in range(trials):
		syms=randrange(maxsyms)+1
		maxinc=randrange(256)+1
		freq=[0]*(syms+1)
		for i in range(1,syms+1):
			freq[i]=freq[i-1]+randrange(maxinc)+1
		inlen=randrange(1000)
		indata=tuple([randrange(syms) for i in range(inlen)])
		# encode
		encdata=[0]*(inlen*maxinc)
		enclen=0
		rng=RangeEncoder(True)
		for i in range(inlen):
			sym=indata[i]
			rng.encode(freq[sym],freq[sym+1],freq[syms])
			enclen+=rng.getbytes(encdata,enclen)
		rng.finish()
		enclen+=rng.getbytes(encdata,enclen)
		# decode
		declen=0
		encpos=0
		rng=RangeEncoder(False)
		while declen<inlen:
			decode=rng.decode(freq[syms])
			if decode==None:
				if encpos==enclen:
					rng.finish()
				else:
					rng.addbyte(encdata[encpos])
					encpos+=1
			else:
				sym=0
				while freq[sym+1]<=decode: sym+=1
				if sym!=indata[declen]:
					print("mismatch: {0}, {1}".format(sym,indata[declen]))
					exit()
				declen+=1
				rng.scale(freq[sym],freq[sym+1],freq[syms])
	print("passed")

sys.path.insert(0,"../")
from RangeEncoder import RangeEncoder
RangeTest()

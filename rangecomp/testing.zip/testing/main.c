/*
main.c - v1.01

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com

--------------------------------------------------------------------------------
This range encoder will convert a sequence of intervals to and from a binary
coded fraction. When these intervals are mapped to cumulative symbol
probabilities, we can compress or decompress data.

Compile:
gcc -O2 main.c range.c -o range.exe

Usage:
range.exe -c image.bmp compress.dat
range.exe -d compress.dat decompress.bmp
*/

#include "range.h"
#include <stdio.h>
#include <string.h>

// Adaptive order-0 symbol model.
void incprob(u32* prob,u32 sym)
{
	// Increment the probability of a given symbol.
	for (u32 i=sym+1;i<257;i++) {prob[i]+=32;}
	if (prob[256]>=65536)
	{
		// Periodically halve all probabilities to help the model forget old symbols.
		for (u32 i=256;i!=0;i--) {prob[i]-=prob[i-1]-1;}
		for (u32 i=1;i<257;i++) {prob[i]=prob[i-1]+(prob[i]>>1);}
	}
}

u32 findsym(u32* prob,u32 code)
{
	// Find the symbol who's cumulative interval encapsulates the given code.
	u32 sym=0;
	while (prob[sym+1]<=code) {sym++;}
	return sym;
}

int main(int argc,char** argv)
{
	// Example compressor and decompressor using an adaptive order-0 symbol model.
	if (argc!=4)
	{
		printf("3 arguments expected\nrange [-c|-d] infile outfile\n");
		return 1;
	}
	const char* mode=argv[1];
	const char* infile=argv[2];
	const char* outfile=argv[3];
	if (strcmp(mode,"-c")!=0 && strcmp(mode,"-d")!=0)
	{
		printf("mode must be -c or -d\n");
		return 1;
	}
	FILE* in=fopen(infile,"rb");
	FILE* out=fopen(outfile,"wb");
	fseek(in,0,SEEK_END);
	u32 insize=ftell(in);
	fseek(in,0,SEEK_SET);
	u32 prob[257];
	for (u32 i=0;i<257;i++) {prob[i]=i*32;}
	if (strcmp(mode,"-c")==0)
	{
		// Compress a file.
		rangeencoder* enc=rccreate(RC_ENCODE);
		for (u32 i=24;i<32;i-=8) {fputc((insize>>i)&255,out);}
		for (u32 inpos=0;inpos<=insize;inpos++)
		{
			if (inpos<insize)
			{
				// Encode a symbol.
				u8 byte=fgetc(in);
				rcencode(enc,prob[byte],prob[byte+1],prob[256]);
				incprob(prob,byte);
			}
			else
			{
				rcfinish(enc);
			}
			// While the encoder has bytes to output, output.
			u32 c;
			while ((c=rcget(enc))<256)
			{
				fputc(c,out);
			}
		}
	}
	else
	{
		// Decompress a file.
		rangeencoder* dec=rccreate(RC_DECODE);
		u32 outsize=0;
		for (u32 i=24;i<32;i-=8) {outsize|=((u32)fgetc(in))<<i;}
		u32 inpos=4,outpos=0;
		while (outpos<outsize)
		{
			u32 decode=rcdecode(dec,prob[256]);
			if (decode!=((u32)-1))
			{
				// We are ready to decode a symbol.
				u32 sym=findsym(prob,decode);
				rcscale(dec,prob[sym],prob[sym+1],prob[256]);
				incprob(prob,sym);
				fputc(sym,out);
				outpos++;
			}
			else if (inpos<insize)
			{
				// We need more input data.
				rcadd(dec,fgetc(in));
				inpos++;
			}
			else
			{
				// Signal that we have no more input data.
				rcfinish(dec);
			}
		}
	}
	fclose(out);
	fclose(in);
	return 0;
}

	fillresize(size) {
		let old=this.lineu32.length;
		size<<=1;
		if (old>=size) {return old;}
		let mem=new Uint32Array(size);
		mem.set(this.lineu32);
		this.linef32=new Float32Array(mem.buffer);
		this.lineu32=mem;
		return size;
	}


	fillpoly(poly,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Reject anything with a NaN, too narrow, or
		// outside the image. Use a binary heap to dynamically sort lines.
		// Keep JS as simple as possible to be efficient. Keep micro optimization in WASM.
		// ~~x = fast floor(x)
		// [0 sort, 1 end, 2 none, 3 none, 4 x0, 5 y0, 6 x1, 7 y1]
		if (poly===undefined) {poly=this.defpoly;}
		if (trans===undefined) {trans=this.deftrans;}
		else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		const curvemaxdist2=0.02;
		let iw=this.img.width,ih=this.img.height;
		let alpha=this.rgba[3]/255.0;
		if (poly.vertidx<3 || iw<1 || ih<1 || alpha<1e-4) {return;}
		// Screenspace transformation.
		let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
		let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
		// Perform a quick AABB-OBB overlap test.
		// Define the transformed bounding box.
		let aabb=poly.aabb;
		let bndx=aabb.minx*matxx+aabb.miny*matxy+matx;
		let bndy=aabb.minx*matyx+aabb.miny*matyy+maty;
		let bnddx0=aabb.dx*matxx,bnddy0=aabb.dx*matyx;
		let bnddx1=aabb.dy*matxy,bnddy1=aabb.dy*matyy;
		// Test if the image AABB has a separating axis.
		let minx=bndx-iw,maxx=bndx;
		if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
		if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
		if (maxx<=0 || 0<=minx) {return;}
		let miny=bndy-ih,maxy=bndy;
		if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Test if the poly OBB has a separating axis.
		let cross=bnddx0*bnddy1-bnddy0*bnddx1;
		minx=bndy*bnddx0-bndx*bnddy0;
		maxx=minx;bnddx0*=ih;bnddy0*=iw;
		if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
		if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
		if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
		if (maxx<=0 || 0<=minx) {return;}
		miny=bndy*bnddx1-bndx*bnddy1;
		maxy=miny;bnddx1*=ih;bnddy1*=iw;
		if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
		if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Loop through the path nodes.
		const lsize=8;
		let memf=this.linef32;
		let lpos=0,lmax=memf.length;
		let movex=0,movey=0,area=0;
		let p0x=0,p0y=0,p1x=0,p1y=0;
		let varr=poly.vertarr;
		let vidx=poly.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			if (v.type===DrawPoly.CURVE) {v=varr[i+2];}
			p0x=p1x;p1x=v.x*matxx+v.y*matxy+matx;
			p0y=p1y;p1y=v.x*matyx+v.y*matyy+maty;
			// Add a basic line.
			let l=lpos;lpos+=lsize;
			if (lmax<lpos) {
				lmax=this.fillresize(lpos);
				memf=this.linef32;
			}
			let m1x=p1x,m1y=p1y;
			if (v.type===DrawPoly.MOVE) {
				// Close any unclosed subpaths.
				m1x=movex;movex=p1x;
				m1y=movey;movey=p1y;
				if (!i || (m1x===p0x && m1y===p0y)) {lpos-=lsize;}
			}
			area+=p0x*m1y-m1x*p0y;
			memf[l+4]=p0x;
			memf[l+5]=p0y;
			memf[l+6]=m1x;
			memf[l+7]=m1y;
			if (v.type!==DrawPoly.CURVE) {continue;}
			// Linear decomposition of curves.
			v=varr[i++];let n1x=v.x*matxx+v.y*matxy+matx,n1y=v.x*matyx+v.y*matyy+maty;
			v=varr[i++];let n2x=v.x*matxx+v.y*matxy+matx,n2y=v.x*matyx+v.y*matyy+maty;
			memf[l  ]=n1x;memf[l+1]=n1y;
			memf[l+2]=n2x;memf[l+3]=n2y;
			area-=((n1x-p0x)*(2*p0y-n2y-p1y)+(n2x-p0x)*(p0y+n1y-2*p1y)
				 +(p1x-p0x)*(2*n2y+n1y-3*p0y))*0.3;
			for (l=lpos-lsize;l<lpos;l+=lsize) {
				// The curve will stay inside the bounding box of [c0,c1,c2,c3].
				// If the subcurve is outside the image, stop subdividing.
				let c3x=memf[l+6],c2x=memf[l+2],c1x=memf[l+0],c0x=memf[l+4];
				let c3y=memf[l+7],c2y=memf[l+3],c1y=memf[l+1],c0y=memf[l+5];
				if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
				    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
					continue;
				}
				let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
				// Test if both control points are close to the line c0->c3. Clamp to ends.
				let lx=c1x-c0x,ly=c1y-c0y;
				let u=dx*lx+dy*ly;
				u=u>0?(u<den?u/den:1):0;
				lx-=dx*u;ly-=dy*u;
				if (!(lx*lx+ly*ly>curvemaxdist2)) {
					lx=c2x-c0x;ly=c2y-c0y;
					u=dx*lx+dy*ly;
					u=u>0?(u<den?u/den:1):0;
					lx-=dx*u;ly-=dy*u;
					if (!(lx*lx+ly*ly>curvemaxdist2)) {continue;}
				}
				// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
				let j=lpos;lpos+=lsize;
				if (lmax<lpos) {
					lmax=this.fillresize(lpos);
					memf=this.linef32;
				}
				let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
				let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
				let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
				let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
				let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
				let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
				memf[l+6]=phx;memf[l+2]=l2x;memf[l+0]=l1x;
				memf[l+7]=phy;memf[l+3]=l2y;memf[l+1]=l1y;
				memf[j+6]=c3x;memf[j+2]=r2x;memf[j+0]=r1x;memf[j+4]=phx;
				memf[j+7]=c3y;memf[j+3]=r2y;memf[j+1]=r1y;memf[j+5]=phy;
				l-=lsize;
			}
		}
		// Prune lines.
		let memu=this.lineu32;
		let amul=area<0?-alpha:alpha;
		for (let l=0;l<lpos;l+=lsize) {
			memu[l]=0;memu[l+1]=0xffffffff;
		}
		/*minx=iw;maxx=0;miny=ih;maxy=0;
		for (let i=lcnt-1;i>=0;i--) {
			let l=lr[i];
			let x0=l.x0,y0=l.y0;
			let x1=l.x1,y1=l.y1;
			if (x0>x1) {x0=x1;x1=l.x0;}
			if (y0>y1) {y0=y1;y1=l.y0;}
			if (y1>0 && y0<ih) {
				minx=minx<x0?minx:x0;
				maxx=maxx>x1?maxx:x1;
				miny=miny<y0?miny:y0;
				maxy=maxy>y1?maxy:y1;
				l.sort=0;l.end=0xffffffff;
				if (x0<iw) {continue;}
			}
			lr[i]=lr[--lcnt]
			lr[lcnt]=l;
		}
		// If all lines are outside the image, abort.
		if (minx>=iw || maxx<=0 || minx>=maxx || miny>=maxy || lcnt<1) {
			return;
		}*/
		// Init blending.
		let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0;
		let maskl=(0x00ff00ff&~amask)>>>0,maskh=(0xff00ff00&~amask)>>>0;
		let colrgb=(this.rgba32[0]|amask)>>>0;
		let coll=(colrgb&maskl)>>>0,colh=(colrgb&maskh)>>>0,colh8=colh>>>8;
		// Process the lines row by row.
		let p=0,y=0,pixels=iw*ih;
		let pnext=lpos?0:pixels,plim=0;
		let areadx1=0;
		let imgdata=this.img.data32;
		while (true) {
			if (p>=plim) {
				if (pnext>=pixels) {break;}
				p=pnext;
				y=~~(p/iw);
				plim=y*iw+iw;
				area=0;
				areadx1=0;
			}
			let areadx2=0;
			while (p>=pnext) {
				// fx0  fx0+1                          fx1  fx1+1
				//  +-----+-----+-----+-----+-----+-----+-----+
				//  |                              .....----  |
				//  |               .....-----'''''           |
				//  | ....-----'''''                          |
				//  +-----+-----+-----+-----+-----+-----+-----+
				//   first  dyx   dyx   dyx   dyx   dyx  last   tail
				//
				// For accuracy, avoid mixing units. Ex: use (y/dy)*dx instead
				// of (y*dx)/dy or y*(dx/dy).
				// Orient upwards, then clip y to [0,1].
				let x0=memf[4],y0=memf[5];
				let x1=memf[6],y1=memf[7];
				let sign=amul,tmp=0;
				let end=memu[1]-plim,sort=plim-iw,x=p-sort;
				if (y0>y1) {
					sign=-sign;
					tmp=x0;x0=x1;x1=tmp;
					tmp=y0;y0=y1;y1=tmp;
				}
				let fy=y0>y?~~y0:y;
				y0-=fy;y1-=fy;x0-=x;x1-=x;
				let dx=x1-x0,dy=y1-y0,nx=x1;
				if (y1>2) {nx+=((2-y1)/dy)*dx;}
				if (y1>1) {x1+=((1-y1)/dy)*dx;y1=1;}
				if (y0<0) {x0+=((0-y0)/dy)*dx;y0=0;}
				nx=nx<x1?nx:x1;
				if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
				dy*=sign;
				let rate=dy/dx;
				if (y1<=0.00001) {
					// Above.
					sort=pixels;
				} else if (x0>=1 || fy>y) {
					// Below or to the left.
					nx=x0;
					sort=(y0<ih?fy:ih)*iw;
				} else if (x1<=1.00001 || end<0) {
					// Vertical line or last pixel.
					let ty=(y0-y1)*sign;
					tmp=x1>0?((-0.5*x1*x1)/dx)*dy:0;
					if (end<0) {
						ty=((0.5-x1)/dx)*dy;
						areadx1+=rate;
					} else {
						tmp=x0>=0?(x0+x1)*ty*0.5:tmp;
					}
					area+=ty-tmp;
					areadx2+=tmp;
					sort+=iw;
				} else {
					// Line spanning multiple pixels.
					tmp=x0>0?((0.5*x0*x0)/dx)*dy:0;
					area-=((0.5-x0)/dx)*dy+tmp;
					areadx1-=rate;
					areadx2+=tmp;
					nx=x1;
					end=x+x1<iw?0:end;
				}
				nx+=x;
				nx=nx<0?0:nx;
				sort+=(nx<iw?~~nx:iw);
				sort=sort>p?sort:pixels;
				memu[0]=sort;
				memu[1]=end?0xffffffff:sort;
				// Heap sort down.
				/*if (sort>=pixels) {
					let t=lr[--lcnt];
					lr[lcnt]=l;l=t;
					sort=l.sort;
				}*/
				let dat0=memu[0],dat1=memu[1],dat2=memu[2],dat3=memu[3];
				let dat4=memu[4],dat5=memu[5],dat6=memu[6],dat7=memu[7];
				let i=0,j=0;
				while ((j=i+i+lsize)<lpos) {
					let j1=j+lsize;
					let s0=memu[j];
					let s1=j1<lpos?memu[j1]:0xffffffff;
					if (s1<s0) {s0=s1;j=j1;}
					if (s0>=sort) {break;}
					memu[i  ]=s0       ;memu[i+1]=memu[j+1];
					memu[i+2]=memu[j+2];memu[i+3]=memu[j+3];
					memu[i+4]=memu[j+4];memu[i+5]=memu[j+5];
					memu[i+6]=memu[j+6];memu[i+7]=memu[j+7];
					i=j;
				}
				memu[i  ]=dat0;memu[i+1]=dat1;memu[i+2]=dat2;memu[i+3]=dat3;
				memu[i+4]=dat4;memu[i+5]=dat5;memu[i+6]=dat6;memu[i+7]=dat7;
				pnext=memu[0];
			}
			// Calculate how much we can draw or skip.
			const cutoff=0.00390625;
			let astop=area+areadx1+areadx2;
			let pstop=p+1,xdif=(pnext<plim?pnext:plim)-pstop;
			if (xdif>0 && (area>=cutoff)===(astop>=cutoff)) {
				let adif=(cutoff-astop)/areadx1+1;
				xdif=(adif>=1 && adif<xdif)?~~adif:xdif;
				astop+=xdif*areadx1;
				pstop+=xdif;
			}
			// Blend the pixel based on how much we're covering.
			if (area>=cutoff) {
				do {
					// a = sa + da*(1-sa)
					// c = (sc - dc)*sa/a + dc
					let sa=area<alpha?area:alpha;
					area+=areadx1+areadx2;
					areadx2=0;
					let dst=imgdata[p];
					let da=(dst>>>ashift)&255;
					if (da===255) {
						sa=256.49-sa*256;
					} else {
						let tmp=sa*255+(1-sa)*da;
						sa=256.49-(sa/tmp)*65280;
						da=tmp+0.49;
					}
					// imul() implicitly casts floor(sa).
					imgdata[p]=(da<<ashift)
						|(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&maskl)
						|((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&maskh);
				} while (++p<pstop);
			}
			p=pstop;
			area=astop;
		}
	}

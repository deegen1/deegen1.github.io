	drawimagef(src,dx,dy,dw,dh) {
		// Draw an image with alpha blending.
		// Note << and imul() implicitly cast floor().
		let dst=this.img;
		dx=dx??0;
		let ix=Math.floor(dx),fx0=dx-ix,fx1=1-fx0;
		dy=dy??0;
		let iy=Math.floor(dy),fy0=dy-iy,fy1=1-fy0;
		let iw=(dw===undefined || dw>src.width )?src.width :ix;
		let ih=(dh===undefined || dh>src.height)?src.height:iy;
		let sx=0,sy=0;
		iw+=ix;
		if (ix<0) {sx=-ix;ix=0;}
		iw=(iw>dst.width?dst.width:iw)-ix;
		ih+=iy;
		if (iy<0) {sy=-iy;iy=0;}
		ih=(ih>dst.height?dst.height:ih)-iy;
		if (iw<=0 || ih<=0) {return;}
		let m00=Math.round(fx0*fy0*256),m01=Math.round(fx0*fy1*256),m10=Math.round(fx1*fy0*256),m11=256-m00-m01-m10;
		let dstdata=dst.data32,drow=iy*dst.width+ix,dinc=dst.width-iw;
		let srcdata=src.data32,srow=sy*src.width+sx,sinc=src.width-iw;
		let ystop=drow+dst.width*ih,xstop=drow+iw;
		let amul=this.rgba[3],amul0=amul/255.0,amul1=amul*(256.0/65025.0);
		let filllim=amul0>0?255/amul0:Infinity;
		let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
		let maskl=0x00ff00ff&namask,maskh=0xff00ff00&namask;
		let sw=src.width,sh=src.height;
		iw=dst.width;
		const imul=Math.imul;
		while (drow<ystop) {
			let stop0=srow+sw-sx,stop1=++sy<sh?stop0:0;
			let s10=srcdata[srow];
			let s11=srow<stop1?srcdata[srow+sw]:0;
			while (drow<xstop) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				srow++;
				let s00=s10,s01=s11;
				s10=srow<stop0?srcdata[srow]:0;
				s11=srow<stop1?srcdata[srow+sw]:0;
				const m=0x00ff00ff;
				let cl=imul(s00&m,m00)+imul(s01&m,m01)+imul(s10&m,m10)+imul(s11&m,m11);
				let ch=imul((s00>>>8)&m,m00)+imul((s01>>>8)&m,m01)+imul((s10>>>8)&m,m10)+imul((s11>>>8)&m,m11);
				src=(ch&0xff00ff00)|((cl>>>8)&m);
				let sa=(src>>>ashift)&255;
				src&=namask;
				if (sa<=0) {drow++;continue;}
				let tmp=dstdata[drow];
				let da=(tmp>>>ashift)&255;
				// Approximate blending by expanding sa from [0,255] to [0,256].
				sa*=amul;
				da=sa*255+da*(65025-sa);
				sa=(sa*65280+(da>>>1))/da;
				da=((da+32512)/65025)<<ashift;
				let l=tmp&0x00ff00ff;
				let h=tmp&0xff00ff00;
				dstdata[drow++]=da|
					(((imul((src&m)-l,sa)>>>8)+l)&maskl)|
					((imul(((src>>>8)&m)-(h>>>8),sa)+h)&maskh);
			}
			xstop+=iw;
			drow+=dinc;
			srow+=sinc;
		}
	}

	drawimagei(src,dx,dy,dw,dh) {
		// Draw an image with alpha blending.
		// Note << and imul() implicitly cast floor().
		let dst=this.img;
		dx=isNaN(dx)?0:Math.round(dx);
		dy=isNaN(dx)?0:Math.round(dy);
		dw=(isNaN(dw) || dw>src.width )?src.width :dx;
		dh=(isNaN(dh) || dh>src.height)?src.height:dh;
		let sx=0,sy=0;
		dw+=dx;
		if (dx<0) {sx=-dx;dx=0;}
		dw=(dw>dst.width?dst.width:dw)-dx;
		dh+=dy;
		if (dy<0) {sy=-dy;dy=0;}
		dh=(dh>dst.height?dst.height:dh)-dy;
		if (dw<=0 || dh<=0) {return;}
		let dstdata=dst.data32,drow=dy*dst.width+dx,dinc=dst.width-dw;
		let srcdata=src.data32,srow=sy*src.width+sx,sinc=src.width-dw;
		let ystop=drow+dst.width*dh,xstop=drow+dw;
		let amul=this.rgba[3],amul0=amul/255.0,amul1=amul*(256.0/65025.0);
		let filllim=amul0>0?255/amul0:Infinity;
		let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
		let maskl=0x00ff00ff&namask,maskh=0xff00ff00&namask;
		let sa,da,l,h,tmp;
		dw=dst.width;
		while (drow<ystop) {
			while (drow<xstop) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				src=srcdata[srow++];
				sa=(src>>>ashift)&255;
				src&=namask;
				if (sa>=filllim) {
					dstdata[drow++]=src|((sa*amul0)<<ashift);
					continue;
				}
				if (sa<=0) {drow++;continue;}
				tmp=dstdata[drow];
				da=(tmp>>>ashift)&255;
				if (da===0) {
					dstdata[drow++]=src|((sa*amul0)<<ashift);
					continue;
				}
				// Approximate blending by expanding sa from [0,255] to [0,256].
				if (da===255) {
					sa*=amul1;
					da=amask;
				} else {
					sa*=amul;
					da=sa*255+da*(65025-sa);
					sa=(sa*65280+(da>>>1))/da;
					da=((da+32512)/65025)<<ashift;
				}
				l=tmp&0x00ff00ff;
				h=tmp&0xff00ff00;
				dstdata[drow++]=da|
					(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
					((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
			}
			xstop+=dw;
			drow+=dinc;
			srow+=sinc;
		}
	}
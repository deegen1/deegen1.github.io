	constructor(width,height) {
		this.ctx2d    =null;
		this.ctxgl    =null;
	}


	screencanvas(canvas) {
		// Rendering to a webgl texture is faster in firefox. Otherwise use 2d.
		if (Object.is(this.canvas,canvas)) {return;}
		this.canvas=canvas;
		try {
			let ctx=canvas.getContext("webgl2",{preserveDrawingBuffer:true});
			let vs=ctx.createShader(ctx.VERTEX_SHADER);
			ctx.shaderSource(vs,`#version 300 es
				in vec2 a_position;
				in vec2 a_texcoord;
				out vec2 v_texcoord;
				void main() {
					gl_Position=vec4(a_position,0,1);
					v_texcoord=a_texcoord;
				}
			`);
			ctx.compileShader(vs);
			let fs=ctx.createShader(ctx.FRAGMENT_SHADER);
			ctx.shaderSource(fs,`#version 300 es
				precision highp float;
				in vec2 v_texcoord;
				uniform sampler2D u_texture;
				out vec4 outColor;
				void main() {
					outColor=texture(u_texture,v_texcoord);
				}
			`);
			ctx.compileShader(fs);
			let prog=ctx.createProgram();
			ctx.attachShader(prog,vs);
			ctx.attachShader(prog,fs);
			ctx.linkProgram(prog);
			ctx.useProgram(prog);
			let tex=ctx.createTexture();
			ctx.bindTexture(ctx.TEXTURE_2D,tex);
			ctx.texParameteri(ctx.TEXTURE_2D,ctx.TEXTURE_MIN_FILTER,ctx.NEAREST);
			ctx.texParameteri(ctx.TEXTURE_2D,ctx.TEXTURE_WRAP_S,ctx.CLAMP_TO_EDGE);
			ctx.texParameteri(ctx.TEXTURE_2D,ctx.TEXTURE_WRAP_T,ctx.CLAMP_TO_EDGE);
			let attrs=[
				{var:"a_position",arr:[-1,-1,-1,1,1,1,1,-1]},
				{var:"a_texcoord",arr:[0,1,0,0,1,0,1,1]}
			];
			for (let attr of attrs) {
				let buf=ctx.createBuffer();
				let loc=ctx.getAttribLocation(prog,attr.var);
				ctx.enableVertexAttribArray(loc);
				ctx.bindBuffer(ctx.ARRAY_BUFFER,buf);
				ctx.bufferData(ctx.ARRAY_BUFFER,new Float32Array(attr.arr),ctx.STATIC_DRAW);
				ctx.vertexAttribPointer(loc,2,ctx.FLOAT,false,0,0);
			}
			this.ctxgl=ctx;
		} catch {
			this.ctx2d=canvas.getContext("2d");
		}
	}


	screenflip() {
		// Render to webgl or 2d.
		let img=this.img;
		let imgw=img.width,imgh=img.height;
		let ctx=this.ctxgl;
		if (ctx===null) {
			let cdata=new Uint8ClampedArray(img.data8.buffer);
			let idata=new ImageData(cdata,imgw,imgh);
			this.ctx2d.putImageData(idata,0,0);
		} else {
			if (this.glw!==imgw || this.glh!==imgh) {
				this.glw=imgw;
				this.glh=imgh;
				ctx.viewport(0,0,imgw,imgh);
				ctx.texImage2D(ctx.TEXTURE_2D,0,ctx.RGBA8,imgw,imgh,0,ctx.RGBA,ctx.UNSIGNED_BYTE,img.data8);
			} else {
				ctx.texSubImage2D(ctx.TEXTURE_2D,0,0,0,imgw,imgh,ctx.RGBA,ctx.UNSIGNED_BYTE,img.data8);
			}
			ctx.drawArrays(ctx.TRIANGLE_FAN,0,4);
		}
	}
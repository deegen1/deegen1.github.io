function drawimage3(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+(1-1e-7);
	let pixmaxy=invyx+invyy-pixminy+(1-1e-7);
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx0=srcx0-srcx,sy0=srcy0-srcy,sx=sx0,sy=sy0;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let xflag=(3>>i)&1,yflag=(6>>i)&1;
						let x0=sx,x1=sx0+(xflag?invxx:0)+(yflag?invxy:0);
						let y0=sy,y1=sy0+(xflag?invyx:0)+(yflag?invyy:0);
						sx=x1;sy=y1;
						let sign=alpha;
						if (x0>x1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
						if (!(y0<1 && y1>0)) {continue;}
						// Clip to unit box.
						let dx=x1-x0,dy=y1-y0;
						let x0y=y0-dy*(x0/dx);
						let x1y=y1+dy*((1-x1)/dx);
						let y0x=x0-dx*(y0/dy);
						let y1x=x1+dx*((1-y1)/dy);
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y1x;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<=0) {
							area+=(y0-y1)*sign;
						} else if (x0<1) {
							let tmp=y0;
							if (x0<0) {x0=0;y0=x0y;}
							if (x1>1) {x1=1;y1=x1y;}
							area+=(tmp-y1-(y0-y1)*(x0+x1)*0.5)*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[row+srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					if (maxc<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-8) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}
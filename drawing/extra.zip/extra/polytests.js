/*------------------------------------------------------------------------------


polytests.js - v1.09

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Tests for:
	Area overlap
	Efficient pixel blending algorithms
	Circle approximation accuracy


--------------------------------------------------------------------------------
TODO


FF
ovals: 2.780200
lines: 1.421280
chars: 0.785960

CR
ovals: 2.155065
lines: 1.094760
chars: 0.668935


*/
/* jshint esversion: 6   */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */


//---------------------------------------------------------------------------------
// Misc


/*
function demoimage() {
	let canvas=document.createElement("canvas");
	document.body.appendChild(canvas);
	let imgwidth=2048;
	let imgheight=2048;
	let imgscale=imgwidth/1000;
	canvas.width=imgwidth;
	canvas.height=imgheight;
	canvas.style.position="absolute";
	canvas.style.left="0px";
	canvas.style.top="0px";
	canvas.style.zIndex=99;
	let ctx=canvas.getContext("2d");
	ctx.font=Math.floor(32*imgscale)+"px consolas";
	ctx.textBaseline="middle";
	ctx.textAlign="center";
	ctx.fillStyle="rgba(0,0,0,255)";
	ctx.fillRect(0,0,imgwidth,imgheight);
}
*/


//---------------------------------------------------------------------------------
// Test 1 - Line Overlap Area Calculation


function areaapprox(x0,y0,x1,y1,samples) {
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let miny=Math.min(y0,y1),maxy=Math.max(y0,y1);
	let x,u;
	let rate=(x1-x0)/(y1-y0);
	let con =x0-y0*rate;
	let prev=null;
	let area=0;
	for (let s=0;s<=samples;s++) {
		u=s/samples;
		if (u>=miny && u<=maxy) {
			x=u*rate+con;
			x=1-Math.min(Math.max(x,0),1);
			if (prev!==null) {area+=prev+x;}
			prev=x;
		}
	}
	area/=2*samples;
	return (y0>y1?area:-area);
}


function areacalc1(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let dxy=difx/dify;
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	tmp=0.0;
	if (y0<0.0) {
		x0=y0x;
		y0=0.0;
	} else if (y0>1.0) {
		x0=y1x;
		y0=1.0;
	}
	if (y1<0.0) {
		x1=y0x;
		y1=0.0;
	} else if (y1>1.0) {
		x1=y1x;
		y1=1.0;
	}
	if (x0<0.0) {
		tmp+=y0-x0y;
		x0=0.0;
		y0=x0y;
	} else if (x0>1.0) {
		x0=1.0;
		y0=x1y;
	}
	if (x1<0.0) {
		tmp+=x0y-y1;
		x1=0.0;
		y1=x0y;
	} else if (x1>1.0) {
		x1=1.0;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp;
}


function areacalc2(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	let tmp;
	let sign=1;
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	let difx=x1-x0;
	let dify=y1-y0;
	if (dify<1e-10 || y0>=1 || y1<=0) {return 0;}
	let dxy=difx/dify;
	let dyx=difx>1e-10?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	// let y0x=x0-y0*dxy;
	// let y1x=y0x+dxy;
	tmp=0.0;
	if (y0<0.0) {
		x0-=y0*dxy;
		y0=0.0;
	}
	if (y1>1.0) {
		x1-=y1*dxy-dxy;
		y1=1.0;
	}
	if (x0<0.0) {
		tmp+=y0-x0y;
		x0=0.0;
		y0=x0y;
	} else if (x0>1.0) {
		x0=1.0;
		y0=x1y;
	}
	if (x1<0.0) {
		tmp+=x0y-y1;
		x1=0.0;
		y1=x0y;
	} else if (x1>1.0) {
		x1=1.0;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function areatest1() {
	// See if the area approximation matches the exact calculation.
	let samples=1<<16;
	let errlim=2/samples;
	let tests=10000;
	let maxdif1=0,maxdif2=0;
	let dif,areac;
	for (let test=0;test<tests;test++) {
		let x0=Math.random()*10-5;
		let y0=Math.random()*10-5;
		let x1=Math.random()*10-5;
		let y1=Math.random()*10-5;
		if (test&256) {x1=x0;}
		if (test&512) {y1=y0;}
		let areaa=areaapprox(x0,y0,x1,y1,samples);
		areac=areacalc1(x0,y0,x1,y1);
		dif=Math.abs(areaa-areac);
		if (maxdif1<dif || !(dif===dif)) {maxdif1=dif;}
		areac=areacalc2(x0,y0,x1,y1);
		dif=Math.abs(areaa-areac);
		if (maxdif2<dif || !(dif===dif)) {maxdif2=dif;}
	}
	console.log("max dif 1: "+maxdif1);
	console.log("max dif 2: "+maxdif2);
	console.log("exp dif  : "+errlim);
}


//---------------------------------------------------------------------------------
// Test 2 - Area Segments


function getrowlines(x0,y0,x1,y1,rowlines,idx,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	let r,rl=rowlines;
	/*if (x0>x1) {
		let tmp;
		amul=-amul;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}*/
	let difx=x1-x0;
	let dify=y1-y0;
	if (Math.abs(dify)<1e-10 || (y0>=1 && y1>=1) || (y0<=0 && y1<=0)) {return idx;}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	let dxy=difx/dify;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y0>1) {y0=1;x0=y1x;}
	if (y1<0) {y1=0;x1=y0x;}
	if (y1>1) {y1=1;x1=y1x;}
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	if (fx0===fx1) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul,c=(2-x0-x1)*dy*0.5;
		r=rl[idx++]; r[0]=fx0  ; r[1]=0; r[2]=c;
		r=rl[idx++]; r[0]=fx1+1; r[1]=0; r[2]=dy-c;
	} else {
		let dyx=(dify/difx)*amul;
		let mul=dyx*0.5,n0=x0-1,n1=x1-1;
		r=rl[idx++]; r[0]=fx0  ; r[1]=   0; r[2]=-n0*n0*mul;
		r=rl[idx++]; r[0]=fx0+1; r[1]=-dyx; r[2]= x0*x0*mul;
		r=rl[idx++]; r[0]=fx1  ; r[1]=   0; r[2]= n1*n1*mul;
		r=rl[idx++]; r[0]=fx1+1; r[1]= dyx; r[2]=-x1*x1*mul;
		// if (fx0+1>fx1) {throw "unsorted";}
	}
	return idx;
}


function areatest2() {
	// See if the area approximation matches the exact calculation.
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=100000;
	let maxdif=0;
	let swaps=0;
	for (let test=0;test<tests;test++) {
		let minx=Infinity,maxx=-Infinity;
		let miny=Infinity,maxy=-Infinity;
		let lines=rnd.modu32(5);
		let linearr=[];
		for (let i=0;i<lines;i++) {
			let x0=rnd.getf64()*200-50;
			let y0=rnd.getf64()*200-50;
			let x1=rnd.getf64()*200-50;
			let y1=rnd.getf64()*200-50;
			if (rnd.getf64()<0.25) {x0=Math.floor(x0);}
			if (rnd.getf64()<0.25) {y0=Math.floor(y0);}
			if (rnd.getf64()<0.25) {x1=x0;}
			if (rnd.getf64()<0.25) {y1=y0;}
			minx=Math.floor(Math.min(minx,Math.min(x0,x1)))-2;
			maxx=Math.ceil( Math.max(maxx,Math.max(x0,x1)))+2;
			miny=Math.floor(Math.min(miny,Math.min(y0,y1)))-2;
			maxy=Math.ceil( Math.max(maxy,Math.max(y0,y1)))+2;
			linearr[i]={x0:x0,y0:y0,x1:x1,y1:y1};
		}
		let rowarr=new Array(lines*4);
		for (let i=0;i<rowarr.length;i++) {rowarr[i]=[0,0,0];}
		for (let cy=miny;cy<maxy;cy++) {
			let rowlines=0;
			for (let i=0;i<lines;i++) {
				let l=linearr[i];
				rowlines=getrowlines(l.x0,l.y0-cy,l.x1,l.y1-cy,rowarr,rowlines,amul);
			}
			for (let i=1;i<rowlines;i++) {
				let j=i,r=rowarr[j];
				while (j>0 && r[0]<rowarr[j-1][0]) {
					swaps++;
					rowarr[j]=rowarr[j-1];
					j--;
				}
				rowarr[j]=r;
			}
			let area=0,arearate=0;
			let ridx=0,nextx=ridx<rowlines?rowarr[ridx][0]:Infinity;
			let cx=minx+Math.floor(rnd.getf64()*(maxx-minx));
			for (;cx<maxx;cx++) {
				while (cx>=nextx) {
					let r=rowarr[ridx++];
					area+=r[1]*(cx-nextx)+r[2];
					arearate+=r[1];
					nextx=ridx<rowlines?rowarr[ridx][0]:Infinity;
				}
				area+=arearate;
				let areac=0.0;
				for (let i=0;i<lines;i++) {
					let l=linearr[i];
					areac+=areacalc1(l.x0-cx,l.y0-cy,l.x1-cx,l.y1-cy)*amul;
				}
				let dif=Math.abs(areac-area);
				if (maxdif<dif || !(dif===dif)) {
					// console.log(dif);
					maxdif=dif;
				}
			}
		}
	}
	console.log("max dif: "+maxdif);
	console.log("swap: "+swaps);
}



//---------------------------------------------------------------------------------
// Test 3 - Area Clipping


function getrowlines2(line,px,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	let x0=line.x0,y0=line.y0-py;
	let x1=line.x1,y1=line.y1-py;
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0>=1 && y1>=1) || (y0<=0 && y1<=0)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let dxy=difx/dify;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y0>1) {y0=1;x0=y1x;}
	if (y1<0) {y1=0;x1=y0x;}
	if (y1>1) {y1=1;x1=y1x;}
	// let next=(y0>y1?x0:x1)+(dxy<0?dxy:0);
	// next=xrow+Math.max(Math.floor(next),l.minx);
	// if (next>=l.maxy) {next=Infinity;}
	if (x1<x0) {tmp=x0;x0=x1;x1=tmp;dyx=-dyx;}
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		dyx*=amul;
		let mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function areacliptest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=1000;
	let maxdif=0;
	for (let test=0;test<tests;test++) {
		let x0=rnd.getf64()*200-50;
		let y0=rnd.getf64()*200-50;
		let x1=rnd.getf64()*200-50;
		let y1=rnd.getf64()*200-50;
		if (rnd.getf64()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf64()*2-1)*dev;
		}
		if (rnd.getf64()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf64()*2-1)*dev;
		}
		let minx=Math.floor(Math.min(x0,x1))-2;
		let maxx=Math.ceil( Math.max(x0,x1))+2;
		let miny=Math.floor(Math.min(y0,y1))-2;
		let maxy=Math.ceil( Math.max(y0,y1))+2;
		let line={x0:x0,y0:y0,x1:x1,y1:y1};
		// if (test!==1) {continue;}//////////////////////
		console.log(test,x0,y0,x1,y1);
		for (let cy=miny;cy<maxy;cy++) {
			let aobj=getrowlines2(line,Infinity,cy,amul);
			let a=aobj[0];
			let area=a.area,areadx1=a.areadx1,areadx2=a.areadx2,cx=a.sort;
			let areac;
			if (cx<0) {
				cx=0;
				areac=areacalc1(line.x0-cx,line.y0-cy,line.x1-cx,line.y1-cy);
				if (Math.abs(areac)<1e-20) {
					throw "zstart: "+areac;
				}
			} else {
				areac=areacalc1(line.x0-(cx-1),line.y0-cy,line.x1-(cx-1),line.y1-cy);
				if (areac!==0) {
					console.log(line,cx);
					throw "prev: "+areac;
				}
			}
			a=aobj[1];
			let stop=Math.min(a.sort,0)+10;
			for (;cx<stop;cx++) {
				if (cx>=a.sort) {
					area+=a.area;
					areadx1+=a.areadx1;
					areadx2+=a.areadx2;
					a.sort=Infinity;
				}
				areac=areacalc1(line.x0-cx,line.y0-cy,line.x1-cx,line.y1-cy)*amul;
				let dif=Math.abs(area-areac);
				if (maxdif<dif) {
					maxdif=dif;
					console.log(maxdif,areac,area,areadx1,areadx2);
				}
				area+=areadx1+areadx2;
				areadx2=0;
			}
			// console.log(aobj[0],aobj[1]);
		}
	}
	console.log("max dif: "+maxdif);
}


//---------------------------------------------------------------------------------
// Stride Test
// Calculate how many pixels can be filled with the same color.


function stridecalc1(x,xnext,area,areadx1,areadx2) {
	let base=Math.floor(area*255+0.5);
	base=Math.min(Math.max(base,0),255);
	while (x<xnext) {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
		let tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp,0),255);
		if (base!==tmp) {break;}
	}
	return x;
}


function stridecalc2(x,xnext,area,areadx1,areadx2) {
	let xdraw=x+1,tmp;
	if (areadx2===0) {
		tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp+(areadx1<0?-0.5:0.5),0.5),254.5);
		tmp=(tmp/255-area)/areadx1+x;
		xdraw=(tmp>x && tmp<xnext)?Math.ceil(tmp):xnext;
	}
	return xdraw;
}


function stridetest() {
	console.log("testing stride calculation");
	let rnd=new Random();
	let tests=100000;
	let tmp;
	for (let test=0;test<tests;test++) {
		let x=rnd.modu32(200)+100;
		let xnext=x+rnd.modu32(100);
		let area=rnd.getf64()*4-2;
		tmp=rnd.modu32(31);
		tmp=tmp>16?0:(1/(1<<tmp));
		let areadx1=(rnd.getf64()*4-2)*tmp;
		// tmp=rnd.modu32(31);
		// tmp=tmp>16?0:(1/(1<<tmp));
		// let areadx2=(rnd.getf64()*4-2)*tmp;
		let areadx2=0;
		let stride1=stridecalc1(x,xnext,area,areadx1,areadx2);
		let stride2=stridecalc2(x,xnext,area,areadx1,areadx2);
		if (stride1!==stride2) {
			console.log("bad stride: "+test);
			console.log(stride1+" != "+stride2);
			console.log("x    = "+x);
			console.log("next = "+xnext);
			console.log("area = "+area);
			console.log("dx1  = "+areadx1);
			console.log("dx2  = "+areadx2);
			return;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 2 - Fast Pixel Blending


function blendtest1() {
	// expects alpha in [0,256], NOT [0,256).
	let samples=20000000*2;
	let arr0=new Uint32Array(samples);
	let i;
	for (i=0;i<samples;i+=2) {
		arr0[i+0]=(Math.random()*0x100000000)>>>0;
		arr0[i+1]=Math.floor(Math.random()*256.99);
	}
	let arr=new Uint32Array(samples);
	let arr8=new Uint8Array(arr.buffer);
	let src=(Math.random()*0x100000000)>>>0;
	let src3=(src>>>24)&0xff;
	let src2=(src>>>16)&0xff;
	let src1=(src>>> 8)&0xff;
	let src0=(src>>> 0)&0xff;
	let dst,a;
	let lh,hh,lh2,hh2;
	let hash,time,pos,hash0=null;
	// ----------------------------------------
	arr.set(arr0);hash=1;
	let base=performance.now();
	for (i=0;i<samples;i+=2) {
		hash=arr[i+1];
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	base=performance.now()-base;
	console.log("baseline:",base,hash);
	console.log("Algorithm, Time, Accurate");
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(arr8[pos]*a+src0*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src1*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src2*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src3*(256-a))>>>8;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	hash0=hash;
	time=performance.now()-time-base;
	console.log("Naive RGB #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(((arr8[pos]-src0)*a)>>8)+src0;pos++;
		arr8[pos]=(((arr8[pos]-src1)*a)>>8)+src1;pos++;
		arr8[pos]=(((arr8[pos]-src2)*a)>>8)+src2;pos++;
		arr8[pos]=(((arr8[pos]-src3)*a)>>8)+src3;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("Naive RGB #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src>>>8)&0x00ff00ff;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)*a+lh*(256-a))>>>8)&0x00ff00ff)+
		       ((((dst>>>8)&0x00ff00ff)*a+hh*(256-a))&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	lh2=lh<<8;
	hh=(src>>>8)&0x00ff00ff;
	hh2=hh<<8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((((dst&0x00ff00ff)-lh)*a+lh2)>>>8)&0x00ff00ff)+
		       (((((dst>>>8)&0x00ff00ff)-hh)*a+hh2)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=src&0xff00ff00;
	let d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)-lh)*a+lh)&0x00ff00ff)+
		       ((((dst&0xff00ff00)-hh)*a+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #3",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	let mask0=0xff000000,mask1=0x00ff0000;
	let mask2=0x0000ff00,mask3=0x000000ff;
	let c0=src&mask0,c1=src&mask1;
	let c2=src&mask2,c3=src&mask3;
	d256=1.0/256.0;
	let na;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		na=1-a;
		dst=arr[i];
		arr[i]=(((dst&mask0)*a+c0*na)&mask0)
		      |(((dst&mask1)*a+c1*na)&mask1)
		      |(((dst&mask2)*a+c2*na)&mask2)
		      |(((dst&mask3)*a+c3*na)&mask3);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("float #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src&0xff00ff00)>>>0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)-hh)>>>8,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=(src&0x00ff00ff)>>>0;
	hh=(src&0xff00ff00)>>>0;
	hh2=hh>>>8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)>>>8)-hh2,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #2",time,hash===hash0);
}


//---------------------------------------------------------------------------------
// Test 3 - Pixel compositing


let blend_rgbashift=[0,0,0,0];
(function (){
	let rgba  =new Uint8ClampedArray([0,1,2,3]);
	let rgba32=new Uint32Array(rgba.buffer);
	let col=rgba32[0];
	for (let i=0;i<32;i+=8) {blend_rgbashift[(col>>>i)&255]=i;}
})();
const [blend_r,blend_g,blend_b,blend_a]=blend_rgbashift;


function blendref(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0) {return dst;}
	sa/=255.0;
	let a=sa+(((dst>>>blend_a)&255)/255.0)*(1-sa);
	sa/=a;
	let da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast1(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	if (da===255) {
		sa/=255.0;
		let da=1-sa;
		return ((255<<blend_a)|
			(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)|
			(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)|
			(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast3(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=255<<blend_a;
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<blend_a;
		src=(src&(~(255<<blend_a)))|da;
		dst=(dst&(~(255<<blend_a)))|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
}


const blendfast2=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	if (da===255) {
		//((imul((dst&0x00ff00ff)-coll,d)>>>8)+coll)&0x00ff00ff)+
		//((imul(((dst&0xff00ff00)>>>8)-colh2,d)+colh)&0xff00ff00);
		//return 0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<${blend_a})+
		(Math.max(Math.min(((src>>>${blend_r})&255)*sa+((dst>>>${blend_r})&255)*da,255),0)<<${blend_r})+
		(Math.max(Math.min(((src>>>${blend_g})&255)*sa+((dst>>>${blend_g})&255)*da,255),0)<<${blend_g})+
		(Math.max(Math.min(((src>>>${blend_b})&255)*sa+((dst>>>${blend_b})&255)*da,255),0)<<${blend_b}))>>> 0;
`.replace(/(>>>)0/g,""));

const blendfast4=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=${(255<<blend_a)>>>0};
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<${blend_a};
		src=(src&${(~(255<<blend_a)>>>0)})|da;
		dst=(dst&${(~(255<<blend_a)>>>0)})|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
`);

/* Inline blending

// Setup
let sa,sa0,sa1,sai,da,dst;
let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
let colrgba=this.rgba32[0]|amask,alpha=this.rgba[3]/255.0;
let coll=colrgba&0x00ff00ff,colh=colrgba&0xff00ff00,colh8=colh>>>8;

// Execution
sa0=Math.min(area,1)*alpha;
if (sa0>=0.999) {
	while (pixcol<pixstop) {
		imgdata[pixcol++]=colrgba;
	}
} else if (sa0>=1/256.0) {
	// Inlining blending is twice as fast as a blend() function.
	sai=(1-sa0)/255.0;
	sa1=256-Math.floor(sa0*256);
	while (pixcol<pixstop) {
		// Approximate blending by expanding sa from [0,255] to [0,256].
		dst=imgdata[pixcol];
		da=(dst>>>ashift)&255;
		if (da===0) {
			imgdata[pixcol++]=0xffffffff;
			continue;
		} else if (da===255) {
			sa=sa1;
		} else if (da<255) {
			da=sa0+da*sai;
			sa=256-Math.floor(Math.min(sa0/da,1)*256);
			da=Math.floor(da*255+0.5);
		}
		imgdata[pixcol++]=((
			(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&0x00ff00ff)+
			((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&0xff00ff00)
			)&namask)|(da<<ashift);
	}
}
*/

function blendtest2() {
	// https://en.wikipedia.org/wiki/Alpha_compositing
	// src drawn on dst
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	console.log("testing blending 3");
	let am=255<<blend_a,nm=(~am)>>>0;
	let count=0;
	for (let test=0;test<1000000;test++) {
		let src=Math.floor(Math.random()*0x100000000);
		let dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		dst>>>=0;
		src>>>=0;
		let ref=blendref(dst,src);
		let calc=blendfast4(dst,src);
		let err=0;
		let dif0=Math.abs(((ref>>>0)&255)-((calc>>>0)&255));
		let dif1=Math.abs(((ref>>>8)&255)-((calc>>>8)&255));
		let dif2=Math.abs(((ref>>>16)&255)-((calc>>>16)&255));
		let dif3=Math.abs(((ref>>>24)&255)-((calc>>>24)&255));
		count+=dif0+dif1+dif2+dif3;
		if (dif0>1 || dif1>1 || dif2>1 || dif3>1) {
			console.log("error");
			console.log(src,dst);
			console.log(ref.toString(16),calc.toString(16));
			return;
		}
	}
	console.log("sum: "+count);
	console.log("passed");
	let sum=0,dst,src;
	let t0=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendref(dst,src);
	}
	t0=performance.now()-t0;
	let t1=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast3(dst,src);
	}
	t1=performance.now()-t1;
	let t2=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast4(dst,src);
	}
	t2=performance.now()-t2;
	console.log(sum);
	console.log(t0);
	console.log(t1);
	console.log(t2);
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 3 - Bezier parameterization


function bezier0(points,u) {
	let v=1-u;
	let cpx=v*v*v*points[0]+3*v*v*u*points[2]+3*v*u*u*points[4]+u*u*u*points[6];
	let cpy=v*v*v*points[1]+3*v*v*u*points[3]+3*v*u*u*points[5]+u*u*u*points[7];
	return [cpx,cpy];
}


function bezier1(points,u1) {
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	/*p3x=p3x+3*(p1x-p2x)-p0x;
	p3y=p3y+3*(p1y-p2y)-p0y;
	p2x=3*(p2x-2*p1x+p0x);
	p2y=3*(p2y-2*p1y+p0y);
	p1x=3*(p1x-p0x);
	p1y=3*(p1y-p0y);
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));*/
	/*p3x=p3x-p0x+3*(p1x-p2x);
	p3y=p3y-p0y+3*(p1y-p2y);
	p2x=3*(p2x+p0x-2*p1x);
	p2y=3*(p2y+p0y-2*p1y);
	p1x=3*(p1x-p0x);
	p1y=3*(p1y-p0y);
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));*/
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));
	return [cpx,cpy];
}


function bezierpolytest() {
	let tests=10000;
	let points=new Float64Array(8);
	let maxerr=0.0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			points[i]=Math.random()*10-5;
		}
		let u=Math.random()*10-5;
		let [x0,y0]=bezier0(points,u);
		let [x1,y1]=bezier1(points,u);
		x1-=x0;
		y1-=y0;
		let err=x1*x1+y1*y1;
		if (maxerr<err || !(err===err)) {
			maxerr=err;
		}
	}
	console.log("bezier err: "+maxerr);
}


//---------------------------------------------------------------------------------
// Bezier Segmentation Tests


function bezierdistance(curve,linearr) {
	let p0x=curve[0],p1x=curve[2],p2x=curve[4],p3x=curve[6];
	let p0y=curve[1],p1y=curve[3],p2y=curve[5],p3y=curve[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let len=linearr.length;
	if (len<1 || Math.abs(linearr[len-1].u-1)>1e-8) {
		throw "invalid points";
	}
	let u0,u1=0;
	let lx0,ly0,lx1=p0x,ly1=p0y,ldx,ldy;
	let maxdist=0;
	for (let i=0;i<len;i++) {
		// Calculate the points of this segment.
		let l=linearr[i];
		u0=u1;
		u1=l.u;
		if (u0>=u1) {
			throw "points not sorted";
		}
		lx0=lx1;lx1=p0x+u1*(p1x+u1*(p2x+u1*p3x));ldx=lx1-lx0;
		ly0=ly1;ly1=p0y+u1*(p1y+u1*(p2y+u1*p3y));ldy=ly1-ly0;
		let mag=ldx*ldx+ldy*ldy;
		// Make sure the line endpoints match our calculation.
		let dx0=l.x0-lx0,dy0=l.y0-ly0,err0=dx0*dx0+dy0*dy0;
		let dx1=l.x1-lx1,dy1=l.y1-ly1,err1=dx1*dx1+dy1*dy1;
		if (err0>1e-10 || err1>1e-10) {
			throw "points not on curve: "+i+"/"+len;
		}
		// Find the greatest distance from the curve to [p0,p1].
		let ldist=Math.sqrt(ldx*ldx+ldy*ldy);
		let steps=Math.floor(ldist+20);
		let umul=(u1-u0)/(steps-1);
		for (let s=0;s<steps;s++) {
			let u=s*umul+u0;
			let cpx=p0x+u*(p1x+u*(p2x+u*p3x))-lx0;
			let cpy=p0y+u*(p1y+u*(p2y+u*p3y))-ly0;
			u=cpx*ldx+cpy*ldy;
			if (u<0) {u=0;}
			else if (u>=mag) {u=1;}
			else {u/=mag;}
			cpx-=u*ldx;
			cpy-=u*ldy;
			let dist=cpx*cpx+cpy*cpy;
			if (maxdist<dist) {
				maxdist=dist;
			}
		}
	}
	return Math.sqrt(maxdist);
}


function beziersegment1(tv,splitlen) {
	// Get the control points and check if the curve's on the screen.
	let p0=0,p0x=tv[p0],p0y=tv[p0+1];
	let p1=2,p1x=tv[p1],p1y=tv[p1+1];
	let p2=4,p2x=tv[p2],p2y=tv[p2+1];
	let p3=6,p3x=tv[p3],p3y=tv[p3+1];
	/*x0=Math.min(p0x,Math.min(p1x,Math.min(p2x,p3x)));
	x1=Math.max(p0x,Math.max(p1x,Math.max(p2x,p3x)));
	y0=Math.min(p0y,Math.min(p1y,Math.min(p2y,p3y)));
	y1=Math.max(p0y,Math.max(p1y,Math.max(p2y,p3y)));
	if (x0>=iw || y0>=ih || y1<=0) {continue;}
	if (x1<=0) {
		if (lcnt>=lrcnt) {
			newlen=(lcnt+1)*2;
			while (lrcnt<newlen) {lr.push({});lrcnt++;}
			this.tmpline=lr;
		}
		l=lr[lcnt++];
		l.x0=p0x;
		l.y0=p0y;
		l.x1=p3x;
		l.y1=p3y;
		continue;
	}*/
	// Interpolate points.
	let lr=[],lrcnt=0,lcnt=0;
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let ppx=p0x,ppy=p0y,u0=0;
	for (let j=0;j<4;j++) {
		let u1=(j+1)/4;
		let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x))-ppx;
		let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y))-ppy;
		let dist=Math.sqrt(cpx*cpx+cpy*cpy);
		let segs=Math.ceil(dist/splitlen);
		// Split up the current segment.
		if (lcnt+segs>=lrcnt) {
			let newlen=(lcnt+segs)*2;
			while (lrcnt<newlen) {lr.push({});lrcnt++;}
			// this.tmpline=lr;
		}
		u1=(u1-u0)/segs;
		for (let s=0;s<segs;s++) {
			u0+=u1;
			cpx=p0x+u0*(p1x+u0*(p2x+u0*p3x));
			cpy=p0y+u0*(p1y+u0*(p2y+u0*p3y));
			let l=lr[lcnt++];
			l.u=u0;
			l.x0=ppx;
			l.y0=ppy;
			l.x1=cpx;
			l.y1=cpy;
			ppx=cpx;
			ppy=cpy;
		}
	}
	return lr.slice(0,lcnt);
}


function beziersegment2(tv,splitlen) {
	// Get the control points and check if the curve's on the screen.
	let p0=0,p0x=tv[p0],p0y=tv[p0+1];
	let p1=2,p1x=tv[p1],p1y=tv[p1+1];
	let p2=4,p2x=tv[p2],p2y=tv[p2+1];
	let p3=6,p3x=tv[p3],p3y=tv[p3+1];
	/*x0=Math.min(p0x,Math.min(p1x,Math.min(p2x,p3x)));
	x1=Math.max(p0x,Math.max(p1x,Math.max(p2x,p3x)));
	y0=Math.min(p0y,Math.min(p1y,Math.min(p2y,p3y)));
	y1=Math.max(p0y,Math.max(p1y,Math.max(p2y,p3y)));
	if (x0>=iw || y0>=ih || y1<=0) {continue;}*/
	splitlen*=splitlen;
	let lr=[],lrcnt=0,lcnt=0;
	if (lcnt>=lrcnt) {
		let newlen=(lcnt+1)*2;
		while (lrcnt<newlen) {lr.push({});lrcnt++;}
		// this.tmpline=lr;
	}
	let l=lr[lcnt++];
	l.x0=p0x;
	l.y0=p0y;
	l.x1=p3x;
	l.y1=p3y;
	l.u0=0;
	l.u =1;
	// Interpolate points.
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	for (let i=0;i<lcnt;) {
		l=lr[i];
		let u=(l.u0+l.u)*0.5;
		let mpx=p0x+u*(p1x+u*(p2x+u*p3x));
		let mpy=p0y+u*(p1y+u*(p2y+u*p3y));
		let dx=mpx-l.x0,dy=mpy-l.y0;
		let dist=dx*dx+dy*dy;
		if (dist<splitlen) {
			dx=mpx-l.x1;dy=mpy-l.y1;
			dist=dx*dx+dy*dy;
		}
		if (dist>=splitlen) {
			// Split up the current segment.
			if (lcnt>=lrcnt) {
				let newlen=(lcnt+1)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				// this.tmpline=lr;
			}
			let n=lr[lcnt++];
			n.u0=u;
			n.u =l.u;
			n.x0=mpx;
			n.y0=mpy;
			n.x1=l.x1;
			n.y1=l.y1;
			l.x1=mpx;
			l.y1=mpy;
			l.u =u;
		} else {
			i++;
		}
	}
	for (let i=1;i<lcnt;i++) {
		let j=i;l=lr[j];
		while (j>0 && l.u<lr[j-1].u) {
			lr[j]=lr[j-1];
			j--;
		}
		lr[j]=l;
	}
	return lr.slice(0,lcnt);
}


function beziersegment3(tv,splitlen) {
	// Get the control points and check if the curve's on the screen.
	let p0=0,p0x=tv[p0],p0y=tv[p0+1];
	let p1=2,p1x=tv[p1],p1y=tv[p1+1];
	let p2=4,p2x=tv[p2],p2y=tv[p2+1];
	let p3=6,p3x=tv[p3],p3y=tv[p3+1];
	/*x0=Math.min(p0x,Math.min(p1x,Math.min(p2x,p3x)));
	x1=Math.max(p0x,Math.max(p1x,Math.max(p2x,p3x)));
	y0=Math.min(p0y,Math.min(p1y,Math.min(p2y,p3y)));
	y1=Math.max(p0y,Math.max(p1y,Math.max(p2y,p3y)));
	if (x0>=iw || y0>=ih || y1<=0) {continue;}*/
	let lr=[],lrcnt=0,lcnt=0;
	if (lcnt>=lrcnt) {
		let newlen=(lcnt+1)*2;
		while (lrcnt<newlen) {lr.push({});lrcnt++;}
		// this.tmpline=lr;
	}
	let l=lr[lcnt++];
	l.x0=p0x;
	l.y0=p0y;
	l.x1=p3x;
	l.y1=p3y;
	l.u0=0;
	l.u =1;
	// Interpolate points.
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	for (let i=0;i<lcnt;) {
		l=lr[i];
		let u2=l.u0*0.75+l.u*0.25,u7=l.u0*0.25+l.u*0.75;
		let m2x=p0x+u2*(p1x+u2*(p2x+u2*p3x));
		let m2y=p0y+u2*(p1y+u2*(p2y+u2*p3y));
		let m7x=p0x+u7*(p1x+u7*(p2x+u7*p3x));
		let m7y=p0y+u7*(p1y+u7*(p2y+u7*p3y));
		let dx,dy,dist,dists;
		/*dx=l.x1-l.x0;dy=l.y1-l.y0;dist  =Math.sqrt(dx*dx+dy*dy);
		dx=m2x -l.x0;dy=m2y -l.y0;dists =Math.sqrt(dx*dx+dy*dy);
		dx=m7x -m2x ;dy=m7y -m2y ;dists+=Math.sqrt(dx*dx+dy*dy);
		dx=l.x1-m7x ;dy=l.y1-m7y ;dists+=Math.sqrt(dx*dx+dy*dy);
		if (dists>=dist*1.0001 && dists>1) {
			// Split up the current segment.
			if (lcnt+3>=lrcnt) {
				let newlen=(lcnt+3)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				//this.tmpline=lr;
			}
			let n;
			n=lr[lcnt++];n.u0=u2;n.u=u7 ;n.x0=m2x;n.y0=m2y;n.x1=m7x ;n.y1=m7y ;
			n=lr[lcnt++];n.u0=u7;n.u=l.u;n.x0=m7x;n.y0=m7y;n.x1=l.x1;n.y1=l.y1;
			l.x1=m2x;
			l.y1=m2y;
			l.u =u2;
		} else {
			i++;
		}*/
		/*dx=l.x1-l.x0;dy=l.y1-l.y0;dist  =Math.sqrt(dx*dx+dy*dy);
		dx=m2x -l.x0;dy=m2y -l.y0;dists =Math.sqrt(dx*dx+dy*dy);
		dx=m7x -m2x ;dy=m7y -m2y ;dists+=Math.sqrt(dx*dx+dy*dy);
		dx=l.x1-m7x ;dy=l.y1-m7y ;dists+=Math.sqrt(dx*dx+dy*dy);
		if (dists>=dist+0.05) {
		//if (dists>=Math.max(dist*1.00001,dist+0.001)) {
			// Split up the current segment.
			if (lcnt+3>=lrcnt) {
				let newlen=(lcnt+3)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				//this.tmpline=lr;
			}
			let n;
			n=lr[lcnt++];n.u0=u2;n.u=u7 ;n.x0=m2x;n.y0=m2y;n.x1=m7x ;n.y1=m7y ;
			n=lr[lcnt++];n.u0=u7;n.u=l.u;n.x0=m7x;n.y0=m7y;n.x1=l.x1;n.y1=l.y1;
			l.x1=m2x;
			l.y1=m2y;
			l.u =u2;
		} else {
			i++;
		}*/
		dist  =Math.abs(l.x1-l.x0)+Math.abs(l.y1-l.y0);
		dists =Math.abs(m2x -l.x0)+Math.abs(m2y -l.y0);
		dists+=Math.abs(m7x -m2x )+Math.abs(m7y -m2y );
		dists+=Math.abs(l.x1-m7x )+Math.abs(l.y1-m7y );
		if (dists>=dist+0.001) {
		// if (dists>=Math.max(dist*1.00001,dist+0.001)) {
			// Split up the current segment.
			if (lcnt+3>=lrcnt) {
				let newlen=(lcnt+3)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				// this.tmpline=lr;
			}
			let n;
			n=lr[lcnt++];n.u0=u2;n.u=u7 ;n.x0=m2x;n.y0=m2y;n.x1=m7x ;n.y1=m7y ;
			n=lr[lcnt++];n.u0=u7;n.u=l.u;n.x0=m7x;n.y0=m7y;n.x1=l.x1;n.y1=l.y1;
			l.x1=m2x;
			l.y1=m2y;
			l.u =u2;
		} else {
			i++;
		}
		/*dx=l.x1-l.x0;dy=l.y1-l.y0;dist  =Math.sqrt(dx*dx+dy*dy);
		dx=m2x -l.x0;dy=m2y -l.y0;dists =Math.sqrt(dx*dx+dy*dy);
		dx=m7x -m2x ;dy=m7y -m2y ;dists+=Math.sqrt(dx*dx+dy*dy);
		dx=l.x1-m7x ;dy=l.y1-m7y ;dists+=Math.sqrt(dx*dx+dy*dy);
		if (dists>=dist*1.0001 && dists>1) {
			// Split up the current segment.
			if (lcnt+2>=lrcnt) {
				let newlen=(lcnt+2)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				//this.tmpline=lr;
			}
			let n;
			n=lr[lcnt++];n.u0=u2;n.u=l.u;n.x0=m2x;n.y0=m2y;n.x1=l.x1;n.y1=l.y1;
			l.x1=m2x;
			l.y1=m2y;
			l.u =u2;
		} else {
			i++;
		}*/
		/*dx=l.x1-l.x0;dy=l.y1-l.y0;dist =(dx*dx+dy*dy);
		dx=m2x -l.x0;dy=m2y -l.y0;dists=(dx*dx+dy*dy);
		dx=m7x -m2x ;dy=m7y -m2y ;dists=Math.max(dists,dx*dx+dy*dy);
		dx=l.x1-m7x ;dy=l.y1-m7y ;dists=Math.max(dists,dx*dx+dy*dy);
		if (dists>=dist*0.22 && dists>1) {
			// Split up the current segment.
			if (lcnt+2>=lrcnt) {
				let newlen=(lcnt+2)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				//this.tmpline=lr;
			}
			let n;
			n=lr[lcnt++];n.u0=u2;n.u=l.u;n.x0=m2x;n.y0=m2y;n.x1=l.x1;n.y1=l.y1;
			l.x1=m2x;
			l.y1=m2y;
			l.u =u2;
		} else {
			i++;
		}*/
	}
	for (let i=1;i<lcnt;i++) {
		let j=i;l=lr[j];
		while (j>0 && l.u<lr[j-1].u) {
			lr[j]=lr[j-1];
			j--;
		}
		lr[j]=l;
	}
	return lr.slice(0,lcnt);
}


function beziersegment4(tv,splitlen) {
	// Get the control points and check if the curve's on the screen.
	let p0=0,p0x=tv[p0],p0y=tv[p0+1];
	let p1=2,p1x=tv[p1],p1y=tv[p1+1];
	let p2=4,p2x=tv[p2],p2y=tv[p2+1];
	let p3=6,p3x=tv[p3],p3y=tv[p3+1];
	/*x0=Math.min(p0x,Math.min(p1x,Math.min(p2x,p3x)));
	x1=Math.max(p0x,Math.max(p1x,Math.max(p2x,p3x)));
	y0=Math.min(p0y,Math.min(p1y,Math.min(p2y,p3y)));
	y1=Math.max(p0y,Math.max(p1y,Math.max(p2y,p3y)));
	if (x0>=iw || y0>=ih || y1<=0) {continue;}*/
	let lr=[],lrcnt=0,lcnt=0;
	if (lcnt>=lrcnt) {
		let newlen=(lcnt+1)*2;
		while (lrcnt<newlen) {lr.push({});lrcnt++;}
		// this.tmpline=lr;
	}
	let l=lr[lcnt++];
	l.x0=p0x;
	l.y0=p0y;
	l.x1=p3x;
	l.y1=p3y;
	l.u0=0;
	l.u =1;
	// Interpolate points.
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	for (let i=0;i<lcnt;) {
		l=lr[i];
		let u=(l.u0+l.u)*0.5;
		let mx=p0x+u*(p1x+u*(p2x+u*p3x));
		let my=p0y+u*(p1y+u*(p2y+u*p3y));
		let mdx=p1x+u*2*p2x+u*u*3*p3x;
		let mdy=p1y+u*2*p2y+u*u*3*p3y;
		let mag=mdx*mdx+mdy*mdy;
		let dx,dy,dist,dists;
		dx=mx-l.x0;dy=my-l.y0;let dist0=dx*dx+dy*dy,err0=dx*mdx+dy*mdy;
		dx=l.x1-mx;dy=l.y1-my;let dist1=dx*dx+dy*dy,err1=dx*mdx+dy*mdy;
		if ((err0<0 || err1<0 || err0*err0<mag*dist0*0.9992 || err1*err1<mag*dist1*0.9992) && (dist0>1 || dist1>1)) {
			// Split up the current segment.
			if (lcnt+3>=lrcnt) {
				let newlen=(lcnt+3)*2;
				while (lrcnt<newlen) {lr.push({});lrcnt++;}
				// this.tmpline=lr;
			}
			let n=lr[lcnt++];
			n.u0=u;
			n.u =l.u;
			n.x0=mx;
			n.y0=my;
			n.x1=l.x1;
			n.y1=l.y1;
			l.x1=mx;
			l.y1=my;
			l.u =u;
		} else {
			i++;
		}
	}
	for (let i=1;i<lcnt;i++) {
		let j=i;l=lr[j];
		while (j>0 && l.u<lr[j-1].u) {
			lr[j]=lr[j-1];
			j--;
		}
		lr[j]=l;
	}
	return lr.slice(0,lcnt);
}

/*
function beziersegment4(tv,splitlen) {
	// Get the control points and check if the curve's on the screen.
	let p0=0,p0x=tv[p0],p0y=tv[p0+1];
	let p1=2,p1x=tv[p1],p1y=tv[p1+1];
	let p2=4,p2x=tv[p2],p2y=tv[p2+1];
	let p3=6,p3x=tv[p3],p3y=tv[p3+1];
	//x0=Math.min(p0x,Math.min(p1x,Math.min(p2x,p3x)));
	//x1=Math.max(p0x,Math.max(p1x,Math.max(p2x,p3x)));
	//y0=Math.min(p0y,Math.min(p1y,Math.min(p2y,p3y)));
	//y1=Math.max(p0y,Math.max(p1y,Math.max(p2y,p3y)));
	//if (x0>=iw || y0>=ih || y1<=0) {continue;}
	let lr=[],lrcnt=0,lcnt=0;
	if (lcnt>=lrcnt) {
		let newlen=(lcnt+1)*2;
		while (lrcnt<newlen) {lr.push({});lrcnt++;}
		//this.tmpline=lr;
	}
	let l=lr[lcnt++];
	l.x0=p0x;
	l.y0=p0y;
	l.x1=p3x;
	l.y1=p3y;
	l.u0=0;
	l.u =1;
	l.dx0=p1x-p0x;l.dy0=p1y-p0y;
	l.dx1=p3x-p2x;l.dy1=p3y-p2y;
	// Interpolate points.
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	for (let i=0;i<lcnt;) {
		l=lr[i];
		let u=(l.u0+l.u)*0.5;
		let dx=p1x+u*(2*p2x+u*3*p3x);
		let dy=p1y+u*(2*p2y+u*3*p3y);
	console.log(3*(),3*(p1y-p0y));
	console.log(3*(p3x-p2x),3*(p3y-p2y));
	// Interpolate points.
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	for (let i=0;i<10;i++) {
		let u=i/9.0;

		console.log(dx,dy);
	}
	throw "x";
}
*/

function beziersegmenttest() {
	let rnd=new Random(10);
	let curve=new Array(8);
	let distsum=0,segsum=0;
	let tests=100;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=(rnd.getf64()*2-1)*100;
		}
		let lr=beziersegment4(curve,3);
		let dist=bezierdistance(curve,lr);
		distsum+=dist;
		segsum+=lr.length;
		console.log(test,dist,lr.length);
	}
	console.log("dist: "+distsum);
	console.log("segs: "+segsum);
}


//---------------------------------------------------------------------------------
// Bezier Distance


function bezierlength0(points) {
	// "Accurate" length calculation.
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let segs=1000;
	let lx=p0x,ly=p0y,dist=0;
	for (let s=1;s<=segs;s++) {
		let u=s/segs;
		let mx=p0x+u*(p1x+u*(p2x+u*p3x));
		let my=p0y+u*(p1y+u*(p2y+u*p3y));
		let dx=mx-lx,dy=my-ly;
		dist+=Math.sqrt(dx*dx+dy*dy);
		lx=mx;
		ly=my;
	}
	return dist;
}


function bezierlength1(points) {
	// approximate length calculation.
	let p0x=points[0],p0y=points[1];
	let c1x=points[2],c1y=points[3];
	let c2x=points[4],c2y=points[5];
	let c3x=points[6],c3y=points[7];
	let dx,dy,dist=0;
	dx=c1x-p0x;dy=c1y-p0y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	return dist*0.5;
}


function bezierlengthtest() {
	console.log("testing bezier length approximation");
	let rnd=new Random(10);
	let curve=new Array(8);
	let tests=100;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=(rnd.getf64()*2-1)*100;
		}
		let dist0=bezierlength0(curve);
		let dist1=bezierlength1(curve);
		let dif=Math.abs(dist0-dist1)/dist1;
		sumdif+=dif;
		console.log(dist0,dist1,dif);
	}
	console.log("dif: "+sumdif.toFixed(6));
}


//---------------------------------------------------------------------------------
// Test 3 - Line Sorting


function sortfunc0(arr,start,stop,field) {
	let len=stop-start,i,tmp;
	if (sortfunc0.sortval===undefined || sortfunc0.sortval.length<stop) {
		sortfunc0.sortval=new Float64Array(stop*2);
		sortfunc0.sortobj=new Array(stop*2);
		sortfunc0.dstval=new Float64Array(stop*2);
	}
	let sortval=sortfunc0.sortval;
	for (i=start;i<stop;i++) {
		sortval[i]=arr[i][field];
	}
	let sortobj=arr;
	let dstval=sortfunc0.dstval;
	let dstobj=sortfunc0.sortobj;
	for (let half=1;half<len;half+=half) {
		let hstop=stop-half;
		for (i=start;i<stop;) {
			let i0=i ,i1=i <hstop?i +half:stop;
			let j0=i1,j1=i1<hstop?i1+half:stop;
			while (i0<i1 && j0<j1) {
				if (sortval[i0]<=sortval[j0]) {
					dstval[i]=sortval[i0  ];
					dstobj[i]=sortobj[i0++];
				} else {
					dstval[i]=sortval[j0  ];
					dstobj[i]=sortobj[j0++];
				}
				i++;
			}
			while (i0<i1) {
				dstval[i  ]=sortval[i0  ];
				dstobj[i++]=sortobj[i0++];
			}
			while (j0<j1) {
				dstval[i  ]=sortval[j0  ];
				dstobj[i++]=sortobj[j0++];
			}
		}
		tmp=sortval;sortval=dstval;dstval=tmp;
		tmp=sortobj;sortobj=dstobj;dstobj=tmp;
	}
	if (!Object.is(sortobj,arr)) {
		for (i=start;i<stop;i++) {arr[i]=sortobj[i];}
	}
}


function sortfunc1(arr,start,stop,field) {
	let len=stop-start,i,tmp;
	if (sortfunc1.sortobj===undefined || sortfunc1.sortobj.length<len) {
		sortfunc1.sortobj=new Array(len*2);
		sortfunc1.dstobj =new Array(len*2);
	}
	let sortobj=sortfunc1.sortobj;
	let dstobj=sortfunc1.dstobj;
	for (i=0;i<len;i++) {sortobj[i]=arr[i+start];}
	for (let half=1;half<len;half+=half) {
		let hlen=len-half;
		for (i=0;i<len;) {
			let i0=i ,i1=i <hlen?i +half:len;
			let j0=i1,j1=i1<hlen?i1+half:len;
			while (i0<i1 && j0<j1) {
				if (sortobj[i0][field]<=sortobj[j0][field]) {
					dstobj[i++]=sortobj[i0++];
				} else {
					dstobj[i++]=sortobj[j0++];
				}
			}
			while (i0<i1) {dstobj[i++]=sortobj[i0++];}
			while (j0<j1) {dstobj[i++]=sortobj[j0++];}
		}
		tmp=sortobj;sortobj=dstobj;dstobj=tmp;
	}
	for (i=0;i<len;i++) {
		arr[start+i]=sortobj[i];
	}
}


function sortfunc2(arr,start,stop,field) {
	let len=stop-start,i,tmp;
	if (sortfunc2.sortobj===undefined || sortfunc2.sortobj.length<len) {
		sortfunc2.sortobj=new Array(len*2);
		sortfunc2.dstobj =new Array(len*2);
	}
	let sortobj=sortfunc2.sortobj;
	let dstobj=sortfunc2.dstobj;
	for (i=0;i<len;i++) {sortobj[i]=arr[i+start];}
	for (let half=1;half<len;half+=half) {
		let hlen=len-half;
		for (i=0;i<len;) {
			let i0=i ,i1=i <hlen?i +half:len;
			let j0=i1,j1=i1<hlen?i1+half:len;
			if (i0<i1 && j0<j1) {
				let iv=sortobj[i0][field];
				let jv=sortobj[j0][field];
				while (1) {
					if (iv<=jv) {
						dstobj[i++]=sortobj[i0++];
						if (i0>=i1) {break;}
						iv=sortobj[i0][field];
					} else {
						dstobj[i++]=sortobj[j0++];
						if (j0>=j1) {break;}
						jv=sortobj[j0][field];
					}
				}
			}
			while (i0<i1) {dstobj[i++]=sortobj[i0++];}
			while (j0<j1) {dstobj[i++]=sortobj[j0++];}
		}
		tmp=sortobj;sortobj=dstobj;dstobj=tmp;
	}
	for (i=0;i<len;i++) {
		arr[start+i]=sortobj[i];
	}
}


function sortfunc3(arr,start,stop,field) {
	let len=stop-start,arr0=arr,i,tmp;
	if (sortfunc3.sortobj===undefined || sortfunc3.sortobj.length<stop) {
		sortfunc3.sortobj=new Array(stop*2);
	}
	let dst=sortfunc3.sortobj;
	for (let half=1;half<len;half+=half) {
		let hstop=stop-half;
		for (i=start;i<stop;) {
			let i0=i ,i1=i <hstop?i +half:stop;
			let j0=i1,j1=i1<hstop?i1+half:stop;
			if (i0<i1 && j0<j1) {
				let iv=arr[i0][field];
				let jv=arr[j0][field];
				while (1) {
					if (iv<=jv) {
						dst[i++]=arr[i0++];
						if (i0>=i1) {break;}
						iv=arr[i0][field];
					} else {
						dst[i++]=arr[j0++];
						if (j0>=j1) {break;}
						jv=arr[j0][field];
					}
				}
			}
			while (i0<i1) {dst[i++]=arr[i0++];}
			while (j0<j1) {dst[i++]=arr[j0++];}
		}
		tmp=dst;dst=arr;arr=tmp;
	}
	if (!Object.is(arr0,arr)) {
		for (i=start;i<stop;i++) {arr0[i]=arr[i];}
	}
}


function sortfunc4(arr,start,stop,field) {
	let len=stop-start,i;
	if (len<33) {
		for (i=start+1;i<stop;i++) {
			let j=i,obj=arr[i],val=obj[field];
			while (j>start && val<arr[j-1][field]) {
				arr[j]=arr[j-1];
				j--;
			}
			arr[j]=obj;
		}
		return;
	}
	if (sortfunc4.sortobj===undefined || sortfunc4.sortobj.length<stop) {
		sortfunc4.sortobj=new Array(stop*2);
	}
	let dst=sortfunc4.sortobj,arr0=arr,tmp;
	for (let half=1;half<len;half+=half) {
		let hstop=stop-half;
		for (i=start;i<stop;) {
			let i0=i ,i1=i <hstop?i +half:stop;
			let j0=i1,j1=i1<hstop?i1+half:stop;
			if (i0<i1 && j0<j1) {
				let io=arr[i0],iv=io[field];
				let jo=arr[j0],jv=jo[field];
				while (1) {
					if (iv<=jv) {
						dst[i++]=io;
						if (++i0>=i1) {break;}
						io=arr[i0];iv=io[field];
					} else {
						dst[i++]=jo;
						if (++j0>=j1) {break;}
						jo=arr[j0];jv=jo[field];
					}
				}
			}
			while (i0<i1) {dst[i++]=arr[i0++];}
			while (j0<j1) {dst[i++]=arr[j0++];}
		}
		tmp=dst;dst=arr;arr=tmp;
	}
	if (!Object.is(arr0,arr)) {
		for (i=start;i<stop;i++) {arr0[i]=arr[i];}
	}
}


function sortfunc5(arr,start,stop,field) {
	let half=16;
	for (let i=start;i<stop;) {
		let i0=i,i1=i+half;i1=i1<stop?i1:stop;
		while (++i<i1) {
			let j=i,obj=arr[i],val=obj[field];
			while (j>i0 && val<arr[j-1][field]) {
				arr[j]=arr[j-1];
				j--;
			}
			arr[j]=obj;
		}
	}
	let len=stop-start;
	if (len<=16) {return;}
	if (sortfunc5.sortobj===undefined || sortfunc5.sortobj.length<stop) {
		sortfunc5.sortobj=new Array(stop*2);
	}
	let dst=sortfunc5.sortobj,arr0=arr,tmp;
	for (;half<len;half+=half) {
		let hstop=stop-half;
		for (let i=start;i<stop;) {
			let i0=i ,i1=i <hstop?i +half:stop;
			let j0=i1,j1=i1<hstop?i1+half:stop;
			if (i0<i1 && j0<j1) {
				let io=arr[i0],iv=io[field];
				let jo=arr[j0],jv=jo[field];
				while (1) {
					if (iv<=jv) {
						dst[i++]=io;
						if (++i0>=i1) {break;}
						io=arr[i0];iv=io[field];
					} else {
						dst[i++]=jo;
						if (++j0>=j1) {break;}
						jo=arr[j0];jv=jo[field];
					}
				}
			}
			while (i0<i1) {dst[i++]=arr[i0++];}
			while (j0<j1) {dst[i++]=arr[j0++];}
		}
		tmp=dst;dst=arr;arr=tmp;
	}
	if (!Object.is(arr0,arr)) {
		for (let i=start;i<stop;i++) {arr0[i]=arr[i];}
	}
}


function sorttest() {
	console.log("Testing sorting speed");
	let funcs=[sortfunc0,sortfunc1,sortfunc2,sortfunc3,sortfunc4,sortfunc5];
	for (let b=0;b<14;b++) {
		let len=1<<b;
		let arr=new Array(len);
		for (let i=0;i<len;i++) {arr[i]={val:0,idx:i};}
		let trials=Math.floor(1000000/len);
		let line=b+": ",t0;
		for (let f=0;f<funcs.length;f++) {
			const sort=funcs[f];
			t0=performance.now();
			for (let trial=0;trial<trials;trial++) {
				for (let i=0;i<len;i++) {arr[i].val=Math.random();}
				sort(arr,0,len,"val");
			}
			line+=Math.floor(performance.now()-t0)+", ";
		}
		console.log(line);
	}
}


//---------------------------------------------------------------------------------
// Heap sorting


function heaptest() {
	console.log("Testing heap");
	let rnd=new Random();
	for (let test=0;test<200;test++) {
		let alloc=rnd.modu32(2000);
		// Build heap.
		let maxval=100000;
		let idused=new Uint32Array(alloc);
		let lr=new Array(alloc),lcnt=0;
		let swaps=0;
		for (let i=0;i<alloc;i++) {
			let l={};
			l.id=i;
			lr[i]=l;
			l.sort=-Infinity;
			if (rnd.modu32(4)===0) {continue;}
			l.sort=rnd.modu32(maxval*2);
			/*let j=lcnt++;
			lr[i]=lr[j];
			let p,lp;
			while (j>0 && l.sort<(lp=lr[p=(j-1)>>1]).sort) {
				swaps++;
				lr[j]=lp;
				j=p;
			}
			lr[j]=l;*/
			lr[i]=lr[lcnt];
			lr[lcnt++]=l;
		}
		for (let i=(lcnt>>1)-1;i>=0;i--) {
			let l=lr[i],s=l.sort,p=i,j;
			while ((j=p+p+1)<lcnt) {
				swaps++;
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=s) {break;}
				lr[p]=lr[j];
				p=j;
			}
			lr[p]=l;
		}
		console.log("swap:",swaps,lcnt);
		while (true) {
			// Test heap properties.
			idused.fill(1);
			let cnt=0;
			for (let i=0;i<alloc;i++) {
				let l=lr[i],id=l.id;
				cnt+=idused[id];
				idused[id]=0;
				if (i>0 && i<lcnt) {
					let p=(i-1)>>1,lp=lr[p];
					if (lp.sort>l.sort) {
						throw "not sorted: "+lp.sort+", "+l.sort;
					}
				}
			}
			if (cnt!==alloc) {
				throw "object missing: "+cnt+" / "+alloc;
			}
			if (lcnt===0 || lr[0].sort>=maxval) {break;}
			// Modify top value.
			let l=lr[0];
			let type=rnd.modu32(4);
			let mod=[1,2,100,maxval-l.sort+10][type];
			l.sort+=rnd.modu32(mod);
			// Heap sort down.
			let i=0,j;
			while ((j=i+i+1)<lcnt) {
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=l.sort) {break;}
				lr[i]=lr[j];
				i=j;
			}
			lr[i]=l;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Bounding Box


/*obbcompute() {
	// Compute an oriented bounding box for fast on-image detection.
	let varr=this.vertarr,vidx=this.vertidx;
	let skip=this.CLOSE;
	let minarea=Infinity;
	this.changed=false;
	this.obb=[0,0,0,0,0,0];
	if (vidx>0) {this.obb=[varr[0].x,varr[0].y,0,0,0,0];}
	// Pick 2 points to form an edge of the OBB.
	for (let i0=0;i0<vidx;i0++) {
		let v0=varr[i0],v0x=v0.x,v0y=v0.y;
		if (v0.type===skip) {continue;}
		// Find another vertex on the boundary with v0.
		let dx=2,dy=0;
		for (let i1=0;i1<vidx;i1++) {
			let v1=varr[i1],v1x=v1.x-v0x,v1y=v1.y-v0y;
			let mag=v1x*v1x+v1y*v1y;
			if (mag<1e-10 || v1.type===skip) {continue;}
			if (v1x*dy-v1y*dx<1e-10 && dx<2) {continue;}
			mag=1.0/Math.sqrt(mag);
			dx=v1x*mag;
			dy=v1y*mag;
		}
		// Find the extremes of the OBB.
		let cx=-dy,cy=dx;
		let dmin=Infinity,dmax=-Infinity,cmin=Infinity,cmax=-Infinity;
		for (let i2=0;i2<vidx;i2++) {
			let v2=varr[i2];
			if (v2.type===skip) {continue;}
			let d=v2.x*dx+v2.y*dy;
			dmin=dmin>d?d:dmin;
			dmax=dmax<d?d:dmax;
			let c=v2.x*cx+v2.y*cy;
			cmin=cmin>c?c:cmin;
			cmax=cmax<c?c:cmax;
		}
		dmax-=dmin;
		cmax-=cmin;
		let area=dmax*cmax;
		if (minarea>area) {
			minarea=area;
			this.obb=[
				dmin*dx+cmin*cx,dmin*dy+cmin*cy,
				dmax*dx,dmax*dy,cmax*cx,cmax*cy
			];
		}
	}
}*/


function aabbdraw(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	let ipoints=[[0,0],[imgwidth,0],[imgwidth,imgheight],[0,imgheight]];
	let ppoints=[[bndx,bndy],[bndx+bnddx0,bndy+bnddy0],[bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1],[bndx+bnddx1,bndy+bnddy1]];
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let p=0;p<2;p++) {
		let arr=[ipoints,ppoints][p];
		for (let i=0;i<4;i++) {
			let x=arr[i][0],y=arr[i][1];
			if (minx>x) {minx=x;}
			if (maxx<x) {maxx=x;}
			if (miny>y) {miny=y;}
			if (maxy<y) {maxy=y;}
		}
	}
	let pad=0.05;
	maxx-=minx;
	maxy-=miny;
	minx-=maxx*pad;
	miny-=maxy*pad;
	maxx=canv.width/(maxx*(1+pad*2));
	maxy=canv.height/(maxy*(1+pad*2));
	for (let p=0;p<2;p++) {
		let arr=[ipoints,ppoints][p];
		ctx.strokeStyle=["#ffffff","#ff0000"][p];
		ctx.beginPath();
		for (let i=0;i<4;i++) {
			let x=(arr[i][0]-minx)*maxx;
			let y=(arr[i][1]-miny)*maxy;
			ctx.lineTo(x,y);
		}
		ctx.closePath();
		ctx.stroke();
	}
}


function aabbcheck0(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if any lines intersect.
	let imglines=[
		[0,0,imgwidth,0],
		[imgwidth,0,imgwidth,imgheight],
		[imgwidth,imgheight,0,imgheight],
		[0,imgheight,0,0]
	];
	let polylines=[
		[bndx,bndy,bndx+bnddx0,bndy+bnddy0],
		[bndx+bnddx0,bndy+bnddy0,bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1],
		[bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1,bndx+bnddx1,bndy+bnddy1],
		[bndx+bnddx1,bndy+bnddy1,bndx,bndy]
	];
	/*for (let il=0;il<4;il++) {
		let [i0x,i0y,i1x,i1y]=imglines[il];
		i1x-=i0x;
		i1y-=i0y;
		for (let pl=0;pl<4;pl++) {
			let [p0x,p0y,p1x,p1y]=polylines[pl];
			p1x-=p0x;
			p1y-=p0y;
			let den=i1x*p1y-i1y*p1x;
			if (Math.abs(den)>1e-10) {
				p0x-=i0x;
				p0y-=i0y;
				let u=(p0x*i1y-p0y*i1x)/den;
				if (u>0.0 && u<1.0) {
					u=(p0x*p1y-p0y*p1x)/den;
					if (u>0.0 && u<1.0) {
						return true;
					}
				}
			}
		}
	}*/
	for (let il=0;il<4;il++) {
		let [i0x,i0y,i1x,i1y]=imglines[il];
		i1x-=i0x;
		i1y-=i0y;
		for (let pl=0;pl<4;pl++) {
			let [p0x,p0y,p1x,p1y]=polylines[pl];
			p1x-=p0x;
			p1y-=p0y;
			let den=i1x*p1y-i1y*p1x;
			p0x-=i0x;
			p0y-=i0y;
			let u=p0x*i1y-p0y*i1x;
			if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
				u=p0x*p1y-p0y*p1x;
				if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
					return true;
				}
			}
		}
	}
	// Either they are not overlapping, or one is entirely inside the other.
	let midx,midy;
	midx=bndx+(bnddx0+bnddx1)*0.5;
	midy=bndy+(bnddy0+bnddy1)*0.5;
	if (midx>=0 && midx<=imgwidth && midy>=0 && midy<=imgheight) {
		return true;
	}
	midx=imgwidth*0.5;
	midy=imgheight*0.5;
	let parity=0;
	for (let pl=0;pl<4;pl++) {
		let [p0x,p0y,p1x,p1y]=polylines[pl];
		p0x-=midx;
		p0y-=midy;
		p1x-=midx;
		p1y-=midy;
		let sign=p0x*p1y-p0y*p1x;
		if (sign<-1e-10) {parity--;}
		if (sign> 1e-10) {parity++;}
	}
	return parity===-4 || parity===4;
}


function aabbcheck1(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx+(bnddx0<0?bnddx0:0)+(bnddx1<0?bnddx1:0);
	let miny=bndy+(bnddy0<0?bnddy0:0)+(bnddy1<0?bnddy1:0);
	let maxx=bndx+(bnddx0>0?bnddx0:0)+(bnddx1>0?bnddx1:0);
	let maxy=bndy+(bnddy0>0?bnddy0:0)+(bnddy1>0?bnddy1:0);
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function aabbcheck2(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function aabbcheck3(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	if (bnddx0<0) {maxx-=ih*bnddx0;} else {minx-=ih*bnddx0;}
	if (bnddy0<0) {minx+=iw*bnddy0;} else {maxx+=iw*bnddy0;}
	if (bnddx1<0) {maxy-=ih*bnddx1;} else {miny-=ih*bnddx1;}
	if (bnddy1<0) {miny+=iw*bnddy1;} else {maxy+=iw*bnddy1;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function aabbcheck4(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1,tmp;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	tmp=ih*bnddx0; if (tmp<0) {maxx-=tmp;} else {minx-=tmp;}
	tmp=iw*bnddy0; if (tmp<0) {minx+=tmp;} else {maxx+=tmp;}
	tmp=ih*bnddx1; if (tmp<0) {maxy-=tmp;} else {miny-=tmp;}
	tmp=iw*bnddy1; if (tmp<0) {miny+=tmp;} else {maxy+=tmp;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function aabbcheck5(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-iw,maxx=bndx;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (maxx<=0 || 0<=minx) {return false;}
	let miny=bndy-ih,maxy=bndy;
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxy<=0 || 0<=miny) {return false;}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=bndy*bnddx0-bndx*bnddy0;
	maxx=minx;bnddx0*=ih;bnddy0*=iw;
	if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
	if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
	if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
	if (maxx<=0 || 0<=minx) {return false;}
	miny=bndy*bnddx1-bndx*bnddy1;
	maxy=miny;bnddx1*=ih;bnddy1*=iw;
	if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
	if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxy<=0 || 0<=miny) {return false;}
	return true;
}


function boundingboxtest() {
	console.log("testing bounding boxes");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&31)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf64()*16-8);
		return ((type&32) || pos)?ret:-ret;
	}
	let tests=1000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let matchcnt=0;
	let difcnt=0;
	let overlap=0;
	for (let test=0;test<tests;test++) {
		let imgwidth=getrnd(true);
		let imgheight=getrnd(true);
		for (let i=0;i<6;i++) {trans[i]=getrnd();}
		for (let i=0;i<4;i++) {aabb[i]=getrnd(i>1);}
		let calc0=aabbcheck0(imgwidth,imgheight,aabb,trans);
		let calc1=aabbcheck1(imgwidth,imgheight,aabb,trans);
		let calc2=aabbcheck2(imgwidth,imgheight,aabb,trans);
		let calc3=aabbcheck3(imgwidth,imgheight,aabb,trans);
		let calc4=aabbcheck4(imgwidth,imgheight,aabb,trans);
		let calc5=aabbcheck5(imgwidth,imgheight,aabb,trans);
		if (calc0!==calc1 || calc0!==calc2 || calc0!==calc3 || calc0!==calc4 || calc0!==calc5) {
			difcnt++;
			/*console.log(calc0,calc1,test);
			console.log("image: ",imgwidth,imgheight);
			console.log("aabb : ",aabb);
			console.log("trans: ",trans);
			aabbdraw(imgwidth,imgheight,aabb,trans);
			throw "x";*/
		} else {
			matchcnt++;
		}
		overlap+=calc0;
	}
	console.log("match  : "+matchcnt);
	console.log("dif    : "+difcnt);
	console.log("overlap: "+overlap);
	console.log("done");
}


function boundingboxspeedtest() {
	console.log("testing bounding box speed");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&15)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf64()*16-8);
		return ((type&16) || pos)?ret:-ret;
	}
	let randmask=(1<<20)-1;
	let rands=randmask+100;
	let randarr=new Float64Array(rands);
	let randabs=new Float64Array(rands);
	for (let i=0;i<rands;i++) {
		randarr[i]=getrnd();
		randabs[i]=Math.abs(randarr[i]);
	}
	let tests=10000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let overlap=0;
	let t0=performance.now();
	let r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck0(imgwidth,imgheight,aabb,trans);
	}
	let t1=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck1(imgwidth,imgheight,aabb,trans);
	}
	let t2=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck2(imgwidth,imgheight,aabb,trans);
	}
	let t3=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck3(imgwidth,imgheight,aabb,trans);
	}
	let t4=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck4(imgwidth,imgheight,aabb,trans);
	}
	let t5=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=aabbcheck5(imgwidth,imgheight,aabb,trans);
	}
	let t6=performance.now();
	console.log("overlaps: ",overlap);
	console.log("t0: "+(t1-t0).toFixed(6));
	console.log("t1: "+(t2-t1).toFixed(6));
	console.log("t2: "+(t3-t2).toFixed(6));
	console.log("t3: "+(t4-t3).toFixed(6));
	console.log("t4: "+(t5-t4).toFixed(6));
	console.log("t5: "+(t6-t5).toFixed(6));
	console.log("done");
}


function boundingboxdemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	let subimg=new Draw.Image(250,200);
	let trans=new Draw.Transform();
	let rnd=new Random();
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpoly.toString();
	Draw.colbnd=[0,0,0,0,0,0];
	Draw.colret=-1;
	func=func.replace("aabb.dy*matyy;",`aabb.dy*matyy; Draw.colret=0;
	                   Draw.colbnd=[bndx,bndy,bnddx0,bnddy0,bnddx1,bnddy1];`);
	for (let i=1;i<10;i++) {func=func.replace("return;","Draw.colret="+i+";return ;");}
	Draw.prototype.fillpoly=parsefunction(func);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let mpos=input.getmousepos();
		let mx=mpos[0]*draw.img.width;
		let my=mpos[1]*draw.img.height;
		if (mx===-Infinity) {mx=0;}
		if (my===-Infinity) {my=0;}
		draw.savestate();
		draw.settransform(trans);
		draw.setcolor(255,0,0,255);
		draw.filloval(mx,my,100,50);
		let imgx=(draw.img.width-subimg.width)*0.5;
		let imgy=(draw.img.height-subimg.height)*0.5;
		draw.savestate();
		draw.setimage(subimg);
		draw.fill(128,128,128,255);
		draw.setcolor(200,0,0,255);
		draw.filloval(mx-imgx,my-imgy,100,50);
		let ret=Draw.colret;
		let aabb=Draw.colbnd.slice();
		draw.loadstate();
		draw.drawimage(subimg,imgx,imgy);
		draw.loadstate();
		draw.setcolor(255,255,255,255);
		let x0=aabb[0]+imgx,y0=aabb[1]+imgy;
		let x1=x0+aabb[2],y1=y0+aabb[3];
		let x2=x1+aabb[4],y2=y1+aabb[5];
		let x3=x0+aabb[4],y3=y0+aabb[5];
		draw.drawline(x0,y0,x1,y1);
		draw.drawline(x1,y1,x2,y2);
		draw.drawline(x2,y2,x3,y3);
		draw.drawline(x3,y3,x0,y0);
		draw.filltext(10,10,"col: "+ret);
		ctx.putImageData(draw.img.imgdata,0,0);
		if (input.getkeyhit(input.MOUSE.LEFT)) {
			trans.setangle(rnd.getf64()*Math.PI*2);
			trans.setscale((rnd.getf64()*2-1)*2,(rnd.getf64()*2-1)*2);
			trans.setoffset((rnd.getf64()*2-1)*50,(rnd.getf64()*2-1)*50);
		}
	}
	update();
}


//---------------------------------------------------------------------------------
// Stress Tests


function ovalstresstest() {
	// console.log("testing ovals");
	let rnd=new Random(10);
	let imgwidth=257;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf64()*10);
		let yrad=Math.pow(2,rnd.getf64()*10);
		let x=(rnd.getf64()*3-1)*imgwidth;
		let y=(rnd.getf64()*3-1)*imgheight;
		draw.filloval(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("ovals: "+time.toFixed(6));
	// console.log("done");
}


function linestresstest() {
	// console.log("testing lines");
	let rnd=new Random(10);
	let imgwidth=257;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=200000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x0=(rnd.getf64()*3-1)*imgwidth;
		let y0=(rnd.getf64()*3-1)*imgheight;
		let x1=(rnd.getf64()*3-1)*imgwidth;
		let y1=(rnd.getf64()*3-1)*imgheight;
		if (rnd.getf64()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf64()*2-1)*dev;
		}
		if (rnd.getf64()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf64()*2-1)*dev;
		}
		draw.thickness=rnd.getf64()*10;
		draw.drawline(x0,y0,x1,y1);
	}
	time=(performance.now()-time)/1000;
	console.log("lines: "+time.toFixed(6));
	// console.log("done");
}


function charstresstest() {
	// console.log("testing characters");
	let rnd=new Random(10);
	let imgwidth=257;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=1000000;
	let text=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~█";
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x=(rnd.getf64()*3-1)*imgwidth;
		let y=(rnd.getf64()*3-1)*imgheight;
		let c=text[test%text.length];
		draw.filltext(x,y,c);
	}
	time=(performance.now()-time)/1000;
	console.log("chars: "+time.toFixed(6));
	// console.log("done");
}


function imagestresstest() {
	console.log("testing images");
	let rnd=new Random(10);
	let draw=new Draw();
	let images=10;
	let imgarr=new Array(images);
	draw.setcolor(0,0,0,255);
	let amask=draw.rgba32[0],nmask=(~amask)>>>0;
	for (let i=0;i<images;i++) {
		let w=i>0?Math.floor(Math.pow(2,i*1.10)+1):0;
		let h=i>0?Math.floor(Math.pow(2,i*1.13)+1):0;
		let img=new Draw.Image(w,h);
		imgarr[i]=img;
		let data32=img.data32,datalen=data32.length,col;
		for (let j=0;j<datalen;j++) {
			col=rnd.getu32();
			switch (rnd.modu32(4)) {
				case 0: col&=nmask; break;
				case 1: col|=amask; break;
				default: break;
			}
			data32[j]=col;
		}
	}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dstimg=imgarr[rnd.modu32(images)];
		let srcimg=imgarr[rnd.modu32(images)];
		draw.setimage(dstimg);
		draw.rgba32[0]=rnd.getu32();
		let w=rnd.modu32(srcimg.width*2);
		let h=rnd.modu32(srcimg.height*2);
		let x=(rnd.getf64()*3-1)*dstimg.width;
		let y=(rnd.getf64()*3-1)*dstimg.height;
		draw.drawimage(srcimg,x,y,w,h);
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
	console.log("done");
}


//---------------------------------------------------------------------------------
// Main


function testmain() {
	if (Draw.wasmloading<2) {
		setTimeout(testmain,1);
		console.log("loading wasm");
		return;
	}
	console.log("starting polygon tests");
	// areatest1();
	// areatest2();
	// areacliptest();
	// stridetest();
	// blendtest1();
	// blendtest2();
	// bezierpolytest();
	// beziersegmenttest();
	// bezierlengthtest();
	// sorttest();
	// heaptest();
	// boundingboxtest()
	// boundingboxspeedtest();
	// boundingboxdemo();
	ovalstresstest();
	linestresstest();
	charstresstest();
	// imagestresstest();
}

window.addEventListener("load",testmain);

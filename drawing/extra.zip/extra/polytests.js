/*------------------------------------------------------------------------------


polytests.js - v1.09

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Check performance.txt for historical data.


--------------------------------------------------------------------------------
TODO


Firefox
ovals: 2.674820
lines: 1.840040
chars: 2.763180

Chrome
ovals: 1.890830
lines: 1.326590
chars: 2.532605


*/
/* npx eslint polytests.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Vector,Transform,Input} from "../library.js";


//---------------------------------------------------------------------------------
// Test 1 - Line Overlap Area Calculation


function UnitAreaApprox(x0,y0,x1,y1,samples) {
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let miny=Math.min(y0,y1),maxy=Math.max(y0,y1);
	let rate=(x1-x0)/(y1-y0);
	let con =x0-y0*rate;
	let prev=NaN;
	let area=0;
	for (let s=0;s<=samples;s++) {
		let u=s/samples;
		if (u>=miny && u<=maxy) {
			let x=u*rate+con;
			x=x>0?x:0;
			x=x<1?1-x:0;
			if (prev===prev) {area+=prev+x;}
			prev=x;
		}
	}
	area/=2*samples;
	return (y0>y1?area:-area);
}


function UnitAreaCalc1(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let dxy=difx/dify;
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	tmp=0.0;
	if (y0<0.0) {
		x0=y0x;
		y0=0.0;
	} else if (y0>1.0) {
		x0=y1x;
		y0=1.0;
	}
	if (y1<0.0) {
		x1=y0x;
		y1=0.0;
	} else if (y1>1.0) {
		x1=y1x;
		y1=1.0;
	}
	if (x0<0.0) {
		tmp+=y0-x0y;
		x0=0.0;
		y0=x0y;
	} else if (x0>1.0) {
		x0=1.0;
		y0=x1y;
	}
	if (x1<0.0) {
		tmp+=x0y-y1;
		x1=0.0;
		y1=x0y;
	} else if (x1>1.0) {
		x1=1.0;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp;
}


function UnitAreaCalc12(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	let tmp=0;
	let sign=1;
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	let difx=x1-x0;
	let dify=y1-y0;
	if (dify<1e-9 || y0>=1 || y1<=0) {return 0;}
	let dxy=difx/dify;
	let dyx=difx>1e-9?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (x1<=0) {return (y0-y1)*sign;}
	if (x0>=1) {return 0;}
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function UnitAreaCalc13(x0,y0,x1,y1) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	let tmp=0,sign=1;
	//if (!(Math.abs(y0)<Infinity && Math.abs(y1)<Infinity && x1-x0!==0)) {
	//	return 0;
	//}
	if (isNaN((y1-y0)/(x1-x0))) {return 0;}
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	//if (x0>=Infinity || x1>=Infinity) {return 0;}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	// If we're entirely outside the bounding box.
	if (!(y0<1 && y1>0 && x0<1 && x1===x1)) {return 0;}
	let iy0=y0>0?y0:0;
	let iy1=y1<1?y1:1;
	if (x1<=0) {return (iy0-iy1)*sign;}
	// Determine if [0,1] is entirely to the left/right of slope.
	let dx=x1-x0,dy=y1-y0;
	// x=x0+(y-y0)*dx/dy
	if ((1-x0)*dy<=(iy0-y0)*dx) {return 0;}
	if ((0-x0)*dy>=(iy1-y0)*dx) {return (iy0-iy1)*sign;}
	// Narrow-phase. Clip to unit box.
	let x0y=y0-dy*(x0/dx);
	let x1y=y0+dy*((1-x0)/dx);
	let y0x=x0-dx*(y0/dy);
	let y1x=x0+dx*((1-y0)/dy);
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	/*if (x0<0 && x1>1) {
		return ((x0-0.5)/dx)*dy*sign;
	} else if (x0<0) {
		return ((x1*x1*0.5-x1+x0)/dx)*dy*sign;
	} else if (x1>1) {
		return -0.5*((1-x0)*(1-x0)/dx)*dy*sign;
	} else {
		return (y0-y1)*(2-x0-x1)*0.5*sign;
	}*/
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


/*
class Fraction {
	// Arbitrary precision fraction

	constructor(n,d) {
		// float, fraction, num/den
		if (d!==undefined) {
			n=BigInt(n);
			d=BigInt(d);
			if (d<0) {d=-d;n=-n;}
		} else if (n instanceof Fraction) {
			d=BigInt(n.d);
			n=BigInt(n.n);
		} else {
			let a=Fraction.fromfloat(n);
			n=a.n;
			d=a.d;
		}
		this.n=n;
		this.d=d;
		this.reduce();
	}


	static sanitize(b) {
		if (b instanceof Fraction) {return b;}
		return new Fraction(b);
	}


	static fromfloat() {
	}


	tofloat() {
	}


	reduce() {
	}


	cmp(b) {
		b=Fraction.sanitize(b);
		let l=this.n*b.d,r=this.d*b.n;
		return (l>r)-(l<r);
	}


	set(b) {
	}


	iadd(b) {
	}


	add(b) {return (new Fraction(this)).iadd(b);}


	sub() {
	}


	mul() {
	}


	div() {
	}

}
*/


function UnitAreaCalc(x0,y0,x1,y1,px,py) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	if (!(px===(px|0) && py===(py|0))) {
		throw `degenerate pixel coordinates: ${px}, ${py}`;
	}
	let sign=1;
	if (y0>y1) {
		sign=-1;
		let tmp=0;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// If we're outside the bounding box.
	let y0p=y0-py,y1p=y1-py;
	let x0p=x0-px,x1p=x1-px;
	if (y0p>=1 || y1p<=0 || (x0p>=1 && x1p>=1)) {return 0;}
	y0p=y0p>0?y0p:0;
	y1p=y1p<1?y1p:1;
	let areap=sign<0?(y1p-y0p):(y0p-y1p);
	if (x0p<=0 && x1p<=0) {return areap;}
	// Use arbitrary precision fractions.
	return NaN;
}


function UnitAreaTest() {
	// See if the area approximation matches the exact calculation.
	let tests=100000;
	let maxdif=0,avgdif=0;
	let rnd=new Random();
	function getrnd() {
		// Try to align near integer boundaries to cause rounding errors.
		let dev=rnd.mod(80)-40;
		return rnd.mod(20)-10+rnd.gets()*Math.pow(2,dev);
	}
	for (let test=0;test<tests;test++) {
		let x0=getrnd(),y0=getrnd();
		let x1=getrnd(),y1=getrnd();
		let px=rnd.mod(10)-5,py=rnd.mod(10)-5;
		let flag=rnd.getu32();
		if ((flag& 3)===0) {x1= x0;}
		if ((flag& 3)===1) {x1=-x0;}
		if ((flag&12)===0) {y1= y0;}
		if ((flag&12)===4) {y1=-y0;}
		//let area0=UnitAreaApprox(x0,y0,x1,y1,samples);
		let area0=UnitAreaCalc13(x0-px,y0-py,x1-px,y1-py);
		let area1=UnitAreaCalc(x0,y0,x1,y1,px,py);
		//if (isNaN(area1)) {continue;}
		let dif=Math.abs(area0-area1);
		if (maxdif<dif || !(dif===dif)) {maxdif=dif;}
		avgdif+=dif;
	}
	avgdif/=tests;
	console.log("max dif:",maxdif);
	console.log("avg dif:",avgdif);
}


//---------------------------------------------------------------------------------
// Test 3 - Area Clipping


function getrowlines2(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	let x0=line.x0,y0=line.y0-py;
	let x1=line.x1,y1=line.y1-py;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0>=1 && y1>=1) || (y0<=0 && y1<=0)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let dxy=difx/dify;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y0>1) {y0=1;x0=y1x;}
	if (y1<0) {y1=0;x1=y0x;}
	if (y1>1) {y1=1;x1=y1x;}
	let next=(y0>y1?x0:x1)+(dxy<0?dxy:0);
	if (next<Math.min(line.x0,line.x1)) {next=Math.min(line.x0,line.x1);}
	if (py+1>Math.max(line.y0,line.y1)) {next=Infinity;}
	a0.next=next;
	if (x1<x0) {tmp=x0;x0=x1;x1=tmp;dyx=-dyx;}
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		dyx*=amul;
		let mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function getrowlines3(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0<=py && y1<=py)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=py;
	y1-=py;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		let dyx=amul/dxy,mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function getrowlines4(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?~~x0:x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	if (x<fx1 && dyx>-1e8 && dyx<1e8) {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
	} else {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
	}
	a0.areadx2+=tmp;
	return [a0,a1];
}


function GetRowRef(line,p,iw,amul) {
	let x=p%iw,y=Math.floor(p/iw);
	let area=UnitAreaCalc(line.x0-x,line.y0-y,line.x1-x,line.y1-y);
	return area*amul;
}


function GetRowLines6(l,p,iw,ih,amul) {
	//     eps     :   max err
	// .0000000001 : 9.163271e-7  6.531069e-4
	// .000000001  : 9.096675e-8
	// .00000001   : 9.234800e-9
	// .0000001    : 7.116655e-8
	// .000001     : 7.116882e-7  7.026196e-1
	// .00001      : 7.116945e-6
	// .0001       : 7.116823e-5
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// For accuracy, avoid mixing units. Ex: use (y/dy)*dx instead
	// of (y*dx)/dy or y*(dx/dy).
	l.area=0;
	l.areadx1=0;
	l.areadx2=0;
	const y=Math.floor(p/iw),xrow=y*iw,x=p-xrow;
	let tmp=0;
	// Orient upwards, then clip y to [0,1].
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	y0-=fy;y1-=fy;x0-=x;x1-=x;
	let dx=x1-x0,dy=y1-y0,nx=x1;
	if (y1>2) {nx+=((2-y1)/dy)*dx;}
	if (y1>1) {x1+=((1-y1)/dy)*dx;y1=1;}
	if (y0<0) {x0+=((0-y0)/dy)*dx;y0=0;}
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;
	let rate=dy/dx;
	let end=l.end-xrow-iw,sort=xrow;
	if (y1<=0.000001) {
		// Above.
		sort=iw*ih;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1.000001 || end<0) {
		// Vertical line or last pixel.
		let ty=(y0-y1)*sign;
		tmp=x1>0?((-0.5*x1*x1)/dx)*dy:0;
		if (end<0) {
			ty=((0.5-x1)/dx)*dy;
			l.areadx1+=rate;
		} else {
			tmp=x0>=0?(x0+x1)*ty*0.5:tmp;
		}
		l.area+=ty-tmp;
		l.areadx2+=tmp;
		sort+=iw;
	} else {
		// Line spanning multiple pixels.
		tmp=x0>0?((0.5*x0*x0)/dx)*dy:0;
		l.area-=((0.5-x0)/dx)*dy+tmp;
		l.areadx1-=rate;
		l.areadx2+=tmp;
		nx=x1;
		end=x+x1<iw?0:end;
	}
	nx+=x;
	nx=nx<0?0:nx;
	l.sort=sort+(nx<iw?~~nx:iw);
	l.end=end?0xffffffff:l.sort;
}


function GetRowLines7(l,p,iw,ih,amul) {
	//     eps     :   max err
	// .0000000001 : 9.163271e-7  4.938340e-4
	// .000000001  : 9.096675e-8
	// .00000001   : 9.234800e-9
	// .0000001    : 7.116655e-8  6.781685e-2
	// .000001     : 7.116882e-7  6.986409e-1
	// .00001      : 7.116945e-6  6.766054e-0
	// .0001       : 7.116823e-5
	//
	// With eps=.0000001
	// max dif : 9.999892e-8
	// avg dif : 1.618923e-7
	// max area: 1.0000000305493204
	// max dx1 : 9999417.385284
	// max dx2 : 4999708.692642
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),plim=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	let end=l.end-plim,sort=plim-iw,x=p-sort;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,nx=x1;
	let dxy=dx/dy,dyx=sign*(dy/dx);
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	if (y1>fy+2) {nx=y0x+2*dxy;}
	if (y1>fy+1) {x1=y0x+dxy;y1=fy+1;}
	if (y0<fy  ) {x0=y0x;y0=fy;}
	// Subtract x and fy after normalizing to row.
	y0-=fy;y1-=fy;x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dyx=-dyx;tmp=x0;x0=x1;x1=tmp;}
	if (!(y1>0.0000001 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1.0000001 || end<0) {
		// Vertical line or last pixel.
		let ty=(y0-y1)*sign;
		tmp=x1>0?-0.5*x1*x1*dyx:0;
		if (end<0) {
			ty=(0.5-x1)*dyx;
			areadx1+=dyx;
		} else {
			tmp=x0>=0?0.5*(x0+x1)*ty:tmp;
		}
		area+=ty-tmp;
		areadx2+=tmp;
		sort+=iw;
	} else {
		// Line spanning multiple pixels.
		tmp=x0>0?0.5*x0*x0*dyx:0;
		area-=(0.5-x0)*dyx+tmp;
		areadx1-=dyx;
		areadx2+=tmp;
		nx=x1;
		end=x+x1<iw?0:1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	l.end=end?0xffffffff:sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines8(l,p,iw,ih,amul) {
	// Error over 10,000,000 tests:
	// max dif : 3.143318e-14
	// sum dif : 1.333336e-14
	// max area: 1.0000000000000187
	// max dx1 : 1.0000000000000002
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	let end=l.end,sort=prow-iw,x=p-sort;
	l.end=-1;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	y0-=fy;y1-=fy;
	let nx=y1>2?y0x+2*dxy:x1;
	if (y1>1) {y1=1;x1=y0x+dxy;}
	if (y0<0) {y0=0;x0=y0x;}
	// Subtract x after normalizing to row.
	x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>0 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1) {
		// Vertical line or last pixel.
		tmp=x1>0?-(x1*x1/dx)*dy:0;
		if (end<p && end>=sort) {
			areadx1+=dyx;
			area+=((x1>0?(1-x1)*(1-x1):(1-2*x1))/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=0?0.5*(x0+x1)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<1?pixels:iw;
	} else {
		// Spanning 2+ pixels.
		tmp=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
		area-=tmp;
		if (x1>=2) {
			areadx1-=dyx;
			tmp=x0>0?(x0*x0/dx)*dy:0;
			l.end=p;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function AreaClipTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(3);
	const maxdim=64;
	const amul=0.7117;
	let maxdif=0,sumdif=0,sumbuf=0,sumden=0;
	let maxarea=0,maxdx1=0,maxdx2=0;
	let tests=10000000;
	function getrnd(dim) {
		// Try to align near integer boundaries to cause rounding errors.
		//let degen=rnd.mod(64);
		//if (degen<3) {return [NaN,-Infinity,Infinity][degen];}
		let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		if (rnd.mod(128)===0) {dev=0;}
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxdif);
		}
		// Setup the line.
		let imgw=rnd.mod(maxdim)+1;
		let imgh=rnd.mod(maxdim)+1;
		let pixels=imgw*imgh;
		let x0=getrnd(imgw);
		let y0=getrnd(imgh);
		let x1=getrnd(imgw);
		let y1=getrnd(imgh);
		let p=rnd.mod(pixels);
		//if (test!==10782) {continue;}
		let minx=Math.floor(x0<x1?x0:x1);
		let maxx=Math.floor(x0>x1?x0:x1);
		let miny=Math.floor(y0<y1?y0:y1);
		let maxy=Math.floor(y0>y1?y0:y1);
		//console.log(minx,maxx,miny,maxy,imgw,imgh);
		let firstpix=Math.max(miny,0)*imgw+Math.min(Math.max(minx,0),imgw);
		let lastpix=Math.min(Math.max(maxy+1,0),imgh)*imgw+Math.min(Math.max(maxx,0),imgw);
		if (miny>=imgh) {
			firstpix=pixels;
			lastpix=pixels;
		}
		let line={sort:0,end:0xffffffff,x0:x0,y0:y0,x1:x1,y1:y1,area:0,areadx1:0,areadx2:0};
		// Pick a starting pixel and compare every pixel after.
		let nextrow=-1;
		let proccnt=0;
		//let area=0,areadx1=0,areadx2=0;
		let linenext=-1;
		let firstproc=1;
		for (;p<pixels;p++) {
			if (p>=nextrow) {
				nextrow=Math.floor(p/imgw)*imgw+imgw;
				line.area=0;
				line.areadx1=0;
				line.areadx2=0;
				proccnt=-firstproc;
				firstproc=0;
				/*if (line.end!==0xffffffff) {
					console.log("new row end:",line.end);
					throw "error";
				}*/
			}
			// Process the start or end of the line.
			if (p>=linenext) {
				GetRowLines8(line,p,imgw,imgh,amul);
				linenext=line.sort;
				proccnt++;
			}
			// Compare with the reference.
			let x=p%imgw,y=Math.floor(p/imgw);
			let calc=GetRowRef(line,p,imgw,amul);
			//console.log("test:",test,line.area,calc);
			let dif=Math.abs(line.area-calc);
			sumbuf+=dif;
			sumden++;
			if (sumden>1000000) {
				sumdif+=sumbuf;
				sumbuf=0;
				sumden=0;
			}
			if (maxdif<dif || isNaN(dif)) {
				maxdif=dif;
				console.log("test:",test,dif);
			}
			maxarea=Math.max(maxarea,Math.abs(line.area));
			maxdx1 =Math.max(maxdx1 ,Math.abs(line.areadx1));
			maxdx2 =Math.max(maxdx2 ,Math.abs(line.areadx2));
			if (!(dif<1e-3)) {
				console.log("test:",test);
				console.log("area:",line.area,calc);
				console.log("img :",imgw,imgh);
				console.log("x y :",x,y,p);
				console.log("line:",line);
				throw "error";
			}
			line.area+=line.areadx1+line.areadx2;
			line.areadx2=0;
			// Check bounds.
			if (proccnt>3) {
				console.log("too many row procs",proccnt);
				throw "error";
			}
			if (p<firstpix && linenext+1<firstpix) {
				console.log("first pixel:",p,pixels,firstpix,linenext);
				console.log("area:",GetRowRef(line,firstpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				throw "error";
			}
			if (p>lastpix && linenext<pixels) {
				console.log("last pixel:",p,pixels,lastpix,linenext);
				console.log("area:",GetRowRef(line,lastpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				throw "error";
			}
			let sort=line.sort;
			if (sort!==(sort>>>0) || sort<p) {
				console.log("invalid sort:",sort,p);
				throw "error";
			}
			let end=line.end;
			if (end!==(end>>0)) {// || (end<pixels && end>=nextrow) || end<p) {
				console.log("invalid end:",end,p,pixels,nextrow);
				throw "error";
			}
		}
	}
	maxdif/=amul;
	sumdif=((sumdif+sumbuf)/tests)/amul;
	maxarea/=amul;
	maxdx1/=amul;
	maxdx2/=amul;
	console.log("max dif :",maxdif);
	console.log("sum dif :",sumdif);
	console.log("max area:",maxarea);
	console.log("max dx1 :",maxdx1);
	console.log("max dx2 :",maxdx2);
}


//---------------------------------------------------------------------------------
// Cache Test


function getrowcache3(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,areadx3:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?Math.floor(x0):x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	let flen=fx1-x;
	if (flen<=0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else if (flen===1) {
		let dy=(y0-y1)*amul;
		let tmp0=dyh-x0*dyx+(x0>0?x0*x0*dyh:0);
		a0.area+=-tmp0;
		a0.areadx2+=dy+tmp0-tmp;
		a0.areadx3+=tmp;
	} else {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
		a0.areadx2+=tmp;
	}
	return [a0,a1];
}


function AreaCacheTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area cache-3");
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=100000;
	let maxdif=0;
	for (let test=0;test<tests;test++) {
		let x0=rnd.getf()*200-50;
		let y0=rnd.getf()*200-50;
		let x1=rnd.getf()*200-50;
		let y1=rnd.getf()*200-50;
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(34);
			dev=dev>31?0:Math.pow(2,-dev);
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(34);
			dev=dev>31?0:Math.pow(2,-dev);
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		let minx=Math.floor(Math.min(x0,x1))-2;
		let maxx=Math.ceil( Math.max(x0,x1))+2;
		let miny=Math.floor(Math.min(y0,y1));
		let maxy=Math.ceil( Math.max(y0,y1))+2;
		let line={x0:x0,y0:y0,x1:x1,y1:y1};
		// console.log(test,x0,y0,x1,y1);
		for (let cy=miny;cy<maxy;cy++) {
			// Pick a random point on the row to start.
			let cx=rnd.mod(maxx-minx+1)+minx;
			let aobj=getrowcache3(line,cx,cy,amul);
			let a=aobj[0];
			let area=a.area,areadx1=a.areadx1,areadx2=a.areadx2,areadx3=a.areadx3;
			// Test current row start.
			cx=a.sort;
			if (Math.abs(y1-y0)>1e-9 && (cy<y0 || cy<y1) && (cy+1>y0 || cy+1>y1)) {
				let areac=UnitAreaCalc(x0-cx,y0-cy,x1-cx,y1-cy);
				if (Math.abs(areac)<1e-18) {throw "row 0: "+areac;}
			}
			// Test next row start prediction.
			let nx=a.next;
			if (nx<Infinity) {
				let areac=UnitAreaCalc(x0-nx,y0-cy-1,x1-nx,y1-cy-1);
				if (Math.abs(areac)<1e-9) {throw "next 0: "+areac;}
				areac=UnitAreaCalc(x0-(nx-1),y0-cy-1,x1-(nx-1),y1-cy-1);
				if (Math.abs(areac)>1e-9) {throw "next -1: "+areac;}
			} else if (cy+1<y0 || cy+1<y1) {
				throw "next y: "+cy+", "+y0+", "+y1;
			}
			// Test that the end of the row is really the end.
			a=aobj[1];
			let stop=a.sort<Infinity?Math.max(a.sort,cx):cx;
			let areac1=UnitAreaCalc(x0-(stop+2),y0-cy,x1-(stop+2),y1-cy);
			let areac2=UnitAreaCalc(x0-(stop+3),y0-cy,x1-(stop+3),y1-cy);
			if (Math.abs(areac1-areac2)>1e-9) {throw "tail 2: "+areac1+", "+areac2;}
			stop+=10;
			for (;cx<stop;cx++) {
				if (cx>=a.sort) {
					area+=a.area;
					areadx1+=a.areadx1;
					areadx2+=a.areadx2;
					a.sort=Infinity;
				}
				let areac=UnitAreaCalc(x0-cx,y0-cy,x1-cx,y1-cy)*amul;
				let dif=Math.abs(area-areac);
				if (maxdif<dif) {
					maxdif=dif;
					console.log(maxdif,areac,area);
				}
				area+=areadx1+areadx2;
				areadx2=areadx3;
				areadx3=0;
			}
		}
	}
	console.log("max dif: "+maxdif);
}


//---------------------------------------------------------------------------------
// Stride Test
// Calculate how many pixels can be filled with the same color.


function stridecalc1(x,xnext,area,areadx1,areadx2) {
	let base=Math.floor(area*255+0.5);
	base=Math.min(Math.max(base,0),255);
	while (x<xnext) {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
		let tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp,0),255);
		if (base!==tmp) {break;}
	}
	return x;
}


function stridecalc2(x,xnext,area,areadx1,areadx2) {
	let xdraw=x+1,tmp=0;
	if (areadx2===0) {
		tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp+(areadx1<0?-0.5:0.5),0.5),254.5);
		tmp=(tmp/255-area)/areadx1+x;
		xdraw=(tmp>x && tmp<xnext)?Math.ceil(tmp):xnext;
	}
	return xdraw;
}


function StrideTest() {
	console.log("testing stride calculation");
	let rnd=new Random();
	let tests=100000;
	let tmp=0;
	for (let test=0;test<tests;test++) {
		let x=rnd.mod(200)+100;
		let xnext=x+rnd.mod(100);
		let area=rnd.getf()*4-2;
		tmp=rnd.mod(31);
		tmp=tmp>16?0:(1/(1<<tmp));
		let areadx1=(rnd.getf()*4-2)*tmp;
		// tmp=rnd.mod(31);
		// tmp=tmp>16?0:(1/(1<<tmp));
		// let areadx2=(rnd.getf()*4-2)*tmp;
		let areadx2=0;
		let stride1=stridecalc1(x,xnext,area,areadx1,areadx2);
		let stride2=stridecalc2(x,xnext,area,areadx1,areadx2);
		if (stride1!==stride2) {
			console.log("bad stride: "+test);
			console.log(stride1+" != "+stride2);
			console.log("x    = "+x);
			console.log("next = "+xnext);
			console.log("area = "+area);
			console.log("dx1  = "+areadx1);
			console.log("dx2  = "+areadx2);
			return;
		}
	}
	console.log("passed");
}


function stridecalc20(area,areadx1,areadx2,cutoff,x,xnext) {
	let side=area>=cutoff;
	do {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
	} while ((area>=cutoff)===side && x<xnext);
	return [x,area];
}


function stridecalc21(area,areadx1,areadx2,cutoff,x,xnext) {
	// const cutoff=0.00390625;
	let astop=area+areadx1+areadx2;
	let xstop=x+1,xdif=xnext-xstop;
	// xdif=(xnext<xrow?xnext:xrow)-xstop;
	if (xdif>0 && (area>=cutoff)===(astop>=cutoff)) {
		let adif=(cutoff-astop)/areadx1+1;
		// xdif=(adif>=1 && adif<xdif)?Math.floor(adif):xdif;
		xdif=(adif>=1 && adif<xdif)?~~adif:xdif;
		astop+=xdif*areadx1;
		xstop+=xdif;
	}
	return [xstop,astop];
}


function StrideTest2() {
	// If area>cutoff, how long until area+areadx2<=cutoff.
	// If any value is NaN or infinity, guarantee progression.
	// Don't let xstop become NaN, negative, or infinite.
	//
	// if (area>=cutoff) {
	//      do {
	//           area+=areadx1+areadx2;
	//           areadx2=0;
	//      } while (++x<xstop);
	// }
	// x=xstop;
	// area=astop;
	//
	console.log("testing stride calculation");
	let rnd=new Random(33);
	function rndpow(min,max,special=false) {
		let flags=rnd.getu32();
		if (special) {
			let type=(flags>>>1)&63;
			if (type<4) {return 0;}
			else if (type<8) {return NaN;}
			else if (type<10) {return Infinity;}
			else if (type<12) {return -Infinity;}
		}
		let exp=rnd.getf()*(max-min)+min;
		let val=Math.pow(2,exp);
		return (flags&1)?val:-val;
	}
	for (let trial=0;trial<10000000;trial++) {
		let cutoff=rndpow(-20,4);
		let area=rndpow(-30,4,true)+cutoff;
		let areadx1=rndpow(-30,4,true);
		let areadx2=rndpow(-30,4,true);
		if ((rnd.getu32()&63)===0) {
			// Special case to force adif=1.
			areadx2=0;
			areadx1=cutoff-area;
		}
		let x=Math.round(rndpow(0,6));
		let xnext=x+Math.round(Math.abs(rndpow(0,8)));
		if (xnext<x+1) {xnext=x+1;}
		let [xstop0,astop0]=stridecalc20(area,areadx1,areadx2,cutoff,x,xnext);
		let [xstop1,astop1]=stridecalc21(area,areadx1,areadx2,cutoff,x,xnext);
		let eq=true;
		if (isNaN(astop0)!==isNaN(astop1)) {eq=false;}
		else if ((Math.abs(astop0)>=Infinity)!==(Math.abs(astop1)>=Infinity)) {eq=false;}
		else if (Math.abs(astop0-astop1)>1e-9) {eq=false;}
		if (xstop0!==xstop1 || !eq) {
			console.log("error "+trial);
			console.log("calc 0 :",xstop0,astop0);
			console.log("calc 1 :",xstop1,astop1);
			console.log("cutoff :",cutoff);
			console.log("area   :",area);
			console.log("areadx1:",areadx1);
			console.log("areadx2:",areadx2);
			console.log("x      :",x);
			console.log("xnext  :",xnext);
			return;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 2 - Fast Pixel Blending


function BlendTest1() {
	// expects alpha in [0,256], NOT [0,256).
	let samples=20000000*2;
	let arr0=new Uint32Array(samples);
	let i=0;
	for (i=0;i<samples;i+=2) {
		arr0[i+0]=(Math.random()*0x100000000)>>>0;
		arr0[i+1]=Math.floor(Math.random()*256.99);
	}
	let arr=new Uint32Array(samples);
	let arr8=new Uint8Array(arr.buffer);
	let src=(Math.random()*0x100000000)>>>0;
	let src3=(src>>>24)&0xff;
	let src2=(src>>>16)&0xff;
	let src1=(src>>> 8)&0xff;
	let src0=(src>>> 0)&0xff;
	let dst=0,a=0;
	let lh=0,hh=0,lh2=0,hh2=0;
	let hash=0,time=0,pos=0,hash0=-1;
	// ----------------------------------------
	arr.set(arr0);hash=1;
	let base=performance.now();
	for (i=0;i<samples;i+=2) {
		hash=arr[i+1];
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	base=performance.now()-base;
	console.log("baseline:",base,hash);
	console.log("Algorithm, Time, Accurate");
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(arr8[pos]*a+src0*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src1*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src2*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src3*(256-a))>>>8;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	hash0=hash;
	time=performance.now()-time-base;
	console.log("Naive RGB #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(((arr8[pos]-src0)*a)>>8)+src0;pos++;
		arr8[pos]=(((arr8[pos]-src1)*a)>>8)+src1;pos++;
		arr8[pos]=(((arr8[pos]-src2)*a)>>8)+src2;pos++;
		arr8[pos]=(((arr8[pos]-src3)*a)>>8)+src3;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("Naive RGB #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src>>>8)&0x00ff00ff;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)*a+lh*(256-a))>>>8)&0x00ff00ff)+
		       ((((dst>>>8)&0x00ff00ff)*a+hh*(256-a))&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	lh2=lh<<8;
	hh=(src>>>8)&0x00ff00ff;
	hh2=hh<<8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((((dst&0x00ff00ff)-lh)*a+lh2)>>>8)&0x00ff00ff)+
		       (((((dst>>>8)&0x00ff00ff)-hh)*a+hh2)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=src&0xff00ff00;
	let d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)-lh)*a+lh)&0x00ff00ff)+
		       ((((dst&0xff00ff00)-hh)*a+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #3",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	let mask0=0xff000000,mask1=0x00ff0000;
	let mask2=0x0000ff00,mask3=0x000000ff;
	let c0=src&mask0,c1=src&mask1;
	let c2=src&mask2,c3=src&mask3;
	d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&mask0)-c0)*a+c0)&mask0)
		      |((((dst&mask1)-c1)*a+c1)&mask1)
		      |((((dst&mask2)-c2)*a+c2)&mask2)
		      |((((dst&mask3)-c3)*a+c3)&mask3);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("float #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src&0xff00ff00)>>>0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)-hh)>>>8,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=(src&0x00ff00ff)>>>0;
	hh=(src&0xff00ff00)>>>0;
	hh2=hh>>>8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)>>>8)-hh2,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #2",time,hash===hash0);
}


//---------------------------------------------------------------------------------
// Test 3 - Pixel compositing


let blend_rgbashift=[0,0,0,0];
(function (){
	let rgba  =new Uint8ClampedArray([0,1,2,3]);
	let rgba32=new Uint32Array(rgba.buffer);
	let col=rgba32[0];
	for (let i=0;i<32;i+=8) {blend_rgbashift[(col>>>i)&255]=i;}
})();
const [blend_r,blend_g,blend_b,blend_a]=blend_rgbashift;


function blendref(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0) {return dst;}
	sa/=255.0;
	let a=sa+(((dst>>>blend_a)&255)/255.0)*(1-sa);
	sa/=a;
	let da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast1(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	if (da===255) {
		sa/=255.0;
		da=1-sa;
		return ((255<<blend_a)|
			(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)|
			(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)|
			(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast3(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=255<<blend_a;
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<blend_a;
		src=(src&(~(255<<blend_a)))|da;
		dst=(dst&(~(255<<blend_a)))|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
}


const blendfast2=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	if (da===255) {
		//((imul((dst&0x00ff00ff)-coll,d)>>>8)+coll)&0x00ff00ff)+
		//((imul(((dst&0xff00ff00)>>>8)-colh2,d)+colh)&0xff00ff00);
		//return 0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<${blend_a})+
		(Math.max(Math.min(((src>>>${blend_r})&255)*sa+((dst>>>${blend_r})&255)*da,255),0)<<${blend_r})+
		(Math.max(Math.min(((src>>>${blend_g})&255)*sa+((dst>>>${blend_g})&255)*da,255),0)<<${blend_g})+
		(Math.max(Math.min(((src>>>${blend_b})&255)*sa+((dst>>>${blend_b})&255)*da,255),0)<<${blend_b}))>>> 0;
`.replace(/(>>>)0/g,""));


const blendfast4=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=${(255<<blend_a)>>>0};
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<${blend_a};
		src=(src&${(~(255<<blend_a)>>>0)})|da;
		dst=(dst&${(~(255<<blend_a)>>>0)})|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
`);


/* Inline blending

// Setup
let sa,sa0,sa1,sai,da,dst;
let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
let colrgba=this.rgba32[0]|amask,alpha=this.rgba[3]/255.0;
let coll=colrgba&0x00ff00ff,colh=colrgba&0xff00ff00,colh8=colh>>>8;

// Execution
sa0=Math.min(area,1)*alpha;
if (sa0>=0.999) {
	while (pixcol<pixstop) {
		imgdata[pixcol++]=colrgba;
	}
} else if (sa0>=1/256.0) {
	// Inlining blending is twice as fast as a blend() function.
	sai=(1-sa0)/255.0;
	sa1=256-Math.floor(sa0*256);
	while (pixcol<pixstop) {
		// Approximate blending by expanding sa from [0,255] to [0,256].
		dst=imgdata[pixcol];
		da=(dst>>>ashift)&255;
		if (da===0) {
			imgdata[pixcol++]=0xffffffff;
			continue;
		} else if (da===255) {
			sa=sa1;
		} else if (da<255) {
			da=sa0+da*sai;
			sa=256-Math.floor(Math.min(sa0/da,1)*256);
			da=Math.floor(da*255+0.5);
		}
		imgdata[pixcol++]=((
			(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&0x00ff00ff)+
			((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&0xff00ff00)
			)&namask)|(da<<ashift);
	}
}
*/

function BlendTest2() {
	// https://en.wikipedia.org/wiki/Alpha_compositing
	// src drawn on dst
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	// c = (sc - dc)*(sa/a) + dc
	console.log("testing blending 3");
	let am=255<<blend_a,nm=(~am)>>>0;
	let count=0;
	for (let test=0;test<1000000;test++) {
		let src=Math.floor(Math.random()*0x100000000);
		let dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		dst>>>=0;
		src>>>=0;
		let ref=blendref(dst,src);
		let calc=blendfast4(dst,src);
		let dif0=Math.abs(((ref>>>0)&255)-((calc>>>0)&255));
		let dif1=Math.abs(((ref>>>8)&255)-((calc>>>8)&255));
		let dif2=Math.abs(((ref>>>16)&255)-((calc>>>16)&255));
		let dif3=Math.abs(((ref>>>24)&255)-((calc>>>24)&255));
		count+=dif0+dif1+dif2+dif3;
		if (dif0>1 || dif1>1 || dif2>1 || dif3>1) {
			console.log("error");
			console.log(src,dst);
			console.log(ref.toString(16),calc.toString(16));
			return;
		}
	}
	console.log("sum: "+count);
	console.log("passed");
	let sum=0,dst=0,src=0;
	let t0=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendref(dst,src);
	}
	t0=performance.now()-t0;
	let t1=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast3(dst,src);
	}
	t1=performance.now()-t1;
	let t2=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast4(dst,src);
	}
	t2=performance.now()-t2;
	console.log(sum);
	console.log(t0);
	console.log(t1);
	console.log(t2);
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 3 - Bezier parameterization


function BezierParam0(points,u) {
	let v=1-u;
	let cpx=v*v*v*points[0]+3*v*v*u*points[2]+3*v*u*u*points[4]+u*u*u*points[6];
	let cpy=v*v*v*points[1]+3*v*v*u*points[3]+3*v*u*u*points[5]+u*u*u*points[7];
	return [cpx,cpy];
}


function BezierParam1(points,u1) {
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));
	return [cpx,cpy];
}


function BezierClosest(curve,point) {
	// Returns the closest u in [0,1] to the point.
	let p0x=curve[0],p0y=curve[1];
	let p1x=curve[2],p1y=curve[3];
	let p2x=curve[4],p2y=curve[5];
	let p3x=curve[6],p3y=curve[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	p0x-=point[0];p0y-=point[1];
	let segs=2048;
	let range=0.5;
	let minu=0.5,mindist=Infinity;
	while (range>1e-10) {
		let mid=minu,sden=2/(segs-1);
		for (let s=0;s<segs;s++) {
			let u=mid+range*(s*sden-1);
			u=u>0?(u<1?u:1):0;
			let dx=p0x+u*(p1x+u*(p2x+u*p3x));
			let dy=p0y+u*(p1y+u*(p2y+u*p3y));
			let dist=dx*dx+dy*dy;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
		}
		segs>>>=1;
		segs=segs>4?segs:4;
		range*=0.5;
	}
	return minu;
}


function BezierParamTest() {
	console.log("testing bezier parameterization");
	let tests=10000;
	let rnd=new Random();
	let curve=new Float64Array(8);
	let pointerr=0;
	let paramerr=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=rnd.gets()*5;
		}
		let u=rnd.getf();
		let [x0,y0]=BezierParam0(curve,u);
		let [x1,y1]=BezierParam1(curve,u);
		let dx=x1-x0,dy=y1-y0;
		let err=dx*dx+dy*dy;
		if (pointerr<err || !(err===err)) {
			pointerr=err;
		}
		let v=BezierClosest(curve,[x0,y0]);
		let [x2,y2]=BezierParam1(curve,v);
		dx=x2-x0;dy=y2-y0;
		err=dx*dx+dy*dy;
		if (paramerr<err || !(err===err)) {
			paramerr=err;
		}
	}
	console.log("point err: "+pointerr.toFixed(9));
	console.log("param err: "+paramerr.toFixed(9));
}


//---------------------------------------------------------------------------------
// Bezier Length


function BezierLength0(points) {
	// "Accurate" length calculation.
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let segs=1000;
	let lx=p0x,ly=p0y,dist=0;
	for (let s=1;s<=segs;s++) {
		let u=s/segs;
		let mx=p0x+u*(p1x+u*(p2x+u*p3x));
		let my=p0y+u*(p1y+u*(p2y+u*p3y));
		let dx=mx-lx,dy=my-ly;
		dist+=Math.sqrt(dx*dx+dy*dy);
		lx=mx;
		ly=my;
	}
	return dist;
}


function BezierLength1(points) {
	// approximate length calculation.
	let p0x=points[0],p0y=points[1];
	let c1x=points[2],c1y=points[3];
	let c2x=points[4],c2y=points[5];
	let c3x=points[6],c3y=points[7];
	let dx=0,dy=0,dist=0;
	dx=c1x-p0x;dy=c1y-p0y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	return dist*0.5;
}


function BezierLengthTest() {
	console.log("testing bezier length approximation");
	let rnd=new Random(10);
	let curve=new Array(8);
	let tests=100;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=(rnd.getf()*2-1)*100;
		}
		let dist0=BezierLength0(curve);
		let dist1=BezierLength1(curve);
		let dif=Math.abs(dist0-dist1)/dist1;
		sumdif+=dif;
		console.log(dist0,dist1,dif);
	}
	console.log("dif: "+sumdif.toFixed(6));
}


//---------------------------------------------------------------------------------
// Bezier Segmentation Tests
// Need at least 3 interpolation points to catch all cubic bezier cases.


function BezierSegment1(curve,splitlen=3) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	// Estimate bezier length.
	let dist=0,dx=0,dy=0;
	dx=c1x-p0x;dy=c1y-p0y;dist =Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	let segs=Math.ceil(dist*0.5/splitlen+1e-10);
	// Segment the curve.
	let lr=[];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let ppx=p0x,ppy=p0y,unorm=1.0/segs,u=0;
	for (let s=0;s<segs;s++) {
		let lu=u,lx=ppx,ly=ppy;
		u+=unorm;
		ppx=p0x+u*(c1x+u*(c2x+u*c3x));
		ppy=p0y+u*(c1y+u*(c2y+u*c3y));
		lr.push({x0:lx,y0:ly,x1:ppx,y1:ppy,u0:lu,u1:u});
	}
	let l=lr[lr.length-1];
	l.u1=1;
	l.x1=curve[6];
	l.y1=curve[7];
	return lr;
}


function BezierSegment2(curve,cutoff,type,segments) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let den=(dx*dx+dy*dy)*cutoff;
		if (den<1e-9) {den=cutoff;dx=1;dy=0;}
		let u0=l.u0,u1=l.u1;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<segments;s++) {
			let u=u0+(u1-u0)*((s+1)/(segments+1));
			let ix=p0x+u*(c1x+u*(c2x+u*c3x));
			let iy=p0y+u*(c1y+u*(c2y+u*c3y));
			let num=dy*(ix-x0)-dx*(iy-y0);
			let dist=num*num;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u;
			}
		}
		console.log("maxdist:",maxdist);
		if (maxdist>den) {
			// we're outside the bounds
			let u=[(u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment3(curve,cutoff,type,samples) {
	// cutoff  = cutoff distance squared
	// samples = how many points on segment to sample
	// type 0  = split at 0.5
	//      1  = split at minimum distance
	//      2  = split at maximum distance
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.u0,u1=l.u1,du=(u1-u0)/(samples+1);
		let den=dx*dx+dy*dy;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<samples;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (mindist>dist) {
				mindist=dist;
				minu=u0;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u0;
			}
		}
		if (maxdist>cutoff && maxdist<Infinity) {
			// The line is too far from the curve, split it.
			let u=[(l.u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment4(curve,curvemaxdist2=0.01) {
	// Sample-and-divide test.
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	l.amul=0;l.area=1;
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;let c3x=p1x-p0x-c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;let c3y=p1y-p0y-c2y;c2y-=c1y;
	for (let j=lcnt-1;j<lcnt;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.amul,u1=l.area,du=(u1-u0)*0.25;
		let den=dx*dx+dy*dy;
		let maxdist=-Infinity,mu=0,mx=0,my=0;
		for (let s=0;s<3;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (maxdist<dist) {
				maxdist=dist;
				mu=u0;
				mx=sx;
				my=sy;
			}
		}
		if (maxdist>curvemaxdist2 && maxdist<Infinity) {
			// The line is too far from the curve, so split it.
			lr.push({});
			l.x1=mx;
			l.y1=my;
			l.area=mu;
			l=lr[lcnt++];
			l.x0=mx;
			l.y0=my;
			l.x1=x1;
			l.y1=y1;
			l.amul=mu;
			l.area=u1;
			j--;
		}
	}
	for (l of lr) {l.u0=l.amul;l.u1=l.area;}
	return lr;
}


function BezierSegment5(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let [k0x,k0y,k1x,k1y,k2x,k2y,k3x,k3y]=curve;
	let lr=[{
		x0:k0x,y0:k0y,
		x1:k3x,y1:k3y,
		x2:k1x,y2:k1y,
		x3:k2x,y3:k2y,
		u0:0,u1:1
	}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	for (let j=lcnt-1;j<lcnt;j++) {
		// The curve will stay inside the bounding box of [c0,c1,c2,c3].
		// If the subcurve is outside the image, stop subdividing.
		l=lr[j];
		let c3x=l.x1,c2x=l.x3,c1x=l.x2,c0x=l.x0;
		let c3y=l.y1,c2y=l.y3,c1y=l.y2,c0y=l.y0;
		/*if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
		    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
			continue;
		}*/
		let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
		// Test if both control points are close to the line c0->c3.
		// Clamp to ends and filter degenerates.
		let lx=c1x-c0x,ly=c1y-c0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=c2x-c0x;ly=c2y-c0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		lr.push({}); // remove
		let u0=l.u0,u1=l.u1,uh=(u0+u1)*0.5; // remove
		let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
		let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
		let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
		let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
		l.x1=phx;l.x3=l2x;l.x2=l1x;
		l.y1=phy;l.y3=l2y;l.y2=l1y;
		l.u1=uh; // remove
		l=lr[lcnt++];
		l.x1=c3x;l.x3=r2x;l.x2=r1x;l.x0=phx;
		l.y1=c3y;l.y3=r2y;l.y2=r1y;l.y0=phy;
		l.u1=u1;l.u0=uh; // remove
		j--;
	}
	return lr;
}


function BezierSegmentTest() {
	// test
	//      u0,u1 is consecutive and covers [0,1]
	//      endpoints match curve(u)
	//      intermediate points based on distance, at least 10
	let rnd=new Random(9876);
	let curve=new Float64Array(8);
	let trials=10000;
	let sumdist=0,sumsegs=0,maxdist=0,sumden=0;
	function getrnd() {
		let degen=rnd.mod(64);
		if (degen<4) {return [0,NaN,Infinity,-Infinity][degen];}
		return rnd.gets()*Math.pow(2,rnd.gets()*20);
	}
	for (let trial=0;trial<trials;trial++) {
		// Generate the curve. Try to generate subpixel curves.
		let degen=false;
		for (let i=0;i<4;i++) {
			let x=getrnd();
			let y=getrnd();
			curve[i*2+0]=x;
			curve[i*2+1]=y;
			if (!(x>-Infinity && x<Infinity && y>-Infinity && y<Infinity)) {
				degen=true;
			}
		}
		//if (trial!==65) {continue;}
		//let lr=BezierSegment1(curve);
		//let lr=BezierSegment3(curve,0.25,2,3);
		//let lr=BezierSegment3(curve,0.01,2,3);
		//let lr=BezierSegment3(curve,0.01,0,3);
		//let lr=BezierSegment3(curve,0.01,2,2);
		//let lr=BezierSegment3(curve,0.01,0,2);
		//let lr=BezierSegment4(curve);
		let lr=BezierSegment5(curve);
		if (degen) {
			if (lr.length!==1) {
				console.log("degen curve not single line");
				console.log("trial:",trial);
				console.log("segs :",lr.length);
				console.log("curve:",curve.toString());
				throw "error";
			}
			continue;
		}
		sumden++;
		lr.sort((l,r)=>{return l.u0-r.u0;});
		let u1=0,x1=curve[0],y1=curve[1];
		let subdist=0;
		for (let l of lr) {
			// Test if end of previous line = start of current.
			let u0=l.u0,x0=l.x0,y0=l.y0;
			if (u0!==u1 || x0!==x1 || y0!==y1) {
				console.log("lines not continuous");
				console.log(u1,x1,y1);
				console.log(u0,x0,y0);
				return;
			}
			// Test if line start is on the curve.
			let u=u0,v=1-u,uu=u*u,vv=v*v,vu=3*v*u;
			let tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6];
			let ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7];
			if (Math.abs(tx-x0)>1e-9 || Math.abs(ty-y0)>1e-9) {
				console.log("line off of curve");
				console.log(tx,ty);
				console.log(x0,y0);
				return;
			}
			// Get maximum distance from segment to curve.
			u1=l.u1;
			x1=l.x1;
			y1=l.y1;
			let dx=x1-x0,dy=y1-y0;
			let den=dx*dx+dy*dy;
			let depth=8,samples=8;
			let du=(u1-u0)*0.5,mu=(u1+u0)*0.5,md=0;
			for (let d=0;d<depth;d++) {
				let nu=mu;
				for (let s=0;s<samples;s++) {
					u=nu+du*(2*(s/(samples-1))-1);
					u=u>u0?u:u0;
					u=u<u1?u:u1;
					v=1-u;uu=u*u;vv=v*v;vu=3*v*u;
					tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6]-x0;
					ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7]-y0;
					let dist=0;
					if (den<1e-9) {
						dist=tx*tx+ty*ty;
					} else {
						dist=dy*tx-dx*ty;
						dist=(dist*dist)/den;
					}
					if (md<dist) {
						md=dist;
						mu=u;
					}
				}
				du*=0.5;
			}
			subdist=subdist>md?subdist:md;
		}
		if (u1!==1 || Math.abs(x1-curve[6])>1e-9 || Math.abs(y1-curve[7])>1e-9) {
			console.log("line end");
			console.log(u1,x1,y1);
			console.log(1,curve[6],curve[7]);
			return;
		}
		// console.log(maxdist,lr.length);
		subdist=Math.sqrt(subdist);
		maxdist=maxdist>subdist?maxdist:subdist;
		sumdist+=subdist;
		sumsegs+=lr.length;
		if (subdist>10) {
			console.log(curve,trial);
			throw "subdist: "+subdist;
		}
	}
	sumdist/=sumden;
	sumsegs/=sumden;
	let score=(sumdist+maxdist)*sumsegs;
	console.log("sumdist: "+sumdist.toFixed(6));
	console.log("maxdist: "+maxdist.toFixed(6));
	console.log("sumsegs: "+sumsegs.toFixed(6));
	console.log("score  : "+score.toFixed(6));
	console.log("done");
}


function BezierSegmentDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	// console.log(ctx);
	let curve=[100,100,600,130,100,770,600,800];
	ctx.strokeStyle="rgba(255,255,255,1.0)";
	ctx.beginPath();
	ctx.moveTo(curve[0],curve[1]);
	ctx.bezierCurveTo(curve[2],curve[3],curve[4],curve[5],curve[6],curve[7]);
	ctx.stroke();
	ctx.fillStyle="rgba(255,0,0,1.0)";
	// let points=BezierSegment1(curve,48);
	let lr=BezierSegment3(curve,0.1,2,3);
	lr.sort((l,r)=>{return l.u0-r.u0;});
	let points=[[lr[0].x0,lr[0].y0]];
	for (let l of lr) {points.push([l.x1,l.y1]);}
	console.log(points.length);
	for (let p of points) {
		ctx.beginPath();
		ctx.arc(p[0],p[1],3,0,Math.PI*2);
		ctx.fill();
	}
	ctx.strokeStyle="rgba(255,0,0,1.0)";
	ctx.beginPath();
	for (let p of points) {
		ctx.lineTo(p[0],p[1]);
	}
	ctx.stroke();
}


function CircleApprox(segs,pos=[0,0],rad=1) {
	// [p0,d0,d1,p1]
	// c0=p0+d0*len
	// c1=p1+d1*len
	// [p0,c0,c1,p1]
	const accuracy=9;
	function trimdec(x) {
		if (Math.abs(x)<1e-10) {x=0;}
		let s=x.toFixed(accuracy);
		while (s[s.length-1]==="0") {s=s.substring(0,s.length-1);}
		if (s[s.length-1]===".") {s=s.substring(0,s.length-1);}
		return s;
	}
	function getpoints(s,proj) {
		let u0=Math.PI*2*(s/segs),u1=Math.PI*2*((s+1)/segs);
		let x0=Math.cos(u0),y0=Math.sin(u0);
		let dx0=-y0,dy0=x0;
		let x1=Math.cos(u1),y1=Math.sin(u1);
		let dx1=y1,dy1=-x1;
		let c1x=x0+dx0*proj,c1y=y0+dy0*proj;
		let c2x=x1+dx1*proj,c2y=y1+dy1*proj;
		return [x0,y0,c1x,c1y,c2x,c2y,x1,y1];
	}
	let projrange=1;
	let mindist=Infinity;
	let minproj=1;
	const tests=8192;
	for (let trial=0;trial<32;trial++) {
		let projmid=minproj;
		for (let p=0;p<101;p++) {
			let proj=projmid+((2*p/100)-1)*projrange;
			if (proj<0) {continue;}
			let [c0x,c0y,c1x,c1y,c2x,c2y,c3x,c3y]=getpoints(0,proj);
			c2x=(c2x-c1x)*3;c1x=(c1x-c0x)*3;c3x=c3x-c0x-c2x;c2x-=c1x;
			c2y=(c2y-c1y)*3;c1y=(c1y-c0y)*3;c3y=c3y-c0y-c2y;c2y-=c1y;
			let maxdist=0;
			for (let t=0;t<tests;t++) {
				let u=t/(tests-1);
				let sx=c0x+u*(c1x+u*(c2x+u*c3x));
				let sy=c0y+u*(c1y+u*(c2y+u*c3y));
				let dist=Math.sqrt(sx*sx+sy*sy)-1;
				dist=dist>0?dist:-dist;
				if (maxdist<dist) {
					maxdist=dist;
					if (mindist<maxdist) {
						break;
					}
				}
			}
			if (mindist>maxdist) {
				console.log(maxdist,proj);
				mindist=maxdist;
				minproj=proj;
			}
		}
		projrange*=0.5;
	}
	let str="M ";
	for (let s=0;s<segs;s++) {
		let pt=getpoints(s,minproj);
		for (let i=0;i<pt.length;i++) {pt[i]=trimdec(pt[i]*rad+pos[i&1]);}
		let [c0x,c0y,c1x,c1y,c2x,c2y,c3x,c3y]=pt;
		if (!s) {str+=c0x+" "+c0y;}
		str+=` C ${c1x} ${c1y} ${c2x} ${c2y} ${c3x} ${c3y}`;
	}
	console.log(str);
}


//---------------------------------------------------------------------------------
// Area


function PathArea1(path) {
	let draw=new Draw(0,0);
	const curvemaxdist2=0.0001;
	let varr=path.vertarr;
	let vidx=path.vertidx;
	if (vidx<2) {return 0;}
	let movex=0,movey=0,p0x=NaN,p0y=NaN,p1x=0,p1y=0;
	let lr=draw.tmpline,lrcnt=lr.length,lcnt=0;
	for (let i=0;i<vidx;i++) {
		let v=varr[i];
		if (v.type===Draw.Path.CURVE) {v=varr[i+2];}
		p0x=p1x;p1x=v.x;
		p0y=p1y;p1y=v.y;
		// Add a basic line.
		if (lrcnt<=lcnt) {
			lr=draw.fillresize(lcnt+1);
			lrcnt=lr.length;
		}
		let l=lr[lcnt++];
		l.x0=p0x;
		l.y0=p0y;
		l.x1=p1x;
		l.y1=p1y;
		if (v.type===Draw.Path.MOVE) {
			// Close any unclosed subpaths.
			if (!i || (movex===p0x && movey===p0y)) {lcnt--;}
			l.x1=movex;movex=p1x;
			l.y1=movey;movey=p1y;
		}
		if (v.type!==Draw.Path.CURVE) {continue;}
		// Linear decomposition of curves.
		v=varr[i++];l.amul   =v.x;l.area   =v.y;
		v=varr[i++];l.areadx1=v.x;l.areadx2=v.y;
		for (let j=lcnt-1;j<lcnt;j++) {
			// The curve will stay inside the bounding box of [c0,c1,c2,c3].
			// If the subcurve is outside the image, stop subdividing.
			l=lr[j];
			let c3x=l.x1,c2x=l.areadx1,c1x=l.amul,c0x=l.x0;
			let c3y=l.y1,c2y=l.areadx2,c1y=l.area,c0y=l.y0;
			let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
			// Test if both control points are close to the line c0->c3. Clamp to ends.
			let lx=c1x-c0x,ly=c1y-c0y;
			let u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			if (!(lx*lx+ly*ly>curvemaxdist2)) {
				lx=c2x-c0x;ly=c2y-c0y;
				u=dx*lx+dy*ly;
				u=u>0?(u<den?u/den:1):0;
				lx-=dx*u;ly-=dy*u;
				if (!(lx*lx+ly*ly>curvemaxdist2)) {continue;}
			}
			// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
			if (lrcnt<=lcnt) {
				lr=draw.fillresize(lcnt+1);
				lrcnt=lr.length;
			}
			let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
			let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
			let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
			let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
			let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
			let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
			l.x1=phx;l.areadx1=l2x;l.amul=l1x;
			l.y1=phy;l.areadx2=l2y;l.area=l1y;
			l=lr[lcnt++];
			l.x1=c3x;l.areadx1=r2x;l.amul=r1x;l.x0=phx;
			l.y1=c3y;l.areadx2=r2y;l.area=r1y;l.y0=phy;
			j--;
		}
	}
	// Close the path.
	if (movex!==p1x || movey!==p1y) {
		if (lrcnt<=lcnt) {
			lr=draw.fillresize(lcnt+1);
			lrcnt=lr.length;
		}
		let l=lr[lcnt++];
		l.x0=p1x;
		l.y0=p1y;
		l.x1=movex;
		l.y1=movey;
	}
	// Calculate the area.
	let area=0;
	for (let i=0;i<lcnt;i++) {
		let l=lr[i];
		area+=l.x0*l.y1-l.x1*l.y0;
	}
	return area*0.5;
}


function PathArea(path) {
	// Use closed form area for curve.
	let varr=path.vertarr;
	let vidx=path.vertidx;
	if (vidx<2) {return 0;}
	let movex=0,movey=0,p0x=NaN,p0y=NaN,p1x=0,p1y=0;
	let area=0;
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		if (v.type===Draw.Path.CURVE) {v=varr[i+2];}
		p0x=p1x;p1x=v.x;
		p0y=p1y;p1y=v.y;
		// Add a basic line.
		let l={};
		l.x0=p0x;
		l.y0=p0y;
		l.x1=p1x;
		l.y1=p1y;
		if (v.type===Draw.Path.MOVE) {
			// Close any unclosed subpaths.
			l.x1=movex;movex=p1x;
			l.y1=movey;movey=p1y;
		}
		area+=p0x*l.y1-l.x1*p0y;
		if (v.type!==Draw.Path.CURVE) {continue;}
		// Linear decomposition of curves.
		v=varr[i++];let n1x=v.x,n1y=v.y;
		v=varr[i++];let n2x=v.x,n2y=v.y;
		area-=((n1x-p0x)*(2*p0y-n2y-p1y)+(n2x-p0x)*(p0y+n1y-2*p1y)
		      +(p1x-p0x)*(2*n2y+n1y-3*p0y))*0.3;
	}
	return area*0.5;
}


function PathAreaTest() {
	console.log("testing path area calculation");
	let rnd=new Random(10);
	let sumerr=0;
	let tests=1000;
	for (let test=0;test<tests;test++) {
		let path=new Draw.Path();
		let segs=rnd.mod(32);
		for (let s=0;s<segs;s++) {
			let type=rnd.mod(4);
			let x0=rnd.gets()*100,y0=rnd.gets()*100;
			if (type===0) {path.moveto(x0,y0);}
			else if (type===1) {path.lineto(x0,y0);}
			else if (type===2) {path.close();}
			else {
				let x1=rnd.gets()*100,y1=rnd.gets()*100;
				let x2=rnd.gets()*100,y2=rnd.gets()*100;
				path.curveto(x1,y1,x2,y2,x0,y0);
			}
		}
		if (path.vertidx>0 && path.vertarr[0].type!==Draw.Path.MOVE) {
			console.log("first type isn't move");
			throw "error";
		}
		let area1=PathArea1(path);
		let area2=PathArea(path);
		let err=Math.abs(area1-area2)/Math.max(Math.abs(area1),Math.abs(area2),1e-10);
		console.log(path.vertidx,area1,area2);
		sumerr+=err;
	}
	sumerr/=tests;
	console.log("rel err: "+sumerr.toFixed(6));
}


//---------------------------------------------------------------------------------
// Tracing


function TraceDemo() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let draw=new Draw(1000,1000);
	let polystr=`M 0 0 L 22 -8 L 36 -7 C 59 -14 69 -2 57 7 C 105 34 64 -18 68 29
	             L 54 29 L 38 29 L 48 25 Z M 22 46 L 52 46`;
	let poly=new Draw.Path(polystr);
	draw.fill(0,0,0,255);
	draw.setcolor(255,255,255,255);
	draw.fillpoly(poly,(new Draw.Transform()).setoffset(400,500).setscale(5));
	ctx.putImageData(draw.img.imgdata,0,0);
}


//---------------------------------------------------------------------------------
// Heap sorting


function HeapSortTest() {
	console.log("Testing heap");
	let rnd=new Random();
	for (let test=0;test<200;test++) {
		let alloc=rnd.mod(2000);
		// Build heap.
		let maxval=100000;
		let idused=new Uint32Array(alloc);
		let lr=new Array(alloc),lcnt=0;
		let swaps=0;
		for (let i=0;i<alloc;i++) {
			let l={};
			l.id=i;
			lr[i]=l;
			l.sort=-Infinity;
			if (rnd.mod(4)===0) {continue;}
			l.sort=rnd.mod(maxval*2);
			/*let j=lcnt++;
			lr[i]=lr[j];
			let p,lp;
			while (j>0 && l.sort<(lp=lr[p=(j-1)>>1]).sort) {
				swaps++;
				lr[j]=lp;
				j=p;
			}
			lr[j]=l;*/
			lr[i]=lr[lcnt];
			lr[lcnt++]=l;
		}
		for (let i=(lcnt>>1)-1;i>=0;i--) {
			let l=lr[i],s=l.sort,p=i,j=0;
			while ((j=p+p+1)<lcnt) {
				swaps++;
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=s) {break;}
				lr[p]=lr[j];
				p=j;
			}
			lr[p]=l;
		}
		console.log("swap:",swaps,lcnt);
		while (true) {
			// Test heap properties.
			idused.fill(1);
			let cnt=0;
			for (let i=0;i<alloc;i++) {
				let l=lr[i],id=l.id;
				cnt+=idused[id];
				idused[id]=0;
				if (i>0 && i<lcnt) {
					let p=(i-1)>>1,lp=lr[p];
					if (lp.sort>l.sort) {
						throw "not sorted: "+lp.sort+", "+l.sort;
					}
				}
			}
			if (cnt!==alloc) {
				throw "object missing: "+cnt+" / "+alloc;
			}
			if (lcnt===0 || lr[0].sort>=maxval) {break;}
			// Modify top value.
			let l=lr[0];
			let type=rnd.mod(4);
			let mod=[1,2,100,maxval-l.sort+10][type];
			l.sort+=rnd.mod(mod);
			// Heap sort down.
			let i=0,j=0;
			while ((j=i+i+1)<lcnt) {
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=l.sort) {break;}
				lr[i]=lr[j];
				i=j;
			}
			lr[i]=l;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Bounding Boxes


function AABBCheck0(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if any lines intersect.
	let imglines=[
		[0,0,imgwidth,0],
		[imgwidth,0,imgwidth,imgheight],
		[imgwidth,imgheight,0,imgheight],
		[0,imgheight,0,0]
	];
	let polylines=[
		[bndx,bndy,bndx+bnddx0,bndy+bnddy0],
		[bndx+bnddx0,bndy+bnddy0,bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1],
		[bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1,bndx+bnddx1,bndy+bnddy1],
		[bndx+bnddx1,bndy+bnddy1,bndx,bndy]
	];
	for (let il=0;il<4;il++) {
		let [i0x,i0y,i1x,i1y]=imglines[il];
		i1x-=i0x;
		i1y-=i0y;
		for (let pl=0;pl<4;pl++) {
			let [p0x,p0y,p1x,p1y]=polylines[pl];
			p1x-=p0x;
			p1y-=p0y;
			let den=i1x*p1y-i1y*p1x;
			p0x-=i0x;
			p0y-=i0y;
			let u=p0x*i1y-p0y*i1x;
			if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
				u=p0x*p1y-p0y*p1x;
				if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
					return true;
				}
			}
		}
	}
	// Either they are not overlapping, or one is entirely inside the other.
	let midx=bndx+(bnddx0+bnddx1)*0.5;
	let midy=bndy+(bnddy0+bnddy1)*0.5;
	if (midx>=0 && midx<=imgwidth && midy>=0 && midy<=imgheight) {
		return true;
	}
	midx=imgwidth*0.5;
	midy=imgheight*0.5;
	let parity=0;
	for (let pl=0;pl<4;pl++) {
		let [p0x,p0y,p1x,p1y]=polylines[pl];
		p0x-=midx;
		p0y-=midy;
		p1x-=midx;
		p1y-=midy;
		let sign=p0x*p1y-p0y*p1x;
		if (sign<-1e-10) {parity--;}
		if (sign> 1e-10) {parity++;}
	}
	return parity===-4 || parity===4;
}


function AABBCheck1(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx+(bnddx0<0?bnddx0:0)+(bnddx1<0?bnddx1:0);
	let miny=bndy+(bnddy0<0?bnddy0:0)+(bnddy1<0?bnddy1:0);
	let maxx=bndx+(bnddx0>0?bnddx0:0)+(bnddx1>0?bnddx1:0);
	let maxy=bndy+(bnddy0>0?bnddy0:0)+(bnddy1>0?bnddy1:0);
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck2(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck3(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	if (bnddx0<0) {maxx-=ih*bnddx0;} else {minx-=ih*bnddx0;}
	if (bnddy0<0) {minx+=iw*bnddy0;} else {maxx+=iw*bnddy0;}
	if (bnddx1<0) {maxy-=ih*bnddx1;} else {miny-=ih*bnddx1;}
	if (bnddy1<0) {miny+=iw*bnddy1;} else {maxy+=iw*bnddy1;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck4(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1,tmp=0;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	tmp=ih*bnddx0; if (tmp<0) {maxx-=tmp;} else {minx-=tmp;}
	tmp=iw*bnddy0; if (tmp<0) {minx+=tmp;} else {maxx+=tmp;}
	tmp=ih*bnddx1; if (tmp<0) {maxy-=tmp;} else {miny-=tmp;}
	tmp=iw*bnddy1; if (tmp<0) {miny+=tmp;} else {maxy+=tmp;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck5(iw,ih,poly,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bx=poly.minx,by=poly.miny;
	let bndx=bx*matxx+by*matxy+matx;
	let bndy=bx*matyx+by*matyy+maty;
	bx=poly.maxx-bx;by=poly.maxy-by;
	let bndxx=bx*matxx,bndxy=bx*matyx;
	let bndyx=by*matxy,bndyy=by*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-iw,maxx=bndx;
	if (bndxx<0) {minx+=bndxx;} else {maxx+=bndxx;}
	if (bndyx<0) {minx+=bndyx;} else {maxx+=bndyx;}
	if (!(minx<0 && 0<maxx)) {return;}
	let miny=bndy-ih,maxy=bndy;
	if (bndxy<0) {miny+=bndxy;} else {maxy+=bndxy;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	// Test if the poly OBB has a separating axis.
	let cross=bndxx*bndyy-bndxy*bndyx;
	minx=bndy*bndxx-bndx*bndxy;maxx=minx;
	bndxx*=ih;bndxy*=iw;
	if (cross<0) {minx+=cross;} else {maxx+=cross;}
	if (bndxx<0) {maxx-=bndxx;} else {minx-=bndxx;}
	if (bndxy<0) {minx+=bndxy;} else {maxx+=bndxy;}
	if (!(minx<0 && 0<maxx)) {return;}
	miny=bndy*bndyx-bndx*bndyy;maxy=miny;
	bndyx*=ih;bndyy*=iw;
	if (cross<0) {maxy-=cross;} else {miny-=cross;}
	if (bndyx<0) {maxy-=bndyx;} else {miny-=bndyx;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	return true;
}


function BoundingBoxTest() {
	console.log("testing bounding boxes");
	let rnd=new Random(10);
	function getrnd() {
		return rnd.gets()*Math.pow(2,rnd.gets()*20);
	}
	let tests=1000000;
	let trans=[1,0,0,0,1,0];
	let difcnt=[0,0,0,0,0,0];
	let overlap=0;
	for (let test=0;test<tests;test++) {
		let imgwidth=getrnd(true);
		let imgheight=getrnd(true);
		for (let i=0;i<6;i++) {trans[i]=getrnd();}
		let x0=getrnd(),x1=getrnd();
		let y0=getrnd(),y1=getrnd();
		let aabb={
			minx:x0<x1?x0:x1,
			maxx:x0<x1?x1:x0,
			miny:y0<y1?y0:y1,
			maxy:y0<y1?y1:y0
		};
		aabb.dx=aabb.maxx-aabb.minx;
		aabb.dy=aabb.maxy-aabb.miny;
		aabb[0]=aabb.minx;
		aabb[1]=aabb.miny;
		aabb[2]=aabb.dx;
		aabb[3]=aabb.dy;
		let ref=AABBCheck5(imgwidth,imgheight,aabb,trans)===true;
		difcnt[0]+=AABBCheck0(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[1]+=AABBCheck1(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[2]+=AABBCheck2(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[3]+=AABBCheck3(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[4]+=AABBCheck4(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[5]+=(AABBCheck5(imgwidth,imgheight,aabb,trans)===true)===ref;
		overlap+=ref;
		// NaN tests.
		let coord=rnd.mod(4);
		if (coord===0) {aabb.minx=NaN;}
		if (coord===1) {aabb.miny=NaN;}
		if (coord===2) {aabb.maxx=NaN;}
		if (coord===3) {aabb.maxy=NaN;}
		if (AABBCheck5(imgwidth,imgheight,aabb,trans)) {
			console.log("NaN passed");
			throw "error";
		}
	}
	for (let i=0;i<difcnt.length;i++) {
		console.log(`dif ${i}  : ${difcnt[i]}`);
	}
	console.log("overlap: "+overlap);
	console.log("done");
}


function BoundingBoxSpeedTest() {
	console.log("testing bounding box speed");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&15)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf()*16-8);
		return ((type&16) || pos)?ret:-ret;
	}
	let randmask=(1<<20)-1;
	let rands=randmask+100;
	let randarr=new Float64Array(rands);
	let randabs=new Float64Array(rands);
	for (let i=0;i<rands;i++) {
		randarr[i]=getrnd();
		randabs[i]=Math.abs(randarr[i]);
	}
	let tests=10000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let overlap=0;
	let t0=performance.now();
	let r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck0(imgwidth,imgheight,aabb,trans);
	}
	let t1=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck1(imgwidth,imgheight,aabb,trans);
	}
	let t2=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck2(imgwidth,imgheight,aabb,trans);
	}
	let t3=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck3(imgwidth,imgheight,aabb,trans);
	}
	let t4=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck4(imgwidth,imgheight,aabb,trans);
	}
	let t5=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck5(imgwidth,imgheight,aabb,trans);
	}
	let t6=performance.now();
	console.log("overlaps: ",overlap);
	console.log("t0: "+(t1-t0).toFixed(6));
	console.log("t1: "+(t2-t1).toFixed(6));
	console.log("t2: "+(t3-t2).toFixed(6));
	console.log("t3: "+(t4-t3).toFixed(6));
	console.log("t4: "+(t5-t4).toFixed(6));
	console.log("t5: "+(t6-t5).toFixed(6));
	console.log("done");
}


function BoundingBoxDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	let subimg=new Draw.Image(250,200);
	let trans=new Transform(2);
	let rnd=new Random();
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpoly.toString();
	Draw.colbnd=[0,0,0,0,0,0];
	Draw.colret=-1;
	func=func.replace("=by*matyy;",`=by*matyy; Draw.colret=0;
	                   Draw.colbnd=[bndx,bndy,bndxx,bndxy,bndyx,bndyy];`);
	for (let i=1;i<10;i++) {func=func.replace("return;","Draw.colret="+i+";return ;");}
	window.DrawPoly=Draw.Path;
	window.Draw=Draw;
	window.Transform=Transform;
	Draw.prototype.fillpoly=parsefunction(func);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let mpos=input.getmousepos();
		let mx=mpos[0];
		let my=mpos[1];
		if (mx===-Infinity) {mx=0;}
		if (my===-Infinity) {my=0;}
		draw.pushstate();
		draw.setcolor(255,0,0,255);
		trans.vec.set([mx,my]);
		draw.settransform(trans);
		draw.filloval(0,0,100,50);
		let imgx=(draw.img.width-subimg.width)*0.5;
		let imgy=(draw.img.height-subimg.height)*0.5;
		draw.pushstate();
		draw.setimage(subimg);
		draw.fill(128,128,128,255);
		draw.setcolor(200,0,0,255);
		trans.vec.set([mx-imgx,my-imgy]);
		draw.settransform(trans);
		draw.filloval(0,0,100,50);
		let ret=Draw.colret;
		let aabb=Draw.colbnd.slice();
		draw.popstate();
		draw.drawimage(subimg,imgx,imgy);
		draw.popstate();
		draw.setcolor(255,255,255,255);
		let x0=aabb[0]+imgx,y0=aabb[1]+imgy;
		let x1=x0+aabb[2],y1=y0+aabb[3];
		let x2=x1+aabb[4],y2=y1+aabb[5];
		let x3=x0+aabb[4],y3=y0+aabb[5];
		draw.drawline(x0,y0,x1,y1);
		draw.drawline(x1,y1,x2,y2);
		draw.drawline(x2,y2,x3,y3);
		draw.drawline(x3,y3,x0,y0);
		draw.filltext(10,10,"col: "+ret);
		draw.screenflip();
		if (input.getkeychange(input.MOUSE.LEFT)>0) {
			trans.set({
				ang:rnd.getf()*Math.PI*2,
				scale:[rnd.gets()*4,rnd.gets()*4],
				vec:[rnd.gets()*100,rnd.gets()*100]
			});
		}
	}
	update();
}


//---------------------------------------------------------------------------------
// Filling Accuracy


function FillDisplayTest() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=100;
	canv.height=100;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	//let input=new Input(canv);
	let draw=new Draw(100,100);
	draw.screencanvas(canv);
	draw.fill(0,0,0,255);
	draw.setcolor(255,255,255,255);
	let x=50,y=50;
	let ang=-Math.PI*0.5,amul=-Math.PI*2*0.437600;
	let poly=new Draw.Path();
	poly.lineto(Math.cos(ang)*20+x,Math.sin(ang)*20+y);ang+=amul;
	poly.lineto(Math.cos(ang)*20+x,Math.sin(ang)*20+y);
	poly.lineto(Math.cos(ang)*26+x,Math.sin(ang)*26+y);ang-=amul;
	poly.lineto(Math.cos(ang)*26+x,Math.sin(ang)*26+y);
	draw.setcolor(255,255,255,255);
	draw.fillpoly(poly);
	draw.screenflip();
}


function FillAccuracyTest() {
	// Create a simple polygon and test fillpoly against a reference.
	console.log("testing polygon fill");
	const maxdim=64,maxpixels4=maxdim*maxdim*4;
	const tests=1000000;
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	let img=draw.img;
	let data=img.data8;
	let orig=new Uint8Array(data.length);
	let rnd=new Random(1);
	function rndexp(dim) {
		// Try to align near integer boundaries to cause overflows.
		let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	draw.setcolor(0xffffffff);
	// Add metrics
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpoly.toString();
	func=func.replace("if (area>=cutoff) {","this.pixcnt++;\nif (area>=cutoff) {");
	func=func.replace("} while (++p<pstop);","this.pixcnt++;\n} while (++p<pstop);");
	window.DrawPoly=Draw.Path;
	window.Draw=Draw;
	draw.pixcnt=0;
	Draw.prototype.fillpoly=parsefunction(func);
	let overdraw=0;
	let pixerr=[0,0,0];
	for (let test=0;test<tests;test++) {
		if ((test%1000)===0) {
			console.log("test:",test,pixerr.toString());
		}
		// Create the image.
		let imgw=rnd.mod(maxdim+1),imgh=rnd.mod(maxdim+1);
		let pixels=imgw*imgh,pixels4=pixels*4;
		//console.log(imgw,imgh);
		img.width=imgw;
		img.height=imgh;
		for (let i=0;i<pixels4;i++) {data[i]=(i&3)<3?0:255;}
		orig.set(data);
		// Create the polygon.
		let lines=rnd.mod(5)+2;
		let poly=new Draw.Path();
		for (let i=0;i<lines;i++) {
			poly.lineto(rndexp(imgw),rndexp(imgh));
		}
		let varr=poly.vertarr;
		let area=PathArea(poly);
		area=area<0?-255.5:255.5;
		// Fill and compare.
		draw.pixcnt=0;
		draw.fillpoly(poly);
		let cnt=0;
		for (let i=0;i<pixels4;i+=4) {
			let p=i>>>2,x=p%imgw,y=~~(p/imgw);
			let r=data[i+0],g=data[i+1],b=data[i+2],a=data[i+3];
			if (r!==g || r!==b || a!==255) {
				console.log(r,g,b,a);
				throw "pixel not monochrome";
			}
			let fill=0;
			for (let j=0;j<lines;j++) {
				let u=varr[j],v=varr[(j+1)%lines];
				fill+=UnitAreaCalc(u.x-x,u.y-y,v.x-x,v.y-y);
			}
			let col=Math.floor(fill*area);
			col=col>0  ?col:0  ;
			col=col<255?col:255;
			cnt+=col>0;
			let dif=Math.abs(col-r);
			dif=dif<2?dif:2;
			pixerr[dif]++;
		}
		overdraw+=draw.pixcnt-cnt;
		for (let i=pixels4;i<maxpixels4;i++) {
			if (data[i]!==orig[i]) {
				let p=i>>>2,x=p%imgw,y=~~(p/imgw);
				console.log(imgw,imgh,x,y);
				throw "overflow";
			}
		}
	}
	console.log(`pixel errors:\n0 : ${pixerr[0]}\n1 : ${pixerr[1]}\n2+: ${pixerr[2]}`);
	console.log("overdraw:",overdraw);
}


function FillCrashTest() {
	// Try and crash fillpoly() with absurd values.
	console.log("testing polygon crashing");
	const maxdim=1024;
	const maxsegs=128;
	const tests=10000000;
	let rnd=new Random(1);
	function rndexp() {
		let degen=rnd.mod(512);
		if (degen<3) {return [NaN,Infinity,-Infinity][degen];}
		let mul=rnd.mod(8)?maxdim:Math.pow(2,rnd.gets()*1200);
		return rnd.gets()*mul;
	}
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	let img=draw.img;
	draw.setcolor(0xffffffff);
	let maxlines=0;
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxlines);
		}
		img.width=rnd.mod(maxdim+1);
		img.height=rnd.mod(maxdim+1);
		// Create the polygon.
		let segs=rnd.mod(maxsegs+1);
		let poly=new Draw.Path();
		for (let i=0;i<segs;i++) {
			let type=rnd.mod(8);
			if (type<1) {
				poly.moveto(rndexp(),rndexp());
			} else if (type<2) {
				poly.close();
			} else if (type<4) {
				poly.lineto(rndexp(),rndexp());
			} else if (type<6) {
				poly.curveto(rndexp(),rndexp(),rndexp(),
			                  rndexp(),rndexp(),rndexp());
			}
		}
		if (poly.vertidx>0 && poly.vertarr[0].type!==Draw.Path.MOVE) {
			console.log("first type not moveto");
			throw "error";
		}
		draw.fillpoly(poly);
		let lines=draw.tmpline.length;
		if (maxlines<lines) {
			maxlines=lines;
			console.log("max line:",maxlines);
		}
	}
}


//---------------------------------------------------------------------------------
// Fonts


function FontFit(fontpath,erroraccept={}) {
	// See how closely a font matches reference images.
	let fontdef=Draw.Font.deffont;
	let glyphs={};
	let fontidx=0,fontlen=fontdef.length;
	function token(eol) {
		let c=0;
		while (fontidx<fontlen && (c=fontdef.charCodeAt(fontidx))<=32 && c!==10) {fontidx++;}
		let i=fontidx;
		while (fontidx<fontlen && fontdef.charCodeAt(fontidx)>eol) {fontidx++;}
		return fontdef.substring(i,fontidx);
	}
	token(10); fontidx++; // name
	token(10); fontidx++; // info
	let scale=parseFloat(token(10));
	let special={"SPC":32};
	let loaded=0;
	while (fontidx<fontlen) {
		fontidx++;
		let chr=token(32);
		if (chr.length<=0) {continue;}
		chr=special[chr]??chr.charCodeAt(0);
		let g={};
		g.width=parseInt(token(32));
		g.path=token(10);
		g.poly=new Draw.Path(g.path);
		g.chr=String.fromCharCode(chr);
		g.num=chr;
		g.img=null;
		// Queue loading the images.
		let img=new Image();
		img.onload=function() {
			g.img=img;
			loaded--;
		};
		img.onerror=function() {
			loaded--;
		};
		img.src=fontpath+g.num.toString().padStart(3,"0")+".png";
		glyphs[g.num]=g;
		loaded++;
	}
	// Once all images have loaded (or failed), process them.
	function process() {
		console.log("loading font:",loaded);
		if (loaded>0) {
			setTimeout(process,1);
			return;
		}
		let draw=new Draw();
		let font=new Draw.Font();
		draw.setfont(font);
		let fonterr=0;
		let fontder=0;
		let dercutoff=Math.cos(-0.15*Math.PI);
		//let adjust=true;
		for (let g of Object.values(glyphs)) {
			console.log("processing:",g.num,g.chr);
			let img=g.img;
			if (img===null) {
				console.log("Image file not found");
				throw "error";
			}
			let iw=img.width,ih=img.height,pixels=iw*ih;
			if (iw!==g.width || ih!==scale) {
				console.log("width :",iw,g.width);
				console.log("height:",ih,scale);
				// Print the rescaled polygon.
				let mul=iw!==g.width?iw/g.width:ih/scale;
				for (let v of g.poly.vertarr) {v.x*=mul;v.y*=mul;}
				console.log("scaled:",g.poly.tostring(0));
				throw "dimensions mismatch";
			}
			// Get the alpha values from the source image.
			let canv=document.createElement("canvas");
			let ctx=canv.getContext("2d");
			canv.width=iw;
			canv.height=ih;
			ctx.drawImage(img,0,0);
			let srcpix=ctx.getImageData(0,0,iw,ih).data;
			canv.remove();
			// See how the pixels differ.
			let dstimg=new Draw.Image(iw,ih);
			draw.setimage(dstimg);
			draw.fill(0,0,0,255);
			draw.setcolor(255,255,255,255);
			draw.filltext(0,0,g.chr,ih);
			let dstdata=dstimg.data8;
			let sumerr=0;
			for (let i=0;i<pixels;i++) {
				let j=i*4;
				let srcc=(srcpix[j+0]+srcpix[j+1]+srcpix[j+2])/(3*255);
				let dstc=dstdata[j+0]/255;
				let u=dstc-srcc;
				sumerr+=Math.abs(u);
				dstdata[j+0]=u<0?Math.round(-u*255):0;
				dstdata[j+1]=0;
				dstdata[j+2]=u>0?Math.round(u*255):0;
				dstdata[j+3]=255;
			}
			fonterr+=sumerr;
			// Find any consecutive curves that don't have parallel derivatives.
			let paths=g.path.split("M");
			let sumder=0;
			let MOVE=Draw.Path.MOVE,CLOSE=Draw.Path.CLOSE,CURVE=Draw.Path.CURVE;
			for (let j=1;j<paths.length;j++) {
				let path="M "+paths[j].trim();
				let poly=new Draw.Path(path);
				let vidx=poly.vertidx;
				let varr=poly.vertarr;
				if (vidx<2 || varr[0].type!==MOVE || varr[vidx-1].type!==CLOSE) {
					console.log(path);
					throw "no Z ending";
				}
				let skip=0;
				for (let k=0;k<vidx;k++) {
					let v0=varr[(k+vidx-1)%vidx];
					let v1=varr[k];
					let v2=varr[(k+1)%vidx];
					// Skip zero-length close.
					let p0=new Vector([v0.x,v0.y]);
					let p1=new Vector([v1.x,v1.y]);
					let p2=new Vector([v2.x,v2.y]);
					if (p1.dist(p0)<1e-10) {
						if (v1.type===CLOSE || v0.type===CLOSE) {v0=varr[(k+vidx-2)%vidx];}
						else {throw "zero-length segment";}
					}
					if (p1.dist(p2)<1e-10) {
						if (v1.type===CLOSE || v2.type===CLOSE) {v2=varr[(k+2)%vidx];}
						else {throw "zero-length segment";}
					}
					// Allow any derivative for line->line.
					if (v0.type!==CURVE && v1.type!==CURVE && v2.type!==CURVE) {continue;}
					if (v1.type===CURVE && !skip) {k++;skip=1;continue;}
					skip=0;
					let dx0=v1.x-v0.x,dy0=v1.y-v0.y,l0=dx0*dx0+dy0*dy0;
					let dx1=v2.x-v1.x,dy1=v2.y-v1.y,l1=dx1*dx1+dy1*dy1;
					let len=l0*l1;
					let dot=dx0*dx1+dy0*dy1,dot2=dot*dot;
					dot/=Math.sqrt(len);
					if (dot>dercutoff && dot2<len) {
						// console.log("sub  :",path);
						console.log("dot  :",dot);
						console.log("coord:",v0.x,v0.y,v1.x,v1.y,v2.x,v2.y);
						console.log("dif  :",dx0,dy0,dx1,dy1);
						sumder++;
					}
				}
			}
			// Error out if we're too off.
			let accept=erroraccept[g.chr]??[0.002,0];
			let limitpix=accept[0]*pixels;
			let limitder=accept[1];
			console.log("err: "+sumerr.toFixed(3)+" / "+limitpix.toFixed(3));
			console.log("der: "+sumder.toString()+" / "+limitder);
			// console.log((new Draw.Path()).addoval(361,116,67,67).tostring(0));
			if (sumerr>limitpix || sumder>limitder) {
				// Display a heatmap of differences.
				canv=document.createElement("canvas");
				document.body.appendChild(canv);
				canv.style.background="#000000";
				canv.style.position="absolute";
				canv.style.top="0px";
				canv.style.left="0px";
				canv.width=g.width;
				canv.height=scale;
				canv.style.width=canv.width+"px";
				canv.style.height=canv.height+"px";
				let cdata=new Uint8ClampedArray(dstimg.data8.buffer);
				let idata=new ImageData(cdata,dstimg.width,dstimg.height);
				ctx=canv.getContext("2d");
				ctx.putImageData(idata,0,0);
				throw "err too great";
			}
		}
		console.log("font err: "+fonterr.toFixed(6));
		console.log("font der: "+fontder);
		console.log("size    : "+fontdef.length);
		console.log("done");
	}
	process();
}


function FontDemo() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	//let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	draw.fill(0,0,0,255);
	draw.setcolor(255,0,0,255);
	let text=
		"████████████████████████████████████\n"+
		"█ !\"#$%&'()*+,-./0123456789:;<=>? █\n"+
		"█ @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^ █\n"+
		"█ `abcdefghijklmnopqrstuvwxyz{|}~ █\n"+
		"█ █                               █\n"+
		"████████████████████████████████████";
	draw.filltext(400,200,text);
	draw.setcolor(255,255,255,255);
	//text="hello\b\b\b\b\bworld";
	//draw.filltext(400,500,text);
	draw.screenflip();
}


//---------------------------------------------------------------------------------
// Stress Tests


function OvalStressTest() {
	// console.log("testing ovals");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.filloval(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("ovals: "+time.toFixed(6));
	// console.log("done");
}


function LineStressTest() {
	// console.log("testing lines");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=200000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x0=(rnd.getf()*3-1)*imgwidth;
		let y0=(rnd.getf()*3-1)*imgheight;
		let x1=(rnd.getf()*3-1)*imgwidth;
		let y1=(rnd.getf()*3-1)*imgheight;
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		draw.linewidth=rnd.getf()*10;
		draw.drawline(x0,y0,x1,y1);
	}
	time=(performance.now()-time)/1000;
	console.log("lines: "+time.toFixed(6));
	// console.log("done");
}


function CharStressTest() {
	// console.log("testing characters");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=2000000;
	let text=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~█";
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		let c=text[test%text.length];
		let s=rnd.getf()*32;
		draw.filltext(x,y,c,s);
	}
	time=(performance.now()-time)/1000;
	console.log("chars: "+time.toFixed(6));
	// console.log("done");
}


function ImageStressTest() {
	let rnd=new Random(10);
	let draw=new Draw();
	let images=10;
	let imgarr=new Array(images);
	draw.setcolor(0,0,0,255);
	let amask=draw.rgba32[0],nmask=(~amask)>>>0;
	for (let i=0;i<images;i++) {
		let w=i>0?Math.floor(Math.pow(2,i*1.10)+1):0;
		let h=i>0?Math.floor(Math.pow(2,i*1.13)+1):0;
		let img=new Draw.Image(w,h);
		imgarr[i]=img;
		let data32=img.data32,datalen=data32.length,col=0;
		for (let j=0;j<datalen;j++) {
			col=rnd.getu32();
			switch (rnd.mod(4)) {
				case 0: col&=nmask; break;
				case 1: col|=amask; break;
				default: break;
			}
			data32[j]=col;
		}
	}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dstimg=imgarr[rnd.mod(images)];
		let srcimg=imgarr[rnd.mod(images)];
		draw.setimage(dstimg);
		draw.rgba32[0]=rnd.getu32();
		//let w=rnd.mod(srcimg.width*2+1);
		//let h=rnd.mod(srcimg.height*2+1);
		let x=(rnd.getf()*3-1)*dstimg.width;
		let y=(rnd.getf()*3-1)*dstimg.height;
		draw.drawimage(srcimg,x,y);//,w,h);
	}
	time=(performance.now()-time)/1000;
	console.log("image: "+time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	/*if (Draw.wasmloading===0) {
		setTimeout(TestMain,1);
		console.log("loading wasm");
		return;
	}*/
	console.log("starting polygon tests");
	//UnitAreaTest();
	//AreaClipTest();
	//AreaCacheTest();
	//StrideTest();
	//StrideTest2();
	//BlendTest1();
	//BlendTest2();
	//BezierParamTest();
	//BezierLengthTest();
	//BezierSegmentTest();
	//BezierSegmentDemo();
	//PathAreaTest();
	//CircleApprox(2,[275,692],65);
	//HeapSortTest();
	//BoundingBoxTest();
	//BoundingBoxSpeedTest();
	//BoundingBoxDemo();
	//FillDisplayTest();
	//FillAccuracyTest();
	//FillCrashTest();
	//FontFit("./font/",{"@":[0.003,1],"b":[0.002,1],"g":[0.002,1],"h":[0.002,1],"m":[0.002,2]});
	//FontDemo();
	//OvalStressTest();
	//LineStressTest();
	//CharStressTest();
	//ImageStressTest();
	console.log("done");
}

window.addEventListener("load",TestMain);

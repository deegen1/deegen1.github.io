/*------------------------------------------------------------------------------


polytests.js - v1.09

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Check performance.txt for historical data.


--------------------------------------------------------------------------------
TODO


Try blending with
let colrgb40=(colrgb&0x0000ff00)*0x1000000+(colrgb&0x00ff00ff);
let colrgb48=colrgb40*0x100;
...
let tmp=(dst&0x0000ff00)*0x1000000+(dst&0x00ff00ff);
tmp=(tmp-colrgb40)*(~~sa)+colrgb48;
imgdata[x]=(da<<24)|((tmp&0xff00ff00)>>>8)|((tmp*2.3283064365386963e-10)&0x0000ff00);


*/
/* jshint esversion: 11  */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */


//---------------------------------------------------------------------------------
// Test 1 - Line Overlap Area Calculation


function areaapprox(x0,y0,x1,y1,samples) {
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let miny=Math.min(y0,y1),maxy=Math.max(y0,y1);
	let x,u;
	let rate=(x1-x0)/(y1-y0);
	let con =x0-y0*rate;
	let prev=null;
	let area=0;
	for (let s=0;s<=samples;s++) {
		u=s/samples;
		if (u>=miny && u<=maxy) {
			x=u*rate+con;
			x=1-Math.min(Math.max(x,0),1);
			if (prev!==null) {area+=prev+x;}
			prev=x;
		}
	}
	area/=2*samples;
	return (y0>y1?area:-area);
}


function areacalc1(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let dxy=difx/dify;
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	tmp=0.0;
	if (y0<0.0) {
		x0=y0x;
		y0=0.0;
	} else if (y0>1.0) {
		x0=y1x;
		y0=1.0;
	}
	if (y1<0.0) {
		x1=y0x;
		y1=0.0;
	} else if (y1>1.0) {
		x1=y1x;
		y1=1.0;
	}
	if (x0<0.0) {
		tmp+=y0-x0y;
		x0=0.0;
		y0=x0y;
	} else if (x0>1.0) {
		x0=1.0;
		y0=x1y;
	}
	if (x1<0.0) {
		tmp+=x0y-y1;
		x1=0.0;
		y1=x0y;
	} else if (x1>1.0) {
		x1=1.0;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp;
}


function areacalc(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	let tmp;
	let sign=1;
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	let difx=x1-x0;
	let dify=y1-y0;
	if (dify<1e-9 || y0>=1 || y1<=0) {return 0;}
	let dxy=difx/dify;
	let dyx=difx>1e-9?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (x1<=0) {return (y0-y1)*sign;}
	if (x0>=1) {return 0;}
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function AreaTest1() {
	// See if the area approximation matches the exact calculation.
	let samples=1<<16;
	let errlim=2/samples;
	let tests=10000;
	let maxdif1=0,maxdif2=0;
	let dif,areac;
	for (let test=0;test<tests;test++) {
		let x0=Math.random()*10-5;
		let y0=Math.random()*10-5;
		let x1=Math.random()*10-5;
		let y1=Math.random()*10-5;
		if (test&256) {x1=x0;}
		if (test&512) {y1=y0;}
		let areaa=areaapprox(x0,y0,x1,y1,samples);
		areac=areacalc1(x0,y0,x1,y1);
		dif=Math.abs(areaa-areac);
		if (maxdif1<dif || !(dif===dif)) {maxdif1=dif;}
		areac=areacalc(x0,y0,x1,y1);
		dif=Math.abs(areaa-areac);
		if (maxdif2<dif || !(dif===dif)) {maxdif2=dif;}
	}
	console.log("max dif 1: "+maxdif1);
	console.log("max dif 2: "+maxdif2);
	console.log("exp dif  : "+errlim);
}


//---------------------------------------------------------------------------------
// Test 3 - Area Clipping


function getrowlines2(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	let x0=line.x0,y0=line.y0-py;
	let x1=line.x1,y1=line.y1-py;
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0>=1 && y1>=1) || (y0<=0 && y1<=0)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let dxy=difx/dify;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y0>1) {y0=1;x0=y1x;}
	if (y1<0) {y1=0;x1=y0x;}
	if (y1>1) {y1=1;x1=y1x;}
	let next=(y0>y1?x0:x1)+(dxy<0?dxy:0);
	if (next<Math.min(line.x0,line.x1)) {next=Math.min(line.x0,line.x1);}
	if (py+1>Math.max(line.y0,line.y1)) {next=Infinity;}
	a0.next=next;
	if (x1<x0) {tmp=x0;x0=x1;x1=tmp;dyx=-dyx;}
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		dyx*=amul;
		let mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function getrowlines3(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0<=py && y1<=py)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=py;
	y1-=py;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		let dyx=amul/dxy,mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function getrowlines4(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?Math.floor(x0):x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	if (x>=fx1) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
	} else {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
	}
	a0.areadx2+=tmp;
	return [a0,a1];
}


function AreaClipTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=100000;
	let maxdif=0;
	for (let test=0;test<tests;test++) {
		let x0=rnd.getf()*200-50;
		let y0=rnd.getf()*200-50;
		let x1=rnd.getf()*200-50;
		let y1=rnd.getf()*200-50;
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(34);
			dev=dev>31?0:Math.pow(2,-dev);
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(34);
			dev=dev>31?0:Math.pow(2,-dev);
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		let minx=Math.floor(Math.min(x0,x1))-2;
		let maxx=Math.ceil( Math.max(x0,x1))+2;
		let miny=Math.floor(Math.min(y0,y1));
		let maxy=Math.ceil( Math.max(y0,y1))+2;
		let line={x0:x0,y0:y0,x1:x1,y1:y1};
		// console.log(test,x0,y0,x1,y1);
		for (let cy=miny;cy<maxy;cy++) {
			// Pick a random point on the row to start.
			let cx=rnd.modu32(maxx-minx+1)+minx;
			let aobj=getrowlines4(line,cx,cy,amul);
			let a=aobj[0];
			let area=a.area,areadx1=a.areadx1,areadx2=a.areadx2;
			// Test current row start.
			cx=a.sort;
			if (Math.abs(y1-y0)>1e-9 && (cy<y0 || cy<y1) && (cy+1>y0 || cy+1>y1)) {
				let areac=areacalc(x0-cx,y0-cy,x1-cx,y1-cy);
				if (Math.abs(areac)<1e-18) {throw "row 0: "+areac;}
			}
			// Test next row start prediction.
			let nx=a.next;
			if (nx<Infinity) {
				let areac=areacalc(x0-nx,y0-cy-1,x1-nx,y1-cy-1);
				if (Math.abs(areac)<1e-9) {throw "next 0: "+areac;}
				areac=areacalc(x0-(nx-1),y0-cy-1,x1-(nx-1),y1-cy-1);
				if (Math.abs(areac)>1e-9) {throw "next -1: "+areac;}
			} else if (cy+1<y0 || cy+1<y1) {
				throw "next y: "+cy+", "+y0+", "+y1;
			}
			// Test that the end of the row is really the end.
			a=aobj[1];
			let stop=a.sort<Infinity?Math.max(a.sort,cx):cx;
			let areac1=areacalc(x0-(stop+1),y0-cy,x1-(stop+1),y1-cy);
			let areac2=areacalc(x0-(stop+2),y0-cy,x1-(stop+2),y1-cy);
			if (Math.abs(areac1-areac2)>1e-9) {throw "tail 2: "+areac1+", "+areac2;}
			stop+=10;
			for (;cx<stop;cx++) {
				if (cx>=a.sort) {
					area+=a.area;
					areadx1+=a.areadx1;
					areadx2+=a.areadx2;
					a.sort=Infinity;
				}
				let areac=areacalc(x0-cx,y0-cy,x1-cx,y1-cy)*amul;
				let dif=Math.abs(area-areac);
				if (maxdif<dif) {
					maxdif=dif;
					console.log(maxdif,areac,area);
				}
				area+=areadx1+areadx2;
				areadx2=0;
			}
		}
	}
	console.log("max dif: "+maxdif);
}


//---------------------------------------------------------------------------------
// Cache Test


function getrowcache3(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,areadx3:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?Math.floor(x0):x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	let flen=fx1-x;
	if (flen<=0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else if (flen===1) {
		let dy=(y0-y1)*amul;
		let tmp0=dyh-x0*dyx+(x0>0?x0*x0*dyh:0);
		a0.area+=-tmp0;
		a0.areadx2+=dy+tmp0-tmp;
		a0.areadx3+=tmp;
	} else {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
		a0.areadx2+=tmp;
	}
	return [a0,a1];
}


function AreaCacheTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area cache-3");
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=100000;
	let maxdif=0;
	for (let test=0;test<tests;test++) {
		let x0=rnd.getf()*200-50;
		let y0=rnd.getf()*200-50;
		let x1=rnd.getf()*200-50;
		let y1=rnd.getf()*200-50;
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(34);
			dev=dev>31?0:Math.pow(2,-dev);
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(34);
			dev=dev>31?0:Math.pow(2,-dev);
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		let minx=Math.floor(Math.min(x0,x1))-2;
		let maxx=Math.ceil( Math.max(x0,x1))+2;
		let miny=Math.floor(Math.min(y0,y1));
		let maxy=Math.ceil( Math.max(y0,y1))+2;
		let line={x0:x0,y0:y0,x1:x1,y1:y1};
		// console.log(test,x0,y0,x1,y1);
		for (let cy=miny;cy<maxy;cy++) {
			// Pick a random point on the row to start.
			let cx=rnd.modu32(maxx-minx+1)+minx;
			let aobj=getrowcache3(line,cx,cy,amul);
			let a=aobj[0];
			let area=a.area,areadx1=a.areadx1,areadx2=a.areadx2,areadx3=a.areadx3;
			// Test current row start.
			cx=a.sort;
			if (Math.abs(y1-y0)>1e-9 && (cy<y0 || cy<y1) && (cy+1>y0 || cy+1>y1)) {
				let areac=areacalc(x0-cx,y0-cy,x1-cx,y1-cy);
				if (Math.abs(areac)<1e-18) {throw "row 0: "+areac;}
			}
			// Test next row start prediction.
			let nx=a.next;
			if (nx<Infinity) {
				let areac=areacalc(x0-nx,y0-cy-1,x1-nx,y1-cy-1);
				if (Math.abs(areac)<1e-9) {throw "next 0: "+areac;}
				areac=areacalc(x0-(nx-1),y0-cy-1,x1-(nx-1),y1-cy-1);
				if (Math.abs(areac)>1e-9) {throw "next -1: "+areac;}
			} else if (cy+1<y0 || cy+1<y1) {
				throw "next y: "+cy+", "+y0+", "+y1;
			}
			// Test that the end of the row is really the end.
			a=aobj[1];
			let stop=a.sort<Infinity?Math.max(a.sort,cx):cx;
			let areac1=areacalc(x0-(stop+2),y0-cy,x1-(stop+2),y1-cy);
			let areac2=areacalc(x0-(stop+3),y0-cy,x1-(stop+3),y1-cy);
			if (Math.abs(areac1-areac2)>1e-9) {throw "tail 2: "+areac1+", "+areac2;}
			stop+=10;
			for (;cx<stop;cx++) {
				if (cx>=a.sort) {
					area+=a.area;
					areadx1+=a.areadx1;
					areadx2+=a.areadx2;
					a.sort=Infinity;
				}
				let areac=areacalc(x0-cx,y0-cy,x1-cx,y1-cy)*amul;
				let dif=Math.abs(area-areac);
				if (maxdif<dif) {
					maxdif=dif;
					console.log(maxdif,areac,area);
				}
				area+=areadx1+areadx2;
				areadx2=areadx3;
				areadx3=0;
			}
		}
	}
	console.log("max dif: "+maxdif);
}


//---------------------------------------------------------------------------------
// Stride Test
// Calculate how many pixels can be filled with the same color.


function stridecalc1(x,xnext,area,areadx1,areadx2) {
	let base=Math.floor(area*255+0.5);
	base=Math.min(Math.max(base,0),255);
	while (x<xnext) {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
		let tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp,0),255);
		if (base!==tmp) {break;}
	}
	return x;
}


function stridecalc2(x,xnext,area,areadx1,areadx2) {
	let xdraw=x+1,tmp;
	if (areadx2===0) {
		tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp+(areadx1<0?-0.5:0.5),0.5),254.5);
		tmp=(tmp/255-area)/areadx1+x;
		xdraw=(tmp>x && tmp<xnext)?Math.ceil(tmp):xnext;
	}
	return xdraw;
}


function StrideTest() {
	console.log("testing stride calculation");
	let rnd=new Random();
	let tests=100000;
	let tmp;
	for (let test=0;test<tests;test++) {
		let x=rnd.modu32(200)+100;
		let xnext=x+rnd.modu32(100);
		let area=rnd.getf()*4-2;
		tmp=rnd.modu32(31);
		tmp=tmp>16?0:(1/(1<<tmp));
		let areadx1=(rnd.getf()*4-2)*tmp;
		// tmp=rnd.modu32(31);
		// tmp=tmp>16?0:(1/(1<<tmp));
		// let areadx2=(rnd.getf()*4-2)*tmp;
		let areadx2=0;
		let stride1=stridecalc1(x,xnext,area,areadx1,areadx2);
		let stride2=stridecalc2(x,xnext,area,areadx1,areadx2);
		if (stride1!==stride2) {
			console.log("bad stride: "+test);
			console.log(stride1+" != "+stride2);
			console.log("x    = "+x);
			console.log("next = "+xnext);
			console.log("area = "+area);
			console.log("dx1  = "+areadx1);
			console.log("dx2  = "+areadx2);
			return;
		}
	}
	console.log("passed");
}


function stridecalc20(area,areadx1,areadx2,cutoff,x,xnext) {
	let side=area>=cutoff;
	do {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
	} while ((area>=cutoff)===side && x<xnext);
	return [x,area];
}


function stridecalc21(area,areadx1,areadx2,cutoff,x,xnext) {
	// const cutoff=0.00390625;
	let astop=area+areadx1+areadx2;
	let xstop=x+1,xdif=xnext-xstop;
	// xdif=(xnext<xrow?xnext:xrow)-xstop;
	if (xdif>0 && (area>=cutoff)===(astop>=cutoff)) {
		let adif=(cutoff-astop)/areadx1+1;
		// xdif=(adif>=1 && adif<xdif)?Math.floor(adif):xdif;
		xdif=(adif>=1 && adif<xdif)?~~adif:xdif;
		astop+=xdif*areadx1;
		xstop+=xdif;
	}
	return [xstop,astop];
}


function StrideTest2() {
	// If area>cutoff, how long until area+areadx2<=cutoff.
	// If any value is NaN or infinity, guarantee progression.
	// Don't let xstop become NaN, negative, or infinite.
	//
	// if (area>=cutoff) {
	//      do {
	//           area+=areadx1+areadx2;
	//           areadx2=0;
	//      } while (++x<xstop);
	// }
	// x=xstop;
	// area=astop;
	//
	console.log("testing stride calculation");
	let rnd=new Random(33);
	function rndpow(min,max,special=false) {
		let flags=rnd.getu32();
		if (special) {
			let type=(flags>>>1)&63;
			if (type<4) {return 0;}
			else if (type<8) {return NaN;}
			else if (type<10) {return Infinity;}
			else if (type<12) {return -Infinity;}
		}
		let exp=rnd.getf()*(max-min)+min;
		let val=Math.pow(2,exp);
		return (flags&1)?val:-val;
	}
	for (let trial=0;trial<10000000;trial++) {
		let cutoff=rndpow(-20,4);
		let area=rndpow(-30,4,true)+cutoff;
		let areadx1=rndpow(-30,4,true);
		let areadx2=rndpow(-30,4,true);
		if ((rnd.getu32()&63)===0) {
			// Special case to force adif=1.
			areadx2=0;
			areadx1=cutoff-area;
		}
		let x=Math.round(rndpow(0,6));
		let xnext=x+Math.round(Math.abs(rndpow(0,8)));
		if (xnext<x+1) {xnext=x+1;}
		let [xstop0,astop0]=stridecalc20(area,areadx1,areadx2,cutoff,x,xnext);
		let [xstop1,astop1]=stridecalc21(area,areadx1,areadx2,cutoff,x,xnext);
		let eq=true;
		if (isNaN(astop0)!==isNaN(astop1)) {eq=false;}
		else if ((Math.abs(astop0)>=Infinity)!==(Math.abs(astop1)>=Infinity)) {eq=false;}
		else if (Math.abs(astop0-astop1)>1e-9) {eq=false;}
		if (xstop0!==xstop1 || !eq) {
			console.log("error "+trial);
			console.log("calc 0 :",xstop0,astop0);
			console.log("calc 1 :",xstop1,astop1);
			console.log("cutoff :",cutoff);
			console.log("area   :",area);
			console.log("areadx1:",areadx1);
			console.log("areadx2:",areadx2);
			console.log("x      :",x);
			console.log("xnext  :",xnext);
			return;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 2 - Fast Pixel Blending


function BlendTest1() {
	// expects alpha in [0,256], NOT [0,256).
	let samples=20000000*2;
	let arr0=new Uint32Array(samples);
	let i;
	for (i=0;i<samples;i+=2) {
		arr0[i+0]=(Math.random()*0x100000000)>>>0;
		arr0[i+1]=Math.floor(Math.random()*256.99);
	}
	let arr=new Uint32Array(samples);
	let arr8=new Uint8Array(arr.buffer);
	let src=(Math.random()*0x100000000)>>>0;
	let src3=(src>>>24)&0xff;
	let src2=(src>>>16)&0xff;
	let src1=(src>>> 8)&0xff;
	let src0=(src>>> 0)&0xff;
	let dst,a;
	let lh,hh,lh2,hh2;
	let hash,time,pos,hash0=null;
	// ----------------------------------------
	arr.set(arr0);hash=1;
	let base=performance.now();
	for (i=0;i<samples;i+=2) {
		hash=arr[i+1];
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	base=performance.now()-base;
	console.log("baseline:",base,hash);
	console.log("Algorithm, Time, Accurate");
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(arr8[pos]*a+src0*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src1*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src2*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src3*(256-a))>>>8;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	hash0=hash;
	time=performance.now()-time-base;
	console.log("Naive RGB #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(((arr8[pos]-src0)*a)>>8)+src0;pos++;
		arr8[pos]=(((arr8[pos]-src1)*a)>>8)+src1;pos++;
		arr8[pos]=(((arr8[pos]-src2)*a)>>8)+src2;pos++;
		arr8[pos]=(((arr8[pos]-src3)*a)>>8)+src3;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("Naive RGB #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src>>>8)&0x00ff00ff;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)*a+lh*(256-a))>>>8)&0x00ff00ff)+
		       ((((dst>>>8)&0x00ff00ff)*a+hh*(256-a))&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	lh2=lh<<8;
	hh=(src>>>8)&0x00ff00ff;
	hh2=hh<<8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((((dst&0x00ff00ff)-lh)*a+lh2)>>>8)&0x00ff00ff)+
		       (((((dst>>>8)&0x00ff00ff)-hh)*a+hh2)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=src&0xff00ff00;
	let d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)-lh)*a+lh)&0x00ff00ff)+
		       ((((dst&0xff00ff00)-hh)*a+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #3",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	let mask0=0xff000000,mask1=0x00ff0000;
	let mask2=0x0000ff00,mask3=0x000000ff;
	let c0=src&mask0,c1=src&mask1;
	let c2=src&mask2,c3=src&mask3;
	d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&mask0)-c0)*a+c0)&mask0)
		      |((((dst&mask1)-c1)*a+c1)&mask1)
		      |((((dst&mask2)-c2)*a+c2)&mask2)
		      |((((dst&mask3)-c3)*a+c3)&mask3);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("float #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src&0xff00ff00)>>>0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)-hh)>>>8,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=(src&0x00ff00ff)>>>0;
	hh=(src&0xff00ff00)>>>0;
	hh2=hh>>>8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)>>>8)-hh2,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #2",time,hash===hash0);
}


//---------------------------------------------------------------------------------
// Test 3 - Pixel compositing


let blend_rgbashift=[0,0,0,0];
(function (){
	let rgba  =new Uint8ClampedArray([0,1,2,3]);
	let rgba32=new Uint32Array(rgba.buffer);
	let col=rgba32[0];
	for (let i=0;i<32;i+=8) {blend_rgbashift[(col>>>i)&255]=i;}
})();
const [blend_r,blend_g,blend_b,blend_a]=blend_rgbashift;


function blendref(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0) {return dst;}
	sa/=255.0;
	let a=sa+(((dst>>>blend_a)&255)/255.0)*(1-sa);
	sa/=a;
	let da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast1(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	if (da===255) {
		sa/=255.0;
		let da=1-sa;
		return ((255<<blend_a)|
			(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)|
			(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)|
			(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast3(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=255<<blend_a;
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<blend_a;
		src=(src&(~(255<<blend_a)))|da;
		dst=(dst&(~(255<<blend_a)))|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
}


const blendfast2=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	if (da===255) {
		//((imul((dst&0x00ff00ff)-coll,d)>>>8)+coll)&0x00ff00ff)+
		//((imul(((dst&0xff00ff00)>>>8)-colh2,d)+colh)&0xff00ff00);
		//return 0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<${blend_a})+
		(Math.max(Math.min(((src>>>${blend_r})&255)*sa+((dst>>>${blend_r})&255)*da,255),0)<<${blend_r})+
		(Math.max(Math.min(((src>>>${blend_g})&255)*sa+((dst>>>${blend_g})&255)*da,255),0)<<${blend_g})+
		(Math.max(Math.min(((src>>>${blend_b})&255)*sa+((dst>>>${blend_b})&255)*da,255),0)<<${blend_b}))>>> 0;
`.replace(/(>>>)0/g,""));


const blendfast4=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=${(255<<blend_a)>>>0};
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<${blend_a};
		src=(src&${(~(255<<blend_a)>>>0)})|da;
		dst=(dst&${(~(255<<blend_a)>>>0)})|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
`);


/* Inline blending

// Setup
let sa,sa0,sa1,sai,da,dst;
let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
let colrgba=this.rgba32[0]|amask,alpha=this.rgba[3]/255.0;
let coll=colrgba&0x00ff00ff,colh=colrgba&0xff00ff00,colh8=colh>>>8;

// Execution
sa0=Math.min(area,1)*alpha;
if (sa0>=0.999) {
	while (pixcol<pixstop) {
		imgdata[pixcol++]=colrgba;
	}
} else if (sa0>=1/256.0) {
	// Inlining blending is twice as fast as a blend() function.
	sai=(1-sa0)/255.0;
	sa1=256-Math.floor(sa0*256);
	while (pixcol<pixstop) {
		// Approximate blending by expanding sa from [0,255] to [0,256].
		dst=imgdata[pixcol];
		da=(dst>>>ashift)&255;
		if (da===0) {
			imgdata[pixcol++]=0xffffffff;
			continue;
		} else if (da===255) {
			sa=sa1;
		} else if (da<255) {
			da=sa0+da*sai;
			sa=256-Math.floor(Math.min(sa0/da,1)*256);
			da=Math.floor(da*255+0.5);
		}
		imgdata[pixcol++]=((
			(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&0x00ff00ff)+
			((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&0xff00ff00)
			)&namask)|(da<<ashift);
	}
}
*/

function BlendTest2() {
	// https://en.wikipedia.org/wiki/Alpha_compositing
	// src drawn on dst
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	// c = (sc - dc)*(sa/a) + dc
	console.log("testing blending 3");
	let am=255<<blend_a,nm=(~am)>>>0;
	let count=0;
	for (let test=0;test<1000000;test++) {
		let src=Math.floor(Math.random()*0x100000000);
		let dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		dst>>>=0;
		src>>>=0;
		let ref=blendref(dst,src);
		let calc=blendfast4(dst,src);
		let err=0;
		let dif0=Math.abs(((ref>>>0)&255)-((calc>>>0)&255));
		let dif1=Math.abs(((ref>>>8)&255)-((calc>>>8)&255));
		let dif2=Math.abs(((ref>>>16)&255)-((calc>>>16)&255));
		let dif3=Math.abs(((ref>>>24)&255)-((calc>>>24)&255));
		count+=dif0+dif1+dif2+dif3;
		if (dif0>1 || dif1>1 || dif2>1 || dif3>1) {
			console.log("error");
			console.log(src,dst);
			console.log(ref.toString(16),calc.toString(16));
			return;
		}
	}
	console.log("sum: "+count);
	console.log("passed");
	let sum=0,dst,src;
	let t0=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendref(dst,src);
	}
	t0=performance.now()-t0;
	let t1=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast3(dst,src);
	}
	t1=performance.now()-t1;
	let t2=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast4(dst,src);
	}
	t2=performance.now()-t2;
	console.log(sum);
	console.log(t0);
	console.log(t1);
	console.log(t2);
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 3 - Bezier parameterization


function BezierParam0(points,u) {
	let v=1-u;
	let cpx=v*v*v*points[0]+3*v*v*u*points[2]+3*v*u*u*points[4]+u*u*u*points[6];
	let cpy=v*v*v*points[1]+3*v*v*u*points[3]+3*v*u*u*points[5]+u*u*u*points[7];
	return [cpx,cpy];
}


function BezierParam1(points,u1) {
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));
	return [cpx,cpy];
}


function BezierParamTest() {
	console.log("testing bezier parameterization");
	let tests=10000;
	let points=new Float64Array(8);
	let maxerr=0.0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			points[i]=Math.random()*10-5;
		}
		let u=Math.random()*10-5;
		let [x0,y0]=BezierParam0(points,u);
		let [x1,y1]=BezierParam1(points,u);
		x1-=x0;
		y1-=y0;
		let err=x1*x1+y1*y1;
		if (maxerr<err || !(err===err)) {
			maxerr=err;
		}
	}
	console.log("bezier err: "+maxerr);
}


//---------------------------------------------------------------------------------
// Bezier Length


function BezierLength0(points) {
	// "Accurate" length calculation.
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let segs=1000;
	let lx=p0x,ly=p0y,dist=0;
	for (let s=1;s<=segs;s++) {
		let u=s/segs;
		let mx=p0x+u*(p1x+u*(p2x+u*p3x));
		let my=p0y+u*(p1y+u*(p2y+u*p3y));
		let dx=mx-lx,dy=my-ly;
		dist+=Math.sqrt(dx*dx+dy*dy);
		lx=mx;
		ly=my;
	}
	return dist;
}


function BezierLength1(points) {
	// approximate length calculation.
	let p0x=points[0],p0y=points[1];
	let c1x=points[2],c1y=points[3];
	let c2x=points[4],c2y=points[5];
	let c3x=points[6],c3y=points[7];
	let dx,dy,dist=0;
	dx=c1x-p0x;dy=c1y-p0y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	return dist*0.5;
}


function BezierLengthTest() {
	console.log("testing bezier length approximation");
	let rnd=new Random(10);
	let curve=new Array(8);
	let tests=100;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=(rnd.getf()*2-1)*100;
		}
		let dist0=BezierLength0(curve);
		let dist1=BezierLength1(curve);
		let dif=Math.abs(dist0-dist1)/dist1;
		sumdif+=dif;
		console.log(dist0,dist1,dif);
	}
	console.log("dif: "+sumdif.toFixed(6));
}


//---------------------------------------------------------------------------------
// Bezier Segmentation Tests
// Need at least 3 interpolation points to catch all cubic bezier cases.


function BezierSegment1(curve,splitlen=3) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	// Estimate bezier length.
	let dist,dx,dy;
	dx=c1x-p0x;dy=c1y-p0y;dist =Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	let segs=Math.ceil(dist*0.5/splitlen+1e-10);
	// Segment the curve.
	let lr=[];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let ppx=p0x,ppy=p0y,unorm=1.0/segs,u=0;
	for (let s=0;s<segs;s++) {
		let lu=u,lx=ppx,ly=ppy;
		u+=unorm;
		ppx=p0x+u*(c1x+u*(c2x+u*c3x));
		ppy=p0y+u*(c1y+u*(c2y+u*c3y));
		lr.push({x0:lx,y0:ly,x1:ppx,y1:ppy,u0:lu,u1:u});
	}
	let l=lr[lr.length-1];
	l.u1=1;
	l.x1=curve[6];
	l.y1=curve[7];
	return lr;
}


function BezierSegment2(curve,cutoff,type,segments) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let den=(dx*dx+dy*dy)*cutoff;
		if (den<1e-9) {den=cutoff;dx=1;dy=0;}
		let u0=l.u0,u1=l.u1;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<segments;s++) {
			let u=u0+(u1-u0)*((s+1)/(segments+1));
			let ix=p0x+u*(c1x+u*(c2x+u*c3x));
			let iy=p0y+u*(c1y+u*(c2y+u*c3y));
			let num=dy*(ix-x0)-dx*(iy-y0);
			let dist=num*num;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u;
			}
		}
		console.log("maxdist:",maxdist);
		if (maxdist>den) {
			// we're outside the bounds
			let u=[(u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment3(curve,cutoff,type,samples) {
	// cutoff  = cutoff distance squared
	// samples = how many points on segment to sample
	// type 0  = split at 0.5
	//      1  = split at minimum distance
	//      2  = split at maximum distance
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.u0,u1=l.u1,du=(u1-u0)/(samples+1);
		let den=dx*dx+dy*dy;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<samples;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (mindist>dist) {
				mindist=dist;
				minu=u0;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u0;
			}
		}
		if (maxdist>cutoff && maxdist<Infinity) {
			// The line is too far from the curve, split it.
			let u=[(l.u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment4(curve,curvemaxdist2=0.01) {
	// Version used in drawing.js.
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	l.amul=0;l.area=1;
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;let c3x=p1x-p0x-c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;let c3y=p1y-p0y-c2y;c2y-=c1y;
	for (let j=lcnt-1;j<lcnt;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.amul,u1=l.area,du=(u1-u0)*0.25;
		let den=dx*dx+dy*dy;
		let maxdist=-Infinity,mu,mx,my;
		for (let s=0;s<3;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (maxdist<dist) {
				maxdist=dist;
				mu=u0;
				mx=sx;
				my=sy;
			}
		}
		if (maxdist>curvemaxdist2 && maxdist<Infinity) {
			// The line is too far from the curve, so split it.
			lr.push({});
			l.x1=mx;
			l.y1=my;
			l.area=mu;
			l=lr[lcnt++];
			l.x0=mx;
			l.y0=my;
			l.x1=x1;
			l.y1=y1;
			l.amul=mu;
			l.area=u1;
			j--;
		}
	}
	for (let l of lr) {l.u0=l.amul;l.u1=l.area;}
	return lr;
}


function BezierSegmentTest() {
	// test
	//      u0,u1 is consecutive and covers [0,1]
	//      endpoints match curve(u)
	//      intermediate points based on distance, at least 10
	let rnd=new Random(9876);
	let curve=new Float64Array(8);
	let trials=10000;
	let sumdist=0,sumsegs=0,maxdist=0;
	for (let trial=0;trial<trials;trial++) {
		// Generate the curve. Try to generate subpixel curves.
		for (let i=0;i<4;i++) {
			let x=Math.pow(2,rnd.getf()*(16+16)-16);
			let y=Math.pow(2,rnd.getf()*(16+16)-16);
			if (x<1) {x*=x;}
			if (y<1) {y*=y;}
			if (x<1e-9) {x=0;}
			if (y<1e-9) {y=0;}
			let sign=rnd.getu32();
			if (sign&1) {x=-x;}
			if (sign&2) {y=-y;}
			let j=rnd.modu32(i+1);
			if (j<i && (sign&4)) {
				x+=curve[j*2+0];
				y+=curve[j*2+1];
			}
			curve[i*2+0]=x;
			curve[i*2+1]=y;
		}
		// let lr=BezierSegment3(curve,0.25,2,3);
		// let lr=BezierSegment3(curve,0.01,2,3);
		// let lr=BezierSegment3(curve,0.01,0,3);
		// let lr=BezierSegment3(curve,0.01,2,2);
		// let lr=BezierSegment3(curve,0.01,0,2);
		// let lr=BezierSegment1(curve);
		let lr=BezierSegment4(curve);
		lr.sort((l,r)=>{return l.u0-r.u0;});
		let u1=0,x1=curve[0],y1=curve[1];
		let subdist=0;
		for (let l of lr) {
			// Test if end of previous line = start of current.
			let u0=l.u0,x0=l.x0,y0=l.y0;
			if (u0!==u1 || x0!==x1 || y0!==y1) {
				console.log("lines not continuous");
				console.log(u1,x1,y1);
				console.log(u0,x0,y0);
				return;
			}
			// Test if line start is on the curve.
			let u=u0,v=1-u,uu=u*u,vv=v*v,vu=3*v*u;
			let tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6];
			let ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7];
			if (Math.abs(tx-x0)>1e-9 || Math.abs(ty-y0)>1e-9) {
				console.log("line off of curve");
				console.log(tx,ty);
				console.log(x0,y0);
				return;
			}
			// Get maximum distance from segment to curve.
			u1=l.u1;
			x1=l.x1;
			y1=l.y1;
			let dx=x1-x0,dy=y1-y0;
			let den=dx*dx+dy*dy;
			let depth=8,samples=8;
			let du=(u1-u0)*0.5,mu=(u1+u0)*0.5,md=0;
			for (let d=0;d<depth;d++) {
				let nu=mu;
				for (let s=0;s<samples;s++) {
					u=nu+du*(2*(s/(samples-1))-1);
					u=u>u0?u:u0;
					u=u<u1?u:u1;
					v=1-u;uu=u*u;vv=v*v;vu=3*v*u;
					tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6]-x0;
					ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7]-y0;
					let d;
					if (den<1e-9) {
						d=tx*tx+ty*ty;
					} else {
						d=dy*tx-dx*ty;
						d=(d*d)/den;
					}
					if (md<d) {
						md=d;
						mu=u;
					}
				}
				du*=0.5;
			}
			subdist=subdist>md?subdist:md;
		}
		if (u1!==1 || Math.abs(x1-curve[6])>1e-9 || Math.abs(y1-curve[7])>1e-9) {
			console.log("line end");
			console.log(u1,x1,y1);
			console.log(1,curve[6],curve[7]);
			return;
		}
		// console.log(maxdist,lr.length);
		subdist=Math.sqrt(subdist);
		maxdist=maxdist>subdist?maxdist:subdist;
		sumdist+=subdist;
		sumsegs+=lr.length;
		if (subdist>10) {
			console.log(curve,trial);
			throw "subdist: "+subdist;
		}
	}
	sumdist/=trials;
	sumsegs/=trials;
	let score=(sumdist+maxdist)*sumsegs;
	console.log(sumdist,maxdist,sumsegs,score);
	console.log("done");
}


function BezierSegmentDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	// console.log(ctx);
	let curve=[100,100,600,130,100,770,600,800];
	ctx.strokeStyle="rgba(255,255,255,1.0)";
	ctx.beginPath();
	ctx.moveTo(curve[0],curve[1]);
	ctx.bezierCurveTo(curve[2],curve[3],curve[4],curve[5],curve[6],curve[7]);
	ctx.stroke();
	ctx.fillStyle="rgba(255,0,0,1.0)";
	// let points=BezierSegment1(curve,48);
	let lr=BezierSegment3(curve,0.1,2,3);
	lr.sort((l,r)=>{return l.u0-r.u0;});
	let points=[[lr[0].x0,lr[0].y0]];
	for (let l of lr) {points.push([l.x1,l.y1]);}
	console.log(points.length);
	for (let p of points) {
		ctx.beginPath();
		ctx.arc(p[0],p[1],3,0,Math.PI*2);
		ctx.fill();
	}
	ctx.strokeStyle="rgba(255,0,0,1.0)";
	ctx.beginPath();
	for (let p of points) {
		ctx.lineTo(p[0],p[1]);
	}
	ctx.stroke();
}


//---------------------------------------------------------------------------------
// Tracing


function TraceDemo() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let draw=new Draw(1000,1000);
	let polystr=`M 0 0 L 22 -8 L 36 -7 C 59 -14 69 -2 57 7 C 105 34 64 -18 68 29
	             L 54 29 L 38 29 L 48 25 Z M 22 46 L 52 46`;
	let poly=new Draw.Poly(polystr);
	draw.fill(0,0,0,255);
	draw.setcolor(255,255,255,255);
	draw.fillpoly(poly,(new Draw.Transform()).setoffset(400,500).setscale(5));
	ctx.putImageData(draw.img.imgdata,0,0);
}


//---------------------------------------------------------------------------------
// Heap sorting


function HeapSortTest() {
	console.log("Testing heap");
	let rnd=new Random();
	for (let test=0;test<200;test++) {
		let alloc=rnd.modu32(2000);
		// Build heap.
		let maxval=100000;
		let idused=new Uint32Array(alloc);
		let lr=new Array(alloc),lcnt=0;
		let swaps=0;
		for (let i=0;i<alloc;i++) {
			let l={};
			l.id=i;
			lr[i]=l;
			l.sort=-Infinity;
			if (rnd.modu32(4)===0) {continue;}
			l.sort=rnd.modu32(maxval*2);
			/*let j=lcnt++;
			lr[i]=lr[j];
			let p,lp;
			while (j>0 && l.sort<(lp=lr[p=(j-1)>>1]).sort) {
				swaps++;
				lr[j]=lp;
				j=p;
			}
			lr[j]=l;*/
			lr[i]=lr[lcnt];
			lr[lcnt++]=l;
		}
		for (let i=(lcnt>>1)-1;i>=0;i--) {
			let l=lr[i],s=l.sort,p=i,j;
			while ((j=p+p+1)<lcnt) {
				swaps++;
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=s) {break;}
				lr[p]=lr[j];
				p=j;
			}
			lr[p]=l;
		}
		console.log("swap:",swaps,lcnt);
		while (true) {
			// Test heap properties.
			idused.fill(1);
			let cnt=0;
			for (let i=0;i<alloc;i++) {
				let l=lr[i],id=l.id;
				cnt+=idused[id];
				idused[id]=0;
				if (i>0 && i<lcnt) {
					let p=(i-1)>>1,lp=lr[p];
					if (lp.sort>l.sort) {
						throw "not sorted: "+lp.sort+", "+l.sort;
					}
				}
			}
			if (cnt!==alloc) {
				throw "object missing: "+cnt+" / "+alloc;
			}
			if (lcnt===0 || lr[0].sort>=maxval) {break;}
			// Modify top value.
			let l=lr[0];
			let type=rnd.modu32(4);
			let mod=[1,2,100,maxval-l.sort+10][type];
			l.sort+=rnd.modu32(mod);
			// Heap sort down.
			let i=0,j;
			while ((j=i+i+1)<lcnt) {
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=l.sort) {break;}
				lr[i]=lr[j];
				i=j;
			}
			lr[i]=l;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Bounding Boxes


function AABBCheck0(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if any lines intersect.
	let imglines=[
		[0,0,imgwidth,0],
		[imgwidth,0,imgwidth,imgheight],
		[imgwidth,imgheight,0,imgheight],
		[0,imgheight,0,0]
	];
	let polylines=[
		[bndx,bndy,bndx+bnddx0,bndy+bnddy0],
		[bndx+bnddx0,bndy+bnddy0,bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1],
		[bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1,bndx+bnddx1,bndy+bnddy1],
		[bndx+bnddx1,bndy+bnddy1,bndx,bndy]
	];
	for (let il=0;il<4;il++) {
		let [i0x,i0y,i1x,i1y]=imglines[il];
		i1x-=i0x;
		i1y-=i0y;
		for (let pl=0;pl<4;pl++) {
			let [p0x,p0y,p1x,p1y]=polylines[pl];
			p1x-=p0x;
			p1y-=p0y;
			let den=i1x*p1y-i1y*p1x;
			p0x-=i0x;
			p0y-=i0y;
			let u=p0x*i1y-p0y*i1x;
			if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
				u=p0x*p1y-p0y*p1x;
				if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
					return true;
				}
			}
		}
	}
	// Either they are not overlapping, or one is entirely inside the other.
	let midx,midy;
	midx=bndx+(bnddx0+bnddx1)*0.5;
	midy=bndy+(bnddy0+bnddy1)*0.5;
	if (midx>=0 && midx<=imgwidth && midy>=0 && midy<=imgheight) {
		return true;
	}
	midx=imgwidth*0.5;
	midy=imgheight*0.5;
	let parity=0;
	for (let pl=0;pl<4;pl++) {
		let [p0x,p0y,p1x,p1y]=polylines[pl];
		p0x-=midx;
		p0y-=midy;
		p1x-=midx;
		p1y-=midy;
		let sign=p0x*p1y-p0y*p1x;
		if (sign<-1e-10) {parity--;}
		if (sign> 1e-10) {parity++;}
	}
	return parity===-4 || parity===4;
}


function AABBCheck1(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx+(bnddx0<0?bnddx0:0)+(bnddx1<0?bnddx1:0);
	let miny=bndy+(bnddy0<0?bnddy0:0)+(bnddy1<0?bnddy1:0);
	let maxx=bndx+(bnddx0>0?bnddx0:0)+(bnddx1>0?bnddx1:0);
	let maxy=bndy+(bnddy0>0?bnddy0:0)+(bnddy1>0?bnddy1:0);
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck2(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck3(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	if (bnddx0<0) {maxx-=ih*bnddx0;} else {minx-=ih*bnddx0;}
	if (bnddy0<0) {minx+=iw*bnddy0;} else {maxx+=iw*bnddy0;}
	if (bnddx1<0) {maxy-=ih*bnddx1;} else {miny-=ih*bnddx1;}
	if (bnddy1<0) {miny+=iw*bnddy1;} else {maxy+=iw*bnddy1;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck4(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1,tmp;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	tmp=ih*bnddx0; if (tmp<0) {maxx-=tmp;} else {minx-=tmp;}
	tmp=iw*bnddy0; if (tmp<0) {minx+=tmp;} else {maxx+=tmp;}
	tmp=ih*bnddx1; if (tmp<0) {maxy-=tmp;} else {miny-=tmp;}
	tmp=iw*bnddy1; if (tmp<0) {miny+=tmp;} else {maxy+=tmp;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck5(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-iw,maxx=bndx;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (maxx<=0 || 0<=minx) {return false;}
	let miny=bndy-ih,maxy=bndy;
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxy<=0 || 0<=miny) {return false;}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=bndy*bnddx0-bndx*bnddy0;maxx=minx;
	bnddx0*=ih;bnddy0*=iw;
	if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
	if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
	if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
	if (maxx<=0 || 0<=minx) {return false;}
	miny=bndy*bnddx1-bndx*bnddy1;maxy=miny;
	bnddx1*=ih;bnddy1*=iw;
	if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
	if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxy<=0 || 0<=miny) {return false;}
	return true;
}


function BoundingBoxTest() {
	console.log("testing bounding boxes");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&31)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf()*16-8);
		return ((type&32) || pos)?ret:-ret;
	}
	let tests=1000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let matchcnt=0;
	let difcnt=0;
	let overlap=0;
	for (let test=0;test<tests;test++) {
		let imgwidth=getrnd(true);
		let imgheight=getrnd(true);
		for (let i=0;i<6;i++) {trans[i]=getrnd();}
		for (let i=0;i<4;i++) {aabb[i]=getrnd(i>1);}
		let calc0=AABBCheck0(imgwidth,imgheight,aabb,trans);
		let calc1=AABBCheck1(imgwidth,imgheight,aabb,trans);
		let calc2=AABBCheck2(imgwidth,imgheight,aabb,trans);
		let calc3=AABBCheck3(imgwidth,imgheight,aabb,trans);
		let calc4=AABBCheck4(imgwidth,imgheight,aabb,trans);
		let calc5=AABBCheck5(imgwidth,imgheight,aabb,trans);
		if (calc0!==calc1 || calc0!==calc2 || calc0!==calc3 || calc0!==calc4 || calc0!==calc5) {
			difcnt++;
			/*console.log(calc0,calc1,test);
			console.log("image: ",imgwidth,imgheight);
			console.log("aabb : ",aabb);
			console.log("trans: ",trans);
			throw "x";*/
		} else {
			matchcnt++;
		}
		overlap+=calc0;
	}
	console.log("match  : "+matchcnt);
	console.log("dif    : "+difcnt);
	console.log("overlap: "+overlap);
	console.log("done");
}


function BoundingBoxSpeedTest() {
	console.log("testing bounding box speed");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&15)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf()*16-8);
		return ((type&16) || pos)?ret:-ret;
	}
	let randmask=(1<<20)-1;
	let rands=randmask+100;
	let randarr=new Float64Array(rands);
	let randabs=new Float64Array(rands);
	for (let i=0;i<rands;i++) {
		randarr[i]=getrnd();
		randabs[i]=Math.abs(randarr[i]);
	}
	let tests=10000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let overlap=0;
	let t0=performance.now();
	let r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck0(imgwidth,imgheight,aabb,trans);
	}
	let t1=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck1(imgwidth,imgheight,aabb,trans);
	}
	let t2=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck2(imgwidth,imgheight,aabb,trans);
	}
	let t3=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck3(imgwidth,imgheight,aabb,trans);
	}
	let t4=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck4(imgwidth,imgheight,aabb,trans);
	}
	let t5=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck5(imgwidth,imgheight,aabb,trans);
	}
	let t6=performance.now();
	console.log("overlaps: ",overlap);
	console.log("t0: "+(t1-t0).toFixed(6));
	console.log("t1: "+(t2-t1).toFixed(6));
	console.log("t2: "+(t3-t2).toFixed(6));
	console.log("t3: "+(t4-t3).toFixed(6));
	console.log("t4: "+(t5-t4).toFixed(6));
	console.log("t5: "+(t6-t5).toFixed(6));
	console.log("done");
}


function BoundingBoxDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	let subimg=new Draw.Image(250,200);
	let trans=new Draw.Transform();
	let rnd=new Random();
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpoly.toString();
	Draw.colbnd=[0,0,0,0,0,0];
	Draw.colret=-1;
	func=func.replace("aabb.dy*matyy;",`aabb.dy*matyy; Draw.colret=0;
	                   Draw.colbnd=[bndx,bndy,bnddx0,bnddy0,bnddx1,bnddy1];`);
	for (let i=1;i<10;i++) {func=func.replace("return;","Draw.colret="+i+";return ;");}
	Draw.prototype.fillpoly=parsefunction(func);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let mpos=input.getmousepos();
		let mx=mpos[0];
		let my=mpos[1];
		if (mx===-Infinity) {mx=0;}
		if (my===-Infinity) {my=0;}
		draw.savestate();
		draw.settransform(trans);
		draw.setcolor(255,0,0,255);
		draw.filloval(mx,my,100,50);
		let imgx=(draw.img.width-subimg.width)*0.5;
		let imgy=(draw.img.height-subimg.height)*0.5;
		draw.savestate();
		draw.setimage(subimg);
		draw.fill(128,128,128,255);
		draw.setcolor(200,0,0,255);
		draw.filloval(mx-imgx,my-imgy,100,50);
		let ret=Draw.colret;
		let aabb=Draw.colbnd.slice();
		draw.loadstate();
		draw.drawimage(subimg,imgx,imgy);
		draw.loadstate();
		draw.setcolor(255,255,255,255);
		let x0=aabb[0]+imgx,y0=aabb[1]+imgy;
		let x1=x0+aabb[2],y1=y0+aabb[3];
		let x2=x1+aabb[4],y2=y1+aabb[5];
		let x3=x0+aabb[4],y3=y0+aabb[5];
		draw.drawline(x0,y0,x1,y1);
		draw.drawline(x1,y1,x2,y2);
		draw.drawline(x2,y2,x3,y3);
		draw.drawline(x3,y3,x0,y0);
		draw.filltext(10,10,"col: "+ret);
		ctx.putImageData(draw.img.imgdata,0,0);
		if (input.getkeyhit(input.MOUSE.LEFT)) {
			trans.setangle(rnd.getf()*Math.PI*2);
			trans.setscale((rnd.getf()*2-1)*2,(rnd.getf()*2-1)*2);
			trans.setoffset((rnd.getf()*2-1)*50,(rnd.getf()*2-1)*50);
		}
	}
	update();
}


//---------------------------------------------------------------------------------
// Article Demos


function PathToBlueprint(path,width,height) {
	let pad=Math.min(width,height)*0.05;
	let rad=3;
	let poly=new Draw.Poly(path);
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			minx=minx<v.x?minx:v.x;
			maxx=maxx>v.x?maxx:v.x;
			miny=miny<v.y?miny:v.y;
			maxy=maxy>v.y?maxy:v.y;
		}
	}
	let dim=Math.min(width*0.35,height)-2*pad;
	maxx-=minx;
	maxy-=miny;
	let norm=dim/(maxx>maxy?maxx:maxy);
	pad=width*0.1;
	let offx=(width*0.5-pad-maxx*norm)*0.5+pad;
	let offy=(height-maxy*norm)*0.5;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			v.x=Math.floor((v.x-minx)*norm+offx);
			v.y=Math.floor((v.y-miny)*norm+offy);
		}
	}
	let px=0,py=0;
	let lines=0,curves=0;
	let control="",points="";
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		switch (v.type) {
			case Draw.Poly.CLOSE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				break;
			case Draw.Poly.MOVE:
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.LINE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.CURVE:
				curves++;
				// points+='\t\t<circle cx={0} cy={1} r={2} />\n'.format(v.x,v.y,rad);
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				px=v.x;
				py=v.y;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
		}
		px=v.x;
		py=v.y;
	}
	let ret=`<svg version="1.1" viewBox="0 0 ${width} ${height}" class="diagram" style="background:#000000">\n`;
	ret+='\t<g class="dimstroke" stroke-width=1>\n'+control+'\t</g>\n';
	ret+='\t<path d="'+poly.tostring(0)+'" fill="none" class="highstroke" />\n';
	ret+='\t<g class="highstroke highfill">\n'+points+'\t</g>\n';
	let off=width*0.5-pad;
	for (let i=0;i<poly.vertidx;i++) {
		poly.vertarr[i].x+=off;
	}
	ret+='\t<path d="'+poly.tostring(0)+'" class="forefill" stroke="none" />\n';
	ret+="</svg>\n";
	console.log(ret);
	console.log("lines : ",lines);
	console.log("curves: ",curves);
}

// Cat
/*
PathToBlueprint(`
M 0 0 L 250 250 L 750 250 L 1000 0 L 1000 700 L 500 1000 L 0 700 Z
M 500 683 L 394 727 L 396 732 L 500 689 L 604 732 L 606 727 Z
M 190 398 C 207 487 327 512 395 450 Z
M 605 450 C 673 512 793 487 810 398 Z
`,1000,400);
*/
// g
/*
PathToBlueprint(`
M 538 267 L 538 340 L 454 340 C 467 353 485 385 485 433 C 485 548 395 614 284
614 C 239 614 212 607 177 590 C 166 605 154 622 154 646 C 154 673 182 690 218
692 L 372 698 C 467 702 536 750 536 828 C 536 933 439 1000 281 1000
C 156 1000 48 966 48 866 C 48 806 85 771 120 745 C 103 739 68 711 68 662
C 68 620 90 585 122 548 C 93 516 80 486 80 438 C 80 333 160 258 282 258
C 315 258 332 262 350 267 Z
M 282 547 C 350 547 395 497 395 436 C 395 385 363 325 282 325
C 238 325 171 353 171 436 C 171 524 245 547 282 547 M 200 770
C 176 788 143 810 144 857 C 143 911 216 930 289 929 C 400 928 441 879 440 838
C 439 794 397 776 339 775 Z
`,1000,400);
*/

function SegmentDemo() {
	const points=[[0,1000],[650,500],[-650,500],[0,0]];
	let [p0x,p0y]=points[0];
	let [c1x,c1y]=points[1];
	let [c2x,c2y]=points[2];
	let [c3x,c3y]=points[3];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	for (let s=0;s<2;s++) {
		let segs=[4,16][s];
		console.log("segments:",segs);
		let px=p0x,py=p0y;
		let out="";
		for (let i=1;i<=segs;i++) {
			let u=i/segs;
			let cpx=Math.floor(p0x+u*(c1x+u*(c2x+u*c3x)));
			let cpy=Math.floor(p0y+u*(c1y+u*(c2y+u*c3y)));
			out+=`\t\t<line x1=${px} y1=${py} x2=${cpx} y2=${cpy} />\n`;
			px=cpx;
			py=cpy;
		}
		console.log(out);
	}
}
// SegmentDemo();


//---------------------------------------------------------------------------------
// Fonts


function FontFit(fontpath,erroraccept={}) {
	// See how closely a font matches reference images.
	let fontdef=_DrawFont.deffont;
	let glyphs={};
	let fontidx=0,fontlen=fontdef.length;
	function token(eol) {
		let c;
		while (fontidx<fontlen && (c=fontdef.charCodeAt(fontidx))<=32 && c!==10) {fontidx++;}
		let i=fontidx;
		while (fontidx<fontlen && fontdef.charCodeAt(fontidx)>eol) {fontidx++;}
		return fontdef.substring(i,fontidx);
	}
	token(10); fontidx++; // name
	token(10); fontidx++; // info
	let scale=parseFloat(token(10));
	let special={"SPC":32};
	let loaded=0;
	while (fontidx<fontlen) {
		fontidx++;
		let chr=token(32);
		if (chr.length<=0) {continue;}
		chr=special[chr]??chr.charCodeAt(0);
		let g={};
		g.width=parseInt(token(32));
		g.path=token(10);
		g.poly=new Draw.Poly(g.path);
		g.chr=String.fromCharCode(chr);
		g.num=chr;
		g.img=null;
		// Queue loading the images.
		let img=new Image();
		img.onload=function() {
			g.img=img;
			loaded--;
		};
		img.onerror=function() {
			loaded--;
		};
		img.src=fontpath+g.num.toString().padStart(3,"0")+".png";
		glyphs[g.num]=g;
		loaded++;
	}
	// Once all images have loaded (or failed), process them.
	function process() {
		console.log("loading font:",loaded);
		if (loaded>0) {
			setTimeout(process,1);
			return;
		}
		let draw=new Draw();
		let font=new Draw.Font();
		draw.setfont(font);
		let fonterr=0;
		let fontder=0;
		let dercutoff=Math.cos(-0.15*Math.PI);
		let adjust=true;
		for (let g of Object.values(glyphs)) {
			console.log("processing:",g.num,g.chr);
			let img=g.img;
			if (img===null) {
				console.log("Image file not found");
				throw "error";
			}
			let iw=img.width,ih=img.height,pixels=iw*ih;
			if (iw!==g.width || ih!==scale) {
				console.log("width :",iw,g.width);
				console.log("height:",ih,scale);
				// Print the rescaled polygon.
				let mul=iw!==g.width?iw/g.width:ih/scale;
				for (let v of g.poly.vertarr) {v.x*=mul;v.y*=mul;}
				console.log("scaled:",g.poly.tostring(0));
				throw "dimensions mismatch";
			}
			// Get the alpha values from the source image.
			let canv=document.createElement("canvas");
			let ctx=canv.getContext("2d");
			canv.width=iw;
			canv.height=ih;
			ctx.drawImage(img,0,0);
			let srcpix=ctx.getImageData(0,0,iw,ih).data;
			canv.remove();
			// See how the pixels differ.
			let dstimg=new Draw.Image(iw,ih);
			draw.setimage(dstimg);
			draw.fill(0,0,0,255);
			draw.setcolor(255,255,255,255);
			draw.filltext(0,0,g.chr,ih);
			let dstdata=dstimg.data8;
			let sumerr=0;
			for (let i=0;i<pixels;i++) {
				let j=i*4;
				let srcc=(srcpix[j+0]+srcpix[j+1]+srcpix[j+2])/(3*255);
				let dstc=dstdata[j+0]/255;
				let u=dstc-srcc;
				sumerr+=Math.abs(u);
				dstdata[j+0]=u<0?Math.round(-u*255):0;
				dstdata[j+1]=0;
				dstdata[j+2]=u>0?Math.round(u*255):0;
				dstdata[j+3]=255;
			}
			fonterr+=sumerr;
			// Find any consecutive curves that don't have parallel derivatives.
			let paths=g.path.split("M");
			let sumder=0;
			for (let j=1;j<paths.length;j++) {
				let path="M"+paths[j];
				let poly=new _DrawPoly(path);
				let vidx=poly.vertidx;
				let varr=poly.vertarr;
				let skip=0;
				for (let k=0;k<vidx;k++) {
					let v0=varr[k?k-1:(vidx-2)];
					let v1=varr[k];
					let v2=varr[k+1<vidx?k+1:1];
					// Allow any derivative for line->line.
					if (v0.type!==_DrawPoly.CURVE && v1.type!==_DrawPoly.CURVE && v2.type!==_DrawPoly.CURVE) {continue;}
					if (v1.type===_DrawPoly.CURVE && !skip) {k++;skip=1;continue;}
					skip=0;
					let dx0=v1.x-v0.x,dy0=v1.y-v0.y,l0=dx0*dx0+dy0*dy0;
					let dx1=v2.x-v1.x,dy1=v2.y-v1.y,l1=dx1*dx1+dy1*dy1;
					let len=l0*l1;
					let dot=dx0*dx1+dy0*dy1,dot2=dot*dot;
					dot/=Math.sqrt(len);
					if (dot>dercutoff && dot2<len) {
						// console.log("sub  :",path);
						console.log("dot  :",dot);
						console.log("coord:",v0.x,v0.y,v1.x,v1.y,v2.x,v2.y);
						console.log("dif  :",dx0,dy0,dx1,dy1);
						sumder++;
					}
				}
			}
			// Error out if we're too off.
			let accept=erroraccept[g.chr]??[0.002,0];
			let limitpix=accept[0]*pixels;
			let limitder=accept[1];
			console.log("err: "+sumerr.toFixed(3)+" / "+limitpix.toFixed(3));
			console.log("der: "+sumder.toString()+" / "+limitder);
			// console.log((new Draw.Poly()).addoval(361,116,67,67).tostring(0));
			if (sumerr>limitpix || sumder>limitder) {
				// Display a heatmap of differences.
				let canv=document.createElement("canvas");
				document.body.appendChild(canv);
				canv.style.background="#000000";
				canv.style.position="absolute";
				canv.style.top="0px";
				canv.style.left="0px";
				canv.width=g.width;
				canv.height=scale;
				canv.style.width=canv.width+"px";
				canv.style.height=canv.height+"px";
				let ctx=canv.getContext("2d");
				ctx.putImageData(dstimg.imgdata,0,0);
				throw "err too great";
			}
		}
		console.log("font err: "+fonterr.toFixed(6));
		console.log("font der: "+fontder);
		console.log("done");
	}
	process();
}


function FontDemo() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.fill(0,0,0,255);
	draw.setcolor(255,0,0,255);
	let text=
		"████████████████████████████████████\n"+
		"█ !\"#$%&'()*+,-./0123456789:;<=>? █\n"+
		"█ @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^ █\n"+
		"█ `abcdefghijklmnopqrstuvwxyz{|}~ █\n"+
		"█ █                               █\n"+
		"████████████████████████████████████";
	draw.filltext(400,200,text);
	draw.setcolor(255,255,255,255);
	text="hello\b\b\b\b\bworld";
	// draw.filltext(400,500,text);
	ctx.putImageData(draw.img.imgdata,0,0);
}


//---------------------------------------------------------------------------------
// Stress Tests


function OvalStressTest() {
	// console.log("testing ovals");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.filloval(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("ovals: "+time.toFixed(6));
	// console.log("done");
}


function LineStressTest() {
	// console.log("testing lines");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=200000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x0=(rnd.getf()*3-1)*imgwidth;
		let y0=(rnd.getf()*3-1)*imgheight;
		let x1=(rnd.getf()*3-1)*imgwidth;
		let y1=(rnd.getf()*3-1)*imgheight;
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.modu32(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		draw.thickness=rnd.getf()*10;
		draw.drawline(x0,y0,x1,y1);
	}
	time=(performance.now()-time)/1000;
	console.log("lines: "+time.toFixed(6));
	// console.log("done");
}


function CharStressTest() {
	// console.log("testing characters");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=2000000;
	let text=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~█";
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		let c=text[test%text.length];
		let s=rnd.getf()*32;
		draw.filltext(x,y,c,s);
	}
	time=(performance.now()-time)/1000;
	console.log("chars: "+time.toFixed(6));
	// console.log("done");
}


function ImageStressTest() {
	let rnd=new Random(10);
	let draw=new Draw();
	let images=10;
	let imgarr=new Array(images);
	draw.setcolor(0,0,0,255);
	let amask=draw.rgba32[0],nmask=(~amask)>>>0;
	for (let i=0;i<images;i++) {
		let w=i>0?Math.floor(Math.pow(2,i*1.10)+1):0;
		let h=i>0?Math.floor(Math.pow(2,i*1.13)+1):0;
		let img=new Draw.Image(w,h);
		imgarr[i]=img;
		let data32=img.data32,datalen=data32.length,col;
		for (let j=0;j<datalen;j++) {
			col=rnd.getu32();
			switch (rnd.modu32(4)) {
				case 0: col&=nmask; break;
				case 1: col|=amask; break;
				default: break;
			}
			data32[j]=col;
		}
	}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dstimg=imgarr[rnd.modu32(images)];
		let srcimg=imgarr[rnd.modu32(images)];
		draw.setimage(dstimg);
		draw.rgba32[0]=rnd.getu32();
		let w=rnd.modu32(srcimg.width*2);
		let h=rnd.modu32(srcimg.height*2);
		let x=(rnd.getf()*3-1)*dstimg.width;
		let y=(rnd.getf()*3-1)*dstimg.height;
		draw.drawimage(srcimg,x,y,w,h);
	}
	time=(performance.now()-time)/1000;
	console.log("image: "+time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	/*if (Draw.wasmloading===0) {
		setTimeout(TestMain,1);
		console.log("loading wasm");
		return;
	}*/
	console.log("starting polygon tests");
	// AreaTest1();
	// AreaClipTest();
	// AreaCacheTest();
	// StrideTest();
	// StrideTest2();
	// BlendTest1();
	// BlendTest2();
	// BezierParamTest();
	// BezierLengthTest();
	// BezierSegmentTest();
	// BezierSegmentDemo();
	// TraceDemo();
	// HeapSortTest();
	// BoundingBoxTest()
	// BoundingBoxSpeedTest();
	// BoundingBoxDemo();
	// FontFit("./extra/font/",{"@":[0.003,1],"g":[0.002,1],"m":[0.002,2]});
	// FontDemo();
	// OvalStressTest();
	// LineStressTest();
	// CharStressTest();
	// ImageStressTest();
	console.log("done");
}

window.addEventListener("load",TestMain);

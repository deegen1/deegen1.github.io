function drawimage6(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const rnd0=1e-6,rnd1=1-rnd0;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-8 && dstw && dsth)) {return;}
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=Infinity,max=-Infinity;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,y0=vy;
		vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0<dstw && x1>=0)) {continue;}
		let dx=x1-x0,dy=y1-y0;
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>dstw?((dstw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	min+=rnd0;max+=rnd1;
	if (!(min<dsth && max>=1)) {return;}
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxy=(invyx>0?invyx:0)+(invyy>0?invyy:0);
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		min=Infinity;max=-Infinity;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,y0=vy;
			vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			let x1=vx,y1=vy;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (y0>=1 || y1<=0) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		min+=rnd0;max+=rnd1;
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			min=srcx0+pixminx;let srcminx=min>0?~~min:0;
			min=srcy0+pixminy;let srcminy=min>0?~~min:0;
			max=srcy0+pixmaxy;let srcmaxy=max<srch?Math.ceil(max):srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcw;srcx++) {
					let sx=srcx0-srcx,sy=srcy0-srcy,area=0;
					min=srcw;max=-1;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						min=min<x0?min:x0;
						max=max>x1?max:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (max<=0) {break;}
					if (min>=1) {srcx+=(~~min)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[srcrow+srcx];
					let smul=area*((col>>>ashift)&255);
					sr+=smul*((col>>>rshift)&255);
					sg+=smul*((col>>>gshift)&255);
					sb+=smul*((col>>>bshift)&255);
					sa+=smul;
					if (max<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}

	// [WASM ENTRY]. Use to insert WASM version of fillpoly.



	// Override fillpoly().
	let func=Draw.prototype.fillpoly.toString();
	let idx=func.search("\\[WASM ENTRY\\]");
	if (idx<0) {
		console.log("Could not find [WASM ENTRY] in fillpoly().");
		Draw.wasmloading=2;
		return;
	}
	func=func.substring(0,idx)+`
		//
		let wasm=this.wasm;
		if (wasm===undefined) {
			wasm=this.wasminit();
		}
		if (!Object.is(imgdata,wasm.imgdata) || iw!==wasm.width || ih!==wasm.height) {
			this.wasmimage(this.img);
		}
		let vidx=poly.vertidx,varr=poly.vertarr;
		if (vidx>wasm.vertmax) {
			wasm.vertmax=vidx;
			this.wasmresize(0);
		}
		let tmpf64=wasm.tmpf64;
		let tmpu32=wasm.tmpu32;
		// transform [0-48]
		tmpf64[0]=matxx;
		tmpf64[1]=matxy;
		tmpf64[2]=matx;
		tmpf64[3]=matyx;
		tmpf64[4]=matyy;
		tmpf64[5]=maty;
		// color [48-52]
		tmpu32[12]=this.rgba32[0];
		// path [52-...]
		tmpu32[13]=vidx;
		let idx=7;
		for (let i=0;i<vidx;i++) {
			let v=varr[i];
			tmpu32[idx+idx]=v.type;
			idx++;
			tmpf64[idx++]=v.x;
			tmpf64[idx++]=v.y;
		}
		wasm.exports.fillpoly();
	}`;
	// console.log(func);
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	Draw.prototype.fillpoly=parsefunction(func);

function drawimage4(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+1;
	let pixmaxy=invyx+invyy-pixminy+1;
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx=srcx0-srcx,sy=srcy0-srcy;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[row+srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					if (maxc<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}
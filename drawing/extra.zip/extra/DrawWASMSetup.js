async function DrawWASMSetup() {
	// Attempt to load the WebAssembly program.
	// fill_wasm.c -> compile -> gzip -> base64
	if (Draw.wasmloading!==undefined) {return;}
	Draw.wasmloading=0;
	let wasmstr=`
		H4sIANk4SWcC/41YTWwb1xHe5ZIUpRW9KydKllyKnPckOkpsKxJjW5RjWVrDqZ3+OIcihwABGImkHFG0
		JEu026RGpLRGkFtPPdQnkrJhwEl6VY5BL83Rpxbope6tt+ZSoIei7jdvV9ylYjmVvZz3O29m3sw3s6st
		bd/QNU3TM8kPYjs72gf6HTygGv7rOx/on2ixsmHU128P/wJLN7dW11ur585oWv/QCoZ0Hhrioa369urH
		dS1mJBOGEU/o+L+p63rC0DU9OTWwo3u7u3FzR3su0fhHNwe+1dPJG/UbG1sfxbSRSoX5V6pLzWal2trY
		2tYMs7Z8vSdWstdjiQbM6/XWh/WlzeWl7bqWSK2sNpubG82PtLhZqfB4hScMPVOprK7XVrfq1VZl5dZ6
		tbW6sV5pLS0367o2XKnUtjcqHy6t15p1IzaE7lJrqVJfrxlGulK53txYXmr6fOLo+5L6/QT2Ki5+Nzn0
		2SuJmGb+9cSQuZO8o6sndiexk7sT/yS2A73v7mqe1fA2b0ptMqZJnUBSMsYkLo2mjHuxlueqBQnSGjLp
		nWnwwgHPaXp/0niCkg2ZWvMea+tikJLeNM+LIUqeNDRhYoAa3BqOLcYWaSCtXdaCP5H2NJEMu8fCphU2
		7WGdmZQbYoQggZfaUuyOY2xStV5Ay1GtF9GyVWuUYvviJTL2xcv9Z9jPPONYv0yOsUiWyJAtsjRCDjRt
		yISXakhX5CiBI+SYyEOZBBui4BlX0hqGv9EaIg8KSXmVb4aCSS9QDiJJm17s0jDluU3ddltYNEo2mV06
		TqpvKwMVwMsSaZx9DIpjACb9CcZ02Ldh/3p3d1ej4KYObG5SCoo/1iBljqw5w6Ec2XOGDZKZM1Ig2TlD
		wxK9ocQOJB4ll2URvghj3JYsB2Em4V+aHPcnE76p5QTPF2GRWEM44JTt2a3+Fjja/V3q7xbDblpplqWX
		V9S2gFJAi6BYAcMJ32ZKLIH+uN9XYkhwyPSfYPV3RX9XHj4/Qy+p86yAioBKUD4/d2nX//v3wqwxja42
		a0xiX9Lbgf3Yr4ZjJlaLTsA5tdiV6FImOnCiI17BEZkOyY6YhHIUnUWXstGBVzviNVgk26FiR5wMJr5b
		EKdCFyU4yGnKiHE4yRRlxQTcdYomOrhK0aXTNN6BFLCZeJ3kPTFN4p6YCXeXoIGgU6EYjxe68g2itiT1
		d7JLr7W79CqebFueYb5nuxRM0mSXXsHMCTyZtjzHZ8122zK829pbvQiH1CXo+3rVv9TX90TJPJh6KsIt
		ohw258Lm+bD5JmSeoVKXzrblWYI409yZbcsSKH57XPl0Oifm6Iw4TyTepJIomkrh52tYeq6GZ3HG7BEa
		lmk20HCWNSzzaUUIW+5SyZcPwpaV5IGw1WfJePh+jhS3zOJOHCXuGyyuwCnyyAuRgbjSv5BAXIg50VZu
		49tWtJU34VctfgPilgNxhW/S4uVfvfiHK3//+O5CLRrd3+2oDT1EYiAUBSCI0wjAUyQUquV/ENUK9Cbj
		Vo7mmCToPJMU5QPGdGoOUZmg04x4CV47CTLFwJfgLamDLYjXhkhiH+OfqXBQovtOWo+IedKYFqcIZBLx
		BeIgxEBSiDIQDrQEJ5aJYc00KS+SJlAQfBwaeDuNIYXdx8hehlJpspbSR2B3NONyftAj4J2gtK/KMV8H
		y9fB7oF30lToY7R6e1RabnBqckj/GY5y/GPUQr6HIc+5ve9fzZONxT05fQ/3G3pblYbD9rYrx++J4wC2
		Ap4csqcsRaOQk6oUUSwpA3lSVMDpSBAyT+MsqsN2ysI8yJOcYYSljOOwlGN+JkRKbchBlQlrEDKLXGth
		i42cSH7Cd1h7jVw/dY0RMRn0bZGn40w4Q5Ow/EyS6XBALKtsYnWAR7/784l/mFMjF5VzOkhnmC7uSck7
		BRbZJGoy78qJSNZ4IM1Ob2NVZQSrwyGRaeOIvMspGlnDwlCHaWg6V85RaUXm/XRWUmmkJEZZk5I6DJOu
		K7PozYGRtKtiTFmlxIkBSWCvx4vo96HwbpcsoCuZvAkT/pInnooxeiTyOMHjFPVL9uwiTZDrigkYsgje
		Y7yIvX4/osYDRC8BRGrCRdgT5OBs8wCWB7kv+G6+RVWnnYtpZFC+yRWDivaefBGsh0aHZMo+EoOhTIPq
		KJapzIfRmCtmUF1YD+BL58m+D0RJUA4O3cClDja+ukSfkfPV3VmOenb4HECAYwcAwkEskwg1bCytcPkS
		SecaBkd5ELjLJMeiBJwvPT34Q/rWoAo432Zmecq9k9bgwQkYCQtfhateQGhzYQOrtVDZ6VsACl7Fw2pl
		AaUPl3xquZzHSPKgc5Hm6eLPZcrF8IX3AC4J2JJVm2d9oAFhyokyVsjRW3aBl+UDyfypIe/pp/8ZuImy
		esjb/a9xU+pe6rbQKP6lWECIxqJoIiCeEuMSff5QQl5vRwyEoRqWSqJoLMbUPxh94CqHB8WvpeMgxg0Z
		g93JaEa3RjJ1hhzlc9FiJE/OVS6XBshYQ40OnmtkIPT3cemowicia42DYy8+lMnJ2FXp8PF4USCEBr8v
		SItUI6XKmS4KmbYc72UWnnF45ngvodWk4waVs0RgimhIWqgXscNGWnMAbTVVWZs0LiyOS8BNG1Ak4fey
		Bh6UvQcIGhcBlluHHNt6JJzQsR2TOU/KUcru9XLtExRS4xDChSXx/Njd70Ct7D050+0ivsJiuQZ/ZkgQ
		KXVUWDZHmogt+5AI9iMxFoowZkYAiAouTojjDsYa7GaFL8U8QKPcUZDlkrJzJmKeBxTa8H6HRruc7hkC
		2t1QG+gSCrQCgTptkUHNC5YGOT/lq6PCudhVEKA1Mg4BXssgM4w2423ADqdovEI1II8JAcbZ2gBPQCIW
		dI9SvN2BpxW5YC7yVRXZ2GV+88hwa7rNfsgaorMobDPw5nlaeA8yzTOKXFRhb/3mrrjgv0blOLByaS0C
		B+ICpzl+3+M6PoALmfRxINmPGyYvw4rY26ryRxiLpAIEVU0cBQiAhHd/ABAKYAs8aEUggQrsXwT/5FKk
		Dx2iIe5cUxiRgRMX2ygXRcbPs3ACPFddysuUKnXWGHCu8W2p2I143ObCiqdv916j0L3SW9YbUxlqr+ct
		bfh0Yb8a5IVn4L8b+qhrwvcKyF34yfY4wJOgPL8sF/apyGlJZMyoTMwIhYUXw3V43jDKBv9F27kt3a+5
		TkANg6fqBqWF6z3VfxS+/6HQ6fYO49SX5Tr28vu//eO/Jt//20IbHA5W/vMblLp7l+9vzg/9ZWBzse1D
		w0FcbX7TjU75wNDTw6tGQnrlptL+C197TWnuOS3gYQGQDflukrYmhnxoiXCwDnGwohzGaIjcJukNBf40
		sgVmKiHQ4BomwBhJ0x/Z4nyNovaaKkBQULRZTY/L7WQkY7NHpbydbco3hGtw4TTND1uSkj0jp74OIDUF
		wa9EXqwPGSRiq+/Z3D5kc/s5Njf7YJDNYh8yi/2FSPlmSaFgZsOO9Rl25P8xbMghy+GCRANoSoX2Heuz
		b+oZ9vXibE6XocR9K63zu4BppoKi3hzBOwxHJmkP7V1VhQ9hxP5UNbXP9fj60o26fiOl9X3W1Pu+aMYi
		HzON7396jPe+Jyai3xmT0Q+SA9HvkQPHdc2qVLZbS9W1yuYGButbWnlwc2ujdqta39rWh9Gs1re367XT
		yx/pw+8u31pv3aJqc2n9+sjMmanpqenTM7fU4MzUzP8A9mL6dLoVAAA=
	`;
	let gzipbytes=Uint8Array.from(atob(wasmstr),(c)=>c.codePointAt(0));
	let gzipstream=new Blob([gzipbytes]).stream();
	let decstream=gzipstream.pipeThrough(new DecompressionStream("gzip"));
	let decblob=await new Response(decstream).blob();
	let wasmbytes=new Uint8Array(await decblob.arrayBuffer());
	// Compile module.
	let module=new WebAssembly.Module(wasmbytes);
	if (!module) {
		console.log("could not load module");
		Draw.wasmloading=1;
		return;
	}
	// console.log("loading module");
	Draw.wasmmodule=module;
	// Set up class functions.
	Draw.prototype.wasmprinti64=function(h,l) {
		let s="Debug: "+((BigInt(h>>>0)<<32n)+BigInt(l>>>0))+"\n";
		console.log(s);
	};
	Draw.prototype.wasmprintf64=function(x) {
		let s="Debug: "+x;
		console.log(s);
	};
	Draw.prototype.wasmimage=function(img) {
		// console.log("setting image");
		let wasm=this.wasm,old=wasm.img;
		if (old!==null && !Object.is(old,img)) {
			// Generate a new copy for the old image.
			let width=old.width,height=old.height,copy=true;
			if (width<1 || height<1) {
				width=1;
				height=1;
				copy=false;
			}
			old.data8  =new Uint8Array(width*height*4);
			old.datac8 =new Uint8ClampedArray(old.data8.buffer);
			old.data32 =new Uint32Array(old.data8.buffer);
			old.imgdata=new ImageData(old.datac8,width,height);
			if (copy) {old.data32.set(wasm.imgdata);}
		}
		wasm.img=img||null;
		this.wasmresize(0);
	};
	Draw.prototype.wasmresize=function(bytes) {
		// console.log("resizing to: "+bytes);
		if (!bytes) {bytes=0;}
		let wasm=this.wasm;
		let img=wasm.img;
		if (img!==null) {
			wasm.width=img.width;
			wasm.height=img.height;
		} else {
			wasm.width=0;
			wasm.height=0;
		}
		let align=15;
		let imglen=(12+wasm.width*wasm.height*4+align)&~align;
		let pathlen=(6*8+4+4+24*wasm.vertmax+align)&~align;
		let heaplen=(wasm.heaplen+align)&~align;
		let sumlen=heaplen+imglen+pathlen;
		if (bytes && sumlen<bytes) {sumlen=bytes;}
		let newlen=1;
		while (newlen<sumlen) {newlen+=newlen;}
		let pagebytes=65536;
		let wasmmem=wasm.instance.exports.memory;
		let pages=Math.ceil((newlen-wasmmem.buffer.byteLength)/pagebytes);
		if (pages>0) {wasmmem.grow(pages);}
		let memu32=new Uint32Array(wasmmem.buffer,heaplen);
		wasm.memu32=memu32;
		memu32[0]=wasmmem.buffer.byteLength;
		memu32[1]=wasm.width;
		memu32[2]=wasm.height;
		wasm.imgdata=null;
		if (img!==null) {
			// Rebind the image pixel buffer.
			let width=img.width;
			let height=img.height;
			if (width<1 || height<1) {
				width=1;
				height=1;
			}
			let pixels=width*height;
			let buf=wasmmem.buffer,off=heaplen+12;
			wasm.imgdata=new Uint32Array(buf,off,pixels);
			if (img.data32.buffer.byteLength>0) {
				wasm.imgdata.set(img.data32);
			}
			img.data8  =new Uint8Array(buf,off,pixels*4);
			img.datac8 =new Uint8ClampedArray(buf,off,pixels*4);
			img.data32 =wasm.imgdata;
			img.imgdata=new ImageData(img.datac8,width,height);
		}
		wasm.tmpu32=new Uint32Array(wasmmem.buffer,heaplen+imglen);
		wasm.tmpf64=new Float64Array(wasmmem.buffer,heaplen+imglen);
		let dif=wasmmem.buffer.byteLength-wasm.tmpu32.byteOffset;
		wasm.vertmax=Math.floor((dif-(6*8+4+4))/24);
	};
	Draw.prototype.wasminit=function() {
		let con=this.constructor;
		let state=this;
		function wasmprinti64(h,l) {state.wasmprinti64(h,l);}
		function wasmprintf64(x)   {state.wasmprintf64(x);}
		function wasmresize(bytes) {state.wasmresize(bytes);}
		let imports={env:{wasmprinti64,wasmprintf64,wasmresize}};
		let inst=new WebAssembly.Instance(con.wasmmodule,imports);
		this.wasm={
			instance:inst,
			exports :inst.exports,
			heaplen :inst.exports.getheapbase(),
			memu32  :null,
			img     :null,
			imgdata :null,
			width   :0,
			height  :0,
			tmpu32  :null,
			tmpf64  :null,
			vertmax :0,
			fill    :inst.exports.fillpoly
		};
		this.wasmresize(0);
		return this.wasm;
	};
	Draw.prototype.fillpoly=function(poly,trans) {
		// Copy the path and image to webassembly memory for faster rendering.
		if (poly===undefined) {poly=this.defpoly;}
		trans=trans===undefined?this.deftrans:this.tmptrans.set(trans);
		let iw=this.img.width,ih=this.img.height,imgdata=this.img.data32;
		let alpha=this.rgba[3]/255.0;
		if (poly.vertidx<3 || iw<1 || ih<1 || alpha<1e-5) {return;}
		// Screenspace transformation.
		let vmulx=this.viewmulx,voffx=this.viewoffx;
		let vmuly=this.viewmuly,voffy=this.viewoffy;
		let matxx=trans.data[0]*vmulx,matxy=trans.data[1]*vmulx,matx=(trans.data[2]-voffx)*vmulx;
		let matyx=trans.data[3]*vmuly,matyy=trans.data[4]*vmuly,maty=(trans.data[5]-voffy)*vmuly;
		// Perform a quick AABB-OBB overlap test.
		// Define the transformed bounding box.
		let aabb=poly.aabb;
		let bndx=aabb.minx*matxx+aabb.miny*matxy+matx;
		let bndy=aabb.minx*matyx+aabb.miny*matyy+maty;
		let bnddx0=aabb.dx*matxx,bnddy0=aabb.dx*matyx;
		let bnddx1=aabb.dy*matxy,bnddy1=aabb.dy*matyy;
		// Test if the image AABB has a separating axis.
		let minx=bndx-iw,maxx=bndx;
		if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
		if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
		if (maxx<=0 || 0<=minx) {return;}
		let miny=bndy-ih,maxy=bndy;
		if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Test if the poly OBB has a separating axis.
		let cross=bnddx0*bnddy1-bnddy0*bnddx1;
		minx=bndy*bnddx0-bndx*bnddy0;
		maxx=minx;bnddx0*=ih;bnddy0*=iw;
		if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
		if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
		if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
		if (maxx<=0 || 0<=minx) {return;}
		miny=bndy*bnddx1-bndx*bnddy1;
		maxy=miny;bnddx1*=ih;bnddy1*=iw;
		if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
		if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Copy to webassembly.
		let wasm=this.wasm;
		if (wasm===undefined) {
			wasm=this.wasminit();
		}
		if (!Object.is(imgdata,wasm.imgdata) || iw!==wasm.width || ih!==wasm.height) {
			this.wasmimage(this.img);
		}
		let vidx=poly.vertidx,varr=poly.vertarr;
		if (vidx>wasm.vertmax) {
			wasm.vertmax=vidx;
			this.wasmresize(0);
		}
		let tmpf64=wasm.tmpf64;
		let tmpu32=wasm.tmpu32;
		// transform [0-48]
		tmpf64[0]=matxx;
		tmpf64[1]=matxy;
		tmpf64[2]=matx;
		tmpf64[3]=matyx;
		tmpf64[4]=matyy;
		tmpf64[5]=maty;
		// color [48-52]
		tmpu32[12]=this.rgba32[0];
		// path [52-...]
		tmpu32[13]=vidx;
		let idx=7;
		for (let i=0;i<vidx;i++) {
			let v=varr[i];
			tmpu32[(idx++)<<1]=v.type;
			tmpf64[idx++]=v.x;
			tmpf64[idx++]=v.y;
		}
		wasm.fill();
	};
	Draw.wasmloading=1;
	// console.log("wasm done");
}
DrawWASMSetup();
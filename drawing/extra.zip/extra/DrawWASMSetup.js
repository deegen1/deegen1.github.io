async function DrawWASMSetup() {
	// Attempt to load the WebAssembly program.
	// fill_wasm.c -> compile -> gzip -> base64
	if (Draw.wasmloading!==undefined) {return;}
	Draw.wasmloading=0;
	let wasmstr=`
		H4sIAGuNQmcC/41YTWwb1xHe5fJPWtG7cqJkyeXPvCfRUWJbkRjbohzL0hpO4/QnORQ5BAjAUCTliKIl
		WaLdJjUipTWK3HrqoT6RlJ0ATtKrcgx6aY45tcemt96SS4GiKOp+85biLmUrqezlvN95M/Nmvpldrbpz
		Q9c0TU/H34ns7mrv6HfwgGr4r+++o3+gRcqG0di4PfYLLN3aXttor104p2nDQ6sY0nlolIe2Gztr7ze0
		iBGPGUY0puP/lq7rMUPX9PhMYlf39vai5q72vUTjH91MfKWn4jcaNza334to45UK86/Uqq1Wpdbe3N7R
		DLO+cn0gVnzQY4kS5vVG+91GdWulutPQYsnVtVZra7P1nhY1KxUer/CEoacrlbWN+tp2o9aurN7aqLXX
		Njcq7epKq6FrY5VKfWez8m51o95qGJFRdKvtaqWxUTeMVKVyvbW5Um35fKLo+5L6/Rj2Ki5+Nz768XOx
		iGb++9SouRu/o6sncie2m70T/SCyC73v7mme1fS2bkptOqJJnUCSMsIkKo2WjHqRtueqBTHSmjLunWvy
		woTntLw/azxB8aZMrntfaxtihOLeLM+LUYqfNjRhYoCa3BqLLEeWKZHSrmr9P5HyNBEPuieCphU07TGd
		mZSbYpwggZfcVuxOYmxatZ5Cy1Gtp9GyVWuCIgfiGTIOxLPDZ9hPPOPEsEyOsUyWSJMtMjRODjRtypiX
		bEpXZCmGI2RO5KFMjA1R8IxXUxqGv9SaIg8KSXmVb4aCSU9RFiJJm57u0RjluU29TkdYNEE2mT06Sapv
		KwMVwMsSKZx9AopjACb9CcZ02Ldp/3pvb0+j/k0d2tykJBT/WoOUWbIWDIeyZC8YNkh6wUiCZBYMDUv0
		phK7L/EEuSyL8EXIcVuyHISZmH9pctKfjPmmllM8X4RFIk3hgFNmYLfGK+BoD3dpuFsMuimlWYaeXVXb
		+pT6tAiKFTCc8G2mxBLoT/p9JYYEh/TwCdZwVwx35dHz0/SMOs/qU9GnEpTPz17Z8//+tTRvzKKrzRvT
		2Bf3dmE/9quxiInVotvnnFzuSXQpHR441RXP4Yh0l2RXTEM5Cs+iS5nwwPNd8QIskulSsStO9ye+WxJn
		AhclOMhZSotJOMkMZcQU3HWGprq4StGjszTZhRSwmXiR5D0xS+KemAt2l6CBoDOBGF8v9eRLRB1J6u90
		j17o9Oh5PJmOPMd8z/eoP0nTPXoOM6fwpDvyAp813+vI4G7rrwwiHFKXoO+LNf9SX9wXJfNw6pEItohy
		0FwImheD5suQeY5KPTrfkecJ4sxyZ74jS6D4HXDl0+mCWKBz4iKReJlKomgqhb9fw9L3angeZ8wfo2GZ
		5vsazrOGZT6tCGHLPSr58kHYspK8L2ztSTIevZ9jxS2zuFPHifsSiytwijz2QmRfXOlfSF9ciDnVUW7j
		21Z0lDfhVy1+CeKW++IK36TFq796+o+v/v39u0v1cHR/t6s2DBCJgVAUgCBOsw+eIqZQLf+DqFaglxm3
		srTAJEYXmSQp32dMZxYQlTE6y4gX47XTIDMMfDHekjzcgnhtijj2Mf6ZCgclum+k9JCYp41ZcYZAphFf
		IA5CDCSJKAPhQItxYpka00yT8iJuAgXBx6HEaykMKew+QfYKlEqRVU0dg93hjMv5QQ+Bd4xSvionfB0s
		Xwd7AN5xU6GP0R7sUWm5yanJIf1nOMrxj1EL+R5GPef2gX8132wu78vZe7jfwNtqNBa0d1w5eU+cBLAV
		8GSRPWUpHIWcVKUIY0kZyJOkAk5HgpB5mmRRHbZTBuZBnuQMIyxlHIelzPmZECm1KUdUJqxDyAxyrYUt
		NnIi+QnfYe01cv3UlSNiMuLbIk8nmXCGJmH5mSTd5YBYUdnE6gKPfv+XU/8wZ8YvK+d0kM4wXdyXkncK
		LLJJ1GXelVOhrPFAmt3BxprKCFaXQyLdwRF5l1M0soaFoS7TwHSuXKDSqsz76ayk0khJTLAmJXUYJl1X
		ZtBbACNp10ROWaXEiQFJYH/Ai+gPgfBujyygK5m8CRP+km88FWP0UORxgscp6pfs2UWaItcVUzBkEbxz
		vIi9/iCkxgNELwFE6sJF2BPk4GzzAJYHuS/4br5CVaddiGhkUL7FFYOK9oF8IayHRkdkyjwUI4FMI+oo
		lqnMh1HOFXOoLqwH8KWLZN8HosQoC4du4lJHmp9fod+S8/ndeY56dvgsQIBjBwDCQSzjCDVsLK1y+RJK
		5xoGJ3gQuMsky6L0OV95dPiH9K1BFXC+zczylH0jpcGDYzASFj4PV72E0ObCBlZro7LTtwEUvIqH1coC
		Sh8u+dRyuYiR+GHnMi3S5Z/LpIvhS28BXGKwJau2yPpAA8KUE2askGOw7BIvy/cl86dGvUcf/idxE2X1
		qLf3X+Om1L3kbaFR9DOxhBCNhNFEQDwlxhX66BMJeb1dkQhCNSiVRNFYjqh/MHriGocHRV9PRUGMGzIC
		u5PRCm8NZeo0OcrnwsVInpxrXC4lyFhHjQ6e62Qg9A9w6ajCp0JrjcNjL38i49ORa9Lh4/GiQAgNfl+Q
		FqlGUpUzPRQyHTk5yCw84/DMyUFCq0vH7VfOEoEpwiFpoV7EDhtpzQG01VVlbdKksDguATcdQJGE38s6
		eFDmHiBoUvSx3Dri2NZD4QSO7ZjMeVpOUGZ/kGu/QSE1CSFcWBLPj92DLtTK3JNzvR7iKyiW6/BnhgSR
		VEcFZXOoidiyj4hgPxS5QIScGQIgKrg4IYo7yDXZzQqfiUWARrmrIMslZed0yDwPKLDh/S5N9DjdMwR0
		eoE20CUQaBUCdTsijZoXLA1yfspXR4ULkWsgQGtkHAK8lkHmGG0mO4AdTtF4hWpCHhMCTLK1AZ6ARCzo
		Had4pwtPK3LBXOSrKrKxy/zmkebWbIf9kDVEZ1nYZt+bF2npLci0yChyWYW99Zu74pL/GpXlwMqmtBAc
		iEuc5vh9j+v4PlzIuI8D8WHcMHkZVkReU5U/wljEFSCoauI4QAAkvPkDgFAAW+BBOwQJVGD/IvgnlyJD
		6BAOced1hRFpOHGxg3JRpP08CyfAc82lvEyqUmedAed1vi0VuyGP21pa9fSdwWsUuq8Olg3GVIbaH3hL
		Bz5dOKj188IT8N8NfNQ14XsF5C78ZAYc4ElQnl+WCwdU5LQk0mZYJmaEwsKL4Do8bwxlg/+i7dyW7hdc
		J6CGwVNz+6WF6z3SfxS8/3337dJq0EPZ0xsczYkww1Xt1bd/96d/Tr/9t6UO+B2u/PZLFL77V+9vLY7+
		NbG13PGB4jDKtr7shad8mBho5dVCAb56U9niU98WmrKD57SBjgUAOKS9Sdq6GPWBJsTBOsLBCnPI0Si5
		LdKbKhXQ+DaYqfRAI+uYAGOkUH9km7M3Sly+dI9L7ngoa/OrdNLb3aF8EzWAzdUHXqczBpdRs/ywXSk+
		MHnyCx9gI3wljxn6ldTxJgpZ77FbsHELFLoFe+gWaP9xU9shQ9lHDGV/KpK+oZIoqNnUuSFTj/8/pg44
		xIFZycDUuSFTJ59gai/KNs7gtQnu5DLUuDAMvyuYZrJf9JvjeMfhyCXtE3tPVemjGLE/VE3tIz26Ub3R
		0G8ktaHPnvrQF89I6GOn8finyejge2Ms/B0yHv5gmQh/r0yc1DWrUtlpV2vrla1NDDa2tfLI1vZm/Vat
		sb2jj6FZa+zsNOpnV97Tx95cubXRvkW1VnXj+vjcuZnZmdmzc7fU4NzM3P8AZgL/UtoVAAA=
	`;
	let gzipbytes=Uint8Array.from(atob(wasmstr),(c)=>c.codePointAt(0));
	let gzipstream=new Blob([gzipbytes]).stream();
	let decstream=gzipstream.pipeThrough(new DecompressionStream("gzip"));
	let decblob=await new Response(decstream).blob();
	let wasmbytes=new Uint8Array(await decblob.arrayBuffer());
	// Compile module.
	let module=new WebAssembly.Module(wasmbytes);
	if (!module) {
		console.log("could not load module");
		Draw.wasmloading=1;
		return;
	}
	// console.log("loading module");
	Draw.wasmmodule=module;
	// Set up class functions.
	Draw.prototype.wasmprinti64=function(h,l) {
		let s="Debug: "+((BigInt(h>>>0)<<32n)+BigInt(l>>>0))+"\n";
		console.log(s);
	};
	Draw.prototype.wasmprintf64=function(x) {
		let s="Debug: "+x;
		console.log(s);
	};
	Draw.prototype.wasmimage=function(img) {
		// console.log("setting image");
		let wasm=this.wasm,old=wasm.img;
		if (old!==null && !Object.is(old,img)) {
			// Generate a new copy for the old image.
			let width=old.width,height=old.height,copy=true;
			if (width<1 || height<1) {
				width=1;
				height=1;
				copy=false;
			}
			old.data8  =new Uint8Array(width*height*4);
			old.datac8 =new Uint8ClampedArray(old.data8.buffer);
			old.data32 =new Uint32Array(old.data8.buffer);
			old.imgdata=new ImageData(old.datac8,width,height);
			if (copy) {old.data32.set(wasm.imgdata);}
		}
		wasm.img=img||null;
		this.wasmresize(0);
	};
	Draw.prototype.wasmresize=function(bytes) {
		// console.log("resizing to: "+bytes);
		if (!bytes) {bytes=0;}
		let wasm=this.wasm;
		let img=wasm.img;
		if (img!==null) {
			wasm.width=img.width;
			wasm.height=img.height;
		} else {
			wasm.width=0;
			wasm.height=0;
		}
		let align=15;
		let imglen=(12+wasm.width*wasm.height*4+align)&~align;
		let pathlen=(6*8+4+4+24*wasm.vertmax+align)&~align;
		let heaplen=(wasm.heaplen+align)&~align;
		let sumlen=heaplen+imglen+pathlen;
		if (bytes && sumlen<bytes) {sumlen=bytes;}
		let newlen=1;
		while (newlen<sumlen) {newlen+=newlen;}
		let pagebytes=65536;
		let wasmmem=wasm.instance.exports.memory;
		let pages=Math.ceil((newlen-wasmmem.buffer.byteLength)/pagebytes);
		if (pages>0) {wasmmem.grow(pages);}
		let memu32=new Uint32Array(wasmmem.buffer,heaplen);
		wasm.memu32=memu32;
		memu32[0]=wasmmem.buffer.byteLength;
		memu32[1]=wasm.width;
		memu32[2]=wasm.height;
		wasm.imgdata=null;
		if (img!==null) {
			// Rebind the image pixel buffer.
			let width=img.width;
			let height=img.height;
			if (width<1 || height<1) {
				width=1;
				height=1;
			}
			let pixels=width*height;
			let buf=wasmmem.buffer,off=heaplen+12;
			wasm.imgdata=new Uint32Array(buf,off,pixels);
			if (img.data32.buffer.byteLength>0) {
				wasm.imgdata.set(img.data32);
			}
			img.data8  =new Uint8Array(buf,off,pixels*4);
			img.datac8 =new Uint8ClampedArray(buf,off,pixels*4);
			img.data32 =wasm.imgdata;
			img.imgdata=new ImageData(img.datac8,width,height);
		}
		wasm.tmpu32=new Uint32Array(wasmmem.buffer,heaplen+imglen);
		wasm.tmpf64=new Float64Array(wasmmem.buffer,heaplen+imglen);
		let dif=wasmmem.buffer.byteLength-wasm.tmpu32.byteOffset;
		wasm.vertmax=Math.floor((dif-(6*8+4+4))/24);
	};
	Draw.prototype.wasminit=function() {
		let con=this.constructor;
		let state=this;
		function wasmprinti64(h,l) {state.wasmprinti64(h,l);}
		function wasmprintf64(x)   {state.wasmprintf64(x);}
		function wasmresize(bytes) {state.wasmresize(bytes);}
		let imports={env:{wasmprinti64,wasmprintf64,wasmresize}};
		let inst=new WebAssembly.Instance(con.wasmmodule,imports);
		this.wasm={
			instance:inst,
			exports :inst.exports,
			heaplen :inst.exports.getheapbase(),
			memu32  :null,
			img     :null,
			imgdata :null,
			width   :0,
			height  :0,
			tmpu32  :null,
			tmpf64  :null,
			vertmax :0,
			fill    :inst.exports.fillpoly
		};
		this.wasmresize(0);
		return this.wasm;
	};
	Draw.prototype.fillpoly=function(poly,trans) {
		// Copy the path and image to webassembly memory for faster rendering.
		if (poly ===undefined) {poly =this.defpoly ;}
		if (trans===undefined) {trans=this.deftrans;}
		let iw=this.img.width,ih=this.img.height,imgdata=this.img.data32;
		let alpha=this.rgba[3]/255.0;
		if (poly.vertidx<3 || iw<1 || ih<1 || alpha<1e-5) {return;}
		// Screenspace transformation.
		let vmulx=this.viewmulx,voffx=this.viewoffx;
		let vmuly=this.viewmuly,voffy=this.viewoffy;
		let matxx=trans.data[0]*vmulx,matxy=trans.data[1]*vmulx,matx=(trans.data[2]-voffx)*vmulx;
		let matyx=trans.data[3]*vmuly,matyy=trans.data[4]*vmuly,maty=(trans.data[5]-voffy)*vmuly;
		// Perform a quick AABB-OBB overlap test.
		// Define the transformed bounding box.
		let aabb=poly.aabb;
		let bndx=aabb.minx*matxx+aabb.miny*matxy+matx;
		let bndy=aabb.minx*matyx+aabb.miny*matyy+maty;
		let bnddx0=aabb.dx*matxx,bnddy0=aabb.dx*matyx;
		let bnddx1=aabb.dy*matxy,bnddy1=aabb.dy*matyy;
		// Test if the image AABB has a separating axis.
		let minx=bndx-iw,maxx=bndx;
		if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
		if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
		if (maxx<=0 || 0<=minx) {return;}
		let miny=bndy-ih,maxy=bndy;
		if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Test if the poly OBB has a separating axis.
		let cross=bnddx0*bnddy1-bnddy0*bnddx1;
		minx=bndy*bnddx0-bndx*bnddy0;
		maxx=minx;bnddx0*=ih;bnddy0*=iw;
		if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
		if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
		if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
		if (maxx<=0 || 0<=minx) {return;}
		miny=bndy*bnddx1-bndx*bnddy1;
		maxy=miny;bnddx1*=ih;bnddy1*=iw;
		if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
		if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Copy to webassembly.
		let wasm=this.wasm;
		if (wasm===undefined) {
			wasm=this.wasminit();
		}
		if (!Object.is(imgdata,wasm.imgdata) || iw!==wasm.width || ih!==wasm.height) {
			this.wasmimage(this.img);
		}
		let vidx=poly.vertidx,varr=poly.vertarr;
		if (vidx>wasm.vertmax) {
			wasm.vertmax=vidx;
			this.wasmresize(0);
		}
		let tmpf64=wasm.tmpf64;
		let tmpu32=wasm.tmpu32;
		// transform [0-48]
		tmpf64[0]=matxx;
		tmpf64[1]=matxy;
		tmpf64[2]=matx;
		tmpf64[3]=matyx;
		tmpf64[4]=matyy;
		tmpf64[5]=maty;
		// color [48-52]
		tmpu32[12]=this.rgba32[0];
		// path [52-...]
		tmpu32[13]=vidx;
		let idx=7;
		for (let i=0;i<vidx;i++) {
			let v=varr[i];
			tmpu32[(idx++)<<1]=v.type;
			tmpf64[idx++]=v.x;
			tmpf64[idx++]=v.y;
		}
		wasm.fill();
	};
	Draw.wasmloading=1;
	// console.log("wasm done");
}
DrawWASMSetup();
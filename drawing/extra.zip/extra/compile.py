#!/usr/bin/python3

import os,re,sys,shutil,gzip,base64

outpath="fill.wasm"
comp="clang fill_wasm.c --target=wasm32 -O3 -flto -nostdlib --no-standard-libraries -Wl,--stack-first -Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined -Wl,--lto-O3 --output "+outpath
if os.path.isfile(outpath): os.remove(outpath)
print(comp)
os.system(comp)
if os.path.isfile(outpath):
	wasmdata=open(outpath,"rb").read()
	wasmcomp=gzip.compress(wasmdata)
	out64="fill_wasm_64.txt"
	str64=base64.b64encode(wasmcomp).decode("utf-8")
	l=len(str64)
	str64="\n".join([str64[i:min(i+80,l)] for i in range(0,l,80)])
	with open(out64,"w") as f: f.write(str64)

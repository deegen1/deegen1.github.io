#!/usr/bin/python3
import os, re, subprocess, math, time
from PIL import Image, ImageFont, ImageDraw

# Scale everything based on the full block height.
text    =" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~█"
textlen =len(text)
fontpath="../../../files/consola.ttf"
#fontpath="Inconsolata-Regular.ttf"
#fontpath="Courier New.ttf"
#fontpath="DejaVuSansMono.ttf"
#fontpath="DejaVuSans.ttf"
#fontpath="Menlo-Regular.ttf"
#fontpath="Verdana.ttf"
#fontpath="SFMono-Regular.otf"
#fontpath="JetBrainsMono-Regular.ttf"
#fontpath="Code New Roman-Regular.otf"
#fontpath="RobotoMono-Regular.ttf"
"""
  Font   |  W/H
Consolas | 0.553
Courier  | 0.529
Menlo    | 0.511
DJV Mono | 0.511
DJV      | 0.508
Inconsol | 0.397
SF Mono  | 0.520
JetBrain | 0.500
"""
width   =1000
height  =1000
backimg =Image.new(mode="RGB",size=(width,height))
backdraw=ImageDraw.Draw(backimg)

# Find the maximum point that fits our image height.
# Needs to be an integer.
minpoint=1
maxpoint=1
while True:
	font=ImageFont.truetype(fontpath,maxpoint)
	rect=backdraw.textbbox((0,0),text,font=font)
	print("max: {0}, {1}".format(maxpoint,rect[3]))
	avg=math.floor(rect[2]/textlen+0.5)
	if avg>width or rect[3]>height: break
	minpoint=maxpoint
	maxpoint+=maxpoint
while minpoint<maxpoint:
	point=(minpoint+maxpoint+1)>>1
	font =ImageFont.truetype(fontpath,point)
	rect =backdraw.textbbox((0,0),text,font=font)
	print(rect[1])
	print("{0}: {1:.3f}, {2:.3f}".format(point,rect[2],rect[3]))
	avg=math.floor(rect[2]/textlen+0.5)
	if avg>width or rect[3]>height:
		maxpoint=point-1
	else:
		minpoint=point

# Load the maximum sized font and calculate the width.
point =minpoint
font  =ImageFont.truetype(fontpath,point)
rect  =backdraw.textbbox((0,0),text,font=font)
width =math.floor(rect[2]/textlen+0.5)
#height=rect[3]
print("point:",point)
print("size :",width,height)

# Save the font images to files.
savedir="font"
if not os.path.exists(savedir): os.mkdir(savedir)
for char in text:
	rect = backdraw.textbbox((0,0),char,font=font)
	img=Image.new(mode="RGB",size=(width,height))
	draw=ImageDraw.Draw(img)
	draw.rectangle((0,0,img.width,img.height),fill=(0,0,0,255))
	draw.text((0,0),char,font=font)
	path=savedir + "/{0:03d}.png".format(ord(char))
	img.save(path)
	print(char,rect)

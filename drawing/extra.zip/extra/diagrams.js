function UnitAreaCalc(x0,y0,x1,y1) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	let tmp=0,sign=1;
	//if (!(Math.abs(y0)<Infinity && Math.abs(y1)<Infinity && x1-x0!==0)) {
	//	return 0;
	//}
	if (isNaN((y1-y0)/(x1-x0))) {return 0;}
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	//if (x0>=Infinity || x1>=Infinity) {return 0;}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	// If we're entirely outside the bounding box.
	if (!(y0<1 && y1>0 && x0<1 && x1===x1)) {return 0;}
	let iy0=y0>0?y0:0;
	let iy1=y1<1?y1:1;
	if (x1<=0) {return (iy0-iy1)*sign;}
	// Determine if [0,1] is entirely to the left/right of slope.
	let dx=x1-x0,dy=y1-y0;
	// x=x0+(y-y0)*dx/dy
	if ((1-x0)*dy<=(iy0-y0)*dx) {return 0;}
	if ((0-x0)*dy>=(iy1-y0)*dx) {return (iy0-iy1)*sign;}
	// Narrow-phase. Clip to unit box.
	let x0y=y0-dy*(x0/dx);
	let x1y=y0+dy*((1-x0)/dx);
	let y0x=x0-dx*(y0/dy);
	let y1x=x0+dx*((1-y0)/dy);
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	/*if (x0<0 && x1>1) {
		return ((x0-0.5)/dx)*dy*sign;
	} else if (x0<0) {
		return ((x1*x1*0.5-x1+x0)/dx)*dy*sign;
	} else if (x1>1) {
		return -0.5*((1-x0)*(1-x0)/dx)*dy*sign;
	} else {
		return (y0-y1)*(2-x0-x1)*0.5*sign;
	}*/
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


//---------------------------------------------------------------------------------
// Article Demos


function PathToBlueprint(path,width,height) {
	let pad=Math.min(width,height)*0.05;
	let rad=3;
	let poly=new Draw.Poly(path);
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			minx=minx<v.x?minx:v.x;
			maxx=maxx>v.x?maxx:v.x;
			miny=miny<v.y?miny:v.y;
			maxy=maxy>v.y?maxy:v.y;
		}
	}
	let dim=Math.min(width*0.35,height)-2*pad;
	maxx-=minx;
	maxy-=miny;
	let norm=dim/(maxx>maxy?maxx:maxy);
	pad=width*0.1;
	let offx=(width*0.5-pad-maxx*norm)*0.5+pad;
	let offy=(height-maxy*norm)*0.5;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			v.x=Math.floor((v.x-minx)*norm+offx);
			v.y=Math.floor((v.y-miny)*norm+offy);
		}
	}
	let px=0,py=0;
	let lines=0,curves=0;
	let control="",points="";
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		switch (v.type) {
			case Draw.Poly.CLOSE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				break;
			case Draw.Poly.MOVE:
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.LINE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.CURVE:
				curves++;
				// points+='\t\t<circle cx={0} cy={1} r={2} />\n'.format(v.x,v.y,rad);
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				px=v.x;
				py=v.y;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
		}
		px=v.x;
		py=v.y;
	}
	let ret=`<svg version="1.1" viewBox="0 0 ${width} ${height}" class="diagram" style="background:#000000">\n`;
	ret+='\t<g class="dimstroke" stroke-width=1>\n'+control+'\t</g>\n';
	ret+='\t<path d="'+poly.tostring(0)+'" fill="none" class="highstroke" />\n';
	ret+='\t<g class="highstroke highfill">\n'+points+'\t</g>\n';
	let off=width*0.5-pad;
	for (let i=0;i<poly.vertidx;i++) {
		poly.vertarr[i].x+=off;
	}
	ret+='\t<path d="'+poly.tostring(0)+'" class="forefill" stroke="none" />\n';
	ret+="</svg>\n";
	console.log(ret);
	console.log("lines : ",lines);
	console.log("curves: ",curves);
}

// Cat
/*
PathToBlueprint(`
M 0 0 L 250 250 L 750 250 L 1000 0 L 1000 700 L 500 1000 L 0 700 Z
M 500 683 L 394 727 L 396 732 L 500 689 L 604 732 L 606 727 Z
M 190 398 C 207 487 327 512 395 450 Z
M 605 450 C 673 512 793 487 810 398 Z
`,1000,400);
*/
// g
/*
PathToBlueprint(`
M 538 267 L 538 340 L 454 340 C 467 353 485 385 485 433 C 485 548 395 614 284
614 C 239 614 212 607 177 590 C 166 605 154 622 154 646 C 154 673 182 690 218
692 L 372 698 C 467 702 536 750 536 828 C 536 933 439 1000 281 1000
C 156 1000 48 966 48 866 C 48 806 85 771 120 745 C 103 739 68 711 68 662
C 68 620 90 585 122 548 C 93 516 80 486 80 438 C 80 333 160 258 282 258
C 315 258 332 262 350 267 Z
M 282 547 C 350 547 395 497 395 436 C 395 385 363 325 282 325
C 238 325 171 353 171 436 C 171 524 245 547 282 547 M 200 770
C 176 788 143 810 144 857 C 143 911 216 930 289 929 C 400 928 441 879 440 838
C 439 794 397 776 339 775 Z
`,1000,400);
*/

function SegmentDemo() {
	const points=[[0,1000],[650,500],[-650,500],[0,0]];
	let [p0x,p0y]=points[0];
	let [c1x,c1y]=points[1];
	let [c2x,c2y]=points[2];
	let [c3x,c3y]=points[3];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	for (let s=0;s<2;s++) {
		let segs=[4,16][s];
		console.log("segments:",segs);
		let px=p0x,py=p0y;
		let out="";
		for (let i=1;i<=segs;i++) {
			let u=i/segs;
			let cpx=Math.floor(p0x+u*(c1x+u*(c2x+u*c3x)));
			let cpy=Math.floor(p0y+u*(c1y+u*(c2y+u*c3y)));
			out+=`\t\t<line x1=${px} y1=${py} x2=${cpx} y2=${cpy} />\n`;
			px=cpx;
			py=cpy;
		}
		console.log(out);
	}
}


function StrideArea() {
	let dim=115;
	let left=40;
	let top=40;
	let x0=1.5,y0=0.1;
	let x1=6.6,y1=0.9;
	console.log("coord 0:",x0*dim+left,(1-y0)*dim+top);
	console.log("coord 1:",x1*dim+left,(1-y1)*dim+top);
	let prev=0;
	for (let i=0;i<8;i++) {
		let area=Math.abs(UnitAreaCalc(x0-i,y0,x1-i,y1));
		console.log(area-prev);
		prev=area;
	}
}


function BlendDemo() {
	let dim=115;
	let left=40;
	let top=40;
	let x0=1.5,y0=0.1;
	let x1=6.6,y1=0.9;
	for (let i=0;i<8;i++) {
		let area=Math.abs(UnitAreaCalc(x0-i,y0,x1-i,y1));
		console.log(area);
		let rgb=`rgb(${Math.round(area*96)},${Math.round(area*96)},${Math.round(area*255)})`;
		let x=left+i*dim;
		console.log(`<rect x=${x} y=${top} width=${dim} height=${dim} fill="${rgb}" stroke="none"/>`);
	}
}


/*

fillresize(size) {
	// Declaring line objects this way allows engines to optimize their structs.
	let len=this.tmpline.length;
	while (len<size) {len+=len+1;}
	while (this.tmpline.length<len) {
		this.tmpline.push({
			sort:0,
			end:0,
			x0:0,y0:0,
			x1:0,y1:0,
			x2:0,y2:0,
			x3:0,y3:0
		});
	}
	return this.tmpline;
}


fillpath(path,trans) {
	// Fills the current path.
	//
	// Preprocess the lines and curves. Use a binary heap to dynamically sort lines.
	// Keep JS as simple as possible to be efficient. Keep micro optimization in WASM.
	// ~~x = fast floor(x)
	if (path===undefined) {path=this.defpath;}
	if (trans===undefined) {trans=this.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	const curvemaxdist2=0.02;
	let iw=this.img.width,ih=this.img.height;
	let alpha=this.rgba[3]/255.0;
	if (path.vertidx<3 || iw<1 || ih<1 || alpha<1e-4) {return;}
	// Screenspace transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	// Perform a quick AABB-OBB overlap test.
	// Define the transformed bounding box.
	let bx=path.minx,by=path.miny;
	let bndx=bx*matxx+by*matxy+matx;
	let bndy=bx*matyx+by*matyy+maty;
	bx=path.maxx-bx;by=path.maxy-by;
	let bndxx=bx*matxx,bndxy=bx*matyx;
	let bndyx=by*matxy,bndyy=by*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-iw,maxx=bndx;
	if (bndxx<0) {minx+=bndxx;} else {maxx+=bndxx;}
	if (bndyx<0) {minx+=bndyx;} else {maxx+=bndyx;}
	if (!(minx<0 && 0<maxx)) {return;}
	let miny=bndy-ih,maxy=bndy;
	if (bndxy<0) {miny+=bndxy;} else {maxy+=bndxy;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	// Test if the path OBB has a separating axis.
	let cross=bndxx*bndyy-bndxy*bndyx;
	minx=bndy*bndxx-bndx*bndxy;maxx=minx;
	bndxx*=ih;bndxy*=iw;
	if (cross<0) {minx+=cross;} else {maxx+=cross;}
	if (bndxx<0) {maxx-=bndxx;} else {minx-=bndxx;}
	if (bndxy<0) {minx+=bndxy;} else {maxx+=bndxy;}
	if (!(minx<0 && 0<maxx)) {return;}
	miny=bndy*bndyx-bndx*bndyy;maxy=miny;
	bndyx*=ih;bndyy*=iw;
	if (cross<0) {maxy-=cross;} else {miny-=cross;}
	if (bndyx<0) {maxy-=bndyx;} else {miny-=bndyx;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	// Loop through the path nodes.
	let lr=this.tmpline,lrcnt=lr.length,lcnt=0;
	let movex=0,movey=0,area=0;
	let p0x=0,p0y=0,p1x=0,p1y=0;
	let varr=path.vertarr;
	let vidx=path.vertidx;
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		if (v.type===DrawPath.CURVE) {v=varr[i+2];}
		p0x=p1x;p1x=v.x*matxx+v.y*matxy+matx;
		p0y=p1y;p1y=v.x*matyx+v.y*matyy+maty;
		// Add a basic line.
		let m1x=p1x,m1y=p1y;
		if (v.type===DrawPath.MOVE) {
			// Close any unclosed subpaths.
			m1x=movex;movex=p1x;
			m1y=movey;movey=p1y;
			if (!i || (m1x===p0x && m1y===p0y)) {continue;}
		}
		if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}
		let l=lr[lcnt++];
		l.sort=0;l.end=-1;
		area+=p0x*m1y-m1x*p0y;
		l.x0=p0x;
		l.y0=p0y;
		l.x1=m1x;
		l.y1=m1y;
		if (v.type!==DrawPath.CURVE) {continue;}
		// Linear decomposition of curves.
		v=varr[i++];let n1x=v.x*matxx+v.y*matxy+matx,n1y=v.x*matyx+v.y*matyy+maty;
		v=varr[i++];let n2x=v.x*matxx+v.y*matxy+matx,n2y=v.x*matyx+v.y*matyy+maty;
		l.x2=n1x;l.x3=n2x;
		l.y2=n1y;l.y3=n2y;
		area-=((n1x-p0x)*(2*p0y-n2y-p1y)+(n2x-p0x)*(p0y+n1y-2*p1y)
			 +(p1x-p0x)*(2*n2y+n1y-3*p0y))*0.3;
		for (let j=lcnt-1;j<lcnt;j++) {
			// The curve will stay inside the bounding box of [c0,c1,c2,c3].
			// If the subcurve is outside the image, stop subdividing.
			l=lr[j];
			let c3x=l.x1,c2x=l.x3,c1x=l.x2,c0x=l.x0;
			let c3y=l.y1,c2y=l.y3,c1y=l.y2,c0y=l.y0;
			if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
			    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
				continue;
			}
			let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
			// Test if both control points are close to the line c0->c3.
			// Clamp to ends and filter degenerates.
			let lx=c1x-c0x,ly=c1y-c0y;
			let u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d1=lx*lx+ly*ly;
			lx=c2x-c0x;ly=c2y-c0y;
			u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d2=lx*lx+ly*ly;
			d1=(d1>d2 || !(d1===d1))?d1:d2;
			if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
			// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
			if (lrcnt<=lcnt) {
				lr=this.fillresize(lcnt+1);
				lrcnt=lr.length;
			}
			let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
			let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
			let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
			let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
			let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
			let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
			l.x1=phx;l.x3=l2x;l.x2=l1x;
			l.y1=phy;l.y3=l2y;l.y2=l1y;
			l=lr[lcnt++];
			l.sort=0;l.end=-1;
			l.x1=c3x;l.x3=r2x;l.x2=r1x;l.x0=phx;
			l.y1=c3y;l.y3=r2y;l.y2=r1y;l.y0=phy;
			j--;
		}
	}
	// Init blending.
	let amul=area<0?-alpha:alpha;
	let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=(0x00ff00ff&~amask)>>>0,maskh=(0xff00ff00&~amask)>>>0;
	let colrgb=(this.rgba32[0]|amask)>>>0;
	let coll=(colrgb&maskl)>>>0,colh=(colrgb&maskh)>>>0,colh8=colh>>>8;
	// Process the lines row by row.
	let p=0,y=0,pixels=iw*ih;
	let pnext=0,prow=0;
	let areadx1=0;
	let imgdata=this.img.data32;
	while (true) {
		if (p>=prow) {
			p=pnext;
			if (p>=pixels || lcnt<1) {break;}
			y=~~(p/iw);
			prow=y*iw+iw;
			area=0;
			areadx1=0;
		}
		let areadx2=0;
		while (p>=pnext) {
			// fx0  fx0+1                          fx1  fx1+1
			//  +-----+-----+-----+-----+-----+-----+-----+
			//  |                              .....----  |
			//  |               .....-----'''''           |
			//  | ....-----'''''                          |
			//  +-----+-----+-----+-----+-----+-----+-----+
			//   first  dyx   dyx   dyx   dyx   dyx  last   tail
			//
			// Orient upwards, then clip y to [0,1].
			let l=lr[0];
			let x0=l.x0,y0=l.y0;
			let x1=l.x1,y1=l.y1;
			let sign=amul,tmp=0;
			let end=l.end,sort=prow-iw,x=p-sort;
			// Orient upwards, then clip y to [0,1].
			if (y0>y1) {
				sign=-sign;
				tmp=x0;x0=x1;x1=tmp;
				tmp=y0;y0=y1;y1=tmp;
			}
			let fy=y0<ih?y0:ih;
			fy=fy>y?~~fy:y;
			y0-=fy;y1-=fy;x0-=x;x1-=x;
			let dx=x1-x0,dy=y1-y0,nx=x1;
			if (y1>2) {nx+=((2-y1)/dy)*dx;}
			if (y1>1) {x1+=((1-y1)/dy)*dx;y1=1;}
			if (y0<0) {x0+=((0-y0)/dy)*dx;y0=0;}
			nx=nx<x1?nx:x1;
			if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
			dy*=sign;
			let rate=dy/dx;
			end-=prow+iw;
			if (y1<=0.000001) {
				// Above.
				sort=iw*ih;
			} else if (x0>=1 || fy>y) {
				// Below or to the left.
				nx=x0;
				sort=fy*iw;
			} else if (x1<=1.000001 || end<0) {
				// Vertical line or last pixel.
				let ty=(y0-y1)*sign;
				tmp=x1>0?((-0.5*x1*x1)/dx)*dy:0;
				if (end<0) {
					ty=((0.5-x1)/dx)*dy;
					areadx1+=rate;
				} else {
					tmp=x0>=0?(x0+x1)*ty*0.5:tmp;
				}
				area+=ty-tmp;
				areadx2+=tmp;
				sort+=iw;
			} else {
				// Line spanning multiple pixels.
				tmp=x0>0?((0.5*x0*x0)/dx)*dy:0;
				area-=((0.5-x0)/dx)*dy+tmp;
				areadx1-=rate;
				areadx2+=tmp;
				nx=x1;
				end=x+x1<iw?0:end;
			}
			nx+=x;
			nx=nx<0?0:nx;
			l.sort=sort+(nx<iw?~~nx:iw);
			l.end=end?0xffffffff:l.sort;
			sort=l.sort;
			// Heap sort down.
			if (sort>=pixels) {
				let t=lr[--lcnt];
				lr[lcnt]=l;l=t;
				sort=l.sort;
			}
			let i=0,j=0;
			while ((j+=j+1)<lcnt) {
				let j1=j+1<lcnt?j+1:j;
				let l0=lr[j],l1=lr[j1];
				let s0=l0.sort,s1=l1.sort;
				if (s0>s1) {s0=s1;l0=l1;j=j1;}
				if (s0>=sort) {break;}
				lr[i]=l0;
				i=j;
			}
			lr[i]=l;
			pnext=lr[0].sort;
		}
		// Calculate how much we can draw or skip.
		const cutoff=0.00390625;
		let astop=area+areadx1+areadx2;
		let pstop=p+1,pdif=(pnext<prow?pnext:prow)-pstop;
		if (pdif>0 && (area>=cutoff)===(astop>=cutoff)) {
			let adif=(cutoff-astop)/areadx1+1;
			pdif=(adif>=1 && adif<pdif)?~~adif:pdif;
			astop+=pdif*areadx1;
			pstop+=pdif;
		}
		// Blend the pixel based on how much we're covering.
		if (area>=cutoff) {
			do {
				// a = sa + da*(1-sa)
				// c = (sc - dc)*sa/a + dc
				let sa=area<alpha?area:alpha;
				area+=areadx1+areadx2;
				areadx2=0;
				let dst=imgdata[p];
				let da=(dst>>>ashift)&255;
				if (da===255) {
					sa=256.49-sa*256;
				} else {
					let tmp=sa*255+(1-sa)*da;
					sa=256.49-(sa/tmp)*65280;
					da=tmp+0.49;
				}
				// imul() implicitly casts floor(sa).
				imgdata[p]=(da<<ashift)
					|(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&maskl)
					|((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&maskh);
			} while (++p<pstop);
		}
		p=pstop;
		area=astop;
	}
}

function LargeNumberDiagram() {
	let x0=100,y0=100;
	let x1=-2.0721043967e+15,y1=-1.7587018106e+15;
}
*/


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	console.log("starting polygon tests");
	//TraceDemo();
	//SegmentDemo();
	//StrideArea();
	BlendDemo();
	console.log("done");
}
TestMain();

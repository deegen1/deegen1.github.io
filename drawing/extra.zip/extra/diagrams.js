//---------------------------------------------------------------------------------
// Article Demos


function PathToBlueprint(path,width,height) {
	let pad=Math.min(width,height)*0.05;
	let rad=3;
	let poly=new Draw.Poly(path);
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			minx=minx<v.x?minx:v.x;
			maxx=maxx>v.x?maxx:v.x;
			miny=miny<v.y?miny:v.y;
			maxy=maxy>v.y?maxy:v.y;
		}
	}
	let dim=Math.min(width*0.35,height)-2*pad;
	maxx-=minx;
	maxy-=miny;
	let norm=dim/(maxx>maxy?maxx:maxy);
	pad=width*0.1;
	let offx=(width*0.5-pad-maxx*norm)*0.5+pad;
	let offy=(height-maxy*norm)*0.5;
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		if (v.type!==Draw.Poly.CLOSE) {
			v.x=Math.floor((v.x-minx)*norm+offx);
			v.y=Math.floor((v.y-miny)*norm+offy);
		}
	}
	let px=0,py=0;
	let lines=0,curves=0;
	let control="",points="";
	for (let i=0;i<poly.vertidx;) {
		let v=poly.vertarr[i++];
		switch (v.type) {
			case Draw.Poly.CLOSE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				break;
			case Draw.Poly.MOVE:
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.LINE:
				lines++;
				// control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
			case Draw.Poly.CURVE:
				curves++;
				// points+='\t\t<circle cx={0} cy={1} r={2} />\n'.format(v.x,v.y,rad);
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				px=v.x;
				py=v.y;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				v=poly.vertarr[i++];
				control+=`\t\t<line x1=${px} y1=${py} x2=${v.x} y2=${v.y} />\n`;
				points+=`\t\t<circle cx=${v.x} cy=${v.y} r=${rad} />\n`;
				break;
		}
		px=v.x;
		py=v.y;
	}
	let ret=`<svg version="1.1" viewBox="0 0 ${width} ${height}" class="diagram" style="background:#000000">\n`;
	ret+='\t<g class="dimstroke" stroke-width=1>\n'+control+'\t</g>\n';
	ret+='\t<path d="'+poly.tostring(0)+'" fill="none" class="highstroke" />\n';
	ret+='\t<g class="highstroke highfill">\n'+points+'\t</g>\n';
	let off=width*0.5-pad;
	for (let i=0;i<poly.vertidx;i++) {
		poly.vertarr[i].x+=off;
	}
	ret+='\t<path d="'+poly.tostring(0)+'" class="forefill" stroke="none" />\n';
	ret+="</svg>\n";
	console.log(ret);
	console.log("lines : ",lines);
	console.log("curves: ",curves);
}

// Cat
/*
PathToBlueprint(`
M 0 0 L 250 250 L 750 250 L 1000 0 L 1000 700 L 500 1000 L 0 700 Z
M 500 683 L 394 727 L 396 732 L 500 689 L 604 732 L 606 727 Z
M 190 398 C 207 487 327 512 395 450 Z
M 605 450 C 673 512 793 487 810 398 Z
`,1000,400);
*/
// g
/*
PathToBlueprint(`
M 538 267 L 538 340 L 454 340 C 467 353 485 385 485 433 C 485 548 395 614 284
614 C 239 614 212 607 177 590 C 166 605 154 622 154 646 C 154 673 182 690 218
692 L 372 698 C 467 702 536 750 536 828 C 536 933 439 1000 281 1000
C 156 1000 48 966 48 866 C 48 806 85 771 120 745 C 103 739 68 711 68 662
C 68 620 90 585 122 548 C 93 516 80 486 80 438 C 80 333 160 258 282 258
C 315 258 332 262 350 267 Z
M 282 547 C 350 547 395 497 395 436 C 395 385 363 325 282 325
C 238 325 171 353 171 436 C 171 524 245 547 282 547 M 200 770
C 176 788 143 810 144 857 C 143 911 216 930 289 929 C 400 928 441 879 440 838
C 439 794 397 776 339 775 Z
`,1000,400);
*/

function SegmentDemo() {
	const points=[[0,1000],[650,500],[-650,500],[0,0]];
	let [p0x,p0y]=points[0];
	let [c1x,c1y]=points[1];
	let [c2x,c2y]=points[2];
	let [c3x,c3y]=points[3];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	for (let s=0;s<2;s++) {
		let segs=[4,16][s];
		console.log("segments:",segs);
		let px=p0x,py=p0y;
		let out="";
		for (let i=1;i<=segs;i++) {
			let u=i/segs;
			let cpx=Math.floor(p0x+u*(c1x+u*(c2x+u*c3x)));
			let cpy=Math.floor(p0y+u*(c1y+u*(c2y+u*c3y)));
			out+=`\t\t<line x1=${px} y1=${py} x2=${cpx} y2=${cpy} />\n`;
			px=cpx;
			py=cpy;
		}
		console.log(out);
	}
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	console.log("starting polygon tests");
	//TraceDemo();
	//SegmentDemo();
	console.log("done");
}

window.addEventListener("load",TestMain);
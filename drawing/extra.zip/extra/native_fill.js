// needs https://developer.mozilla.org/en-US/docs/Web/API/CSS_Typed_OM_API

// in fillpoly()
return this.nativefill(poly,matxx,matxy,matx,matyx,matyy,maty);

// in Drawing
	nativefill(poly,matxx,matxy,matx,matyx,matyy,maty) {
		let native=this.native;
		if (!native) {
			let canvas=new OffscreenCanvas(1,1);
			native={
				canvas:canvas,
				ctx:canvas.getContext("2d"),
				img:null
			};
			this.native=native;
		}
		let img=native.img;
		let canvas=native.canvas;
		let ctx=native.ctx;
		if (img!==this.img || (this.img.updated&1)) {
			// img.sync();
			img=this.img;
			native.img=img;
			img.updated=0;
			canvas.width=img.width;
			canvas.height=img.height;
			ctx.putImageData(img.imgdata,0,0);
		}
		img.updated|=2;
		let rgba=this.rgba;
		let rgbstr=`rgba(${rgba[0]},${rgba[1]},${rgba[2]},${rgba[3]/255.0})`;
		ctx.fillStyle=rgbstr;
		// Not available in firefox.
		// ctx.fillStyle=CSSStyleValue.parse("color",rgbstr);
		ctx.beginPath();
		let varr=poly.vertarr;
		let verts=poly.vertidx;
		for (let i=0;i<verts;i++) {
			let v=varr[i],t=v.type;
			let x=v.x*matxx+v.y*matxy+matx;
			let y=v.x*matyx+v.y*matyy+maty;
			if (t===_DrawPoly.MOVE) {
				ctx.moveTo(x,y);
			} else if (t===_DrawPoly.CLOSE) {
				ctx.closePath();
			} else if (t===_DrawPoly.LINE) {
				ctx.lineTo(x,y);
			} else if (t===_DrawPoly.CURVE) {
				v=varr[++i];
				let x1=v.x*matxx+v.y*matxy+matx;
				let y1=v.x*matyx+v.y*matyy+maty;
				v=varr[++i];
				let x2=v.x*matxx+v.y*matxy+matx;
				let y2=v.x*matyx+v.y*matyy+maty;
				ctx.bezierCurveTo(x,y,x1,y1,x2,y2);
			} else {
				throw "unknown path type: "+t;
			}
		}
		ctx.closePath();
		ctx.fill();
	}

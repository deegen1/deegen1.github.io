	fillresize(size) {
		// Declaring line objects this way allows engines to optimize their structs.
		let len=this.tmpline.length;
		while (len<size) {len+=len+1;}
		while (this.tmpline.length<len) {
			this.tmpline.push({
				sort:0,
				next:0,
				x0:0,
				y0:0,
				x1:0,
				y1:0,
				dxy:0,
				amul:0,
				area:0,
				areadx1:0,
				areadx2:0
			});
		}
		return this.tmpline;
	}


	fillpoly(poly,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Reject anything with a NaN, too narrow, or
		// outside the image. Use a binary heap to dynamically sort lines.
		// Keep JS as simple as possible to be efficient. Keep micro optimization in WASM.
		// ~~x = fast floor(x)
		if (poly===undefined) {poly=this.defpoly;}
		if (trans===undefined) {trans=this.deftrans;}
		else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		const curvemaxdist2=0.02;
		let iw=this.img.width,ih=this.img.height;
		let alpha=this.rgba[3]/255.0;
		if (poly.vertidx<3 || iw<1 || ih<1 || alpha<1e-4) {return;}
		// Screenspace transformation.
		let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
		let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
		// Perform a quick AABB-OBB overlap test.
		// Define the transformed bounding box.
		let aabb=poly.aabb;
		let bndx=aabb.minx*matxx+aabb.miny*matxy+matx;
		let bndy=aabb.minx*matyx+aabb.miny*matyy+maty;
		let bnddx0=aabb.dx*matxx,bnddy0=aabb.dx*matyx;
		let bnddx1=aabb.dy*matxy,bnddy1=aabb.dy*matyy;
		// Test if the image AABB has a separating axis.
		let minx=bndx-iw,maxx=bndx;
		if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
		if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
		if (maxx<=0 || 0<=minx) {return;}
		let miny=bndy-ih,maxy=bndy;
		if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Test if the poly OBB has a separating axis.
		let cross=bnddx0*bnddy1-bnddy0*bnddx1;
		minx=bndy*bnddx0-bndx*bnddy0;
		maxx=minx;bnddx0*=ih;bnddy0*=iw;
		if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
		if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
		if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
		if (maxx<=0 || 0<=minx) {return;}
		miny=bndy*bnddx1-bndx*bnddy1;
		maxy=miny;bnddx1*=ih;bnddy1*=iw;
		if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
		if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Loop through the path nodes.
		let lr=this.tmpline,lrcnt=lr.length,lcnt=0;
		let movex=0,movey=0,area=0;
		let p0x=0,p0y=0,p1x=0,p1y=0;
		let varr=poly.vertarr;
		let vidx=poly.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			if (v.type===DrawPoly.CURVE) {v=varr[i+2];}
			p0x=p1x;p1x=v.x*matxx+v.y*matxy+matx;
			p0y=p1y;p1y=v.x*matyx+v.y*matyy+maty;
			// Add a basic line.
			if (lrcnt<=lcnt) {
				lr=this.fillresize(lcnt+1);
				lrcnt=lr.length;
			}
			let l=lr[lcnt++];
			l.x0=p0x;
			l.y0=p0y;
			l.x1=p1x;
			l.y1=p1y;
			if (v.type===DrawPoly.MOVE) {
				// Close any unclosed subpaths.
				if (!i || (movex===p0x && movey===p0y)) {lcnt--;}
				l.x1=movex;movex=p1x;
				l.y1=movey;movey=p1y;
			}
			area+=p0x*l.y1-l.x1*p0y;
			if (v.type!==DrawPoly.CURVE) {continue;}
			// Linear decomposition of curves.
			v=varr[i++];let n1x=v.x*matxx+v.y*matxy+matx,n1y=v.x*matyx+v.y*matyy+maty;
			v=varr[i++];let n2x=v.x*matxx+v.y*matxy+matx,n2y=v.x*matyx+v.y*matyy+maty;
			l.amul=n1x;l.areadx1=n2x;
			l.area=n1y;l.areadx2=n2y;
			area-=((n1x-p0x)*(2*p0y-n2y-p1y)+(n2x-p0x)*(p0y+n1y-2*p1y)
				 +(p1x-p0x)*(2*n2y+n1y-3*p0y))*0.3;
			for (let j=lcnt-1;j<lcnt;j++) {
				// The curve will stay inside the bounding box of [c0,c1,c2,c3].
				// If the subcurve is outside the image, stop subdividing.
				l=lr[j];
				let c3x=l.x1,c2x=l.areadx1,c1x=l.amul,c0x=l.x0;
				let c3y=l.y1,c2y=l.areadx2,c1y=l.area,c0y=l.y0;
				if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
				    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
					continue;
				}
				let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
				// Test if both control points are close to the line c0->c3. Clamp to ends.
				let lx=c1x-c0x,ly=c1y-c0y;
				let u=dx*lx+dy*ly;
				u=u>0?(u<den?u/den:1):0;
				lx-=dx*u;ly-=dy*u;
				if (!(lx*lx+ly*ly>curvemaxdist2)) {
					lx=c2x-c0x;ly=c2y-c0y;
					u=dx*lx+dy*ly;
					u=u>0?(u<den?u/den:1):0;
					lx-=dx*u;ly-=dy*u;
					if (!(lx*lx+ly*ly>curvemaxdist2)) {continue;}
				}
				// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
				if (lrcnt<=lcnt) {
					lr=this.fillresize(lcnt+1);
					lrcnt=lr.length;
				}
				let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
				let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
				let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
				let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
				let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
				let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
				l.x1=phx;l.areadx1=l2x;l.amul=l1x;
				l.y1=phy;l.areadx2=l2y;l.area=l1y;
				l=lr[lcnt++];
				l.x1=c3x;l.areadx1=r2x;l.amul=r1x;l.x0=phx;
				l.y1=c3y;l.areadx2=r2y;l.area=r1y;l.y0=phy;
				j--;
			}
		}
		// Prune lines.
		minx=iw;maxx=0;miny=ih;maxy=0;
		let amul=area<0?-alpha:alpha;
		let maxcnt=lcnt;
		lcnt=0;
		for (let i=0;i<maxcnt;i++) {
			let l=lr[i];
			// Always point the line up to simplify math.
			let x0=l.x0,x1=l.x1;
			let y0=l.y0,y1=l.y1;
			l.amul=amul;
			if (y0>y1) {
				l.x0=x1;l.x1=x0;x0=x1;x1=l.x1;
				l.y0=y1;l.y1=y0;y0=y1;y1=l.y1;
				l.amul=-amul;
			}
			let dx=x1-x0,dy=y1-y0;
			// Too thin or NaN.
			if (!(dx===dx && dy>1e-9)) {continue;}
			// Clamp y to [0,imgheight), then clamp x so x<imgwidth.
			l.dxy=dx/dy;
			let dyx=Math.abs(dx)>1e-9?dy/dx:0;
			let y0x=x0-y0*l.dxy;
			let yhx=x0+(ih-y0)*l.dxy;
			let xwy=y0+(iw-x0)*dyx;
			if (y0<0 ) {y0=0 ;x0=y0x;}
			if (y1>ih) {y1=ih;x1=yhx;}
			if (y1-y0<1e-9) {continue;}
			if (x0>=iw && x1>=iw) {maxx=iw;continue;}
			if (x0>=iw) {x0=iw;y0=xwy;}
			if (x1>=iw) {x1=iw;y1=xwy;}
			let fy=~~y0,fx=x0;
			if (x1<x0) {
				x0=x1;x1=fx;
				fx=l.x0+(fy+1-l.y0)*l.dxy;
				fx=fx>x0?fx:x0;
			}
			l.sort=fy*iw+(fx>0?~~fx:0);
			l.next=0;
			lr[i]=lr[lcnt];
			lr[lcnt++]=l;
			// Calculate the bounding box.
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
			miny=miny<y0?miny:y0;
			maxy=maxy>y1?maxy:y1;
		}
		// If all lines are outside the image, abort.
		if (minx>=iw || maxx<=0 || minx>=maxx || miny>=maxy || lcnt<=0) {
			return;
		}
		maxx=maxx<iw?Math.ceil(maxx):iw;
		// Linear time heap construction.
		for (let p=(lcnt>>1)-1;p>=0;p--) {
			let i=p,j=0;
			let l=lr[p];
			while ((j=i+i+1)<lcnt) {
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=l.sort) {break;}
				lr[i]=lr[j];
				i=j;
			}
			lr[i]=l;
		}
		// Init blending.
		let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0;
		let maskl=(0x00ff00ff&~amask)>>>0,maskh=(0xff00ff00&~amask)>>>0;
		let colrgb=(this.rgba32[0]|amask)>>>0;
		let coll=(colrgb&maskl)>>>0,colh=(colrgb&maskh)>>>0,colh8=colh>>>8;
		// Process the lines row by row.
		let x=lr[0].sort,y=0;
		let xnext=x,xlim=x;
		let areadx1=0;
		let pixels=iw*ih;
		let imgdata=this.img.data32;
		while (true) {
			if (x>=xlim) {
				if (xnext>=pixels) {break;}
				x=xnext;
				y=~~(x/iw);
				xlim=y*iw+maxx;
				area=0;
				areadx1=0;
			}
			let areadx2=0;
			while (x>=xnext) {
				// fx0  fx0+1                          fx1  fx1+1
				//  +-----+-----+-----+-----+-----+-----+-----+
				//  |                              .....----  |
				//  |               .....-----'''''           |
				//  | ....-----'''''                          |
				//  +-----+-----+-----+-----+-----+-----+-----+
				//   first  dyx   dyx   dyx   dyx   dyx  last   tail
				let l=lr[0];
				if (x>=l.next) {
					let x0=l.x0,y0=l.y0-y;
					let x1=l.x1,y1=l.y1-y;
					let next=Infinity;
					let dxy=l.dxy,y0x=x0-y0*dxy;
					if (y0<0) {y0=0;x0=y0x;}
					if (y1>1) {y1=1;x1=y0x+dxy;next=x1;}
					if (x0>x1) {
						let tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
						next-=dxy;next=next>l.x1?next:l.x1;
					}
					l.sort=next>=maxx?pixels:(xlim-maxx+iw+(next>0?~~next:0));
					let dyx=l.amul/dxy,dyh=dyx*0.5;
					let fx0=x-xlim+maxx;
					let fx1=Math.floor(x1);
					x0-=fx0;
					x1-=fx0>fx1?fx0:fx1;
					let tmp=x1>0?-x1*x1*dyh:0;
					if (fx0<fx1) {
						if (fx1<maxx) {
							l.area=dyh-x1*dyx-tmp;
							l.areadx1=dyx;
							l.areadx2=tmp;
							l.next=l.sort;
							l.sort=fx1+xlim-maxx;
						}
						tmp=x0>0?x0*x0*dyh:0;
						area-=dyh-x0*dyx+tmp;
						areadx1-=dyx;
					} else {
						// Vertical line - avoid divisions.
						let dy=(y0-y1)*l.amul;
						tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
						area+=dy-tmp;
					}
					areadx2+=tmp;
				} else {
					area+=l.area;
					areadx1+=l.areadx1;
					areadx2+=l.areadx2;
					l.sort=l.next;
				}
				// Heap sort down.
				let i=0,j=0;
				while ((j=i+i+1)<lcnt) {
					if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
					if (lr[j].sort>=l.sort) {break;}
					lr[i]=lr[j];
					i=j;
				}
				lr[i]=l;
				xnext=lr[0].sort;
			}
			// Calculate how much we can draw or skip.
			const cutoff=0.00390625;
			let astop=area+areadx1+areadx2;
			let xstop=x+1,xdif=(xnext<xlim?xnext:xlim)-xstop;
			if (xdif>0 && (area>=cutoff)===(astop>=cutoff)) {
				let adif=(cutoff-astop)/areadx1+1;
				xdif=(adif>=1 && adif<xdif)?~~adif:xdif;
				astop+=xdif*areadx1;
				xstop+=xdif;
			}
			// Blend the pixel based on how much we're covering.
			if (area>=cutoff) {
				do {
					// a = sa + da*(1-sa)
					// c = (sc - dc)*sa/a + dc
					let sa=area<alpha?area:alpha;
					area+=areadx1+areadx2;
					areadx2=0;
					let dst=imgdata[x];
					let da=(dst>>>ashift)&255;
					if (da===255) {
						sa=256.49-sa*256;
					} else {
						let tmp=sa*255+(1-sa)*da;
						sa=256.49-sa*65280/tmp;
						da=tmp+0.49;
					}
					// imul() implicitly casts floor(sa).
					imgdata[x]=(da<<ashift)
						|(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&maskl)
						|((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&maskh);
				} while (++x<xstop);
			}
			x=xstop;
			area=astop;
		}
	}

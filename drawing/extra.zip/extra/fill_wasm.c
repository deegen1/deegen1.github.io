/*------------------------------------------------------------------------------


fill_wasm.c - v1.00

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for fillpoly().
The stack and heap share memory. --stack-first keeps the stack at 0.
Some variables are marked as volatile to prevent compiler reordering.

Memory layout:


     +-------+-----+-------+-----+
     | stack | env | image | tmp |
     +-------+-----+-------+-----+


Environment variables:


      0  4 img width
      4  4 img height
      8  4 path len
     12  4 tmp len
     16  4 color
     20 48 transform
     68  * image data


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang fill_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--stack-first \
-Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined --output fill.wasm


--------------------------------------------------------------------------------
TODO


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	#pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
	#pragma clang diagnostic ignored "-Wreserved-identifier"
#endif

#include <stdint.h>
#include <math.h>

typedef  uint8_t u8;
typedef uint16_t u16;
typedef  int16_t i16;
typedef uint32_t u32;
typedef  int32_t i32;
typedef uint64_t u64;
typedef  int64_t i64;
typedef    float f32;
typedef   double f64;


//---------------------------------------------------------------------------------
// Javascript helper functions


extern void dbgprintjs(int h,int l);
void dbgprint(u64 x) {
	dbgprintjs((int)(x>>32),(int)(x&0xffffffff));
}


extern const uint8_t __heap_base;
__attribute__((used)) int getheapbase(void) {
	return (int)&__heap_base;
}


//---------------------------------------------------------------------------------
// Fill helper functions


// Use volatile to prevent reordering.
#define env     ((volatile u64*)&__heap_base)
#define envlen  9
#define mem     (((volatile u64*)&__heap_base)+envlen)
#define stopint 0x20000


// __attribute__((noinline))
u64 getmem(u64 addr) {
	env[7]=addr;
	env[8]=0;
	getmemjs();
	return env[8];
}


// __attribute__((noinline))
u32 setmem(u64 addr,u64 val) {
	env[7]=addr;
	env[8]=val;
	setmemjs();
	return env[8]!=0;
}


void mul64(u64* hi,u64* lo,u64 a,u64 b,u64 mod) {
	u64 rh=0,rl=0;
	if (!hi && !(mod&(mod-1))) {
		rl=(a*b)&(mod-1);
	} else {
		#define add(x) if (x && rl>=mod-x) {rl+=x-mod;rh+=i;} else {rl+=x;}
		for (u64 i=1ULL<<63;i;i>>=1) {
			add(rl)
			if (b&i) {add(a)}
		}
		#undef add
		if (hi) {*hi=rh;}
	}
	if (lo) {*lo=rl;}
}


//---------------------------------------------------------------------------------
// Main Loop


__attribute__((used)) void fillpoly(void) {

}

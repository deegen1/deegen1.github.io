/*------------------------------------------------------------------------------


fill_wasm.c - v1.00

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for fillpoly().
The stack and heap share memory. --stack-first keeps the stack at 0.
Some variables are marked as volatile to prevent compiler reordering.

Memory layout:


     +-------+-----+-------+-----+
     | stack | env | image | tmp |
     +-------+-----+-------+-----+


Environment variables:


      0  4 img width
      4  4 img height
      8  4 path len
     12  4 tmp len
     16  4 color
     20 48 transform
     68  * image data


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang fill_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--stack-first \
-Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined --output fill.wasm


--------------------------------------------------------------------------------
TODO


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	#pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
	#pragma clang diagnostic ignored "-Wreserved-identifier"
#endif

#include <stdint.h>
//#include <math.h>

typedef  uint8_t u8;
typedef uint16_t u16;
typedef  int16_t i16;
typedef uint32_t u32;
typedef  int32_t i32;
typedef uint64_t u64;
typedef  int64_t i64;
typedef    float f32;
typedef   double f64;


//---------------------------------------------------------------------------------
// Javascript helper functions


extern void wasmprinti64(int h,int l);
void dbgprinti64(i64 x) {wasmprinti64((int)(x>>32),(int)(x&0xffffffff));}


extern void wasmprintf64(f64 x);
void dbgprintf64(f64 x) {wasmprintf64(x);}


extern const uint8_t __heap_base;
__attribute__((used)) int getheapbase(void) {
	return (int)&__heap_base;
}

extern void wasmresize(u32 bytes);


// https://github.com/emscripten-core/emscripten
#define fmin  __builtin_wasm_min_f64
#define fmax  __builtin_wasm_max_f64
//#define fmin  __builtin_wasm_min_f32
//#define fmax  __builtin_wasm_max_f32
#define floor __builtin_floor
#define ceil  __builtin_ceil
#define fsqrt __builtin_sqrt
#define fabs  __builtin_fabs
#define isnan __builtin_isnan


//---------------------------------------------------------------------------------
// Main Loop


typedef struct Line {
	f64 x0;
	f64 y0;
	f64 x1;
	f64 y1;
	f64 dxy;
	f64 dyx;
	i32 maxy;
	i32 minx;
	f64 area;
	f64 areadx1;
	f64 areadx2;
	i32 next;
} Line;


typedef struct Vert {
	i32 type;
	i32 filler;
	f64 x;
	f64 y;
} Vert;


#define MOVE  0
//#define CLOSE 1
//#define LINE  2
#define CURVE 3


__attribute__((used)) void fillpoly(void) {
	//dbgprint((u64)getheapbase());
	//dbgprinti64((u64)memlen);
	#define ALIGN ((u32)15)
	u32 heaplen=(((u32)(&__heap_base))+ALIGN)&~ALIGN;
	u32 memlen=*((u32*)heaplen);
	//dbgprinti64((i64)memlen);
	i32 iw=*((i32*)(heaplen+4));
	i32 ih=*((i32*)(heaplen+8));
	u32* imgdata=(u32*)(heaplen+12);
	//i32 pixels=iw*ih;
	//dbgprinti64((i64)iw);
	u32 i,j;
	f64 tmp;
	Line* l;
	//Line** lr;
	f64 splitlen=3;
	f64 x0,y0,x1,y1;
	f64 p0x,p0y,p1x=0,p1y=0;
	i32 pixels=iw*ih;
	u32 imglen=(((u32)(pixels*4))+12+ALIGN)&~ALIGN;
	u32 idx=heaplen+imglen;
	//u32* img32=(&__heap_base)+idx;
	f64 matxx=*((f64*)(idx   ));
	f64 matxy=*((f64*)(idx+ 8));
	f64 matx =*((f64*)(idx+16));
	f64 matyx=*((f64*)(idx+24));
	f64 matyy=*((f64*)(idx+32));
	f64 maty =*((f64*)(idx+40));
	u32 color=*((u32*)(idx+48));
	u32 vidx =*((u32*)(idx+52));
	Vert* varr=(Vert*)(idx+56);
	u32 pathlen=(ALIGN+6*8+4+4+24*vidx)&~ALIGN;
	u32 linestart=heaplen+imglen+pathlen;
	u32 lrcnt=(memlen-linestart)/sizeof(Line),lcnt=0;
	Line* lrs=(Line*)linestart;
	for (i=0;i<vidx;i++) {
		Vert v=varr[i];
		//dbgprinti64((i64)v.type);
		//dbgprintf64(v.x);
		//dbgprintf64(v.y);
		if (v.type==CURVE) {v=varr[i+2];}
		p0x=p1x; p1x=v.x*matxx+v.y*matxy+matx;
		p0y=p1y; p1y=v.x*matyx+v.y*matyy+maty;
		if (v.type==MOVE) {continue;}
		// Add a basic line.
		if (lrcnt<=lcnt) {
			wasmresize(memlen+sizeof(Line));
			memlen=*((u32*)heaplen);
			lrcnt=(memlen-linestart)/sizeof(Line);
		}
		l=lrs+(lcnt++);
		l->x0=p0x;
		l->y0=p0y;
		l->x1=p1x;
		l->y1=p1y;
		if (v.type==CURVE) {
			// Linear decomposition of curves.
			// Get the control points and check if the curve's on the screen.
			v=varr[i++]; f64 c1x=v.x*matxx+v.y*matxy+matx,c1y=v.x*matyx+v.y*matyy+maty;
			v=varr[i++]; f64 c2x=v.x*matxx+v.y*matxy+matx,c2y=v.x*matyx+v.y*matyy+maty;
			f64 c3x=p1x,c3y=p1y;
			x0=fmin(p0x,fmin(c1x,fmin(c2x,c3x)));
			x1=fmax(p0x,fmax(c1x,fmax(c2x,c3x)));
			y0=fmin(p0y,fmin(c1y,fmin(c2y,c3y)));
			y1=fmax(p0y,fmax(c1y,fmax(c2y,c3y)));
			if (x0>=iw || y0>=ih || y1<=0) {lcnt--;continue;}
			if (x1<=0) {continue;}
			// Estimate bezier length.
			f64 dx,dy,dist;
			dx=c1x-p0x;dy=c1y-p0y;dist =fsqrt(dx*dx+dy*dy);
			dx=c2x-c1x;dy=c2y-c1y;dist+=fsqrt(dx*dx+dy*dy);
			dx=c3x-c2x;dy=c3y-c2y;dist+=fsqrt(dx*dx+dy*dy);
			dx=p0x-c3x;dy=p0y-c3y;dist+=fsqrt(dx*dx+dy*dy);
			u32 segs=(u32)(ceil(dist*0.5/splitlen));
			if (segs<=1) {continue;}
			lcnt--;
			if (lrcnt<=lcnt+segs) {
				wasmresize(memlen+sizeof(Line)*(segs+1));
				memlen=*((u32*)heaplen);
				lrcnt=(memlen-linestart)/sizeof(Line);
			}
			// Segment the curve.
			c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
			c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
			f64 ppx=p0x,ppy=p0y,u,unorm=1.0/((f64)segs);
			for (u32 s=0;s<segs;s++) {
				u=(s+1)*unorm;
				f64 cpx=p0x+u*(c1x+u*(c2x+u*c3x));
				f64 cpy=p0y+u*(c1y+u*(c2y+u*c3y));
				l=lrs+(lcnt++);
				l->x0=ppx;
				l->y0=ppy;
				l->x1=cpx;
				l->y1=cpy;
				ppx=cpx;
				ppy=cpy;
			}
		}
	}
	u32 lrstart=(((u32)((u8*)(lrs+lcnt)))+ALIGN)&~ALIGN;
	u32 lrend=lrstart+(lcnt+1)*sizeof(i64);
	if (lrend>memlen) {
		wasmresize(lrend);
		memlen=*((u32*)heaplen);
	}
	//dbgprinti64(memlen);
	//dbgprinti64(lrstart);
	//dbgprinti64(lrend);
	i64* lr=(i64*)lrstart;
	// Prune lines.
	f64 minx=iw,maxx=0,miny=ih,maxy=0;
	f64 amul=((u8*)&color)[3]*(256.0/255.0);
	if ((matxx<0)!=(matyy<0)) {amul=-amul;}
	f64 y0x,y1x,dy,dx;
	u32 maxcnt=lcnt;
	lcnt=0;
	const f64 NAN=0.0/0.0;
	for (i=0;i<maxcnt;i++) {
		l=lrs+i;
		// If we mirror the image, we need to flip the line direction.
		x0=l->x0;y0=l->y0;
		x1=l->x1;y1=l->y1;
		dx=x1-x0;
		dy=y1-y0;
		// Too thin or NaN.
		if (!(dx==dx) || !(fabs(dy)>1e-10)) {continue;}
		// Clamp y to [0,imgheight), then clamp x so x<imgwidth.
		l->dxy=dx/dy;
		l->dyx=fabs(dx)>1e-10?dy/dx:0;
		y0x=x0-y0*l->dxy;
		f64 yhx=x0+(ih-y0)*l->dxy;
		f64 xwy=y0+(iw-x0)*l->dyx;
		if (y0<0 ) {y0=0 ;x0=y0x;}
		if (y0>ih) {y0=ih;x0=yhx;}
		if (y1<0 ) {y1=0 ;x1=y0x;}
		if (y1>ih) {y1=ih;x1=yhx;}
		if (fabs(y1-y0)<1e-20) {continue;}
		if (x0>=iw && x1>=iw) {maxx=iw;continue;}
		f64 fx=y0<y1?x0:x1;
		if (x0>=iw) {x0=iw;y0=xwy;}
		if (x1>=iw) {x1=iw;y1=xwy;}
		// Calculate the bounding box.
		l->minx=(i32)(fmax(fmin(x0,x1),0));
		f64 fy=(i32)(fmin(y0,y1));
		l->maxy=(i32)(ceil(fmax(y0,y1)));
		minx=fmin(minx,l->minx);
		maxx=fmax(maxx,fmax(x0,x1));
		miny=fmin(miny,fy);
		maxy=fmax(maxy,l->maxy);
		l->maxy*=iw;
		l->area=NAN;
		fx=fmin(fx,(fy+1-l->y0)*l->dxy+l->x0);
		lr[lcnt++]=(((i64)(fy*iw+fmax(floor(fx),l->minx)))<<32)|((i64)l);
	}
	// If all lines are outside the image, abort.
	if (minx>=iw || maxx<=0 || minx>=maxx || miny>=maxy || lcnt<=0) {
		return;
	}
	// Linear time heap construction.
	lr[lcnt]=0x7fffffffffffffffLL;
	for (u32 p=(lcnt>>1)-1;p<lcnt;p--) {
		i=p;
		i64 sort=lr[p];
		while ((j=i+i+1)<lcnt) {
			i64 lv=lr[j],rv=lr[j+1];
			if (rv<lv) {j++;lv=rv;}
			if (lv>=sort) {break;}
			lr[i]=lv;
			i=j;
		}
		lr[i]=sort;
	}
	//for (i=0;i<lcnt;i++) {
	//	dbgprinti64(-((i64)i));
	//	dbgprinti64((i64)lr[i]->sort);
	//}
	// Init blending.
	u32 amask=0,ashift=0;
	((u8*)&amask)[3]=255;
	while ((amask>>ashift)>255) {ashift+=8;}
	f64 imask=1.0/((f64)amask);
	u32 maskl=0x00ff00ff&~amask,maskh=0xff00ff00&~amask;
	u32 sa;
	//u32 da;
	u32 colrgb=color&~amask;
	u32 coll=colrgb&0x00ff00ff,colh=colrgb&0xff00ff00,colh8=colh>>8;
	f64 filllim=255;
	// Process the lines row by row.
	i32 x=lr[0]>>32,y=0;
	i32 xnext=x,xrow=-1;
	f64 area=0,areadx1=0,areadx2;
	while (1) {
		areadx2=0;
		if (x>=xrow) {
			if (xnext<x || xnext>=pixels) {break;}
			x=xnext;
			y=(i32)(x/iw);
			xrow=(y+1)*iw;
			area=0;
			areadx1=0;
		}
		while (x>=xnext) {
			// fx0  fx0+1                          fx1  fx1+1
			//  +-----+-----+-----+-----+-----+-----+-----+
			//  |                              .....----  |
			//  |               .....-----'''''           |
			//  | ....-----'''''                          |
			//  +-----+-----+-----+-----+-----+-----+-----+
			//   first  dyx   dyx   dyx   dyx   dyx  last   tail
			l=(Line*)(lr[0]&0xffffffff);
			i64 sort;
			if (isnan(l->area)) {
				x0=l->x0;y0=l->y0-y;
				x1=l->x1;y1=l->y1-y;
				f64 dyx=l->dyx,dxy=l->dxy;
				y0x=x0-y0*dxy;
				y1x=y0x+dxy;
				if (y0<0) {y0=0;x0=y0x;}
				if (y0>1) {y0=1;x0=y1x;}
				if (y1<0) {y1=0;x1=y0x;}
				if (y1>1) {y1=1;x1=y1x;}
				i32 next=(i32)((y0>y1?x0:x1)+(dxy<0?dxy:0));
				next=xrow+(next>l->minx?next:l->minx);
				if (next>=l->maxy) {next=pixels;}
				if (x1<x0) {tmp=x0;x0=x1;x1=tmp;dyx=-dyx;}
				i32 fx0=(i32)x0;
				i32 fx1=(i32)x1;
				x0-=fx0;
				x1-=fx1;
				if (fx0==fx1 || fx1<0) {
					// Vertical line - avoid divisions.
					dy=(y0-y1)*amul;
					tmp=fx1>=0?(x0+x1)*dy*0.5:0;
					area+=dy-tmp;
					areadx2+=tmp;
					sort=next;
				} else {
					dyx*=amul;
					f64 mul=dyx*0.5,n0=x0-1,n1=x1-1;
					if (fx0<0) {
						area-=mul-(x0+fx0)*dyx;
					} else {
						area-=n0*n0*mul;
						areadx2+=x0*x0*mul;
					}
					areadx1-=dyx;
					l->area=n1*n1*mul;
					l->areadx1=dyx;
					l->areadx2=x1*x1*mul;
					l->next=next;
					sort=fx1<iw?fx1+xrow-iw:next;
				}
			} else {
				area   +=l->area;
				areadx1+=l->areadx1;
				areadx2-=l->areadx2;
				l->area =NAN;
				sort =l->next;
			}
			// Heap sort down.
			i=0;
			sort=(sort<<32)|((i64)l);
			while ((j=i+i+1)<lcnt) {
				i64 lv=lr[j],rv=lr[j+1];
				if (rv<lv) {j++;lv=rv;}
				if (lv>=sort) {break;}
				lr[i]=lv;
				i=j;
			}
			lr[i]=sort;
			xnext=lr[0]>>32;
		}
		// Shade the pixels based on how much we're covering.
		// If the area isn't changing much use the same area for multiple pixels.
		i32 xdraw=x+1;
		u32 sa1=(u32)(area+0.5);
		if (areadx2==0) {
			tmp=fmin(fmax(sa1+(areadx1<0?-0.5:0.5),0.5),255.5);
			tmp=(tmp-area)/areadx1+x;
			xdraw=(tmp>x && tmp<xnext)?(i32)(ceil(tmp)):xnext;
			if (xdraw>xrow) {xdraw=xrow;}
			areadx2=(xdraw-x)*areadx1;
		} else {
			areadx2+=areadx1;
		}
		if (sa1>=filllim) {
			u32 col=colrgb|((sa1<255?sa1:255)<<ashift);
			do {imgdata[x]=col;} while (++x<xdraw);
		} else if (sa1>0) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			sa1=256-sa1;
			f64 sab=area*(1.0/256.0),sai=(1-sab)*imask;
			do {
				u32 dst=imgdata[x];
				u32 da=dst&amask;
				if (da==amask) {
					sa=sa1;
				} else {
					tmp=sab+da*sai;
					sa=256-((u32)(area/tmp+0.5));
					da=((u32)(tmp*255.0+0.5))<<ashift;
				}
				imgdata[x]=da|
					(((((dst&0x00ff00ff)-coll)*sa>>8)+coll)&maskl)|
					(((((dst>>8)&0x00ff00ff)-colh8)*sa+colh)&maskh);
			} while (++x<xdraw);
		}
		x=xdraw;
		area+=areadx2;
	}
}

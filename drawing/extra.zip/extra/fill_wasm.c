/*------------------------------------------------------------------------------


fill_wasm.c - v1.03

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for fillpoly().
The stack and heap share memory. --stack-first keeps the stack at 0.
Some variables are marked as volatile to prevent compiler reordering.

Memory layout:


     +-------+-----+-------+-----+
     | stack | env | image | tmp |
     +-------+-----+-------+-----+


Environment variables:


      0  4 img width
      4  4 img height
      8  4 path len
     12  4 tmp len
     16  4 color
     20 48 transform
     68  * image data


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang fill_wasm.c --target=wasm32 -O3 -nostdlib -Wl,--stack-first \
-Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined --output fill.wasm
-mbulk-memory


--------------------------------------------------------------------------------
TODO


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	#pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
	#pragma clang diagnostic ignored "-Wreserved-identifier"
	#pragma clang diagnostic ignored "-Wfloat-equal"
#endif

#include <stdint.h>
// #include <math.h>

typedef  uint8_t u8;
typedef uint16_t u16;
typedef  int16_t i16;
typedef uint32_t u32;
typedef  int32_t i32;
typedef uint64_t u64;
typedef  int64_t i64;
typedef    float f32;
typedef   double f64;


//---------------------------------------------------------------------------------
// Javascript helper functions


extern void wasmprinti64(int h,int l);
void dbgprinti64(i64 x) {wasmprinti64((int)(x>>32),(int)(x&0xffffffff));}


extern void wasmprintf64(f64 x);
void dbgprintf64(f64 x) {wasmprintf64(x);}


extern const uint8_t __heap_base;
__attribute__((used)) int getheapbase(void) {
	return (int)&__heap_base;
}

extern void wasmresize(u32 bytes);


// https://github.com/emscripten-core/emscripten
#define fmin  __builtin_wasm_min_f64
#define fmax  __builtin_wasm_max_f64
// #define fmin  __builtin_wasm_min_f32
// #define fmax  __builtin_wasm_max_f32
// #define floor __builtin_floor
// #define ceil  __builtin_ceil
// #define fsqrt __builtin_sqrt
#define fabs  __builtin_fabs
// #define isnan __builtin_isnan


//---------------------------------------------------------------------------------
// Main Loop


typedef struct Line {
	f64 x0;
	f64 y0;
	f64 x1;
	f64 y1;
	f64 dxy;
	f64 amul;
	f64 area;
	f64 areadx1;
	f64 areadx2;
	i32 next;
} Line;


typedef struct Vert {
	i32 type;
	i32 _pad;
	f64 x;
	f64 y;
} Vert;


#define MOVE  0
// #define CLOSE 1
// #define LINE  2
#define CURVE 3


__attribute__((used)) void fillpoly(void) {
	// dbgprint((u64)getheapbase());
	// dbgprinti64((u64)memlen);
	#define ALIGN ((u32)15)
	#define curvemaxdist2 0.01
	u32 heaplen=(((u32)(&__heap_base))+ALIGN)&~ALIGN;
	u32 memlen=*((u32*)heaplen);
	// dbgprinti64((i64)memlen);
	i32 iw=*((i32*)(heaplen+4));
	i32 ih=*((i32*)(heaplen+8));
	u32* imgdata=(u32*)(heaplen+12);
	// i32 pixels=iw*ih;
	// dbgprinti64((i64)iw);
	Line* l;
	// Line** lr;
	f64 p0x,p0y,p1x=0,p1y=0;
	f64 movex=0,movey=0;
	i32 pixels=iw*ih;
	u32 imglen=(((u32)(pixels*4))+12+ALIGN)&~ALIGN;
	u32 idx=heaplen+imglen;
	// u32* img32=(&__heap_base)+idx;
	f64 matxx=*((f64*)(idx   ));
	f64 matxy=*((f64*)(idx+ 8));
	f64 matx =*((f64*)(idx+16));
	f64 matyx=*((f64*)(idx+24));
	f64 matyy=*((f64*)(idx+32));
	f64 maty =*((f64*)(idx+40));
	u32 color=*((u32*)(idx+48));
	u32 vidx =*((u32*)(idx+52));
	Vert* varr=(Vert*)(idx+56);
	u32 pathlen=(ALIGN+6*8+4+4+24*vidx)&~ALIGN;
	u32 linestart=heaplen+imglen+pathlen;
	u32 lrcnt=(memlen-linestart)/sizeof(Line),lcnt=0;
	Line* lrs=(Line*)linestart;
	for (u32 i=0;i<vidx;i++) {
		Vert v=varr[i];
		// dbgprinti64((i64)v.type);
		// dbgprintf64(v.x);
		// dbgprintf64(v.y);
		if (v.type==CURVE) {v=varr[i+2];}
		p0x=p1x; p1x=v.x*matxx+v.y*matxy+matx;
		p0y=p1y; p1y=v.x*matyx+v.y*matyy+maty;
		if (v.type==MOVE) {movex=p1x;movey=p1y;continue;}
		// Add a basic line.
		if (lrcnt<=lcnt) {
			wasmresize(memlen+sizeof(Line));
			memlen=*((u32*)heaplen);
			lrcnt=(memlen-linestart)/sizeof(Line);
		}
		l=lrs+(lcnt++);
		l->x0=p0x;
		l->y0=p0y;
		l->x1=p1x;
		l->y1=p1y;
		if (v.type==CURVE) {
			// Linear decomposition of curves.
			// Get the control points and check if the curve's on the screen.
			v=varr[i++]; f64 c1x=v.x*matxx+v.y*matxy+matx,c1y=v.x*matyx+v.y*matyy+maty;
			v=varr[i++]; f64 c2x=v.x*matxx+v.y*matxy+matx,c2y=v.x*matyx+v.y*matyy+maty;
			if ((p0x<=0 && p1x<=0 && c1x<=0 && c2x<=0) || (p0x>=iw && p1x>=iw && c1x>=iw && c2x>=iw) ||
			    (p0y<=0 && p1y<=0 && c1y<=0 && c2y<=0) || (p0y>=ih && p1y>=ih && c1y>=ih && c2y>=ih)) {
				continue;
			}
			l->amul=0;l->area=1;
			c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;f64 c3x=p1x-p0x-c2x;c2x-=c1x;
			c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;f64 c3y=p1y-p0y-c2y;c2y-=c1y;
			for (u32 j=lcnt-1;j<lcnt;j++) {
				// For each line segment between [u0,u1], sample the curve at a few spots between
				// u0 and u1 and measure the distance to the line. If it's too great, split.
				l=lrs+j;
				f64 x0=l->x0,x1=l->x1,dx=x1-x0;
				f64 y0=l->y0,y1=l->y1,dy=y1-y0;
				f64 u0=l->amul,u1=l->area,du=(u1-u0)*0.25;
				f64 den=dx*dx+dy*dy;
				f64 maxdist=-(1.0/0.0),mu=0,mx=0,my=0;
				for (u32 s=0;s<3;s++) {
					// Project a point on the curve onto the line. Clamp to ends of line.
					u0+=du;
					f64 sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
					f64 sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
					f64 w=dx*lx+dy*ly;
					w=w>0?(w<den?w/den:1):0;
					lx-=dx*w;
					ly-=dy*w;
					f64 dist=lx*lx+ly*ly;
					if (maxdist<dist) {
						maxdist=dist;
						mu=u0;
						mx=sx;
						my=sy;
					}
				}
				if (maxdist>curvemaxdist2 && maxdist<(1.0/0.0)) {
					// The line is too far from the curve, so split it.
					if (lrcnt<=lcnt) {
						wasmresize(memlen+sizeof(Line));
						memlen=*((u32*)heaplen);
						lrcnt=(memlen-linestart)/sizeof(Line);
					}
					l->x1=mx;
					l->y1=my;
					l->area=mu;
					l=lrs+(lcnt++);
					l->x0=mx;
					l->y0=my;
					l->x1=x1;
					l->y1=y1;
					l->amul=mu;
					l->area=u1;
					j--;
				}
			}
		}
	}
	// Close the path.
	if (movex!=p1x || movey!=p1y) {
		if (lrcnt<=lcnt) {
			wasmresize(memlen+sizeof(Line));
			memlen=*((u32*)heaplen);
			lrcnt=(memlen-linestart)/sizeof(Line);
		}
		l=lrs+(lcnt++);
		l->x0=p1x;
		l->y0=p1y;
		l->x1=movex;
		l->y1=movey;
	}
	u32 lrstart=(((u32)((u8*)(lrs+lcnt)))+ALIGN)&~ALIGN;
	u32 lrend=lrstart+(lcnt+1)*sizeof(i64);
	if (lrend>memlen) {
		wasmresize(lrend);
		memlen=*((u32*)heaplen);
	}
	// dbgprinti64(memlen);
	// dbgprinti64(lrstart);
	// dbgprinti64(lrend);
	i64* lr=(i64*)lrstart;
	// Prune lines.
	f64 minx=iw,maxx=0,miny=ih,maxy=0;
	// f64 amul=((u8*)&color)[3]*(256.0/255.0);
	// u32 alpha=(u32)amul;
	f64 amul=((u8*)&color)[3]/255.0;
	f64 alpha=amul;
	amul=(matxx<0)!=(matyy<0)?-amul:amul;
	u32 maxcnt=lcnt;
	lcnt=0;
	for (u32 i=0;i<maxcnt;i++) {
		l=lrs+i;
		// Always point the line up to simplify math.
		f64 x0=l->x0,x1=l->x1;
		f64 y0=l->y0,y1=l->y1;
		l->amul=amul;
		if (y0>y1) {
			l->x0=x1;l->x1=x0;x0=x1;x1=l->x1;
			l->y0=y1;l->y1=y0;y0=y1;y1=l->y1;
			l->amul=-amul;
		}
		f64 dx=x1-x0,dy=y1-y0;
		// Too thin or NaN.
		if (!(dx==dx) || !(dy>1e-9)) {continue;}
		// Clamp y to [0,imgheight), then clamp x so x<imgwidth.
		l->dxy=dx/dy;
		f64 dyx=fabs(dx)>1e-9?dy/dx:0;
		f64 y0x=x0-y0*l->dxy;
		f64 yhx=x0+(ih-y0)*l->dxy;
		f64 xwy=y0+(iw-x0)*dyx;
		if (y0<0 ) {y0=0 ;x0=y0x;}
		if (y1>ih) {y1=ih;x1=yhx;}
		if (y1-y0<1e-9) {continue;}
		if (x0>=iw && x1>=iw) {maxx=iw;continue;}
		if (x0>=iw) {x0=iw;y0=xwy;}
		if (x1>=iw) {x1=iw;y1=xwy;}
		// Calculate the bounding box.
		minx=fmin(minx,fmin(x0,x1));
		maxx=fmax(maxx,fmax(x0,x1));
		miny=miny<y0?miny:y0;
		maxy=maxy>y1?maxy:y1;
		i32 fy=(i32)y0;
		if (x1<x0) {x0=fmax(l->x0+(fy+1-l->y0)*l->dxy,x1);}
		l->next=0;
		lr[lcnt++]=(((i64)(fy*iw+((i32)(x0>0?x0:0))))<<32)|((i64)l);
	}
	// If all lines are outside the image, abort.
	if (minx>=iw || maxx<=0 || minx>=maxx || miny>=maxy || lcnt<=0) {
		return;
	}
	// Linear time heap construction.
	lr[lcnt]=0x7fffffffffffffffLL;
	for (u32 p=(lcnt>>1)-1;p<lcnt;p--) {
		u32 i=p,j;
		i64 sort=lr[p];
		while ((j=i+i+1)<lcnt) {
			i64 lv=lr[j],rv=lr[j+1];
			if (rv<lv) {j++;lv=rv;}
			if (lv>=sort) {break;}
			lr[i]=lv;
			i=j;
		}
		lr[i]=sort;
	}
	// for (i=0;i<lcnt;i++) {
	// 	dbgprinti64(-((i64)i));
	// 	dbgprinti64((i64)lr[i]->sort);
	// }
	// Init blending.
	u32 amask=0,ashift=0;
	((u8*)&amask)[3]=255;
	while ((amask>>ashift)>255) {ashift+=8;}
	// const u32 ashift=24,amask=0xff000000;
	const u32 maskl=0x00ff00ff&~amask,maskh=0xff00ff00&~amask;
	// f64 imask=1.0/((f64)amask);
	u32 colrgb=color&~amask;
	u32 coll=colrgb&0x00ff00ff,colh=colrgb&0xff00ff00,colh8=colh>>8;
	// Process the lines row by row.
	i32 x=lr[0]>>32,y=0;
	i32 xnext=x,xrow=-1;
	f64 area=0,areadx1=0,areadx2;
	while (1) {
		if (x>=xrow) {
			if (xnext>=pixels) {break;}
			x=xnext;
			y=x/iw;
			xrow=(y+1)*iw;
			area=0;
			areadx1=0;
		}
		areadx2=0;
		while (x>=xnext) {
			// fx0  fx0+1                          fx1  fx1+1
			//  +-----+-----+-----+-----+-----+-----+-----+
			//  |                              .....----  |
			//  |               .....-----'''''           |
			//  | ....-----'''''                          |
			//  +-----+-----+-----+-----+-----+-----+-----+
			//   first  dyx   dyx   dyx   dyx   dyx  last   tail
			l=(Line*)(lr[0]&0xffffffff);
			i64 sort;
			if (x>=l->next) {
				f64 x0=l->x0,y0=l->y0-y;
				f64 x1=l->x1,y1=l->y1-y;
				f64 next=1.0/0.0;
				f64 dxy=l->dxy,y0x=x0-y0*dxy;
				if (y0<0) {y0=0;x0=y0x;}
				if (y1>1) {y1=1;x1=y0x+dxy;next=x1;}
				if (x0>x1) {
					f64 tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
					next-=dxy;next=next>l->x1?next:l->x1;
				}
				sort=next>=iw?pixels:(xrow+((i32)(next>0?next:0)));
				f64 dyx=l->amul/dxy,dyh=dyx*0.5;
				i32 fx0=x-xrow+iw;
				i32 fx1=(i32)x1;
				x0-=fx0;
				x1-=fx0>fx1?fx0:fx1;
				f64 tmp=x1>0?-x1*x1*dyh:0;
				if (fx0>=fx1) {
					// Vertical line - avoid divisions.
					f64 dy=(y0-y1)*l->amul;
					tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
					area+=dy-tmp;
				} else {
					if (fx1<iw) {
						l->area=dyh-x1*dyx-tmp;
						l->areadx1=dyx;
						l->areadx2=tmp;
						l->next=(i32)sort;
						sort=fx1+xrow-iw;
					}
					tmp=x0>0?x0*x0*dyh:0;
					area-=dyh-x0*dyx+tmp;
					areadx1-=dyx;
				}
				areadx2+=tmp;
			} else {
				area+=l->area;
				areadx1+=l->areadx1;
				areadx2+=l->areadx2;
				sort=l->next;
			}
			// Heap sort down.
			if (sort<pixels) {
				sort=(sort<<32)|((i64)l);
			} else if (--lcnt) {
				sort=lr[lcnt];
				lr[lcnt]=0x7fffffffffffffffLL;
			} else {
				// The last element will overwrite lr[lcnt]=0x7fff...
				sort=0x7fffffffffffffffLL;
			}
			u32 i=0,j=1;
			while (j<lcnt) {
				i64 lv=lr[j],rv=lr[j+1];
				if (lv>rv) {j++;lv=rv;}
				if (lv>=sort) {break;}
				lr[i]=lv;
				i=j;
				j+=j+1;
			}
			lr[i]=sort;
			xnext=lr[0]>>32;
		}
		// Calculate how much we can draw or skip.
		const f64 cutoff=0.00390625;
		f64 astop=area+areadx1+areadx2;
		i32 xstop=x+1,xdif=(xnext<xrow?xnext:xrow)-xstop;
		if (xdif>0 && (area>=cutoff)==(astop>=cutoff)) {
			f64 adif=(cutoff-astop)/areadx1+1;
			xdif=(adif>=1 && adif<xdif)?((i32)adif):xdif;
			astop+=xdif*areadx1;
			xstop+=xdif;
		}
		/*if (area>=cutoff) {
			if (fabs(areadx1)<=1e-5) {
				if (areadx2!=0) {
					// a = sa + da*(1-sa)
					// c = (sc - dc)*sa/a + dc
					f64 sa=area<alpha?area:alpha;
					u32 dst=imgdata[x];
					f64 da=(dst>>ashift)&255;
					if (da==255) {
						sa=256.49-sa*256;
					} else {
						f64 tmp=sa*255+(1-sa)*da;
						sa=256.49-sa*65280/tmp;
						da=tmp+0.49;
					}
					u32 sai=(u32)sa;
					imgdata[x++]=(((u32)da)<<ashift)|
						(((((dst&0x00ff00ff)-coll)*sai>>8)+coll)&maskl)|
						(((((dst>>8)&0x00ff00ff)-colh8)*sai+colh)&maskh);
					area+=areadx2;
				}
				if (x<xstop) {
					f64 sa=area<alpha?area:alpha;
					if (sa>=0.998046875) {
						u32 col=colrgb|amask;
						do {imgdata[x]=col;} while (++x<xstop);
					} else if (sa>=cutoff) {
						// a = sa + da*(1-sa)
						// c = (sc - dc)*sa/a + dc
						u32 sa1=(u32)(256.49-sa*256);
						do {
							// a = sa + da*(1-sa)
							// c = (sc - dc)*sa/a + dc
							u32 dst=imgdata[x];
							f64 da=(dst>>ashift)&255;
							u32 sai=sa1;
							if (da!=255) {
								f64 tmp=sa*255+(1-sa)*da;
								sai=(u32)(256.49-sa*65280/tmp);
								da=tmp+0.49;
							}
							imgdata[x]=(((u32)da)<<ashift)|
								(((((dst&0x00ff00ff)-coll)*sai>>8)+coll)&maskl)|
								(((((dst>>8)&0x00ff00ff)-colh8)*sai+colh)&maskh);
						} while (++x<xstop);
					}
				}
			} else {
				do {
					// a = sa + da*(1-sa)
					// c = (sc - dc)*sa/a + dc
					f64 sa=area<alpha?area:alpha;
					area+=areadx1+areadx2;
					areadx2=0;
					u32 dst=imgdata[x];
					f64 da=(dst>>ashift)&255;
					if (da==255) {
						sa=256.49-sa*256;
					} else {
						f64 tmp=sa*255+(1-sa)*da;
						sa=256.49-sa*65280/tmp;
						da=tmp+0.49;
					}
					u32 sai=(u32)sa;
					imgdata[x]=(((u32)da)<<ashift)|
						(((((dst&0x00ff00ff)-coll)*sai>>8)+coll)&maskl)|
						(((((dst>>8)&0x00ff00ff)-colh8)*sai+colh)&maskh);
				} while (++x<xstop);
			}
		}
		x=xstop;
		area=astop;*/
		// Blend the pixel based on how much we're covering.
		if (area>=cutoff) {
			do {
				// a = sa + da*(1-sa)
				// c = (sc - dc)*sa/a + dc
				f64 sa=area<alpha?area:alpha;
				area+=areadx1+areadx2;
				areadx2=0;
				u32 dst=imgdata[x];
				f64 da=(dst>>ashift)&255;
				if (da==255) {
					sa=256.49-sa*256;
				} else {
					f64 tmp=sa*255+(1-sa)*da;
					sa=256.49-sa*65280/tmp;
					da=tmp+0.49;
				}
				u32 sai=(u32)sa;
				imgdata[x]=(((u32)da)<<ashift)|
					(((((dst&0x00ff00ff)-coll)*sai>>8)+coll)&maskl)|
					(((((dst>>8)&0x00ff00ff)-colh8)*sai+colh)&maskh);
			} while (++x<xstop);
		}
		x=xstop;
		area=astop;
		// Shade the pixels based on how much we're covering.
		// If the area isn't changing much use the same area for multiple pixels.
		/*i32 xdraw;
		u32 sa1=(u32)(area+0.5);
		if (areadx2==0) {
			if (fabs(areadx1)<1e-9) {
				xdraw=xnext;
			} else {
				f64 tmp=fmin(fmax(sa1+(areadx1<0?-0.5:0.5),0.5),255.5);
				tmp=(tmp-area)/areadx1+x;
				xdraw=(tmp>x && tmp<xnext)?(i32)(ceil(tmp)):xnext;
			}
			if (xdraw>xrow) {xdraw=xrow;}
			areadx2=(xdraw-x)*areadx1;
		} else {
			xdraw=x+1;
			areadx2+=areadx1;
		}
		sa1=sa1<alpha?sa1:alpha;
		if (sa1>=255) {
			u32 col=colrgb|amask;
			do {imgdata[x]=col;} while (++x<xdraw);
		} else if (sa1>0) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			// c = (sc - dc)*sa/a + dc
			sa1=256-sa1;
			f64 sab=area*(1.0/256.0),sai=(1-sab)*imask;
			do {
				u32 dst=imgdata[x];
				u32 da=dst&amask,sa;
				if (da==amask) {
					sa=sa1;
				} else {
					f64 tmp=sab+da*sai;
					sa=256-((u32)(area/tmp+0.5));
					da=((u32)(tmp*255.0+0.5))<<ashift;
				}
				imgdata[x]=da|
					(((((dst&0x00ff00ff)-coll)*sa>>8)+coll)&maskl)|
					(((((dst>>8)&0x00ff00ff)-colh8)*sa+colh)&maskh);
			} while (++x<xdraw);
		}
		x=xdraw;
		area+=areadx2;*/
	}
}

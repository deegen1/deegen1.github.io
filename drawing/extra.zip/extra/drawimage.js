/*------------------------------------------------------------------------------


drawimage.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


maxbits=9, tests=10000

Func      |    ISO    |    2^-3   |    2^-2   |    2^-1   |    2^0    |    2^1    |    2^2    |    2^3
----------+-----------+-----------+-----------+-----------+-----------+-----------+-----------+-----------
DrawI FF  |   0.2406
DrawF FF  |   0.4028
Draw1 FF  |   3.0704  |   0.9348  |   1.6854  |   3.7893  |   8.9366  |  22.1076  |  38.7595  |  64.3557
Draw2 FF  |   1.9974  |   1.6388  |   2.2003  |   3.5731  |   6.3445  |  13.0903  |  20.5578  |  32.5617
Draw3 FF  |   1.6733  |   1.9517  |   2.5817  |   4.1206  |   7.1728  |  14.6896  |  23.0747  |  36.3240
Draw4 FF  |   2.1858  |   1.3950  |   1.8550  |   3.0206  |   5.3489  |  11.2723  |  18.1800  |  29.1808
Draw5 FF  |   1.4985  |   1.2816  |   1.7196  |   2.7644  |   4.8267  |   9.7720  |  15.4685  |  24.5054
Draw6 FF  |   1.5496  |   1.3726  |   1.8301  |   2.9591  |   5.1992  |  10.6685  |  16.8611  |  26.8372
DrawI CR  |   0.2318
DrawF CR  |   0.3192
Draw1 CR  |   2.0075  |   0.5729  |   0.9665  |   2.1188  |   4.9570  |  12.1961  |  21.2511  |  35.6497
Draw2 CR  |   1.4640  |   1.0370  |   1.3981  |   2.2968  |   4.0905  |   8.5187  |  13.4394  |  21.4602
Draw3 CR  |   1.3949  |   0.9545  |   1.2753  |   2.0695  |   3.6488  |   7.6084  |  12.0916  |  19.2100
Draw4 CR  |   1.4776  |   0.8463  |   1.1278  |   1.8181  |   3.2064  |   6.7341  |  10.8783  |  17.5502
Draw5 CR  |   1.0814  |   0.8359  |   1.1031  |   1.7784  |   3.2569  |   6.6256  |  10.6625  |  17.0823
Draw6 CR  |   1.0822  |   0.8312  |   1.1057  |   1.7724  |   3.1765  |   6.4742  |  10.3971  |  16.9497


*/
/* npx eslint drawimage.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Transform,Input} from "../library.js";


//---------------------------------------------------------------------------------
// Helper Functions


function UnitAreaCalc(x0,y0,x1,y1,px,py) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	let tmp=0,sign=1;
	if (isNaN((y1-y0)/(x1-x0))) {return 0;}
	x0-=px;y0-=py;
	x1-=px;y1-=py;
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	//if (x0>=Infinity || x1>=Infinity) {return 0;}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	// If we're entirely outside the bounding box.
	if (!(y0<1 && y1>0 && x0<1 && x1===x1)) {return 0;}
	let iy0=y0>0?y0:0;
	let iy1=y1<1?y1:1;
	if (x1<=0) {return (iy0-iy1)*sign;}
	// Determine if [0,1] is entirely to the left/right of slope.
	let dx=x1-x0,dy=y1-y0;
	// x=x0+(y-y0)*dx/dy
	if ((1-x0)*dy<=(iy0-y0)*dx) {return 0;}
	if ((0-x0)*dy>=(iy1-y0)*dx) {return (iy0-iy1)*sign;}
	// Narrow-phase. Clip to unit box.
	let x0y=y0-dy*(x0/dx);
	let x1y=y0+dy*((1-x0)/dx);
	let y0x=x0-dx*(y0/dy);
	let y1x=x0+dx*((1-y0)/dy);
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function AABBCheck(img_aabb,path_aabb,trans) {
	// Transform the path AABB to an OBB.
	// new_x = x*matxx + y*matxy + matx
	// new_y = x*matyx + y*matyy + maty
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let imgx=img_aabb.minx,imgy=img_aabb.miny;
	let imgw=img_aabb.maxx-imgx,imgh=img_aabb.maxy-imgy;
	// Define the transformed bounding box.
	let bx=path_aabb.minx,by=path_aabb.miny;
	let bndx=bx*matxx+by*matxy+matx-imgx;
	let bndy=bx*matyx+by*matyy+maty-imgy;
	bx=path_aabb.maxx-bx;by=path_aabb.maxy-by;
	let bndxx=bx*matxx,bndxy=bx*matyx;
	let bndyx=by*matxy,bndyy=by*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-imgw,maxx=bndx;
	if (bndxx<0) {minx+=bndxx;} else {maxx+=bndxx;}
	if (bndyx<0) {minx+=bndyx;} else {maxx+=bndyx;}
	if (!(minx<0 && 0<maxx)) {return false;}
	let miny=bndy-imgh,maxy=bndy;
	if (bndxy<0) {miny+=bndxy;} else {maxy+=bndxy;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return false;}
	// Test if the path OBB has a separating axis.
	let cross=bndxx*bndyy-bndxy*bndyx;
	minx=bndy*bndxx-bndx*bndxy;maxx=minx;
	bndxx*=imgh;bndxy*=imgw;
	if (cross<0) {minx+=cross;} else {maxx+=cross;}
	if (bndxx<0) {maxx-=bndxx;} else {minx-=bndxx;}
	if (bndxy<0) {minx+=bndxy;} else {maxx+=bndxy;}
	if (!(minx<0 && 0<maxx)) {return false;}
	miny=bndy*bndyx-bndx*bndyy;maxy=miny;
	bndyx*=imgh;bndyy*=imgw;
	if (cross<0) {maxy-=cross;} else {miny-=cross;}
	if (bndyx<0) {maxy-=bndyx;} else {miny-=bndyx;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return false;}
	return true;
}


class AreaImage {

	constructor(width,height) {
		this.width=width;
		this.height=height;
		this.data=new Float64Array(width*height);
		this.clear();
	}


	clear() {
		let data=this.data;
		let i=this.width*this.height;
		if (i>data.length) {
			throw `invalid dimensions: ${i}, ${data.length}`;
		}
		while (i>7) {
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
		}
		while (i>0) {
			data[--i]=0;
		}
		this.readidx=0;
		this.writeidx=0;
		this.lockmax=-1;
	}


	lockrow(y) {
		if (!(y>=0 && y<this.height && y===(y|0))) {
			throw `invalid y: ${y}`;
		}
		let w=this.width,i=y*w;
		this.readidx=-i;
		this.writeidx=-i;
		this.lockmax=i+w;
	}


	write(i,val) {
		let r=this.readidx,w=this.writeidx;
		if (w<=0) {
			if (i<-w || !(i===(i|0))) {throw `non consecutive write: ${i} != ${w}`;}
			w=i;
		}
		if (!(i===w && i<this.lockmax)) {
			throw `Write OOB: ${w} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=++w;
		this.readidx=w>r?w:r;
		this.data[i]=val;
	}


	read(i) {
		let r=this.readidx,w=this.writeidx;
		if (r<=0) {
			if (i<-r || !(i===(i|0))) {throw `non consecutive read: ${i} != ${r}`;}
			r=i;
		}
		if (!(i===r && i<this.lockmax)) {
			throw `Read OOB: ${r} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=w>r?w:r;
		this.readidx=r+1;
		return this.data[i];
	}

}


//---------------------------------------------------------------------------------
// Stride


function CalcRowBounds1(ret,x0,y0,x1,y1,py,imgw) {
	let area=0,areadx1=0,areadx2=0;
	let minx=Infinity,maxx=-Infinity;
	ret.skip=0;
	let sidx=0,aidx=0;
	let sortarr=ret.sortarr;
	let areaarr=ret.areaarr;
	while (true) {
		let sign=1,tmp=0;
		if (x0>x1) {
			sign=-1;
			tmp=x0;x0=x1;x1=tmp;
			tmp=y0;y0=y1;y1=tmp;
		}
		y0-=py;y1-=py;
		if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
		// Above, below, or degenerate.
		if (y1<=0 || y0>=1) {break;}
		let dx=x1-x0,dy=y1-y0,dyx=dy/dx;
		let dxy=dx/dy,y0x=x0-y0*dxy;
		if (y0<0) {y0=0;x0=y0x;}
		if (y1>1) {y1=1;x1=y0x+dxy;}
		minx=minx<x0?minx:x0;
		maxx=maxx>x1?maxx:x1;
		if (x0>=imgw || !(dyx!==0)) {break;}
		let i0=x0>0?~~x0:0;
		let i1=x1>0?~~x1:0;
		x0-=i0;
		x1-=i1;
		dy*=0.5*sign;
		let tmp1=x1>0?(x1*x1/dx)*dy:0;
		let xlen=i1-i0;
		if (xlen<=0) {
			// 1 pixel or last.
			dy=(y0-y1)*sign;
			let tmp0=x0>=0?(x0+x1)*dy*0.5:-tmp1;
			sortarr[sidx++]=i0;
			areaarr[aidx++]=dy-tmp0;
			areaarr[aidx++]=0;
			areaarr[aidx++]=tmp0;
		} else if (xlen<=1) {
			// 2 pixels. Avoid dyx in case it's thin.
			let tmp0=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
			dy=(y0-y1)*sign;
			sortarr[sidx++]=i0;
			areaarr[aidx++]=-tmp0;
			areaarr[aidx++]=0;
			areaarr[aidx++]=0;
			sortarr[sidx++]=i1;
			areaarr[aidx++]=dy+tmp0+tmp1;
			areaarr[aidx++]=0;
			areaarr[aidx++]=-tmp1;
		} else {
			// 3+ pixels.
			dyx*=sign;
			let tmp0=x0>0?(x0*x0/dx)*dy:0;
			sortarr[sidx++]=i0;
			areaarr[aidx++]=-((1-2*x0)/dx)*dy-tmp0;
			areaarr[aidx++]=-dyx;
			areaarr[aidx++]=tmp0;
			sortarr[sidx++]=i1;
			areaarr[aidx++]=((1-2*x1)/dx)*dy+tmp1;
			areaarr[aidx++]=dyx;
			areaarr[aidx++]=-tmp1;
		}
		break;
	}
	//if (minx<imgw && maxx>0) {
		ret.minr=minx>0?~~minx:0;
		ret.maxr=maxx<imgw?Math.ceil(maxx):imgw;
		for (let i=0;i<sidx;i++) {
			let j=i,v=(sortarr[i]<<3)|i,n=0;
			while (j>0 && (n=sortarr[j-1])>v) {
				sortarr[j--]=n;
			}
			sortarr[j]=v;
		}
	//} else {
	//	ret.minr=imgw;
	//	ret.maxr=0;
	//	sidx=0;
	//}
	sortarr[sidx]=0xffffffff;
	ret.area=area;
	ret.areadx1=areadx1;
	ret.areadx2=areadx2;
}


function AreaClipTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(3);
	let maxdif=0,sumdif=0;
	const maxdim=64;
	let tests=1000000;
	function getrnd(dim) {
		// Try to align near integer boundaries to cause rounding errors.
		let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		if (rnd.mod(128)===0) {dev=0;}
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	let ret={
		skip:0,
		area:0,
		areadx1:0,
		areadx2:0,
		minr:0,
		maxr:0,
		areaarr:new Float64Array(3*8),
		sortarr:new Uint32Array(5)
	};
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxdif);
		}
		// Setup the line.
		let imgw=rnd.mod(maxdim)+1;
		let imgh=rnd.mod(maxdim)+1;
		let x0=getrnd(imgw);
		let y0=getrnd(imgh);
		let x1=getrnd(imgw);
		let y1=getrnd(imgh);
		for (let py=0;py<imgh;py++) {
			CalcRowBounds1(ret,x0,y0,x1,y1,py,imgw);
			if (ret.skip) {
				continue;
			}
			let area=ret.area;
			let areadx1=ret.areadx1;
			let areadx2=ret.areadx2;
			//let minr=ret.minr;
			//let maxr=ret.maxr;
			let sortarr=ret.sortarr;
			let areaarr=ret.areaarr;
			let sidx=0,xnext=sortarr[0]>>>3;
			for (let px=0;px<imgw;px++) {
				let calc=UnitAreaCalc(x0,y0,x1,y1,px,py);
				while (px>=xnext) {
					if (sidx>2) {throw "sidx";}
					let a=(sortarr[sidx++]&7)*3;
					area   +=areaarr[a  ];
					areadx1+=areaarr[a+1];
					areadx2+=areaarr[a+2];
					xnext=sortarr[sidx]>>>3;
				}
				let dif=area-calc;
				dif=dif>0?dif:-dif;
				maxdif=maxdif>dif?maxdif:dif;
				sumdif+=dif;
				if (dif>1e-10 || isNaN(dif)) {
					console.log("test:",test);
					console.log("dif :",dif);
					console.log("area:",area);
					console.log("calc:",calc);
					console.log("line:",x0,y0,x1,y1);
					throw "error";
				}
				area+=areadx1+areadx2;
				areadx2=0;
			}
		}
	}
	console.log("max dif:",maxdif);
	console.log("sum dif:",sumdif);
}


//---------------------------------------------------------------------------------
// Fill Functions


function FillRect1(dstimg,rx,ry,rw,rh,trans) {
	// V1: Try and fill every pixel.
	let parr=[0,0,0,0,0,0,0,0],r1=rx+rw,r2=ry+rh,p=null;
	p=trans.apply([rx,ry]);parr[0]=p[0];parr[1]=p[1];
	p=trans.apply([r1,ry]);parr[2]=p[0];parr[3]=p[1];
	p=trans.apply([r1,r2]);parr[4]=p[0];parr[5]=p[1];
	p=trans.apply([rx,r2]);parr[6]=p[0];parr[7]=p[1];
	let imgw=dstimg.width,imgh=dstimg.height;
	for (let y=0;y<imgh;y++) {
		dstimg.lockrow(y);
		for (let x=0;x<imgw;x++) {
			let area=0;
			let x1=parr[6],y1=parr[7];
			for (let i=0;i<8;i+=2) {
				let x0=x1,y0=y1;
				x1=parr[i];y1=parr[i+1];
				area+=UnitAreaCalc(x0,y0,x1,y1,x,y);
			}
			area=area<0?-area:area;
			dstimg.write(y*imgw+x,area);
		}
	}
}


function FillRect2(dstimg,srcw,srch,trans) {
	// V2: perform AABB-OBB test and clip drawing rect.
	let dstw=dstimg.width,dsth=dstimg.height;
	// Imagespace transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let det=matxx*matyy-matxy*matyx;
	let adet=det<0?-det:det;
	if (srcw*srch*adet<1e-15 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst)->src AABB overlap.
	let minx=srcw,maxx=0;
	let miny=srch,maxy=0;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src)->dst AABB overlap, and calculate vertex positions.
	let dstvert=new Array(8);
	minx=dstw;maxx=0;
	miny=dsth;maxy=0;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Fill the pixels.
	let starty=miny>0?Math.floor(miny):0;
	let stopy=maxy<dsth?Math.ceil(maxy):dsth;
	let startx=minx>0?Math.floor(minx):0;
	let stopx=maxx<dstw?Math.ceil(maxx):dstw;
	for (let y=starty;y<stopy;y++) {
		dstimg.lockrow(y);
		for (let x=startx;x<stopx;x++) {
			let area=0;
			let x1=dstvert[6],y1=dstvert[7];
			for (let i=0;i<8;i+=2) {
				let x0=x1;x1=dstvert[i  ];
				let y0=y1;y1=dstvert[i+1];
				area+=UnitAreaCalc(x0,y0,x1,y1,x,y);
			}
			area=det<0?-area:area;
			area=area>0?area:0;
			dstimg.write(y*dstw+x,area);
		}
	}
}


function FillRect3(dstimg,srcw,srch,trans) {
	// V3: Calculate row intercepts.
	let dstw=dstimg.width,dsth=dstimg.height;
	// Imagespace transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let det=matxx*matyy-matxy*matyx;
	let adet=det<0?-det:det;
	let alpha=det<0?-1:1;
	if (srcw*srch*adet<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst)->src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src)->dst AABB overlap. Calculate vertex positions.
	let dstvert=new Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Fill the pixels.
	let sortarr=new Uint32Array(9);
	let areaarr=new Float64Array(8*3);
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty);
		let area=0,areadx1=0,areadx2=0;
		minx=Infinity;maxx=-Infinity;
		let sidx=0,aidx=0;
		let vx1=dstvert[6],vy1=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let vx0=vx1;vx1=dstvert[i  ];
			let vy0=vy1;vy1=dstvert[i+1];
			let x0=vx0,y0=vy0,x1=vx1,y1=vy1;
			let sign=alpha;
			if (x0>x1) {
				sign=-sign;
				x0=vx1;x1=vx0;
				y0=vy1;y1=vy0;
			}
			y0-=dsty;y1-=dsty;
			if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
			// Above, below, or degenerate.
			if (y1<=0 || y0>=1) {continue;}
			let dx=x1-x0,dy=y1-y0,dyx=dy/dx;
			let dxy=dx/dy,y0x=x0-y0*dxy;
			if (y0<0) {y0=0;x0=y0x;}
			if (y1>1) {y1=1;x1=y0x+dxy;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
			if (x0>=dstw || !(dyx!==0)) {continue;}
			let i0=x0>0?~~x0:0;
			let i1=x1>0?~~x1:0;
			x0-=i0;
			x1-=i1;
			dy*=0.5*sign;
			let tmp1=x1>0?(x1*x1/dx)*dy:0;
			let xlen=i1-i0;
			if (xlen<=0) {
				// 1 pixel or last.
				dy=(y0-y1)*sign;
				let tmp0=x0>=0?(x0+x1)*dy*0.5:-tmp1;
				sortarr[sidx++]=i0;
				areaarr[aidx++]=dy-tmp0;
				areaarr[aidx++]=0;
				areaarr[aidx++]=tmp0;
			} else if (xlen<=1) {
				// 2 pixels. Avoid dyx in case it's thin.
				let tmp0=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
				dy=(y0-y1)*sign;
				sortarr[sidx++]=i0;
				areaarr[aidx++]=-tmp0;
				areaarr[aidx++]=0;
				areaarr[aidx++]=0;
				sortarr[sidx++]=i1;
				areaarr[aidx++]=dy+tmp0+tmp1;
				areaarr[aidx++]=0;
				areaarr[aidx++]=-tmp1;
			} else {
				// 3+ pixels.
				dyx*=sign;
				let tmp0=x0>0?(x0*x0/dx)*dy:0;
				sortarr[sidx++]=i0;
				areaarr[aidx++]=-((1-2*x0)/dx)*dy-tmp0;
				areaarr[aidx++]=-dyx;
				areaarr[aidx++]=tmp0;
				sortarr[sidx++]=i1;
				areaarr[aidx++]=((1-2*x1)/dx)*dy+tmp1;
				areaarr[aidx++]=dyx;
				areaarr[aidx++]=-tmp1;
			}
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let row=dsty*dstw;
		let dstx=row+(minx>0?~~minx:0);
		let maxr=row+(maxx<dstw?Math.ceil(maxx):dstw);
		for (let i=0;i<sidx;i++) {
			let j=i,v=((row+sortarr[i])<<3)|i,n=0;
			while (j>0 && (n=sortarr[j-1])>v) {
				sortarr[j--]=n;
			}
			sortarr[j]=v;
		}
		if (sidx>=sortarr.length || aidx>areaarr.length) {
			throw `sorting idx: ${sidx}, ${aidx}`;
		}
		sortarr[sidx]=0xffffffff;
		sidx=0;
		let xnext=sortarr[0]>>>3;
		for (;dstx<maxr;dstx++) {
			while (dstx>=xnext) {
				let a=(sortarr[sidx++]&7)*3;
				area   +=areaarr[a  ];
				areadx1+=areaarr[a+1];
				areadx2+=areaarr[a+2];
				xnext=sortarr[sidx]>>>3;
			}
			dstimg.write(dstx,area);
			area+=areadx1+areadx2;
			areadx2=0;
		}
	}
}


function FillRect4(dstimg,srcimg,trans) {
	// V4: Project into srcimg.
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let det=matxx*matyy-matxy*matyx;
	let adet=det<0?-det:det;
	let alpha=det;
	if (srcw*srch*adet<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst) and src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let dstvert=new Float64Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Iterate over the dst rows.
	let srcvert=new Float64Array(8);
	let sortarr=new Uint32Array(9);
	let areaarr=new Float64Array(8*3);
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty);
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (;dstx<dstmaxx;dstx++) {
			// Map the dst pixel to src and calculate bounds.
			minx=Infinity;maxx=-Infinity;
			miny=Infinity;maxy=-Infinity;
			for (let i=0;i<8;i+=2) {
				let u=dstx+((20>>i)&1),v=dsty+((80>>i)&1);
				let x=u*invxx+v*invxy+invx;srcvert[i  ]=x;
				let y=u*invyx+v*invyy+invy;srcvert[i+1]=y;
				minx=minx<x?minx:x;
				maxx=maxx>x?maxx:x;
				miny=miny<y?miny:y;
				maxy=maxy>y?maxy:y;
			}
			if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {continue;}
			// Iterate over src rows.
			let srcy=miny>0?~~miny:0;
			let srcmaxy=maxy<srch?Math.ceil(maxy):srch;
			let sa=0;
			let readcount=0;
			for (;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy);
				// Calculate src x bounds and area gradients.
				let area=0,areadx1=0,areadx2=0;
				let sidx=0,aidx=0;
				minx=Infinity;maxx=-Infinity;
				vx=srcvert[6];vy=srcvert[7];
				for (let i=0;i<8;i+=2) {
					let x0=vx,x1=srcvert[i  ];
					let y0=vy,y1=srcvert[i+1];
					vx=x1;vy=y1;
					let sign=alpha;
					if (x0>x1) {
						sign=-sign;
						x1=x0;x0=vx;
						y1=y0;y0=vy;
					}
					y0-=srcy;y1-=srcy;
					if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
					// Above, below, or degenerate.
					if (y1<=0 || y0>=1) {continue;}
					let dx=x1-x0,dy=y1-y0,dyx=dy/dx;
					let dxy=dx/dy,y0x=x0-y0*dxy;
					if (y0<0) {y0=0;x0=y0x;}
					if (y1>1) {y1=1;x1=y0x+dxy;}
					minx=minx<x0?minx:x0;
					maxx=maxx>x1?maxx:x1;
					if (x0>=srcw || !(dyx!==0)) {continue;}
					let i0=x0>0?~~x0:0;
					let i1=x1>0?~~x1:0;
					x0-=i0;
					x1-=i1;
					dy*=0.5*sign;
					let tmp1=x1>0?(x1*x1/dx)*dy:0;
					let xlen=i1-i0;
					if (xlen<=0) {
						// 1 pixel or last.
						dy=(y0-y1)*sign;
						let tmp0=x0>=0?(x0+x1)*dy*0.5:-tmp1;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=dy-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=tmp0;
					} else if (xlen<=1) {
						// 2 pixels. Avoid dyx in case it's thin.
						let tmp0=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
						dy=(y0-y1)*sign;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=dy+tmp0+tmp1;
						areaarr[aidx++]=0;
						areaarr[aidx++]=-tmp1;
					} else {
						// 3+ pixels.
						dyx*=sign;
						let tmp0=x0>0?(x0*x0/dx)*dy:0;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-((1-2*x0)/dx)*dy-tmp0;
						areaarr[aidx++]=-dyx;
						areaarr[aidx++]=tmp0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=((1-2*x1)/dx)*dy+tmp1;
						areaarr[aidx++]=dyx;
						areaarr[aidx++]=-tmp1;
					}
				}
				if (!(minx<srcw && maxx>0)) {continue;}
				// Sort the gradient changes.
				let row=srcy*srcw;
				let srcx=row+(minx>0?~~minx:0);
				let srcmaxx=row+(maxx<srcw?Math.ceil(maxx):srcw);
				for (let i=0;i<sidx;i++) {
					let j=i,v=((row+sortarr[i])<<3)|i,n=0;
					while (j>0 && (n=sortarr[j-1])>v) {
						sortarr[j--]=n;
					}
					sortarr[j]=v;
				}
				if (sidx>=sortarr.length || aidx>areaarr.length) {
					console.log("sorting idx:",sidx,aidx);
					throw "error";
				}
				sortarr[sidx]=0xffffffff;
				// Sum the src pixels.
				sidx=0;
				let sort=sortarr[0],nextx=sort>>>3;
				for (;srcx<srcmaxx;srcx++) {
					while (srcx>=nextx) {
						let a=(sort&7)*3;
						area   +=areaarr[a  ];
						areadx1+=areaarr[a+1];
						areadx2+=areaarr[a+2];
						sort=sortarr[++sidx];
						nextx=sort>>>3;
					}
					let prev=srcimg.read(srcx)+area/adet;
					srcimg.write(srcx,prev);
					if (!(prev>=0 && prev<1.00000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					area+=areadx1+areadx2;
					areadx2=0;
				}
			}
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				throw "error";
			}
			// Write to dst. Note alpha*det already averages the colors.
			if (!(sa<-1e-14 || sa>1e-14)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			dstimg.write(dstrow+dstx,sa);
		}
	}
}


function FillRect5(dstimg,srcimg,trans) {
	// V5: Calculate pixel area directly.
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let det=matxx*matyy-matxy*matyx;
	let adet=det<0?-det:det;
	let alpha=det;
	if (srcw*srch*adet<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst) and src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let dstvert=new Float64Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Iterate over the dst rows.
	let srcvert=new Float64Array(8);
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty);
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (;dstx<dstmaxx;dstx++) {
			// Map the dst pixel to src and calculate bounds.
			let minu=Infinity,maxu=-Infinity;
			let minv=Infinity,maxv=-Infinity;
			for (let i=0;i<8;i+=2) {
				let u=dstx+((20>>i)&1),v=dsty+((80>>i)&1);
				let x=u*invxx+v*invxy+invx;srcvert[i  ]=x;
				let y=u*invyx+v*invyy+invy;srcvert[i+1]=y;
				minu=minu<x?minu:x;
				maxu=maxu>x?maxu:x;
				minv=minv<y?minv:y;
				maxv=maxv>y?maxv:y;
			}
			if (!(minu<srcw && maxu>0 && minv<srch && maxv>0)) {continue;}
			// Iterate over src rows.
			let srcminx=minu>0?~~minu:0;
			let srcmaxx=maxu<srcw?Math.ceil(maxu):srcw;
			let srcminy=minv>0?~~minv:0;
			let srcmaxy=maxv<srch?Math.ceil(maxv):srch;
			let sa=0;
			let readcount=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy);
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-Infinity;
					vx=srcvert[6]-srcx;vy=srcvert[7]-srcy;
					for (let i=0;i<8;i+=2) {
						let x0=vx,x1=srcvert[i  ]-srcx;
						let y0=vy,y1=srcvert[i+1]-srcy;
						vx=x1;vy=y1;
						let sign=alpha;
						if (x0>x1) {sign=-sign;x1=x0;x0=vx;y1=y0;y0=vy;}
						if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
						if (!(y0<1 && y1>0)) {continue;}
						let dx=x1-x0,dy=y1-y0;
						// Clip to unit box.
						let x0y=y0-dy*(x0/dx);
						let x1y=y1+dy*((1-x1)/dx);
						let y0x=x0-dx*(y0/dy);
						let y1x=x1+dx*((1-y1)/dy);
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y1x;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						if (x0>=1) {continue;}
						let tmp=y0;
						if (x1<0) {x0=0;x1=0;}
						if (x0<0) {x0=0;y0=x0y;}
						if (x1>1) {x1=1;y1=x1y;}
						area+=(tmp-y0+(y0-y1)*(2-x0-x1)*0.5)*sign;
					}
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					let pix=row+srcx;
					let prev=srcimg.read(pix)+area/adet;
					srcimg.write(pix,prev);
					if (!(prev>=0 && prev<1.00000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					if (maxc<=1) {break;}
				}
			}
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				throw "error";
			}
			// Write to dst. Note alpha*det already averages the colors.
			if (!(sa<-1e-14 || sa>1e-14)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			dstimg.write(dstrow+dstx,sa);
		}
	}
}


function FillRect6(dstimg,srcimg,trans) {
	// V6: Calculate pixel verts in place. Simplify pixel AABB calculations.
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let det=matxx*matyy-matxy*matyx;
	let adet=det<0?-det:det;
	let alpha=det;
	if (srcw*srch*adet<1e-10 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+(1-1e-7);
	let pixmaxy=invyx+invyy-pixminy+(1-1e-7);
	// Iterate over dst rows.
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty);
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			//if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {throw "error";}
			// Iterate over src rows.
			let sa=0;
			let readcount=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy);
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx0=srcx0-srcx,sy0=srcy0-srcy,sx=sx0,sy=sy0;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let xflag=(3>>i)&1,yflag=(6>>i)&1;
						let x0=sx,x1=sx0+(xflag?invxx:0)+(yflag?invxy:0);
						let y0=sy,y1=sy0+(xflag?invyx:0)+(yflag?invyy:0);
						sx=x1;sy=y1;
						let sign=alpha;
						if (x0>x1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
						if (!(y0<1 && y1>0)) {continue;}
						// Clip to unit box.
						let dx=x1-x0,dy=y1-y0;
						let x0y=y0-dy*(x0/dx);
						let x1y=y1+dy*((1-x1)/dx);
						let y0x=x0-dx*(y0/dy);
						let y1x=x1+dx*((1-y1)/dy);
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y1x;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<=0) {
							area+=(y0-y1)*sign;
						} else if (x0<1) {
							let tmp=y0;
							if (x0<0) {x0=0;y0=x0y;}
							if (x1>1) {x1=1;y1=x1y;}
							area+=(tmp-y1-(y0-y1)*(x0+x1)*0.5)*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let pix=row+srcx;
					let prev=srcimg.read(pix)+area/adet;
					srcimg.write(pix,prev);
					if (!(prev>=0 && prev<1.000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					if (maxc<=1) {break;}
				}
			}
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				throw "error";
			}
			// Write to dst. Note alpha*det already averages the colors.
			if (!(sa<-1e-14 || sa>1e-14)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			dstimg.write(dstrow+dstx,sa);
		}
	}
}


function FillRect7(dstimg,srcimg,trans) {
	// V7: faster vertex calculation
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	let offx=0,offy=0;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5;
	if (Math.abs(srcw*srch*alpha)<1e-12 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+1;
	let pixmaxy=invyx+invyy-pixminy+1;
	// Iterate over dst rows.
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty);
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			////////////////////////////// REMOVE //////////////////////////////////
			if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {throw "error";}
			// Iterate over src rows.
			let sa=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			let readcount=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy);
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx=srcx0-srcx,sy=srcy0-srcy;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let pix=row+srcx;
					let prev=srcimg.read(pix)+area/(det>0?det:-det);
					srcimg.write(pix,prev);
					if (!(prev>=0 && prev<1.000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					if (maxc<=1) {break;}
				}
			}
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				throw "error";
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (!(sa<-1e-14 || sa>1e-14)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			dstimg.write(dstrow+dstx,sa);
		}
	}
}


function FillRect8(dstimg,srcimg,trans) {
	// V8: better pixel trimming
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	let offx=0,offy=0;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const rnd0=1e-7,rnd1=1-rnd0; // TRIM TO 1e-6
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5;
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-15 && dstw && dsth)) {return;} // TRIM TO 1e-8
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=Infinity,max=-Infinity;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,y0=vy;
		vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0+rnd0<dstw && x1>=rnd0)) {continue;}
		let dx=x1-x0,dy=y1-y0;
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>dstw?((dstw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	min+=rnd0;max+=rnd1;
	if (!(min<dsth && max>=1)) {return;}
	if (!AABBCheck({minx:0,miny:0,maxx:dstw,maxy:dsth},{minx:0,miny:0,maxx:srcw,maxy:srch},(new Transform(trans)).shift([offx,offy]))) { // REMOVE
		throw "no AABB overlap";
	}
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Precompute pixel AABB offsets and slightly shrink them.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0)+rnd0;
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0)+rnd0;
	let pixmaxx=invxx+invxy-pixminx+1;
	let pixmaxy=invyx+invyy-pixminy+1;
	// Iterate over dst rows.
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty); // REMOVE
		// Calculate dst x bounds for the row.
		min=Infinity;max=-Infinity;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,y0=vy;
			vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			let x1=vx,y1=vy;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (y0>=rnd1 || y1<rnd0) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		min+=rnd0;max+=rnd1;
		if (!(min<dstw && max>=1)) {throw "error1";} // REMOVE
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			min=srcx0+pixminx;let srcminx=min>0?~~min:0;
			min=srcy0+pixminy;let srcminy=min>0?~~min:0;
			max=srcx0+pixmaxx;let srcmaxx=max<srcw?~~max:srcw;
			max=srcy0+pixmaxy;let srcmaxy=max<srch?~~max:srch;
			if (!(srcminx<srcw && srcmaxx>0 && min<srch && max>0)) {throw "error2";} // REMOVE
			// Iterate over src rows.
			let sa=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			let readcount=0; // REMOVE
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy); // REMOVE
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let sx=srcx0-srcx,sy=srcy0-srcy,area=0;
					min=srcw;max=-1;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						min=min<x0?min:x0;
						max=max>x1?max:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (max<=0) {break;}
					if (min>=1) {srcx+=(~~min)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					// REMOVE
					let pix=srcrow+srcx;
					let prev=srcimg.read(pix)+area/(det>0?det:-det);
					srcimg.write(pix,prev);
					if (!(prev>=0 && prev<1.000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					if (max<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			// REMOVE
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				console.log(pixminx,pixmaxx);
				console.log(pixminy,pixmaxy);
				console.log(srcminx,srcmaxx);
				console.log(srcminy,srcmaxy);
				throw "error";
			}
			if (!(sa<-1e-14 || sa>1e-14)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			let pix=dstrow+dstx;
			dstimg.write(pix,sa);
		}
	}
}


function FillRect9(dstimg,srcimg,trans) {
	// V9: Removed src pixel epsilon
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	//if (trans===undefined) {trans=draw.deftrans;}
	//else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	//let dstimg=draw.img;
	let offx=0,offy=0; // REMOVE
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const rnd0=1e-9,rnd1=1-rnd0; // TRIM TO 1e-6
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5; // REMOVE
	//let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-15 && dstw && dsth)) {return;} // TRIM TO 1e-8
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=Infinity,max=-Infinity;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,y0=vy;
		vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0<dstw && x1>=0)) {continue;}
		let dx=x1-x0,dy=y1-y0;
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>dstw?((dstw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	min+=rnd0;max+=rnd1;
	if (!(min<dsth && max>=1)) {return;}
	if (!AABBCheck({minx:0,miny:0,maxx:dstw,maxy:dsth},{minx:0,miny:0,maxx:srcw,maxy:srch},(new Transform(trans)).shift([offx,offy]))) { // REMOVE
		throw "no AABB overlap";
	}
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx; // REMOVE
	//let pixmaxy=invyx+invyy-pixminy;
	let pixmaxy=(invyx>0?invyx:0)+(invyy>0?invyy:0);
	// Iterate over dst rows.
	//let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	//let dstdata=dstimg.data32;
	//let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		dstimg.lockrow(dsty); // REMOVE
		// Calculate dst x bounds for the row.
		min=Infinity;max=-Infinity;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,y0=vy;
			vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			let x1=vx,y1=vy;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (y0>=1 || y1<=0) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		min+=rnd0;max+=rnd1;
		if (!(min<dstw && max>=1)) { // REMOVE
			console.log(min,max);
			throw "error1";
		}
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			min=srcx0+pixminx;let srcminx=min>0?~~min:0;
			min=srcy0+pixminy;let srcminy=min>0?~~min:0;
			max=srcy0+pixmaxy;let srcmaxy=max<srch?Math.ceil(max):srch;
			if (!(srcx0+pixminx<srcw && srcx0+pixmaxx>0 && min<srch && max>0)) {throw "error2";} // REMOVE
			// Iterate over src rows.
			let sa=0; // REMOVE
			//let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			let readcount=0; // REMOVE
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				srcimg.lockrow(srcy); // REMOVE
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcw;srcx++) {
					let sx=srcx0-srcx,sy=srcy0-srcy,area=0;
					min=srcw;max=-1;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						min=min<x0?min:x0;
						max=max>x1?max:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (max<=0) {break;}
					if (min>=1) {srcx+=(~~min)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					// REMOVE
					let pix=srcrow+srcx;
					let prev=srcimg.read(pix)+area/(det>0?det:-det);
					srcimg.write(pix,prev);
					if (!(prev>=0 && prev<1.000001)) {
						console.log("too many src reads:",prev);
						throw "error";
					}
					if (!(area<-1e-20 || area>1e-20)) {
						console.log("zero src area:",area);
						throw "error";
					}
					readcount++;
					sa+=area;
					/*let col=srcdata[srcrow+srcx];
					let smul=area*((col>>>ashift)&255);
					sr+=smul*((col>>>rshift)&255);
					sg+=smul*((col>>>gshift)&255);
					sb+=smul*((col>>>bshift)&255);
					sa+=smul;*/
					if (max<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			// REMOVE
			if (!readcount) {
				console.log("no reads:",dstx,dsty);
				console.log(pixminx);
				console.log(pixminy,pixmaxy);
				throw "error";
			}
			if (!(sa<-1e-20 || sa>1e-20)) {
				console.log("zero dst area:",sa);
				throw "error";
			}
			sa=sa>0?sa:0;
			sa=sa<1?sa:1;
			let pix=dstrow+dstx;
			dstimg.write(pix,sa);
			/*if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}*/
		}
	}
}


//---------------------------------------------------------------------------------


function DisplayRectTest() {
	// Test drawing a transformed rectangle.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let imgw=draw.img.width;
	let imgh=draw.img.height;
	draw.fill(0,0,0,255);
	let rnd=new Random();
	let trans=new Transform(2);
	// Randomize transform.
	for (let i=0;i<4;i++) {
		trans.mat[i]=rnd.gets();
	}
	for (let i=0;i<2;i++) {
		trans.vec[i]=rnd.mod(imgw);
	}
	let dstdata=draw.img.data32;
	let dstarea=new AreaImage(imgw,imgh);
	let areadata=dstarea.data;
	let srcimg=new AreaImage(100,100);
	FillRect4(dstarea,srcimg,trans);
	for (let y=0;y<imgh;y++) {
		for (let x=0;x<imgw;x++) {
			let i=y*imgw+x;
			let area=areadata[i];
			let val=area>0?(area*255.9|0):0;
			dstdata[i]=val|(val<<8)|(val<<16)|(val<<24)|0xff000000;
		}
	}
	draw.screenflip();
}


function TestRectFill() {
	let tests=200000;
	let maxbits=10,maxdim=1<<maxbits;
	let dst1=new AreaImage(maxdim,maxdim);
	let dst2=new AreaImage(maxdim,maxdim);
	let src =new AreaImage(maxdim,maxdim);
	let rnd=new Random(1);
	let trans=new Transform(2);
	function rndpow(min,max) {
		return rnd.gets()*Math.pow(2,rnd.getf()*(max-min)+min);
	}
	let maxdif=0;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		let dimw=1<<rnd.mod(maxbits+1);
		let dimh=1<<rnd.mod(maxbits+1);
		let dstw=rnd.mod(dimw+1);
		let dsth=rnd.mod(dimh+1);
		dimw=1<<rnd.mod(maxbits+1);
		dimh=1<<rnd.mod(maxbits+1);
		let srcw=rnd.mod(dimw+1);
		let srch=rnd.mod(dimh+1);
		dst1.width=dstw;dst1.height=dsth;
		dst2.width=dstw;dst2.height=dsth;
		src.width =srcw;src.height =srch;
		dst1.clear();
		dst2.clear();
		src.clear();
		for (let i=0;i<4;i++) {trans.mat[i]=rndpow(-20,20);}
		trans.vec[0]=(rnd.getf()*3-1)*dstw;
		trans.vec[1]=(rnd.getf()*3-1)*dsth;
		//FillRect1(dst1,0,0,srcw,srch,trans);
		FillRect2(dst1,srcw,srch,trans);
		//FillRect3(dst2,srcw,srch,trans);
		//FillRect4(dst2,src,trans);
		//FillRect5(dst2,src,trans);
		//FillRect6(dst2,src,trans);
		//FillRect7(dst2,src,trans);
		//FillRect8(dst2,src,trans);
		FillRect9(dst2,src,trans);
		let pixels=dstw*dsth;
		let data1=dst1.data,data2=dst2.data;
		for (let i=0;i<pixels;i++) {
			let v1=data1[i],v2=data2[i];
			let dif=v1-v2;
			dif=dif<0?-dif:dif;
			sumdif+=dif;
			if (maxdif<dif) {
				maxdif=dif;
				//console.log("dif:",test,maxdif,sumdif);
			}
		}
	}
	console.log("max dif:",maxdif);
	console.log("sum dif:",sumdif);
}


//---------------------------------------------------------------------------------
// Old drawimage functions.


function drawimagei(draw,src,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	// Note << and imul() implicitly cast floor().
	let dst=draw.img;
	dx=isNaN(dx)?0:Math.round(dx);
	dy=isNaN(dx)?0:Math.round(dy);
	dw=(isNaN(dw) || dw>src.width )?src.width :dx;
	dh=(isNaN(dh) || dh>src.height)?src.height:dh;
	let sx=0,sy=0;
	dw+=dx;
	if (dx<0) {sx=-dx;dx=0;}
	dw=(dw>dst.width?dst.width:dw)-dx;
	dh+=dy;
	if (dy<0) {sy=-dy;dy=0;}
	dh=(dh>dst.height?dst.height:dh)-dy;
	if (dw<=0 || dh<=0) {return;}
	let dstdata=dst.data32,drow=dy*dst.width+dx,dinc=dst.width-dw;
	let srcdata=src.data32,srow=sy*src.width+sx,sinc=src.width-dw;
	let ystop=drow+dst.width*dh,xstop=drow+dw;
	let amul=draw.rgba[3],amul0=amul/255.0,amul1=amul*(256.0/65025.0);
	let filllim=amul0>0?255/amul0:Infinity;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
	let maskl=0x00ff00ff&namask,maskh=0xff00ff00&namask;
	let sa=0,da=0,l=0,h=0,tmp=0;
	dw=dst.width;
	while (drow<ystop) {
		while (drow<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			src=srcdata[srow++];
			sa=(src>>>ashift)&255;
			src&=namask;
			if (sa>=filllim) {
				dstdata[drow++]=src|((sa*amul0)<<ashift);
				continue;
			}
			if (sa<=0) {drow++;continue;}
			tmp=dstdata[drow];
			da=(tmp>>>ashift)&255;
			if (da===0) {
				dstdata[drow++]=src|((sa*amul0)<<ashift);
				continue;
			}
			// Approximate blending by expanding sa from [0,255] to [0,256].
			if (da===255) {
				sa*=amul1;
				da=amask;
			} else {
				sa*=amul;
				da=sa*255+da*(65025-sa);
				sa=(sa*65280+(da>>>1))/da;
				da=((da+32512)/65025)<<ashift;
			}
			l=tmp&0x00ff00ff;
			h=tmp&0xff00ff00;
			dstdata[drow++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dw;
		drow+=dinc;
		srow+=sinc;
	}
}


function drawimagei2(draw,src,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	// Note << and imul() implicitly cast floor().
	let dst=draw.img;
	dx=isNaN(dx)?0:Math.round(dx);
	dy=isNaN(dx)?0:Math.round(dy);
	dw=(isNaN(dw) || dw>src.width )?src.width :dx;
	dh=(isNaN(dh) || dh>src.height)?src.height:dh;
	let sx=0,sy=0;
	dw+=dx;
	if (dx<0) {sx=-dx;dx=0;}
	dw=(dw>dst.width?dst.width:dw)-dx;
	dh+=dy;
	if (dy<0) {sy=-dy;dy=0;}
	dh=(dh>dst.height?dst.height:dh)-dy;
	if (dw<=0 || dh<=0) {return;}
	let dstdata=dst.data32,drow=dy*dst.width+dx,dinc=dst.width-dw;
	let srcdata=src.data32,srow=sy*src.width+sx,sinc=src.width-dw;
	let ystop=drow+dst.width*dh,xstop=drow+dw;
	let amul=draw.rgba[3];
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	let sa=0,da=0,l=0,h=0,tmp=0;
	dw=dst.width;
	while (drow<ystop) {
		while (drow<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			src=srcdata[srow++];
			sa=(src>>>ashift)&255;
			if (sa<=0) {drow++;continue;}
			tmp=dstdata[drow];
			da=(tmp>>>ashift)&255;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			sa*=amul;
			da=sa*255+da*(65025-sa);
			sa=(sa*65280+(da>>>1))/da;
			da=((da+32512)/65025)<<ashift;
			l=tmp&0x00ff00ff;
			h=tmp&0xff00ff00;
			dstdata[drow++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dw;
		drow+=dinc;
		srow+=sinc;
	}
}


function drawimagef(draw,src,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	// Note << and imul() implicitly cast floor().
	let dst=draw.img;
	dx=dx??0;
	let ix=Math.floor(dx),fx0=dx-ix,fx1=1-fx0;
	dy=dy??0;
	let iy=Math.floor(dy),fy0=dy-iy,fy1=1-fy0;
	let iw=(dw===undefined || dw>src.width )?src.width :ix;
	let ih=(dh===undefined || dh>src.height)?src.height:iy;
	let sx=0,sy=0;
	iw+=ix;
	if (ix<0) {sx=-ix;ix=0;}
	iw=(iw>dst.width?dst.width:iw)-ix;
	ih+=iy;
	if (iy<0) {sy=-iy;iy=0;}
	ih=(ih>dst.height?dst.height:ih)-iy;
	if (iw<=0 || ih<=0) {return;}
	let m00=Math.round(fx0*fy0*256),m01=Math.round(fx0*fy1*256);
	let m10=Math.round(fx1*fy0*256),m11=256-m00-m01-m10;
	let dstdata=dst.data32,drow=iy*dst.width+ix,dinc=dst.width-iw;
	let srcdata=src.data32,srow=sy*src.width+sx,sinc=src.width-iw;
	let ystop=drow+dst.width*ih,xstop=drow+iw;
	let amul=draw.rgba[3];
	let ashift=draw.rgbashift[3],namask=(~(255<<ashift))>>>0;
	let maskl=0x00ff00ff&namask,maskh=0xff00ff00&namask;
	let sw=src.width,sh=src.height;
	iw=dst.width;
	const imul=Math.imul;
	while (drow<ystop) {
		let stop0=srow+sw-sx,stop1=++sy<sh?stop0:0;
		let s10=srcdata[srow];
		let s11=srow<stop1?srcdata[srow+sw]:0;
		while (drow<xstop) {
			// Interpolate 2x2 source pixels.
			srow++;
			let s00=s10,s01=s11;
			s10=srow<stop0?srcdata[srow]:0;
			s11=srow<stop1?srcdata[srow+sw]:0;
			const m=0x00ff00ff;
			let cl=imul(s00&m,m00)+imul(s01&m,m01)+imul(s10&m,m10)+imul(s11&m,m11);
			let ch=imul((s00>>>8)&m,m00)+imul((s01>>>8)&m,m01)+imul((s10>>>8)&m,m10)+imul((s11>>>8)&m,m11);
			src=(ch&0xff00ff00)|((cl>>>8)&m);
			let sa=(src>>>ashift)&255;
			if (sa<=0) {drow++;continue;}
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			// Approximate blending by expanding sa from [0,255] to [0,256].
			src&=namask;
			let tmp=dstdata[drow];
			let da=(tmp>>>ashift)&255;
			sa*=amul;
			da=sa*255+da*(65025-sa);
			sa=(sa*65280+(da>>>1))/da;
			da=((da+32512)/65025)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[drow++]=da|
				(((imul((src&m)-l,sa)>>>8)+l)&maskl)|
				((imul(((src>>>8)&m)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=iw;
		drow+=dinc;
		srow+=sinc;
	}
}


function drawimage1(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst) and src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let dstvert=new Float64Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Iterate over the dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let srcvert=new Float64Array(8);
	let sortarr=new Uint32Array(9);
	let areaarr=new Float64Array(8*3);
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (;dstx<dstmaxx;dstx++) {
			// Map the dst pixel to src and calculate bounds.
			minx=Infinity;maxx=-Infinity;
			miny=Infinity;maxy=-Infinity;
			for (let i=0;i<8;i+=2) {
				let u=dstx+((20>>i)&1),v=dsty+((80>>i)&1);
				let x=u*invxx+v*invxy+invx;srcvert[i  ]=x;
				let y=u*invyx+v*invyy+invy;srcvert[i+1]=y;
				minx=minx<x?minx:x;
				maxx=maxx>x?maxx:x;
				miny=miny<y?miny:y;
				maxy=maxy>y?maxy:y;
			}
			if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {continue;}
			// Iterate over src rows.
			let srcy=miny>0?~~miny:0;
			let srcmaxy=maxy<srch?Math.ceil(maxy):srch;
			let sa=0,sr=0,sg=0,sb=0;
			for (;srcy<srcmaxy;srcy++) {
				// Calculate src x bounds and area gradients.
				let area=0,areadx1=0,areadx2=0;
				let sidx=0,aidx=0;
				minx=Infinity;maxx=-Infinity;
				vx=srcvert[6];vy=srcvert[7];
				for (let i=0;i<8;i+=2) {
					let x0=vx,x1=srcvert[i  ];
					let y0=vy,y1=srcvert[i+1];
					vx=x1;vy=y1;
					let sign=alpha;
					if (x0>x1) {
						sign=-sign;
						x1=x0;x0=vx;
						y1=y0;y0=vy;
					}
					y0-=srcy;y1-=srcy;
					if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
					// Above, below, or degenerate.
					if (y1<=0 || y0>=1) {continue;}
					let dx=x1-x0,dy=y1-y0,dyx=dy/dx;
					let dxy=dx/dy,y0x=x0-y0*dxy;
					if (y0<0) {y0=0;x0=y0x;}
					if (y1>1) {y1=1;x1=y0x+dxy;}
					minx=minx<x0?minx:x0;
					maxx=maxx>x1?maxx:x1;
					if (x0>=srcw || !(dyx!==0)) {continue;}
					let i0=x0>0?~~x0:0;
					let i1=x1>0?~~x1:0;
					x0-=i0;
					x1-=i1;
					dy*=0.5*sign;
					let tmp1=x1>0?(x1*x1/dx)*dy:0;
					let xlen=i1-i0;
					if (xlen<=0) {
						// 1 pixel or last.
						dy=(y0-y1)*sign;
						let tmp0=x0>=0?(x0+x1)*dy*0.5:-tmp1;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=dy-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=tmp0;
					} else if (xlen<=1) {
						// 2 pixels. Avoid dyx in case it's thin.
						let tmp0=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
						dy=(y0-y1)*sign;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=dy+tmp0+tmp1;
						areaarr[aidx++]=0;
						areaarr[aidx++]=-tmp1;
					} else {
						// 3+ pixels.
						dyx*=sign;
						let tmp0=x0>0?(x0*x0/dx)*dy:0;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-((1-2*x0)/dx)*dy-tmp0;
						areaarr[aidx++]=-dyx;
						areaarr[aidx++]=tmp0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=((1-2*x1)/dx)*dy+tmp1;
						areaarr[aidx++]=dyx;
						areaarr[aidx++]=-tmp1;
					}
				}
				if (!(minx<srcw && maxx>0)) {continue;}
				// Sort the gradient changes.
				let row=srcy*srcw;
				let srcx=row+(minx>0?~~minx:0);
				let srcmaxx=row+(maxx<srcw?Math.ceil(maxx):srcw);
				for (let i=0;i<sidx;i++) {
					let j=i,v=((row+sortarr[i])<<3)|i,n=0;
					while (j>0 && (n=sortarr[j-1])>v) {
						sortarr[j--]=n;
					}
					sortarr[j]=v;
				}
				sortarr[sidx]=0xffffffff;
				// Sum the src pixels. Premultiply alpha.
				sidx=0;
				let sort=sortarr[0],nextx=sort>>>3;
				for (;srcx<srcmaxx;srcx++) {
					while (srcx>=nextx) {
						let a=(sort&7)*3;
						area   +=areaarr[a  ];
						areadx1+=areaarr[a+1];
						areadx2+=areaarr[a+2];
						sort=sortarr[++sidx];
						nextx=sort>>>3;
					}
					let col=srcdata[srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					area+=areadx1+areadx2;
					areadx2=0;
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-8) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


function drawimage2(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst) and src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let dstvert=new Float64Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Iterate over the dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (;dstx<dstmaxx;dstx++) {
			// Map the dst pixel to src and calculate bounds.
			let sbasex=dstx*invxx+dsty*invxy+invx;
			let sbasey=dstx*invyx+dsty*invyy+invy;
			let sminfx=sbasex+(invxx<0?invxx:0)+(invxy<0?invxy:0);
			let smaxfx=sbasex+(invxx>0?invxx:0)+(invxy>0?invxy:0);
			let sminfy=sbasey+(invyx<0?invyx:0)+(invyy<0?invyy:0);
			let smaxfy=sbasey+(invyx>0?invyx:0)+(invyy>0?invyy:0);
			if (!(sminfx<srcw && smaxfx>0 && sminfy<srch && smaxfy>0)) {continue;}
			// Iterate over src rows.
			let sminix=sminfx>0?~~sminfx:0;
			let sminiy=sminfy>0?~~sminfy:0;
			let smaxix=smaxfx<srcw?Math.ceil(smaxfx):srcw;
			let smaxiy=smaxfy<srch?Math.ceil(smaxfy):srch;
			let sa=0,sr=0,sg=0,sb=0;
			for (let srcy=sminiy;srcy<smaxiy;srcy++) {
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=sminix;srcx<smaxix;srcx++) {
					let area=0,minc=srcw,maxc=-Infinity;
					let sx0=sbasex-srcx,sy0=sbasey-srcy,sx=sx0,sy=sy0;
					for (let i=0;i<4;i++) {
						let xflag=(3>>i)&1,yflag=(6>>i)&1;
						let x0=sx,x1=sx0+(xflag?invxx:0)+(yflag?invxy:0);
						let y0=sy,y1=sy0+(xflag?invyx:0)+(yflag?invyy:0);
						sx=x1;sy=y1;
						let sign=alpha;
						if (x0>x1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
						if (!(y0<1 && y1>0)) {continue;}
						let dx=x1-x0,dy=y1-y0;
						// Clip to unit box.
						let x0y=y0-dy*(x0/dx);
						let x1y=y1+dy*((1-x1)/dx);
						let y0x=x0-dx*(y0/dy);
						let y1x=x1+dx*((1-y1)/dy);
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y1x;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						if (x0>=1) {continue;}
						let tmp=y0;
						if (x1<0) {x0=0;x1=0;}
						if (x0<0) {x0=0;y0=x0y;}
						if (x1>1) {x1=1;y1=x1y;}
						area+=(tmp-y0+(y0-y1)*(2-x0-x1)*0.5)*sign;
					}
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Sum src pixels. Premultiply alpha.
					let col=srcdata[row+srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					if (maxc<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-8) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


function drawimage3(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+(1-1e-7);
	let pixmaxy=invyx+invyy-pixminy+(1-1e-7);
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx0=srcx0-srcx,sy0=srcy0-srcy,sx=sx0,sy=sy0;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let xflag=(3>>i)&1,yflag=(6>>i)&1;
						let x0=sx,x1=sx0+(xflag?invxx:0)+(yflag?invxy:0);
						let y0=sy,y1=sy0+(xflag?invyx:0)+(yflag?invyy:0);
						sx=x1;sy=y1;
						let sign=alpha;
						if (x0>x1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
						if (!(y0<1 && y1>0)) {continue;}
						// Clip to unit box.
						let dx=x1-x0,dy=y1-y0;
						let x0y=y0-dy*(x0/dx);
						let x1y=y1+dy*((1-x1)/dx);
						let y0x=x0-dx*(y0/dy);
						let y1x=x1+dx*((1-y1)/dy);
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y1x;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<=0) {
							area+=(y0-y1)*sign;
						} else if (x0<1) {
							let tmp=y0;
							if (x0<0) {x0=0;y0=x0y;}
							if (x1>1) {x1=1;y1=x1y;}
							area+=(tmp-y1-(y0-y1)*(x0+x1)*0.5)*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[row+srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					if (maxc<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-8) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


function drawimage4(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	const dstvert=[0,0,0,0,0,0,0,0];
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	let dstminy=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	// Check inv(dst) and src AABB overlap.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxx=invxx+invxy-pixminx+1;
	let pixmaxy=invyx+invyy-pixminy+1;
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstminx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			minx=srcx0+pixminx;let srcminx=minx>0?~~minx:0;
			miny=srcy0+pixminy;let srcminy=miny>0?~~miny:0;
			maxx=srcx0+pixmaxx;let srcmaxx=maxx<srcw?~~maxx:srcw;
			maxy=srcy0+pixmaxy;let srcmaxy=maxy<srch?~~maxy:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let row=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let area=0,minc=srcw,maxc=-1;
					let sx=srcx0-srcx,sy=srcy0-srcy;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						minc=minc<x0?minc:x0;
						maxc=maxc>x1?maxc:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (maxc<=0) {break;}
					if (minc>=1) {srcx+=(~~minc)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[row+srcx];
					let amul=area*((col>>>ashift)&255);
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					sa+=amul;
					if (maxc<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


function drawimage5(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const rnd=0.99999;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-8 && dstw && dsth)) {return;}
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=Infinity,max=-Infinity;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,y0=vy;
		vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0<dstw && x1>0)) {continue;}
		let dx=x1-x0,dy=y1-y0;
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>dstw?((dstw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	if (!(min<dsth && max>0)) {return;}
	max+=rnd;
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Precompute pixel AABB offsets and slightly shrink them.
	let midx=(invxx+invxy)*0.5;
	let midy=(invyx+invyy)*0.5;
	let devx=((invxx>0?invxx:0)+(invxy>0?invxy:0)-midx)*rnd;
	let devy=((invyx>0?invyx:0)+(invyy>0?invyy:0)-midy)*rnd;
	let pixminx=midx-devx,pixmaxx=midx+devx+1;
	let pixminy=midy-devy,pixmaxy=midy+devy+1;
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		min=Infinity;max=-Infinity;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,y0=vy;
			vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			let x1=vx,y1=vy;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (y0>=1 || y1<=0) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		max+=rnd;
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			min=srcx0+pixminx;let srcminx=min>0?~~min:0;
			min=srcy0+pixminy;let srcminy=min>0?~~min:0;
			max=srcx0+pixmaxx;let srcmaxx=max<srcw?~~max:srcw;
			max=srcy0+pixmaxy;let srcmaxy=max<srch?~~max:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let sx=srcx0-srcx,sy=srcy0-srcy,area=0;
					min=srcw;max=-1;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						min=min<x0?min:x0;
						max=max>x1?max:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (max<=0) {break;}
					if (min>=1) {srcx+=(~~min)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[srcrow+srcx];
					let smul=area*((col>>>ashift)&255);
					sr+=smul*((col>>>rshift)&255);
					sg+=smul*((col>>>gshift)&255);
					sb+=smul*((col>>>bshift)&255);
					sa+=smul;
					if (max<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


function drawimage6(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const rnd0=1e-6,rnd1=1-rnd0;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*0.5*draw.rgba[3]/(255*255);
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-8 && dstw && dsth)) {return;}
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=Infinity,max=-Infinity;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,y0=vy;
		vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0<dstw && x1>=0)) {continue;}
		let dx=x1-x0,dy=y1-y0;
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>dstw?((dstw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	min+=rnd0;max+=rnd1;
	if (!(min<dsth && max>=1)) {return;}
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Precompute pixel AABB offsets.
	let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
	let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
	let pixmaxy=(invyx>0?invyx:0)+(invyy>0?invyy:0);
	// Iterate over dst rows.
	let [rshift,gshift,bshift,ashift]=draw.rgbashift;
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		min=Infinity;max=-Infinity;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,y0=vy;
			vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			let x1=vx,y1=vy;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (y0>=1 || y1<=0) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		min+=rnd0;max+=rnd1;
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let srcx0=dstx*invxx+dsty*invxy+invx;
			let srcy0=dstx*invyx+dsty*invyy+invy;
			min=srcx0+pixminx;let srcminx=min>0?~~min:0;
			min=srcy0+pixminy;let srcminy=min>0?~~min:0;
			max=srcy0+pixmaxy;let srcmaxy=max<srch?Math.ceil(max):srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			let xr=invxx,xi=invxy;
			let yr=invyx,yi=invyy;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcw;srcx++) {
					let sx=srcx0-srcx,sy=srcy0-srcy,area=0;
					min=srcw;max=-1;
					for (let i=0;i<4;i++) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let dx=xr,dy=yr;
						let x0=sx,y0=sy;
						sx+=dx;xr=xi;xi=-dx;
						sy+=dy;yr=yi;yi=-dy;
						let x1=sx,y1=sy;
						if (y0>y1) {sign=-sign;x1=x0;x0=sx;y1=y0;y0=sy;}
						if (y0>=1 || y1<=0) {continue;}
						// Clip to unit row.
						let dxy=dx/dy;
						let y0x=x0-y0*dxy;
						if (y0<0) {y0=0;x0=y0x;}
						if (y1>1) {y1=1;x1=y0x+dxy;}
						if (x0>x1) {let tmp=x0;x0=x1;x1=tmp;dx=-dx;}
						min=min<x0?min:x0;
						max=max>x1?max:x1;
						// Calculate area to the right.
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=h+h-tmp;
						} else if (x0<1) {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Skip pixels if we are too far left or right.
					if (max<=0) {break;}
					if (min>=1) {srcx+=(~~min)-1;continue;}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[srcrow+srcx];
					let smul=area*((col>>>ashift)&255);
					sr+=smul*((col>>>rshift)&255);
					sg+=smul*((col>>>gshift)&255);
					sb+=smul*((col>>>bshift)&255);
					sa+=smul;
					if (max<=1) {break;}
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}


//---------------------------------------------------------------------------------
// drawimage tests


function DrawImageDisplay() {
	// Displays an animated drawimage().
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let input=new Input(canv);
	let rnd=new Random();
	// Generate our source image.
	let srcw=100,srch=91;
	let srcimg=new Draw.Image(srcw,srch);
	draw.pushstate();
	draw.setimage(srcimg);
	draw.fill(0,0,0,0);
	draw.setcolor(255,0,0,128);
	draw.fillrect(0,0,srcw,1);
	draw.setcolor(0,255,0,200);
	draw.fillrect(srcw-1,0,1,srch);
	draw.setcolor(0,0,255,255);
	draw.fillrect(0,srch-1,srcw,1);
	draw.setcolor(255,255,255,64);
	draw.fillrect(0,0,1,srch);
	draw.setcolor(40,40,200,200);
	draw.fillcircle(srcw*0.5,srch*0.5,Math.min(srcw,srch)*0.45);
	draw.setcolor(200,40,40,255);
	draw.fillrect(srcw-30,srch-30,30,30);
	draw.setcolor(255,255,255,255);
	draw.filltext(5,5,"Hello\nWorld",24);
	draw.popstate();
	let trans=new Transform(2);
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		let dstw=draw.img.width;
		let dsth=draw.img.width;
		draw.setcolor(40,40,80,255);
		let dim=50;
		for (let y=0;y<dsth;y+=dim) {
			for (let x=0;x<dstw;x+=dim) {
				if ((x+y)%(2*dim)) {
					draw.fillrect(x,y,dim,dim);
				}
			}
		}
		// Randomize transform.
		if (input.getkeychange(input.MOUSE.LEFT)>0 || input.getkeychange(input.KEY.SPACE)>0) {
			for (let i=0;i<4;i++) {
				trans.mat[i]=rnd.gets()*Math.pow(2,rnd.getf()*7-3);
			}
		}
		let [mx,my]=input.getmousepos();
		let time=performance.now();
		draw.drawimage(srcimg,mx,my,trans);
		//drawimage1(draw,srcimg,mx,my,trans);
		//drawimage2(draw,srcimg,mx,my,trans);
		//drawimage3(draw,srcimg,mx,my,trans);
		//drawimage4(draw,srcimg,mx,my,trans);
		//drawimage5(draw,srcimg,mx,my,trans);
		//drawimage6(draw,srcimg,mx,my,trans);
		time=(performance.now()-time)*0.001;
		draw.setcolor(255,255,255,255);
		draw.filltext(5,5,"Click to transform",20);
		draw.filltext(5,30,"Time: "+time.toFixed(6),20);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


function ImageStressTest() {
	// Stress Draw.drawimage().
	console.log("stress testing drawimage()");
	let rnd=new Random(10);
	let draw=new Draw();
	let maxbits=8,maxdim=1<<maxbits;
	let dstimg=new Draw.Image(maxdim,maxdim);
	let srcimg=new Draw.Image(maxdim,maxdim);
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	draw.setimage(dstimg);
	let pixels=dstimg.width*dstimg.height;
	for (let i=0;i<pixels;i++) {dstdata[i]=rnd.getu32();}
	pixels=srcimg.width*srcimg.height;
	for (let i=0;i<pixels;i++) {srcdata[i]=rnd.getu32();}
	let trans=new Transform(2);
	let tests=2000000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dimw=1<<rnd.mod(maxbits+1);
		let dimh=1<<rnd.mod(maxbits+1);
		dstimg.width =rnd.mod(dimw+1);
		dstimg.height=rnd.mod(dimh+1);
		dimw=1<<rnd.mod(maxbits+1);
		dimh=1<<rnd.mod(maxbits+1);
		srcimg.width =rnd.mod(dimw+1);
		srcimg.height=rnd.mod(dimh+1);
		for (let i=0;i<4;i++) {
			trans.mat[i]=rnd.gets()*Math.pow(2,rnd.gets()*20);
		}
		trans.vec[0]=(rnd.getf()*3-1)*dstimg.width;
		trans.vec[1]=(rnd.getf()*3-1)*dstimg.height;
		draw.rgba32[0]=rnd.getu32();
		draw.drawimage(srcimg,0,0,trans);
		//drawimage1(draw,srcimg,0,0,trans);
		//drawimage2(draw,srcimg,0,0,trans);
		//drawimage3(draw,srcimg,0,0,trans);
		//drawimage4(draw,srcimg,0,0,trans);
		//drawimage5(draw,srcimg,0,0,trans);
		//drawimage6(draw,srcimg,0,0,trans);
	}
	time=(performance.now()-time)/1000;
	console.log("image: "+time.toFixed(6));
}


function ImageSpeedTest() {
	// Stress Draw.drawimage().
	console.log("speed testing drawimage()");
	let rnd=new Random(10);
	let draw=new Draw();
	let maxbits=9,maxdim=1<<maxbits;
	let dstimg=new Draw.Image(maxdim,maxdim);
	let srcimg=new Draw.Image(maxdim,maxdim);
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	//let amask=(255<<draw.rgbashift[3])>>>0;
	draw.setimage(dstimg);
	let pixels=dstimg.width*dstimg.height;
	for (let i=0;i<pixels;i++) {dstdata[i]=rnd.getu32();}
	pixels=srcimg.width*srcimg.height;
	for (let i=0;i<pixels;i++) {srcdata[i]=rnd.getu32();}
	let trans=new Transform(2);
	let tests=10000;
	// Set to remove transforms.
	let isometric=0;
	let maxscale=isometric?-1:6;
	let outstr="";
	for (let scale=-1;scale<=maxscale;scale++) {
		let pot=scale-(maxscale>>1);
		let mag=Math.pow(2,pot);
		let matxx=1,matxy=0;
		let matyx=0,matyy=1;
		let time=performance.now();
		for (let test=0;test<tests;test++) {
			// Limit src dimensions to maxdim/2 and draw it in the center.
			let dimw=1<<rnd.mod(maxbits+1);
			let dimh=1<<rnd.mod(maxbits+1);
			let srcw=rnd.mod(dimw+1);
			let srch=rnd.mod(dimh+1);
			srcimg.width=srcw;
			srcimg.height=srch;
			// Create a unit area transform.
			if (scale>=0) {
				let ang=rnd.getf()*Math.PI*2;
				let xmul=(rnd.mod(2)*2-1)*mag;
				let ymul=(rnd.mod(2)*2-1)*mag;
				trans.mat[0]=matxx= xmul*Math.cos(ang);
				trans.mat[1]=matxy=-xmul*Math.sin(ang);
				trans.mat[2]=matyx= ymul*Math.sin(ang);
				trans.mat[3]=matyy= ymul*Math.cos(ang);
			}
			// Calculate AABB and center.
			let minx=Infinity,maxx=-Infinity;
			let miny=Infinity,maxy=-Infinity;
			for (let i=0;i<4;i++) {
				let x0=((3>>i)&1)?srcw:0;
				let y0=((6>>i)&1)?srch:0;
				let x=matxx*x0+matxy*y0;
				let y=matyx*x0+matyy*y0;
				minx=minx<x?minx:x;
				maxx=maxx>x?maxx:x;
				miny=miny<y?miny:y;
				maxy=maxy>y?maxy:y;
			}
			// Randomly place the image if it's small, otherwise center.
			let xdev=Math.max(maxdim-(maxx-minx),1)*0.5;
			let ydev=Math.max(maxdim-(maxy-miny),1)*0.5;
			let x=(maxdim-minx-maxx)*0.5+rnd.gets()*xdev;
			let y=(maxdim-miny-maxy)*0.5+rnd.gets()*ydev;
			// Align to integer boundary.
			if (scale<0) {x=Math.round(x);y=Math.round(y);}
			draw.rgba32[0]=rnd.getu32();
			draw.drawimage(srcimg,x,y,trans);
			//drawimagei(draw,srcimg,x,y);
			//drawimagef(draw,srcimg,x,y);
			//drawimage1(draw,srcimg,x,y,trans);
			//drawimage2(draw,srcimg,x,y,trans);
			//drawimage3(draw,srcimg,x,y,trans);
			//drawimage4(draw,srcimg,x,y,trans);
			//drawimage5(draw,srcimg,x,y,trans);
			//drawimage6(draw,srcimg,x,y,trans);
		}
		let timestr=((performance.now()-time)*0.001).toFixed(4);
		let type=scale<0?"iso ":`2^${pot.toString().padStart(2,' ')}`;
		console.log(type+": "+timestr);
		outstr+="  |  "+timestr.padStart(7," ");
	}
	console.log(outstr);
}


function TestMain() {
	//AreaClipTest();
	//DisplayRectTest();
	//TestRectFill();
	DrawImageDisplay();
	//ImageStressTest();
	//ImageSpeedTest();
	console.log("done");
}
TestMain();

			if (sa<1e-5) {continue;}
			if (sa>0.9999) {
				let a=1.001/sa;
				sa=255;sr*=a;sg*=a;sb*=a;
			} else {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				sa=a*255.255;
				sr=(sr+dmul*((col>>>rshift)&255))*adiv;
				sg=(sg+dmul*((col>>>gshift)&255))*adiv;
				sb=(sb+dmul*((col>>>bshift)&255))*adiv;
			}
			dstdata[pix]=(sa<<ashift)|(sr<<rshift)|(sg<<gshift)|(sb<<bshift);

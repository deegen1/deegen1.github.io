drawimage(srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=this.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=this.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	// src->dst transformation and inverse.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*this.rgba[3]/(255*255);
	if (Math.abs(srcw*srch*alpha)<1e-10 || !dstw || !dsth) {return;}
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check inv(dst) and src AABB overlap.
	let minx=Infinity,maxx=-Infinity;
	let miny=Infinity,maxy=-Infinity;
	for (let i=0;i<4;i++) {
		let u=((6>>i)&1)?dstw:0,v=((12>>i)&1)?dsth:0;
		let x=u*invxx+v*invxy+invx;
		let y=u*invyx+v*invyy+invy;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {return;}
	// Check trans(src) and dst AABB overlap. Calculate vertex positions.
	let dstvert=new Float64Array(8);
	minx=Infinity;maxx=-Infinity;
	miny=Infinity;maxy=-Infinity;
	for (let i=0;i<8;i+=2) {
		let u=((20>>i)&1)?srcw:0,v=((80>>i)&1)?srch:0;
		let x=u*matxx+v*matxy+matx;dstvert[i  ]=x;
		let y=u*matyx+v*matyy+maty;dstvert[i+1]=y;
		minx=minx<x?minx:x;
		maxx=maxx>x?maxx:x;
		miny=miny<y?miny:y;
		maxy=maxy>y?maxy:y;
	}
	if (!(minx<dstw && maxx>0 && miny<dsth && maxy>0)) {return;}
	// Iterate over the dst rows.
	let [rshift,gshift,bshift,ashift]=this.rgbashift;
	let srcvert=new Float64Array(8);
	let sortarr=new Uint32Array(9);
	let areaarr=new Float64Array(8*3);
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	let dsty=miny>0?~~miny:0;
	let dstmaxy=maxy<dsth?Math.ceil(maxy):dsth;
	for (;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		minx=Infinity;maxx=-Infinity;
		let vx=dstvert[6],vy=dstvert[7];
		for (let i=0;i<8;i+=2) {
			let x0=vx,x1=dstvert[i  ];
			let y0=vy,y1=dstvert[i+1];
			vx=x1;vy=y1;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			y0-=dsty;y1-=dsty;
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
			let y0x=x0-y0*dxy,y1x=y0x+dxy;
			x0=y0>0?x0:y0x;
			x1=y1<1?x1:y1x;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			minx=minx<x0?minx:x0;
			maxx=maxx>x1?maxx:x1;
		}
		if (!(minx<dstw && maxx>0)) {continue;}
		let dstrow=dsty*dstw;
		let dstx=minx>0?~~minx:0;
		let dstmaxx=maxx<dstw?Math.ceil(maxx):dstw;
		for (;dstx<dstmaxx;dstx++) {
			// Map the dst pixel to src and calculate bounds.
			minx=Infinity;maxx=-Infinity;
			miny=Infinity;maxy=-Infinity;
			for (let i=0;i<8;i+=2) {
				let u=dstx+((20>>i)&1),v=dsty+((80>>i)&1);
				let x=u*invxx+v*invxy+invx;srcvert[i  ]=x;
				let y=u*invyx+v*invyy+invy;srcvert[i+1]=y;
				minx=minx<x?minx:x;
				maxx=maxx>x?maxx:x;
				miny=miny<y?miny:y;
				maxy=maxy>y?maxy:y;
			}
			if (!(minx<srcw && maxx>0 && miny<srch && maxy>0)) {continue;}
			// Iterate over src rows.
			let srcy=miny>0?~~miny:0;
			let srcmaxy=maxy<srch?Math.ceil(maxy):srch;
			let sa=0,sr=0,sg=0,sb=0;
			for (;srcy<srcmaxy;srcy++) {
				// Calculate src x bounds and area gradients.
				let area=0,areadx1=0,areadx2=0;
				let sidx=0,aidx=0;
				minx=Infinity;maxx=-Infinity;
				vx=srcvert[6];vy=srcvert[7];
				for (let i=0;i<8;i+=2) {
					let x0=vx,x1=srcvert[i  ];
					let y0=vy,y1=srcvert[i+1];
					vx=x1;vy=y1;
					let sign=alpha;
					if (x0>x1) {
						sign=-sign;
						x1=x0;x0=vx;
						y1=y0;y0=vy;
					}
					y0-=srcy;y1-=srcy;
					if (y0>y1) {sign=-sign;y0=1-y0;y1=1-y1;}
					// Above, below, or degenerate.
					if (y1<=0 || y0>=1) {continue;}
					let dx=x1-x0,dy=y1-y0,dyx=dy/dx;
					let dxy=dx/dy,y0x=x0-y0*dxy;
					if (y0<0) {y0=0;x0=y0x;}
					if (y1>1) {y1=1;x1=y0x+dxy;}
					minx=minx<x0?minx:x0;
					maxx=maxx>x1?maxx:x1;
					if (x0>=srcw || !(dyx!==0)) {continue;}
					let i0=x0>0?~~x0:0;
					let i1=x1>0?~~x1:0;
					x0-=i0;
					x1-=i1;
					dy*=0.5*sign;
					let tmp1=x1>0?(x1*x1/dx)*dy:0;
					let xlen=i1-i0;
					if (xlen<=0) {
						// 1 pixel or last.
						dy=(y0-y1)*sign;
						let tmp0=x0>=0?(x0+x1)*dy*0.5:-tmp1;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=dy-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=tmp0;
					} else if (xlen<=1) {
						// 2 pixels. Avoid dyx in case it's thin.
						let tmp0=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
						dy=(y0-y1)*sign;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-tmp0;
						areaarr[aidx++]=0;
						areaarr[aidx++]=0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=dy+tmp0+tmp1;
						areaarr[aidx++]=0;
						areaarr[aidx++]=-tmp1;
					} else {
						// 3+ pixels.
						dyx*=sign;
						let tmp0=x0>0?(x0*x0/dx)*dy:0;
						sortarr[sidx++]=i0;
						areaarr[aidx++]=-((1-2*x0)/dx)*dy-tmp0;
						areaarr[aidx++]=-dyx;
						areaarr[aidx++]=tmp0;
						sortarr[sidx++]=i1;
						areaarr[aidx++]=((1-2*x1)/dx)*dy+tmp1;
						areaarr[aidx++]=dyx;
						areaarr[aidx++]=-tmp1;
					}
				}
				if (!(minx<srcw && maxx>0)) {continue;}
				// Sort the gradient changes.
				let row=srcy*srcw;
				let srcx=row+(minx>0?~~minx:0);
				let srcmaxx=row+(maxx<srcw?Math.ceil(maxx):srcw);
				for (let i=0;i<sidx;i++) {
					let j=i,v=((row+sortarr[i])<<3)|i,n=0;
					while (j>0 && (n=sortarr[j-1])>v) {
						sortarr[j--]=n;
					}
					sortarr[j]=v;
				}
				sortarr[sidx]=0xffffffff;
				// Sum the src pixels. Premultiply alpha.
				sidx=0;
				let sort=sortarr[0],nextx=sort>>>3;
				for (;srcx<srcmaxx;srcx++) {
					while (srcx>=nextx) {
						let a=(sort&7)*3;
						area   +=areaarr[a  ];
						areadx1+=areaarr[a+1];
						areadx2+=areaarr[a+2];
						sort=sortarr[++sidx];
						nextx=sort>>>3;
					}
					let col=srcdata[srcx];
					let amul=area*((col>>>ashift)&255);
					sa+=amul;
					sr+=amul*((col>>>rshift)&255);
					sg+=amul*((col>>>gshift)&255);
					sb+=amul*((col>>>bshift)&255);
					area+=areadx1+areadx2;
					areadx2=0;
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-8) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)/255)*(1-sa);
				let a=sa+dmul,adiv=1.001/a;
				let da=a*255.255;
				let dr=(sr+dmul*((col>>>rshift)&255))*adiv;
				let dg=(sg+dmul*((col>>>gshift)&255))*adiv;
				let db=(sb+dmul*((col>>>bshift)&255))*adiv;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}

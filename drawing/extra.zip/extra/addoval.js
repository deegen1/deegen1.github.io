addoval(x,y,xrad,yrad) {
	// Circle approximation. Max error: 0.000196
	const c=0.551915024;
	let dx=xrad,dy=(yrad??xrad),cx=c*dx,cy=c*dy;
	this.moveto(x,y+dy);
	this.curveto(x-cx,y+dy,x-dx,y+cy,x-dx,y   );
	this.curveto(x-dx,y-cy,x-cx,y-dy,x   ,y-dy);
	this.curveto(x+cx,y-dy,x+dx,y-cy,x+dx,y   );
	this.curveto(x+dx,y+cy,x+cx,y+dy,x   ,y+dy);
	return this;
}

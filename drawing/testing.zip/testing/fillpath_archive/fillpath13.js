// Accurate lerp() for line clipping.
class Draw1 extends Draw {

	constructor(imgw,imgh) {
		super(imgw,imgh);
	}


	fillextend() {
		// Declaring line objects this way allows engines to optimize their structs.
		this.tmpline.push({
			sort:0,
			x0:0,y0:0,
			x1:0,y1:0,
			x2:0,y2:0
		});
	}


	static lerp(x,x0,x1,y0,y1) {
		// Most accurate linear interpolation.
		// y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
		let y;
		if (x0>x1 || (x0===x1 && y0>y1)) {
			y=x0;x0=x1;x1=y;
			y=y0;y0=y1;y1=y;
		}
		y=x>x0?y1:y0;
		if (x>x0 && x<x1) {
			let dx=x1-x0,dy=y1-y0,u=x-x0,v=x1-x;
			if (u>v) {x0=x1;y0=y1;u=-v;}
			y=y0;
			if ((x>0)!==(x0>0)) {
				// Rebase large coordinates.
				u=x;
				y-=x0*(dy/dx);
			}
			y+=(u/dx)*dy;
			y=y===y?y:y0;
		}
		return y;
	}


	fillpath(path,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Use a binary heap to dynamically sort lines.
		// Keep JS as simple as possible to be efficient. Put micro optimization in WASM.
		const curvemaxdist2=0.02;
		const lerp=Draw1.lerp;
		path =path ??this.defpath;
		trans=trans??this.deftrans;
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		// Screenspace transformation.
		let mat=trans.mat;
		let matxx=mat[0],matxy=mat[1],matx=trans.vec[0];
		let matyx=mat[2],matyy=mat[3],maty=trans.vec[1];
		let det=matxx*matyy-matxy*matyx;
		// Check if trans(path) and image AABB overlap. Calculate y intercepts.
		let imgw=this.img.width,imgh=this.img.height;
		let alpha=this.rgba[3]/255,amul=det<0?-alpha:alpha;
		let w0=path.minx,w1=path.maxx;
		let h0=path.miny,h1=path.maxy;
		let cover=(w1-w0)*(h1-h0)*det*amul;
		if (!(path.vertidx>2 && imgw>0 && imgh>0 && cover>8e-6 && alpha>8e-6)) {return;}
		let vx=w0*matxx+h0*matxy+matx;
		let vy=w0*matyx+h0*matyy+maty;
		let miny=imgh,maxy=0;
		for (let i=1;i<16;i+=i) {
			let w=(3&i)?w1:w0;
			let h=(6&i)?h1:h0;
			let x0=vx,x1=vx=w*matxx+h*matxy+matx;
			let y0=vy,y1=vy=w*matyx+h*matyy+maty;
			if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (!(x0<imgw && x1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,xw=x1-imgw;
			y0-=x0<0?(x0/dx)*dy:0;
			y1-=xw>0?(xw/dx)*dy:0;
			if (y0>y1) {h=y0;y0=y1;y1=h;}
			miny=miny<y0?miny:y0;
			maxy=maxy>y1?maxy:y1;
		}
		if (!(miny<imgh && maxy>0)) {return;}
		miny=miny>0?miny:0;
		maxy=maxy<imgh?maxy:imgh;
		// Loop through the path nodes.
		let lr=this.tmpline,lrcnt=lr.length,lcnt=0;
		let subidx=0,subbnd=0;
		let movex=0,movey=0,x3=0,y3=0;
		let varr=path.vertarr;
		let vidx=path.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			let type=v.type;
			let x0=x3,x1=x3=v.x*matxx+v.y*matxy+matx,x2;
			let y0=y3,y1=y3=v.x*matyx+v.y*matyy+maty,y2;
			subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>miny?4:0)|(y0<maxy?8:0);
			// Add a basic line.
			if (lrcnt<=lcnt) {
				this.fillextend();
				lrcnt=lr.length;
			}
			let l=lr[lcnt++];
			if (type!==DrawPath.CURVE) {
				if (type===DrawPath.MOVE) {
					// Close any unclosed subpaths.
					x1=movex;movex=x3;
					y1=movey;movey=y3;
					// If the subpath isn't on screen, remove it.
					lcnt=subbnd<15?subidx:lcnt;
					subidx=lcnt;
					subbnd=0;
				}
				l.x0=x0;l.y0=y0;
				l.x1=x1;l.y1=y1;
				continue;
			}
			// Linear decomposition of curves.
			v=varr[++i];x2=v.x*matxx+v.y*matxy+matx;y2=v.x*matyx+v.y*matyy+maty;
			v=varr[++i];x3=v.x*matxx+v.y*matxy+matx;y3=v.x*matyx+v.y*matyy+maty;
			let next=-1,next0=0;
			while (true) {
				// The curve will stay inside the bounding box of [0,1,2,3].
				// If the subcurve is outside the image, stop subdividing.
				if (next===next0) {
					subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>miny?4:0)|(y0<maxy?8:0);
					l.x0=x0;l.y0=y0;
					l.x1=x3;l.y1=y3;
					if (next<0) {break;}
					l=lr[next];
					next=l.sort;
					x0=x3;x1=l.x0;x2=l.x1;x3=l.x2;
					y0=y3;y1=l.y0;y2=l.y1;y3=l.y2;
				}
				next0=next;
				if (!(x0>0 || x1>0 || x2>0 || x3>0)
				||  !(x0<imgw || x1<imgw || x2<imgw || x3<imgw)
				||  !(y0>miny || y1>miny || y2>miny || y3>miny)
				||  !(y0<maxy || y1<maxy || y2<maxy || y3<maxy)
				) {continue;}
				// Test if both control points are close to the line p0->p3.
				// Clamp to ends and filter degenerates.
				let dx=x3-x0,dy=y3-y0;
				let lx=x1-x0,ly=y1-y0;
				let d=dx*dx+dy*dy;
				let u=dx*lx+dy*ly;
				u=u>0?(u<d?u/d:1):0;
				lx-=dx*u;ly-=dy*u;
				let a=lx*lx+ly*ly;
				lx=x2-x0;ly=y2-y0;
				u=dx*lx+dy*ly;
				u=u>0?(u<d?u/d:1):0;
				lx-=dx*u;ly-=dy*u;
				let b=lx*lx+ly*ly;
				d=(a>b || !(a===a))?a:b;
				if (!(d>curvemaxdist2 && d<Infinity)) {continue;}
				// Split the curve in half. [0,1,2,3] = [0,1h,2h,3h] + [3h,4,5,3]
				if (lrcnt<=lcnt) {
					this.fillextend();
					lrcnt=lr.length;
				}
				let xt=(x1+x2)*0.5,yt=(y1+y2)*0.5;
				let x5=(x2+x3)*0.5,y5=(y2+y3)*0.5;
				let x4=(xt+x5)*0.5,y4=(yt+y5)*0.5;
				let n=lr[lcnt];
				n.sort=next;
				n.x0=x4;n.x1=x5;n.x2=x3;
				n.y0=y4;n.y1=y5;n.y2=y3;
				x1=(x0+x1)*0.5;y1=(y0+y1)*0.5;
				x2=(x1+xt)*0.5;y2=(y1+yt)*0.5;
				x3=(x2+x4)*0.5;y3=(y2+y4)*0.5;
				next=lcnt++;
			}
		}
		// Init blending.
		let shift=this.rgbashift;
		let rshift=shift[0],gshift=shift[1],bshift=shift[2],ashift=shift[3];
		let fill=this.rgba32[0]|(255<<ashift);
		let rmul=this.rgba[0],gmul=this.rgba[1],bmul=this.rgba[2];
		amul=path.area<0?-amul:amul;
		// Process the lines row by row.
		let py=0,pstop=0,heap=lcnt-1;
		let lnext=(~~miny)*imgw,pmax=Math.ceil(maxy)*imgw;
		let areacon=0;
		let imgdata=this.img.data32;
		while (true) {
			let pix=lnext;
			if (pix>=pstop) {
				if (pix>=pmax || lcnt<1) {break;}
				py=~~(pix/imgw);
				pstop=py*imgw+imgw;
				areacon=0;
			}
			let areatmp=0;
			let px=pix-pstop+imgw;
			while (pix>=lnext) {
				// Calculate the area of overlap and where to sort the line.
				// +---------+----/----+---------+
				// |         |   /.....|         |
				// |         |  /......|         |
				// |         | /.......|         |
				// +---------+/--------+---------+
				let l=lr[heap];
				let x0=l.x0,y0=l.y0;
				let x1=l.x1,y1=l.y1;
				let sort=pmax;
				let sign=amul,u;
				if (y0>y1) {
					sign=-sign;
					u=x0;x0=x1;x1=u;
					u=y0;y0=y1;y1=u;
				}
				if (py<y1 && y0<maxy && y0<y1) {
					// Find the bottom of the line.
					let ny=y0>py?~~y0:py,r1=ny+1,nx=px+1;
					// Clip to the row.
					let a0=x0,a1=x1,b0=y0,b1=y1;
					if (y1>r1) {x1=lerp(r1,b0,b1,a0,a1);y1=r1;}
					if (y0<ny) {x0=lerp(ny,b0,b1,a0,a1);y0=ny;}
					if (x0>x1) {
						sign=-sign;
						u=x0;x0=x1;x1=u;
						u=y0;y0=y1;y1=u;
					}
					if (!(x0<nx && ny<=py)) {
						// Under or to the left. If leaning past the edge of the image, abort.
						if (x0<imgw || a1<imgw) {nx=x0;} else {ny=imgh;}
					} else if (x1<=px) {
						// To the right. Area won't change after this pixel.
						x0=lerp(ny+2,b0,b1,a0,a1);
						nx=x0<x1?x0:x1;
						ny=b1>r1?r1:imgh;
						areacon+=(y0-y1)*sign;
					} else {
						// Overlapping - clip to the column.
						x0-=px;x1-=px;u=y0;
						if (x0<0) {y0=lerp(px,a0,a1,b0,b1);x0=0;}
						if (x1>1) {y1=lerp(nx,a0,a1,b0,b1);x1=1;}
						areatmp+=(u-y1+(x0+x1)*0.5*(y1-y0))*sign;
					}
					nx=nx<0?0:nx;
					sort=ny*imgw+(nx<imgw?~~nx:imgw);
					sort=sort>pix?sort:(pix+1);
				}
				l.sort=sort;
				// Heap sort down.
				if (sort>=pmax) {
					let t=lr[--lcnt];
					lr[lcnt]=l;l=t;
					sort=l.sort;
				}
				let i=heap,j;
				while ((j=i+i+1)<lcnt) {
					let k=j+(j+1<lcnt);
					let l0=lr[j],l1=lr[k];
					let s0=l0.sort,s1=l1.sort;
					if (s0>s1) {s0=s1;l0=l1;j=k;}
					if (s0>=sort) {break;}
					lr[i]=l0;
					i=j;
				}
				lr[i]=l;
				// During the first pass, sort from the bottom down.
				if (heap) {heap--;} else {lnext=lr[0].sort;}
			}
			// Blend the pixel based on how much we're covering. 8e-6=0.5/(255*255).
			let stop=lnext<pstop?lnext:pstop;
			let sa=areacon+areatmp;
			sa=sa<alpha?sa:alpha;
			if (sa>0.996079) {
				do {imgdata[pix]=fill;} while (++pix<stop);
			} else if (sa>8e-6) {
				let sr=rmul*sa,sg=gmul*sa,sb=bmul*sa;
				do {
					// a = sa + da*(1-sa)
					// c = (sc*sa + dc*da*(1-sa)) / a
					let col=imgdata[pix];
					let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
					let a=sa+dmul;
					let da=a*255+0.5;a=1/a;
					let dr=(sr+dmul*((col>>>rshift)&255))*a+0.5;
					let dg=(sg+dmul*((col>>>gshift)&255))*a+0.5;
					let db=(sb+dmul*((col>>>bshift)&255))*a+0.5;
					imgdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
				} while (++pix<stop);
			}
		}
	}

}
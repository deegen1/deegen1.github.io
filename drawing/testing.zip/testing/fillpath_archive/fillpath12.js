/*


Uses arrays instead of objects.

this.linevert=new Array();
this.linesort=new Array();

Firefox
rect: 0.690540
oval: 2.419620
line: 1.762400
char: 2.535920

Chrome
rect: 0.501185
oval: 1.973260
line: 1.809645
char: 2.385965


*/

	fillextend() {
		// Declaring line objects this way allows engines to optimize their structs.
		let varr=this.linevert;
		let sarr=this.linesort;
		let len=varr.length>>>2;
		len=len?len<<1:1;
		while (varr.length<len*4) {varr.push(0);}
		while (sarr.length<len*6) {sarr.push(0);}
	}


	fillpath(path,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Use a binary heap to dynamically sort lines.
		// Keep JS as simple as possible to be efficient. Keep micro optimization in WASM.
		// ~~x = fast floor(x)
		if (path===undefined) {path=this.defpath;}
		if (trans===undefined) {trans=this.deftrans;}
		else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		// Screenspace transformation.
		let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
		let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
		let det=(matxx*matyy-matxy*matyx)*path.area;
		const curvemaxdist2=0.02;
		let iw=this.img.width,ih=this.img.height;
		let alpha=this.rgba[3]/255.0;
		let amul=det<0?-alpha:alpha;
		if (path.vertidx<3 || iw<1 || ih<1 || det*amul<1e-6) {return;}
		// Check if trans(path) and image AABB overlap. Calculate y intercepts.
		let min=Infinity,max=-Infinity;
		let vx=0,vy=0;
		for (let i=0;i<5;i++) {
			let w=((i+1)&2)?path.maxx:path.minx;
			let h=((i  )&2)?path.maxy:path.miny;
			let x0=vx,y0=vy;
			vx=w*matxx+h*matxy+matx;
			vy=w*matyx+h*matyy+maty;
			let x1=vx,y1=vy;
			if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			let dx=x1-x0,dy=y1-y0;
			if (!(dx>=0 && dy===dy)) {return;}
			if (!i || x0>=iw || x1<0) {continue;}
			y0+=x0<0?-(x0/dx)*dy:0;
			y1+=x1>iw?((iw-x1)/dx)*dy:0;
			if (y0>y1) {x0=y0;y0=y1;y1=x0;}
			min=min<y0?min:y0;
			max=max>y1?max:y1;
		}
		if (!(min<ih && max>0)) {return;}
		let pminy=min>0?~~min:0;
		let pmaxy=max<ih?Math.ceil(max):ih;
		// Loop through the path nodes.
		let lr=this.linevert,lrcnt=lr.length,lcnt=0;
		let movex=0,movey=0;
		let p2x=0,p2y=0,p3x=0,p3y=0;
		let varr=path.vertarr;
		let vidx=path.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			let type=v.type;
			let p0x=p3x,p0y=p3y;
			p3x=v.x*matxx+v.y*matxy+matx;
			p3y=v.x*matyx+v.y*matyy+maty;
			let p1x=p3x,p1y=p3y;
			// Add a basic line.
			if (lrcnt<=lcnt) {
				this.fillextend();
				lrcnt=lr.length;
			}
			if (type!==DrawPath.CURVE) {
				if (type===DrawPath.MOVE) {
					// Close any unclosed subpaths.
					p1x=movex;movex=p3x;
					p1y=movey;movey=p3y;
				}
				let l=lcnt;lcnt+=4;
				lr[l  ]=p0x;
				lr[l+1]=p0y;
				lr[l+2]=p1x;
				lr[l+3]=p1y;
				if (p1y===p0y) {lcnt-=4;}
				continue;
			}
			// Linear decomposition of curves.
			v=varr[++i];p2x=v.x*matxx+v.y*matxy+matx;p2y=v.x*matyx+v.y*matyy+maty;
			v=varr[++i];p3x=v.x*matxx+v.y*matxy+matx;p3y=v.x*matyx+v.y*matyy+maty;
			let ci=0,cprev=-1;
			let cv=this.linesort;
			while (true) {
				// Advance to next segment.
				if (cprev===ci) {
					let l=lcnt;lcnt+=4;
					lr[l  ]=p0x;lr[l+1]=p0y;
					lr[l+2]=p3x;lr[l+3]=p3y;
					if (!ci) {break;}
					p0x=p3x;p1x=cv[--ci];p2x=cv[--ci];p3x=cv[--ci];
					p0y=p3y;p1y=cv[--ci];p2y=cv[--ci];p3y=cv[--ci];
				}
				cprev=ci;
				// If the subcurve is outside the image, stop subdividing.
				if ((p0x<=0 && p1x<=0 && p2x<=0 && p3x<=0) || (p0x>=iw && p1x>=iw && p2x>=iw && p3x>=iw) ||
				    (p0y<=0 && p1y<=0 && p2y<=0 && p3y<=0) || (p0y>=ih && p1y>=ih && p2y>=ih && p3y>=ih)) {
					continue;
				}
				// Test if both control points are close to the line p0->p3.
				// Clamp to ends and filter degenerates.
				let dx=p3x-p0x,dy=p3y-p0y,den=dx*dx+dy*dy;
				let lx=p1x-p0x,ly=p1y-p0y;
				let u=dx*lx+dy*ly;
				u=u>0?(u<den?u/den:1):0;
				lx-=dx*u;ly-=dy*u;
				let d1=lx*lx+ly*ly;
				lx=p2x-p0x;ly=p2y-p0y;
				u=dx*lx+dy*ly;
				u=u>0?(u<den?u/den:1):0;
				lx-=dx*u;ly-=dy*u;
				let d2=lx*lx+ly*ly;
				d1=(d1>d2 || !(d1===d1))?d1:d2;
				if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
				// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
				if (lrcnt<=lcnt+ci) {
					this.fillextend();
					lrcnt=lr.length;
				}
				let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
				let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
				let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
				cv[ci++]=p3y;cv[ci++]=r2y;cv[ci++]=r1y;
				cv[ci++]=p3x;cv[ci++]=r2x;cv[ci++]=r1x;
				p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
				p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
				p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
			}
		}
		let sortarr=this.linesort;
		lcnt>>>=2;let sortmul=lcnt;
		for (let i=0;i<lcnt;i++) {
			sortarr[i]=i;
		}
		// Init blending.
		let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0;
		let maskl=(0x00ff00ff&~amask)>>>0,maskh=(0xff00ff00&~amask)>>>0;
		let colrgb=(this.rgba32[0]|amask)>>>0;
		let coll=(colrgb&maskl)>>>0,colh=(colrgb&maskh)>>>0,colh8=colh>>>8;
		// Process the lines row by row.
		let p=0,pmax=pmaxy*iw,y=0;
		let pnext=pminy*iw,prow=0,lnext=0;
		let area=0,areadx1=0;
		let imgdata=this.img.data32;
		while (true) {
			if (p>=prow) {
				p=pnext;
				if (p>=pmax || lcnt<1) {break;}
				y=~~(p/iw);
				prow=y*iw+iw;
				area=0;
				areadx1=0;
			}
			let areadx2=0;
			while (p>=pnext) {
				// fx0  fx0+1                          fx1  fx1+1
				//  +-----+-----+-----+-----+-----+-----+-----+
				//  |                              .....----  |
				//  |               .....-----'''''           |
				//  | ....-----'''''                          |
				//  +-----+-----+-----+-----+-----+-----+-----+
				//   first  dyx   dyx   dyx   dyx   dyx  last   tail
				//
				// Orient upwards, then clip y to [0,1].
				let l=lnext<<2;
				let x0=lr[l  ],y0=lr[l+1];
				let x1=lr[l+2],y1=lr[l+3];
				let sign=amul,tmp=0;
				if (y0>y1) {
					sign=-sign;
					tmp=x0;x0=x1;x1=tmp;
					tmp=y0;y0=y1;y1=tmp;
				}
				// Calculate row and col.
				let sort=prow-iw,c0=p-sort,c1=c0+1;
				let r0=y0<ih?~~y0:ih;
				r0=y0>y?r0:y;
				let r1=r0+1,r2=r0+2;
				// Clamp y to row. Ensure consecutive rows use the same calculations.
				let dx=x1-x0,dy=y1-y0,nx=x1;
				if (dy>1) {
					// Large numbers.
					let dxy=dx/dy,y0x=x0-y0*dxy;
					if (y1>r2) {nx=y0x+r2*dxy;}
					if (y1>r1) {x1=y0x+r1*dxy;y1=r1;}
					if (y0<r0) {x0=y0x+r0*dxy;y0=r0;}
				} else {
					// Small numbers.
					if (y1>r2) {nx=x0-((y0-r2)/dy)*dx;}
					if (y1>r1) {x1=x0-((y0-r1)/dy)*dx;y1=r1;}
					if (y0<r0) {x0=x0-((y0-r0)/dy)*dx;y0=r0;}
				}
				nx=nx<x1?nx:x1;
				if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
				dy*=sign;let dyx=dy/dx;dy*=0.5;
				if (!(y1>r0 && dyx!==0)) {
					// Above or degenerate.
					sort=pmax;
				} else if (x0>=c1 || r0>y) {
					// Below or to the left.
					nx=x0;
					sort=r0*iw;
				} else if (x1<=c1) {
					// Vertical line or last pixel.
					let t0=x1-c0,t1=x1-c1;
					tmp=x1>c0?-(t0*t0/dx)*dy:0;
					if (c0>1 && x0<c0-1) {
						areadx1+=dyx;
						area+=((x1>c0?t1*t1:-t0-t1)/dx)*dy;
					} else {
						dy=(y0-y1)*sign;
						tmp=x0>=c0?0.5*(x0-c0+t0)*dy:tmp;
						area+=dy-tmp;
					}
					areadx2+=tmp;
					sort+=y1<r1?pmax:iw;
				} else {
					// Spanning 2+ pixels.
					let t0=x0-c0,t1=x0-c1;
					tmp=((x0>c0?t1*t1:-t0-t1)/dx)*dy;
					area-=tmp;
					if (x1>=c0+2) {
						areadx1-=dyx;
						tmp=x0>c0?(t0*t0/dx)*dy:0;
					}
					areadx2+=tmp;
					nx=x1;
				}
				nx=nx<0?0:nx;
				sort+=nx<iw?~~nx:iw;
				// Heap sort down.
				if (sort>p && sort<pmax) {
					sort=sort*sortmul+lnext;
				} else {
					sort=sortarr[--lcnt];
					if (!lcnt) {sort=pmax*sortmul;}
				}
				let i=0,j0=0;
				while ((j0+=j0+1)<lcnt) {
					let j1=j0+1<lcnt?j0+1:j0;
					let s0=sortarr[j0],s1=sortarr[j1];
					if (s0>s1) {s0=s1;j0=j1;}
					if (s0>=sort) {break;}
					sortarr[i]=s0;
					i=j0;
				}
				sortarr[i]=sort;
				sort=sortarr[0];
				pnext=~~(sort/sortmul);
				lnext=sort%sortmul;
			}
			// Calculate how much we can draw or skip.
			const cutoff=0.00390625;
			let astop=area+areadx1+areadx2;
			let pstop=p+1,pdif=(pnext<prow?pnext:prow)-pstop;
			if (pdif>0 && (area>=cutoff)===(astop>=cutoff)) {
				let adif=(cutoff-astop)/areadx1+1;
				pdif=(adif>=1 && adif<pdif)?~~adif:pdif;
				astop+=pdif*areadx1;
				pstop+=pdif;
			}
			// Blend the pixel based on how much we're covering.
			if (area>=cutoff) {
				do {
					// a = da + ( 1-da)*sa
					// c = dc + (sc-dc)*sa/a
					let sa=area<alpha?area:alpha;
					area+=areadx1+areadx2;
					areadx2=0;
					let dst=imgdata[p];
					let da=(dst>>>ashift)&255;
					if (da===255) {
						sa=256.49-sa*256;
					} else {
						let tmp=sa*255+(1-sa)*da;
						sa=256.49-(sa/tmp)*65280;
						da=tmp+0.49;
					}
					// imul() implicitly casts floor(sa).
					imgdata[p]=(da<<ashift)
						|(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&maskl)
						|((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&maskh);
				} while (++p<pstop);
			}
			p=pstop;
			area=astop;
		}
	}

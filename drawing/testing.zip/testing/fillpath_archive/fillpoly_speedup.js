// About 10% speedup.
// After curve segmentation.
		minx=iw;maxx=0;miny=ih;maxy=0;
		for (let i=lcnt-1;i>=0;i--) {
			let l=lr[i];
			let x0=l.x0,y0=l.y0;
			let x1=l.x1,y1=l.y1;
			if (x0>x1) {x0=x1;x1=l.x0;}
			if (y0>y1) {y0=y1;y1=l.y0;}
			if (!(y1<=0 || y0>=ih)) {
				minx=minx<x0?minx:x0;
				maxx=maxx>x1?maxx:x1;
				miny=miny<y0?miny:y0;
				maxy=maxy>y1?maxy:y1;
				l.sort=(y0>0?~~y0:0)*iw+(x0>0?~~x0:0);
				if (!(x0>=iw)) {continue;}
			}
			lr[i]=lr[--lcnt];
			lr[lcnt]=l;
		}
		// If all lines are outside the image, abort.
		if (minx>=iw || maxx<=0 || minx>=maxx || miny>=maxy || lcnt<1) {
			return;
		}
		// Linear time heap construction.
		for (let p=(lcnt>>1)-1;p>=0;p--) {
			let l=lr[p];
			let i=p,j=p,sort=l.sort;
			while ((j+=j+1)<lcnt) {
				let j1=j+1<lcnt?j+1:j;
				let l0=lr[j],l1=lr[j1];
				let s0=l0.sort,s1=l1.sort;
				if (s0>s1) {s0=s1;l0=l1;j=j1;}
				if (s0>=sort) {break;}
				lr[i]=l0;
				i=j;
			}
			lr[i]=l;
		}
//let pnext=lr[0].sort,prow=0;


// Lerp()
{
		// Clip lines to screen and calculate first pixel.
		let ncnt=0;
		for (let i=0;i<lcnt;i++) {
			let l=lr[i];
			let x0=l.x0,y0=l.y0;
			let x1=l.x1,y1=l.y1,u;
			if (y0>y1) {
				u=x0;x0=x1;x1=u;
				u=y0;y0=y1;y1=u;
			}
			let a0=x0,a1=x1,b0=y0,b1=y1;
			if (y0<miny) {y0=miny;x0=lerp(y0,b0,b1,a0,a1);}
			if (y1>maxy) {y1=maxy;x1=lerp(y1,b0,b1,a0,a1);}
			if ((x0>imgw)!==(x1>imgw)) {
				let y=lerp(imgw,a0,a1,b0,b1);
				if (x0<x1) {y1=y;x1=imgw;} else {y0=y;x0=imgw;}
			}
			if (!(y1>y0 && (x0<imgw || x1<imgw))) {
				continue;
			}
			let ny=~~y0;
			if (a1<a0) {x0=lerp(ny+1,b0,b1,a0,a1);}
			let nx=x0>0?~~x0:0;
			l.sort=ny*imgw+nx;
			l.y2=-1;
			lr[i]=lr[ncnt];
			lr[ncnt++]=l;
		}
		if (!ncnt) {return;}
		lcnt=ncnt;
		// Linear time heap construction.
		for (let p=(lcnt>>1)-1;p>=0;p--) {
			let l=lr[p];
			let i=p,j=p,sort=l.sort;
			while ((j+=j+1)<lcnt) {
				let j1=j+1<lcnt?j+1:j;
				let l0=lr[j],l1=lr[j1];
				let s0=l0.sort,s1=l1.sort;
				if (s0>s1) {s0=s1;l0=l1;j=j1;}
				if (s0>=sort) {break;}
				lr[i]=l0;
				i=j;
			}
			lr[i]=l;
		}
}

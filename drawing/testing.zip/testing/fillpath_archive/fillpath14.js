// Fast version of fillpath13.js
class Draw1 extends Draw {

	constructor(imgw,imgh) {
		super(imgw,imgh);
	}


	fillextend() {
		// Declaring line objects this way allows engines to optimize their structs.
		this.tmpline.push({
			next:0,
			x0:0,y0:0,
			x1:0,y1:0
		});
	}


	fillpath(path,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Use a binary heap to dynamically sort lines.
		// Keep as simple as possible to be efficient. Put micro optimization in WASM.
		path =path ??this.defpath;
		trans=trans??this.deftrans;
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		// Screenspace transformation.
		let mat=trans.mat;
		let matxx=mat[0],matxy=mat[1],matx=trans.vec[0];
		let matyx=mat[2],matyy=mat[3],maty=trans.vec[1];
		let det=matxx*matyy-matxy*matyx;
		// Check if trans(path) and image AABB overlap. Calculate y intercepts.
		let imgw=this.img.width,imgh=this.img.height;
		let alpha=this.rgba[3]/255,amul=det<0?-alpha:alpha;
		let w0=path.minx,w1=path.maxx;
		let h0=path.miny,h1=path.maxy;
		let cover=(w1-w0)*(h1-h0)*det*amul;
		if (!(path.vertidx>2 && imgw>0 && imgh>0 && cover>8e-6 && alpha>8e-6)) {return;}
		let vx=w0*matxx+h0*matxy+matx;
		let vy=w0*matyx+h0*matyy+maty;
		let miny=imgh,maxy=0;
		for (let i=1;i<16;i+=i) {
			let w=(3&i)?w1:w0;
			let h=(6&i)?h1:h0;
			let x0=vx,x1=vx=w*matxx+h*matxy+matx;
			let y0=vy,y1=vy=w*matyx+h*matyy+maty;
			if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (!(x0<imgw && x1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,xw=x1-imgw;
			y0-=x0<0?(x0/dx)*dy:0;
			y1-=xw>0?(xw/dx)*dy:0;
			if (y0>y1) {h=y0;y0=y1;y1=h;}
			miny=miny<y0?miny:y0;
			maxy=maxy>y1?maxy:y1;
		}
		if (!(miny<imgh && maxy>0)) {return;}
		miny=miny>0?miny:0;
		maxy=maxy<imgh?maxy:imgh;
		// Loop through the path nodes.
		let lr=this.tmpline,lrcnt=lr.length,lcnt=0;
		let subidx=0,subbnd=0;
		let movex=0,movey=0,x3=0,y3=0;
		let varr=path.vertarr;
		let vidx=path.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			let type=v.type;
			let x0=x3,x1=x3=v.x*matxx+v.y*matxy+matx,x2;
			let y0=y3,y1=y3=v.x*matyx+v.y*matyy+maty,y2;
			subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>miny?4:0)|(y0<maxy?8:0);
			// Add a basic line.
			if (lrcnt<=lcnt) {
				this.fillextend();
				lrcnt=lr.length;
			}
			let l=lr[lcnt++];
			if (type!==DrawPath.CURVE) {
				if (type===DrawPath.MOVE) {
					// Close any unclosed subpaths.
					x1=movex;movex=x3;
					y1=movey;movey=y3;
					// If the subpath isn't on screen, remove it.
					lcnt=subbnd<15?subidx:lcnt;
					subidx=lcnt;
					subbnd=0;
				}
				l.x0=x0;l.y0=y0;
				l.x1=x1;l.y1=y1;
				continue;
			}
			// Linear decomposition of curves.
			v=varr[++i];x2=v.x*matxx+v.y*matxy+matx;y2=v.x*matyx+v.y*matyy+maty;
			v=varr[++i];x3=v.x*matxx+v.y*matxy+matx;y3=v.x*matyx+v.y*matyy+maty;
			let next=-1;
			let x4=x0,y4=y0,u0=0,u1=1;
			let a4=x0,b4=y0,a5=x1,b5=y1;
			while (true) {
				// Given u0 and u1, calculate control points (p5,p6) and endpoint p7.
				let v0=1-u0,v1=1-u1,a6,a7,a8,b6,b7,b8;
				a6=v1*x0+u1*x1;a7=v1*x1+u1*x2;a8=v1*x2+u1*x3;
				b6=v1*y0+u1*y1;b7=v1*y1+u1*y2;b8=v1*y2+u1*y3;
				a6=v1*a6+u1*a7;a7=v1*a7+u1*a8;
				b6=v1*b6+u1*b7;b7=v1*b7+u1*b8;
				let x5=v1*a4+u1*a5,y5=v1*b4+u1*b5;
				let x6=v0*a6+u0*a7,y6=v0*b6+u0*b7;
				let x7=v1*a6+u1*a7,y7=v1*b6+u1*b7;
				if (u1>=1) {x7=x3;y7=y3;}
				// If the subcurve is inside the image and u1-u0 hasn't collapsed, subdivide.
				if ((y4>miny || y5>miny || y6>miny || y7>miny)
				&&  (y4<maxy || y5<maxy || y6<maxy || y7<maxy)
				&&  (x4<imgw || x5<imgw || x6<imgw || x7<imgw)
				&&  (x4>0 || x5>0 || x6>0 || x7>0) && u1-u0>1e-4) {
					// Test if both control points are close to the line p4->p7.
					// Clamp to ends and filter degenerates.
					let dx=x7-x4,dy=y7-y4;
					let lx=x5-x4,ly=y5-y4;
					let d=dx*dx+dy*dy;
					let u=dx*lx+dy*ly;
					u=u>0?(u<d?u/d:1):0;
					lx-=dx*u;ly-=dy*u;
					let a=lx*lx+ly*ly;
					lx=x6-x4;ly=y6-y4;
					u=dx*lx+dy*ly;
					u=u>0?(u<d?u/d:1):0;
					lx-=dx*u;ly-=dy*u;
					let b=lx*lx+ly*ly;
					d=a>b?a:b;
					if (d>0.02) {
						if (lrcnt<=lcnt) {
							this.fillextend();
							lrcnt=lr.length;
						}
						let m=lr[lcnt];
						m.next=next;
						next=lcnt++;
						m.x0=u1;
						u1=(u0+u1)*0.5;
						continue;
					}
				}
				// Commit this segment of the curve.
				subbnd|=(x4>0?1:0)|(x4<imgw?2:0)|(y4>miny?4:0)|(y4<maxy?8:0);
				l.x0=x4;l.y0=y4;
				l.x1=x7;l.y1=y7;
				if (next<0) {break;}
				l=lr[next];
				next=l.next;
				u0=u1;u1=l.x0;
				x4=x7;y4=y7;
				a4=a6;b4=b6;
				a5=a7;b5=b7;
			}
		}
		if (!lcnt) {return;}
		// Init blending.
		let shift=this.rgbashift;
		let rshift=shift[0],gshift=shift[1],bshift=shift[2],ashift=shift[3];
		let fill=this.rgba32[0]|(255<<ashift);
		let rmul=this.rgba[0],gmul=this.rgba[1],bmul=this.rgba[2];
		amul=path.area<0?-amul:amul;
		// Process the lines row by row.
		let py=0,prow=0,pmax=Math.ceil(maxy)*imgw;
		let lnext=(~~miny)*imgw,heap=lcnt-1;
		let areacon=0;
		let imgdata=this.img.data32;
		while (lnext<pmax) {
			let pix=lnext;
			if (pix>=prow) {
				py=~~(pix/imgw);
				prow=py*imgw+imgw;
				areacon=0;
			}
			let areatmp=0;
			let px=pix-prow+imgw;
			while (pix>=lnext) {
				// Calculate the area of overlap and where to sort the line.
				// +---------+----/----+---------+
				// |         |   /.....|         |
				// |         |  /......|         |
				// |         | /.......|         |
				// +---------+/--------+---------+
				let l=lr[heap];
				let x0=l.x0,y0=l.y0;
				let x1=l.x1,y1=l.y1;
				let next=pmax;
				let sign=amul,u;
				if (y0>y1) {
					sign=-sign;
					u=x0;x0=x1;x1=u;
					u=y0;y0=y1;y1=u;
				}
				if (py<y1 && y0<maxy && y0<y1) {
					// Find the bottom of the line.
					let ny=y0>py?~~y0:py,r1=ny+1,r2=ny+2,nx=px+1;
					// Clip to the row. For large coordinates, use the closest endpoint to imgh/2.
					let dx=x1-x0,dy=y1-y0;
					let bx=x0,by=y0,x2=x1,y2=y1;
					if (y0+y1<imgh) {bx=x1;by=y1;}
					if (y1>r1) {x1=bx+((r1-by)/dy)*dx;y1=r1;}
					if (y0<ny) {x0=bx+((ny-by)/dy)*dx;y0=ny;}
					if (x0>x1) {
						sign=-sign;
						u=x0;x0=x1;x1=u;
						u=y0;y0=y1;y1=u;
					}
					if (!(x0<nx && ny<=py)) {
						// Under or to the left. If leaning past the edge of the image, abort.
						if (x0<imgw || x2<imgw) {nx=x0;} else {ny=imgh;}
					} else if (x1<=px) {
						// To the right. Area won't change after this pixel.
						x0=y2>r2?bx+((r2-by)/dy)*dx:x2;
						nx=x0<x1?x0:x1;
						ny=y2>r1?r1:imgh;
						areacon+=(y0-y1)*sign;
					} else {
						// Overlapping. Clip to the column.
						x0-=px;x1-=px;u=y0;
						dx=x1-x0;dy=y1-y0;
						if (x0<0) {y0-=((x0  )/dx)*dy;x0=0;}
						if (x1>1) {y1-=((x1-1)/dx)*dy;x1=1;}
						areatmp+=(u-y1+(x0+x1)*0.5*(y1-y0))*sign;
					}
					nx=nx<0?0:nx;
					next=ny*imgw+(nx<imgw?~~nx:imgw);
					next=next>pix?next:(pix+1);
				}
				l.next=next;
				// Heap sort down.
				if (next>=pmax) {
					let t=lr[--lcnt];
					lr[lcnt]=l;l=t;
					next=l.next;
				}
				let i=heap,j;
				while ((j=i+i+1)<lcnt) {
					let k=j+(j+1<lcnt);
					let l0=lr[j],l1=lr[k];
					let v0=l0.next,v1=l1.next;
					if (v0>v1) {v0=v1;l0=l1;j=k;}
					if (v0>=next) {break;}
					lr[i]=l0;
					i=j;
				}
				lr[i]=l;
				// During the first pass, sort from the bottom down.
				if (heap) {heap--;} else {lnext=lr[0].next;}
			}
			// Blend the pixel based on how much we're covering. 8e-6=0.5/(255*255).
			let stop=lnext<prow?lnext:prow;
			let sa=areacon+areatmp;
			sa=sa<alpha?sa:alpha;
			if (sa>0.996079) {
				do {imgdata[pix]=fill;} while (++pix<stop);
			} else if (sa>8e-6) {
				let sr=rmul*sa,sg=gmul*sa,sb=bmul*sa;
				do {
					// a = sa + da*(1-sa)
					// c = (sc*sa + dc*da*(1-sa)) / a
					let col=imgdata[pix];
					let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
					let a=sa+dmul;
					let da=a*255+0.5;a=1/a;
					let dr=(sr+dmul*((col>>>rshift)&255))*a+0.5;
					let dg=(sg+dmul*((col>>>gshift)&255))*a+0.5;
					let db=(sb+dmul*((col>>>bshift)&255))*a+0.5;
					imgdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
				} while (++pix<stop);
			}
		}
	}

}
/*


*/
/* npx eslint pointtest.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Transform,Input} from "../library.js";
const DrawPath=Draw.Path;


function LerpTest() {
	console.log("testing interpolation");
	function GetBounds(coord,len) {
		let min=Infinity,max=-Infinity;
		for (let i=0;i<len;i++) {
			let x=coord[i];
			min=min<x?min:x;
			max=max>x?max:x;
		}
		return [min,max];
	}
	function LerpLine(coord,u) {
		let y0=coord[0],y1=coord[1];
		return (1-u)*y0+u*y1;
	}
	//function LerpLine1(coord,u) {
	//	let y0=coord[0],y1=coord[1];
	//	return y0+(y1-y0)*u;
	//}
	function LerpCurve(coord,u) {
		let y0=coord[0],y1=coord[1];
		let y2=coord[2],y3=coord[3];
		let w=1-u;
		return w*(w*w*y0+u*(w*y1+u*y2)*3)+u*u*u*y3;
	}
	function LerpCurve1(coord,u) {
		let y0=coord[0],y1=coord[1];
		let y2=coord[2],y3=coord[3];
		let w=1-u;
		return (y0*(w*w)+(y1*w+y2*u)*u*3)*w+y3*(u*u*u);
	}
	let rnd=new Random(1);
	let coord=[0,0,0,0],coords=coord.length;
	for (let test=0;test<10000;test++) {
		console.log("test:",test);
		for (let i=0;i<coords;i++) {
			let j=rnd.mod(coords);
			let p=rnd.gets();
			let x=(j<i?coord[j]:0)+rnd.gets()*Math.pow(2,20*p*p*p);
			j=rnd.mod(i+1);
			coord[i]=coord[j];
			coord[j]=x;
		}
		let u0=0,u1=0;
		let ly1=-Infinity;
		while (true) {
			// Check line endpoints.
			let ly0=ly1;ly1=LerpLine(coord,u1);
			let y0=coord[0],y1=coord[1];
			if (u1===0 && !(ly1===y0)) {
				console.log("ly0:",ly1);
				console.log("y0 :",y0);
				console.log("dif:",y0-ly1);
				throw "not line 0";
			}
			if (u1===1 && !(ly1===y1)) {
				console.log("ly1:",ly1);
				console.log("y1 :",y1);
				console.log("dif:",y1-ly1);
				throw "not line 1";
			}
			if (u0!==u1) {
				let dir0= y0!== y1?( y0< y1?6:3):2;
				let dir1=ly0!==ly1?(ly0<ly1?4:1):2;
				if (!(dir0&dir1)) {
					console.log(y0,y1);
					console.log(ly0,ly1);
					throw "not monotonic";
				}
			}
			let bnd=GetBounds(coord,2);
			let min=bnd[0],max=bnd[1];
			if (!(ly1>=min && ly1<=max)) {
				throw "out of bounds";
			}
			// Check curve endpoints.
			let cy1=LerpCurve(coord,u1);
			y0=coord[0];y1=coord[3];
			if (u1===0 && !(cy1===y0)) {
				console.log("cy0:",cy1);
				console.log("y0 :",y0);
				console.log("dif:",y0-cy1);
				throw "not curve 0";
			}
			if (u1===1 && !(cy1===y1)) {
				console.log("cy1:",cy1);
				console.log("y1 :",y1);
				console.log("dif:",y1-cy1);
				throw "not curve 1";
			}
			bnd=GetBounds(coord,4);
			min=bnd[0];max=bnd[1];
			if (!(cy1>=min && cy1<=max)) {
				throw "out of bounds";
			}
			// Advance u.
			if (!(u1<1)) {break;}
			u0=u1;
			let p=rnd.getf();
			u1+=rnd.getf()*Math.pow(2,-20*(p*p*p));
			u1=u1<1?u1:1;
		}
	}
}


function QuadraticTest() {
	function df(coord,u) {
		let c0=-3*(1-u)*(1-u);
		let c1=3*(3*u*u-4*u+1);
		let c2=3*u*(2-3*u);
		let c3=3*u*u;
		return c0*coord[0]+c1*coord[1]+c2*coord[2]+c3*coord[3];
	}
	let rnd=new Random(1);
	let coord=[0,0,0,0];
	for (let test=0;test<10000;test++) {
		for (let i=0;i<4;i++) {
			let j=rnd.mod(4);
			let p=rnd.gets();
			let x=(j<i?coord[j]:0)+rnd.gets()*Math.pow(2,20*p*p*p);
			j=rnd.mod(i+1);
			coord[i]=coord[j];
			coord[j]=x;
		}
		//console.log(coord);
		//console.log(coord.toString());
		let y0=coord[0];
		let y1=coord[1];
		let y2=coord[2];
		let y3=coord[3];
		let d0=y1-y0,d1=y1-y2,d2=d0+d1,d3=y3-y0+3*d1;
		let disc=d2*d2-d0*d3;
		if (disc>=0) {
			disc=Math.sqrt(disc);
			disc=d3<0?-disc:disc;
			let a=(d2-disc)/d3;
			let b=(d2+disc)/d3;
			if (!(a<=b)) {
				console.log("a>b:",a,b);
				throw "error";
			}
			let da=Math.abs(df(coord,a));
			if (da>1e-10) {
				console.log("a :",a);
				console.log("da:",da);
				//throw "error";
			}
			let db=Math.abs(df(coord,b));
			if (db>1e-10) {
				console.log("b :",b);
				console.log("db:",db);
				//throw "error";
			}
		}
	}
}


function CurveTest(curve) {
	let x0=curve[0],y0=curve[1];
	let x1=curve[2],y1=curve[3];
	let x2=curve[4],y2=curve[5];
	let x3=curve[6],y3=curve[7];
	let c=new Array(8*32);
	let d=0,maxdepth=(c.length>>>3)<<3,sign=0;
	while (true) {
		// Check if we're on 0. If we've converged, count what side we're on and backtrack.
		let l=y0<y1?y0:y1;l=l<y2?l:y2;l=l<y3?l:y3;
		let h=y0>y1?y0:y1;h=h>y2?h:y2;h=h>y3?h:y3;
		if (!(l<=0 && h>0 && h-l>1e-10 && d<maxdepth)) {
			if (x0<=0 && l<=0 && h>0) {sign+=y0>y1?-1:1;}
			//if (l<=0 && h>0 && x0<=(y0/(y1-y0))*(x1-x0)) {sign+=y0>y1?1:-1;}
			if (!d) {break;}
			y3=c[--d];y2=c[--d];y1=c[--d];y0=c[--d];
			x3=c[--d];x2=c[--d];x1=c[--d];x0=c[--d];
			continue;
		}
		// Split the curve in half: [0,1,2,3] = [0,1,2,3] + [3,4,5,6]
		let x6=x3,y6=y3;
		let xt=(x1+x2)*0.5,yt=(y1+y2)*0.5;
		let x5=(x2+x3)*0.5,y5=(y2+y3)*0.5;
		let x4=(xt+x5)*0.5,y4=(yt+y5)*0.5;
		x1=(x0+x1)*0.5;y1=(y0+y1)*0.5;
		x2=(x1+xt)*0.5;y2=(y1+yt)*0.5;
		x3=(x2+x4)*0.5;y3=(y2+y4)*0.5;
		// Push the second half if it's on 0.
		l=y3<y4?y3:y4;l=l<y5?l:y5;l=l<y6?l:y6;
		h=y3>y4?y3:y4;h=h>y5?h:y5;h=h>y6?h:y6;
		if (l<=0 && h>0) {
			c[d++]=x3;c[d++]=x4;c[d++]=x5;c[d++]=x6;
			c[d++]=y3;c[d++]=y4;c[d++]=y5;c[d++]=y6;
		}
	}
	return sign;
}


function pointinside(path,point,trans) {
	// Test if a point is in a path.
	// Arrange equations so py in [y[i],y[i+1]) is always used.
	let vidx=path.vertidx;
	if (!vidx) {return false;}
	// Put the point in path-space.
	let px=point[0],py=point[1];
	if (trans) {
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		let mat=trans.mat,vec=trans.vec;
		let det=mat[0]*mat[3]-mat[1]*mat[2];
		let tx=px-vec[0],ty=py-vec[1];
		px=(tx*mat[3]-ty*mat[1])/det;
		py=(ty*mat[0]-tx*mat[2])/det;
	}
	if (!(px>=path.minx && px<=path.maxx && py>=path.miny && py<=path.maxy)) {return false;}
	let x3=0,y3=0,movex=0,movey=0;
	let parity=0;
	let varr=path.vertarr;
	let intr=[0,0,0];
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		let x0=x3,x1=x3=v.x-px,x2;
		let y0=y3,y1=y3=v.y-py,y2;
		if (v.type!==DrawPath.CURVE) {
			// Close any unclosed subpaths.
			if (v.type===DrawPath.MOVE) {
				x1=movex;movex=x3;
				y1=movey;movey=y3;
			}
			// Line test.
			if ((y0<=0 && y1>0) || (y0>=0 && y1<0)) {
				let u=y0/(y0-y1),x=(1-u)*x0+u*x1;
				if (x<=0) {parity+=y0>y1?1:-1;}
			}
			continue;
		}
		// Find all u where y(u)=0, then check x(u)<=0.
		// First find the 3 intervals dy(u) can change signs.
		v=varr[++i];x2=v.x-px;y2=v.y-py;
		v=varr[++i];x3=v.x-px;y3=v.y-py;
		let r=1;
		let d0=y1-y0,d1=y1-y2,d2=d0+d1,d3=y3-y0+3*d1;
		let disc=d2*d2-d0*d3;
		if (disc>=0) {
			disc=Math.sqrt(disc);
			disc=d3<0?-disc:disc;
			let a=(d2-disc)/d3;
			let b=(d2+disc)/d3;
			if (a>0 && a<1) {intr[r++]=a;}
			if (b>0 && b<1) {intr[r++]=b;}
		}
		// Binary search each interval for y(u)=0.
		let u0=1,z0=y3;
		while (r>0) {
			let h=u0,l=u0=intr[--r],w=1-l;
			let z1=z0;z0=w*(w*w*y0+l*(w*y1+l*y2)*3)+l*l*l*y3;
			if (!((z0<=0 && z1>0) || (z0>=0 && z1<0))) {continue;}
			if (z0>z1) {l=h;h=u0;}
			for (let j=0;j<48;j++) {
				let u=(l+h)*0.5;w=1-u;
				let y=w*(w*w*y0+u*(w*y1+u*y2)*3)+u*u*u*y3;
				if (y>0) {h=u;} else {l=u;}
			}
			w=1-l;
			let x=w*(w*w*x0+l*(w*x1+l*x2)*3)+l*l*l*x3;
			if (x<=0) {parity+=z0>z1?1:-1;}
		}
	}
	return (path.area<0?-parity:parity)>0;
}


function pointinsidedraw(path,point,trans,draw) {
	// Test if a point is in a path.
	// Arrange equations so py in [y[i],y[i+1]) is always used.
	let vidx=path.vertidx;
	if (!vidx) {return false;}
	// Put the point in path-space.
	let px=point[0],py=point[1];
	if (trans) {
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		let mat=trans.mat,vec=trans.vec;
		let det=mat[0]*mat[3]-mat[1]*mat[2];
		let tx=px-vec[0],ty=py-vec[1];
		px=(tx*mat[3]-ty*mat[1])/det;
		py=(ty*mat[0]-tx*mat[2])/det;
	}
	if (!(px>=path.minx && px<=path.maxx && py>=path.miny && py<=path.maxy)) {return false;}
	let x3=0,y3=0,movex=0,movey=0;
	let parity=0;
	let varr=path.vertarr;
	let intr=[0,0,0];
	trans=(new Transform(trans)).shift([px,py],true);
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		let x0=x3,x1=x3=v.x-px,x2;
		let y0=y3,y1=y3=v.y-py,y2;
		if (v.type!==DrawPath.CURVE) {
			// Close any unclosed subpaths.
			if (v.type===DrawPath.MOVE) {
				x1=movex;movex=x3;
				y1=movey;movey=y3;
			}
			// Line test.
			if ((y0<=0 && y1>0) || (y0>=0 && y1<0)) {
				let u=y0/(y0-y1),x=(1-u)*x0+u*x1;
				if (x<=0) {parity+=y0>y1?1:-1;}
				let pt=trans.apply([x,0]);
				draw.setcolor(255,0,0,255);
				draw.filloval(pt[0],pt[1],5,5);
			}
			continue;
		}
		// Find all u where y(u)=0, then check x(u)<=0.
		// First find the 3 intervals dy(u) can change signs.
		v=varr[++i];x2=v.x-px;y2=v.y-py;
		v=varr[++i];x3=v.x-px;y3=v.y-py;
		let r=1;
		let d0=y1-y0,d1=y1-y2,d2=d0+d1,d3=y3-y0+3*d1;
		let disc=d2*d2-d0*d3;
		if (disc>=0) {
			disc=Math.sqrt(disc);
			disc=d3<0?-disc:disc;
			let a=(d2-disc)/d3;
			let b=(d2+disc)/d3;
			if (a>0 && a<1) {intr[r++]=a;}
			if (b>0 && b<1) {intr[r++]=b;}
		}
		// Binary search each interval for y(u)=0.
		let u0=1,z0=y3;
		let pt=trans.apply([x3,z0]);
		draw.setcolor(0,0,255,255);
		draw.filloval(pt[0],pt[1],5,5);
		while (r>0) {
			let h=u0,l=u0=intr[--r],w=1-l;
			let z1=z0;z0=w*(w*w*y0+l*(w*y1+l*y2)*3)+l*l*l*y3;
			pt=trans.apply([w*(w*w*x0+l*(w*x1+l*x2)*3)+l*l*l*x3,w*(w*w*y0+l*(w*y1+l*y2)*3)+l*l*l*y3]);
			draw.setcolor(0,0,255,255);
			draw.filloval(pt[0],pt[1],5,5);
			if (!((z0<=0 && z1>0) || (z0>=0 && z1<0))) {continue;}
			if (z0>z1) {l=h;h=u0;}
			for (let j=0;j<48;j++) {
				let u=(l+h)*0.5;w=1-u;
				let y=w*(w*w*y0+u*(w*y1+u*y2)*3)+u*u*u*y3;
				if (y>0) {h=u;} else {l=u;}
			}
			w=1-l;
			let x=w*(w*w*x0+l*(w*x1+l*x2)*3)+l*l*l*x3;
			if (x<=0) {parity+=z0>z1?1:-1;}
			pt=trans.apply([x,0]);
			draw.setcolor(0,0,255,255);
			draw.filloval(pt[0],pt[1],10,10);
		}
	}
	return (path.area<0?-parity:parity)>0;
}


function PointDisplay() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	let trans=new Transform(2);
	let path=new Draw.Path(`
		M 1 2 L 6 -6 C 6 3 22 -13 23 -6 L 26 0 C 54 -9 32 15 37 -12 L 27 -13 L 23
		-20 L 13 -12 L -1 -13 Z M 28 -10 L 14 -9 L 18 -14 Z
	`);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let mpos=input.getmousepos();
		trans=new Transform({ang:[performance.now()*0.0001],scale:[6,8],vec:[300,300]});
		draw.setcolor(255,255,255,255);
		//console.log(path.pointinside(mpos,trans));
		//if (pointinside(path,mpos,trans)) {
		if (path.pointinside(mpos,trans)) {
			draw.setcolor(60,255,60,255);
		} else {
			draw.setcolor(255,255,255,255);
		}
		draw.fillpath(path,trans);
		pointinsidedraw(path,mpos,trans,draw);
		draw.screenflip();
	}
	update();
}


function TestMain() {
	//LerpTest();
	//QuadraticTest();
	PointDisplay();
}
TestMain();

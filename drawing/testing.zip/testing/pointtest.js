/*

*/
/* npx eslint drawimage.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Transform,Input} from "../library.js";


function PointInsideTest() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	let trans=new Transform(2);
	let rnd=new Random();
	let path=new Draw.Path(`
		M 1 2 L 6 -6 C 6 3 22 -13 23 -6 L 26 0 C 54 -9 32 15 37 -12 L 27 -13 L 23
		-20 L 13 -12 L -1 -13 Z M 28 -10 L 14 -9 L 18 -14 Z
	`);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let [mx,my]=input.getmousepos();
		let trans=new Transform({ang:[performance.now()*0.0001],scale:[6,8],vec:[300,300]});
		if (path.pointinside([mx,my],trans,draw)) {
			draw.setcolor(60,255,60,255);
		} else {
			draw.setcolor(255,255,255,255);
		}
		draw.fillpath(path,trans);
		path.pointinside([mx,my],trans,draw)
		draw.screenflip();
	}
	update();
}

//PointInsideTest();


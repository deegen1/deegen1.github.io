/*------------------------------------------------------------------------------


areacalc.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


see lerp.py


*/
/* npx eslint areacalc.js -c ../../../standards/eslint.js */


import {Random} from "../library.js";


//---------------------------------------------------------------------------------
// Line Overlap Area Calculation


function Lerp1(x,x0,x1,y0,y1) {
	// Most accurate linear interpolation.
	// y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	if (!(x0===x0 && x1===x1 && y0===y0 && y1===y1)) {return NaN;}
	let y;
	if (x0>x1 || (x0===x1 && y0>y1)) {
		y=x0;x0=x1;x1=y;
		y=y0;y0=y1;y1=y;
	}
	y=x<=x0?y0:y1;
	if (x>x0 && x<x1) {
		let dy=y1-y0,u=x-x0,v=x1-x;
		if (u>v) {y0=y1;u=-v;}
		y=y0+(u/(x1-x0))*dy;
		y=y===y?y:y0;
	}
	return y;
}


function Lerp2(x,x0,x1,y0,y1) {
	// Most accurate linear interpolation.
	// y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	if (!(x0===x0 && x1===x1 && y0===y0 && y1===y1)) {return NaN;}
	let y;
	if (x0>x1 || (x0===x1 && y0>y1)) {
		y=x0;x0=x1;x1=y;
		y=y0;y0=y1;y1=y;
	}
	y=x>x0?y1:y0;
	if (x>x0 && x<x1) {
		let dx=x1-x0,dy=y1-y0,u=x-x0,v=x1-x;
		if (u>v) {x0=x1;y0=y1;u=-v;}
		let ay=dy>0?dy:-dy,ax=dx>1;
		y=y0;
		if ((x>0)!==(x0>0)) {
			u=x;
			v=x0>0?x0:-x0;
			y-=(v>ay)===ax?(x0/dx)*dy:x0*(dy/dx);
		}
		v=u>0?u:-u;
		y+=(v>ay)===ax?(u/dx)*dy:u*(dy/dx);
		y=y===y?y:y0;
	}
	return y;
}


function Lerp(x,x0,x1,y0,y1) {
	// Most accurate linear interpolation.
	// y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	if (!(x0===x0 && x1===x1 && y0===y0 && y1===y1)) {return NaN;}
	let y;
	if (x0>x1 || (x0===x1 && y0>y1)) {
		y=x0;x0=x1;x1=y;
		y=y0;y0=y1;y1=y;
	}
	y=x>x0?y1:y0;
	if (x>x0 && x<x1) {
		let dx=x1-x0,dy=y1-y0,u=x-x0,v=x1-x;
		if (u>v) {x0=x1;y0=y1;u=-v;}
		y=y0;
		if ((x>0)!==(x0>0)) {
			u=x;
			y-=x0*(dy/dx);
		}
		y+=(u/dx)*dy;
		y=y===y?y:y0;
	}
	return y;
}


function UnitAreaApprox(x0,y0,x1,y1,px,py,samples=10000) {
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	x0-=px;y0-=py;
	x1-=px;y1-=py;
	let miny=Math.min(y0,y1),maxy=Math.max(y0,y1);
	let dy=y1-y0;
	let prev=NaN;
	let area=0;
	for (let s=0;s<=samples;s++) {
		let u=s/samples;
		if (u>=miny && u<=maxy) {
			let v=(u-y0)/dy;
			let x=v*x1+(1-v)*x0;
			x=x>0?x:0;
			x=x<1?1-x:0;
			if (prev===prev) {area+=prev+x;}
			prev=x;
		}
	}
	area/=2*samples;
	return (y0>y1?area:-area);
}


function UnitAreaCalc(x0,y0,x1,y1,px=0,py=0) {
	// max dif: 0.00019999999488096165
	// avg dif: 0.00000117334298790786
	// Calculate the area to the right of the line.
	// Divide like by like, ex: (y/dy)*dx instead of (y*dx)/dy.
	// Use (1-u)*x0+u*x1 for interpolation accuracy.
	if (!(px===(px|0) && py===(py|0))) {
		throw `degenerate pixel coordinates: ${px}, ${py}`;
	}
	let sign=0,u;
	if (y0>y1) {
		sign=1;
		u=x0;x0=x1;x1=u;
		u=y0;y0=y1;y1=u;
	}
	let c1=px+1,r1=py+1;
	// If the pixel's outside the entire bounding box.
	if (!(y0<r1 && y1>py && (x0<c1 || x1<c1))) {return 0;}
	let area=(y1<r1?y1:r1)-(y0>py?y0:py);
	area=sign?area:-area;
	if (!(x0>px || x1>px)) {return area;}
	// If the pixel's too far left or right to overlap based on x=(y/dy)*dx+x0.
	let x0y=Lerp(px,x0,x1,y0,y1);
	let x1y=Lerp(c1,x0,x1,y0,y1);
	let y0x=Lerp(py,y0,y1,x0,x1);
	let y1x=Lerp(r1,y0,y1,x0,x1);
	if (y0<py) {y0=py;x0=y0x;}
	if (y1>r1) {y1=r1;x1=y1x;}
	if (x0>x1) {
		sign^=1;
		u=x0;x0=x1;x1=u;
		u=y0;y0=y1;y1=u;
	}
	if (!(x0<c1)) {return 0;}
	if (!(x1>px)) {return area;}
	// We're overlapping. Clip to the pixel.
	x0-=px;x1-=px;
	area=y0;
	if (x0<0) {x0=0;y0=x0y;}
	if (x1>1) {x1=1;y1=x1y;}
	area=y1-area+(x0+x1)*0.5*(y0-y1);
	//area=area< 1?area: 1;
	//area=area>-1?area:-1;
	area=sign?area:-area;
	return area;
}


function UnitAreaCalc2(x0,y0,x1,y1,px=0,py=0) {
	// max dif: 0.00019999999488096165
	// avg dif: 0.00000117334298790786
	// Calculate the area to the right of the line.
	// Divide like by like, ex: (y/dy)*dx instead of (y*dx)/dy.
	// Use (1-u)*x0+u*x1 for interpolation accuracy.
	if (!(px===(px|0) && py===(py|0))) {
		throw `degenerate pixel coordinates: ${px}, ${py}`;
	}
	let sign=-1,u;
	if (y0>y1) {
		sign=1;
		u=x0;x0=x1;x1=u;
		u=y0;y0=y1;y1=u;
	}
	let c1=px+1,r1=py+1;
	// If the pixel's outside the entire bounding box.
	if (!(y0<r1 && y1>py && (x0<c1 || x1<c1))) {return 0;}
	let area=(y1<r1?y1:r1)-(y0>py?y0:py);
	area=sign>0?area:-area;
	if (!(x0>px || x1>px)) {return area;}
	// If the pixel's too far left or right to overlap based on x=(y/dy)*dx+x0.
	//let x0y=Lerp(px,x0,x1,y0,y1);
	//let x1y=Lerp(c1,x0,x1,y0,y1);
	let dx=x1-x0,dy=y1-y0;
	if (y0<py) {x0=Lerp(py,y0,y1,x0,x1);y0=py;}
	if (y1>r1) {x1=Lerp(r1,y0,y1,x0,x1);y1=r1;}
	if (x0>x1) {u=x0;x0=x1;x1=u;dx=-dx;}
	x0-=px;x1-=px;
	if (!(x0<1)) {return 0;}
	if (!(x1>0)) {return area;}
	// Calculate area to the right.
	if (x1<1) {
		// Vertical line or last pixel.
		let h=y1-y0,tmp=x1>0?(x1*x1/dx)*dy:0;
		area=h-(x0<0?tmp:(x1+x0)*h)*0.5;
	} else {
		x1=1-x0;
		area=((x0>0?x1*x1:x1-x0)/dx)*dy*0.5;
	}
	area*=sign;
	area=area< 1?area: 1;
	area=area>-1?area:-1;
	return area;
}


function UnitAreaTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing unit area calculation");
	let tests=1000000;
	let maxdif=0,avgdif=0;
	let rnd=new Random(1);
	function getrnd() {
		// Try to align near integer boundaries to cause rounding errors.
		let p=rnd.gets()*14-10;
		return rnd.mod(21)-10+rnd.gets()*Math.pow(2,p*p*p);
	}
	let passed=0;
	for (let test=0;test<tests;test++) {
		let x0=getrnd(),y0=getrnd();
		let x1=getrnd(),y1=getrnd();
		let px=rnd.mod(21)-10,py=rnd.mod(21)-10;
		let flag=rnd.getu32();
		//if (test!==190) {continue;}
		if ((flag& 3)===0) {x1= x0;}
		if ((flag& 3)===1) {x1=-x0;}
		if ((flag&12)===0) {y1= y0;}
		if ((flag&12)===4) {y1=-y0;}
		let area0=UnitAreaApprox(x0,y0,x1,y1,px,py);
		let area1=UnitAreaCalc(x0,y0,x1,y1,px,py);
		if (area0===area0) {
			let dif=Math.abs(area0-area1);
			if (maxdif<dif || !(dif===dif)) {
				maxdif=dif;
				console.log("test :",test);
				console.log("dif  :",dif);
				console.log("area0:",area0);
				console.log("area1:",area1);
				console.log("x0 y0:",x0.toExponential(9),y0.toExponential(9));
				console.log("x1 y1:",x1.toExponential(9),y1.toExponential(9));
				console.log("px py:",px,py);
			}
			avgdif+=dif;
			passed++;
		}
	}
	avgdif/=tests;
	console.log("passed :",passed);
	console.log("max dif:",maxdif);
	console.log("avg dif:",avgdif);
}
//UnitAreaTest();

export {Lerp,UnitAreaCalc};

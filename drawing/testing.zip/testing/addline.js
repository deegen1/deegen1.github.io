	addline(x0,y0,x1,y1,rad) {
		// Line with circular ends.
		let dx=x1-x0,dy=y1-y0;
		let dist=dx*dx+dy*dy;
		if (dist<1e-20) {
			x1=x0;
			y1=y0;
			dx=rad;
			dy=0.0;
		} else {
			dist=rad/Math.sqrt(dist);
			dx*=dist;
			dy*=dist;
		}
		const c=0.551915024;
		let cx=c*dx,c0=cx-dy,c3=cx+dy;
		let cy=c*dy,c1=dx+cy,c2=dx-cy;
		this.moveto(x1+dy,y1-dx);
		this.curveto(x1+c3,y1-c2,x1+c1,y1-c0,x1+dx,y1+dy);
		this.curveto(x1+c2,y1+c3,x1+c0,y1+c1,x1-dy,y1+dx);
		this.lineto(x0-dy,y0+dx);
		this.curveto(x0-c3,y0+c2,x0-c1,y0+c0,x0-dx,y0-dy);
		this.curveto(x0-c2,y0-c3,x0-c0,y0-c1,x0+dy,y0-dx);
		return this.close();
	}

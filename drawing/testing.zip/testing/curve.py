"""-----------------------------------------------------------------------------


curve.py - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Test the accuracy of different cubic bezier interpolation methods.


"""

import random,math
import mpmath as mp
mp.mp.prec=2048


def CurveRef(u,curve):
	u=mp.mpf(u)
	v=mp.mpf(1)-u
	arr=[mp.mpf(x) for x in curve]
	for i in range(7,-1,-1):
		for j in range(i&1,i,2):
			arr[j]=v*arr[j]+u*arr[j+2]
	return arr[:2]


def Curve1(u,curve):
	v=1-u
	coef=[v*v*v,v*v*u*3,v*u*u*3,u*u*u]
	pt=[0,0]
	for i in range(8): pt[i&1]+=coef[i>>1]*curve[i]
	return pt


def Curve2(u,curve):
	v=1-u
	x0,y0,x1,y1,x2,y2,x3,y3=curve
	a6=v*x0+u*x1;a7=v*x1+u*x2;a8=v*x2+u*x3
	b6=v*y0+u*y1;b7=v*y1+u*y2;b8=v*y2+u*y3
	a6=v*a6+u*a7;a7=v*a7+u*a8
	b6=v*b6+u*b7;b7=v*b7+u*b8
	return [v*a6+u*a7,v*b6+u*b7]


if __name__=="__main__":
	#print(LerpRef(-1000,-1.0000000000001,-1,0,2))
	random.seed(1)
	funcarr=[Curve1,Curve2]
	funcs=len(funcarr)
	funccnt=[0]*funcs
	funcdif=[0]*funcs
	curve=[0]*8
	for test in range(100000):
		# Generate coords. Include NaNs, Infs, and copies.
		for i in range(8):
			p=(random.random()-0.5)*16
			b=random.random()*2-1
			a=random.randrange(-10,10)
			x=a+b*math.exp(p*p*p)
			curve[i]=x
			j=random.randrange(16)
			if j<i: curve[j]=x if random.random()<0.5 else -x
		u=random.random()
		# No NaNs.
		maxdist=mp.mpf("inf")
		ref=CurveRef(u,curve)
		for i in range(funcs):
			func=funcarr[i]
			pt=func(u,curve)
			#print(pt,ref)
			dx=ref[0]-pt[0]
			dy=ref[1]-pt[1]
			dist=dx*dx+dy*dy
			funcdif[i]=dist
			if maxdist>dist: maxdist=dist
		maxdist+=1e-20
		for i in range(funcs):
			funccnt[i]+=funcdif[i]<=maxdist
	print("ranks:",funccnt)
	print("done")


/*------------------------------------------------------------------------------


*/
/* npx eslint tracing.js -c ../../../standards/eslint.js */


import {Transform} from "../library.js";
import {Draw} from "../drawing.js";


function DrawOutline(draw,path,trans) {
	trans=new Transform(trans??{dim:2});
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0];
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1];
	let lr=[],lcnt=0;
	function AddSeg() {
		let seg={
			x0:0,y0:0,
			x1:0,y1:0,
			x2:0,y2:0,
			x3:0,y3:0
		};
		lr.push(seg);
		lcnt=lr.length;
		return seg;
	}
	const curvemaxdist2=0.02;
	let p0x=0,p0y=0,p1x=0,p1y=0;
	let varr=path.vertarr;
	let vidx=path.vertidx;
	for (let i=0;i<vidx;i++) {
		let v=varr[i<vidx?i:0];
		if (v.type===Draw.Path.CURVE) {v=varr[i+2];}
		p0x=p1x;p1x=v.x*matxx+v.y*matxy+matx;
		p0y=p1y;p1y=v.x*matyx+v.y*matyy+maty;
		// Add a basic line.
		if (v.type===Draw.Path.MOVE) {continue;}
		let l=AddSeg();
		l.x0=p0x;
		l.y0=p0y;
		l.x1=p1x;
		l.y1=p1y;
		if (v.type!==Draw.Path.CURVE) {continue;}
		// Linear decomposition of curves.
		v=varr[i++];let n1x=v.x*matxx+v.y*matxy+matx,n1y=v.x*matyx+v.y*matyy+maty;
		v=varr[i++];let n2x=v.x*matxx+v.y*matxy+matx,n2y=v.x*matyx+v.y*matyy+maty;
		l.x2=n1x;l.x3=n2x;
		l.y2=n1y;l.y3=n2y;
		for (let j=lcnt-1;j<lcnt;j++) {
			// The curve will stay inside the bounding box of [c0,c1,c2,c3].
			// If the subcurve is outside the image, stop subdividing.
			l=lr[j];
			let c3x=l.x1,c2x=l.x3,c1x=l.x2,c0x=l.x0;
			let c3y=l.y1,c2y=l.y3,c1y=l.y2,c0y=l.y0;
			let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
			// Test if both control points are close to the line c0->c3.
			// Clamp to ends and filter degenerates.
			let lx=c1x-c0x,ly=c1y-c0y;
			let u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d1=lx*lx+ly*ly;
			lx=c2x-c0x;ly=c2y-c0y;
			u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d2=lx*lx+ly*ly;
			d1=(d1>d2 || !(d1===d1))?d1:d2;
			if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
			// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
			let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
			let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
			let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
			let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
			let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
			let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
			l.x1=phx;l.x3=l2x;l.x2=l1x;
			l.y1=phy;l.y3=l2y;l.y2=l1y;
			l=AddSeg();
			l.x1=c3x;l.x3=r2x;l.x2=r1x;l.x0=phx;
			l.y1=c3y;l.y3=r2y;l.y2=r1y;l.y0=phy;
			j--;
		}
	}
	for (let i=0;i<lcnt;i++) {
		let l=lr[i];
		draw.drawline(l.x0,l.y0,l.x1,l.y1);
	}
}


function TracingDemo() {
	let canvas=document.createElement("canvas");
	document.body.appendChild(canvas);
	canvas.style.background="#000000";
	canvas.style.position="absolute";
	canvas.style.top="0px";
	canvas.style.left="0px";
	canvas.width=1000;
	canvas.height=1000;
	canvas.style.width=canvas.width+"px";
	canvas.style.height=canvas.height+"px";
	let draw=new Draw(canvas);
	let patharr=[
		`M396 553c11-32 23-81 21-140h86c0 68-8 135-49 211l99 124H440l-43-54c-43 35-95
		61-171 61-125 0-198-72-198-181 0-94 53-150 121-190-35-46-65-88-65-153C84 117
		165 68 256 68c91 0 160 52 160 143 0 85-58 134-146 183ZM227 341c40-25 102-54 102
		-123 0-49-29-78-76-78-54 0-81 37-81 83 0 54 32 89 55 118Zm-34 98c-34 23-76 59
		-76 126 0 72 49 117 119 117 45 0 80-16 113-48Z`,
		`M 0 0`,
		`M 0 0 1 0`,
		//`M 0 0 1 0 1 1 .5 1`,
		//`M 0 0 1 0 1 1 .85 -1`,
		`M 0 0 1 0 1 1 1.15 -1`,
		//`M 0 0 1 0 1 1 0.05 -1`,
		`M 0 0 1 0 1 1 .5 1 Z`
		//`M 0.75 .75 1 0 1 1 0 1 Z`
	];
	draw.fill(0,0,0,255);
	draw.setcolor(255,255,255);
	let paths=patharr.length;
	for (let p=0;p<paths*2;p++) {
		draw.setcolor(255,255,255);
		let sign=(p&1)*2-1;
		let pathstr=patharr[p>>>1];
		let path=new Draw.Path(pathstr,{scale:[sign,1]});
		let scale=80/Math.max(path.maxx-path.minx,path.maxy-path.miny);
		path.apply({scale:[scale,scale],vec:[500+sign*200-scale*path.minx,(p>>>1)*120+100-scale*path.miny]});
		DrawOutline(draw,path);
		//draw.tracepath(path);
		draw.setcolor(255,0,0);
		//if (p!==4) {continue;}
		let outline=path.trace(2);
		DrawOutline(draw,outline);
		draw.fillpath(outline);
		draw.setcolor(255,255,255);
		DrawOutline(draw,path);
	}
	draw.screenflip();
}

//TracingDemo();
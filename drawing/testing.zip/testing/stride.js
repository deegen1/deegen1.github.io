/*

replace if (l.row===y)
with    if (x>=1 && x0<-1)

*/
/* npx eslint stride.js -c ../../../standards/eslint.js */


import {Random} from "../library.js";


function UnitAreaCalc(x0,y0,x1,y1,px,py) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	x0-=px;y0-=py;
	x1-=px;y1-=py;
	let tmp=0,sign=1;
	//if (!(Math.abs(y0)<Infinity && Math.abs(y1)<Infinity && x1-x0!==0)) {
	//	return 0;
	//}
	if (isNaN((y1-y0)/(x1-x0))) {return 0;}
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	//if (x0>=Infinity || x1>=Infinity) {return 0;}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	// If we're entirely outside the bounding box.
	if (!(y0<1 && y1>0 && x0<1 && x1===x1)) {return 0;}
	let iy0=y0>0?y0:0;
	let iy1=y1<1?y1:1;
	if (x1<=0) {return (iy0-iy1)*sign;}
	// Determine if [0,1] is entirely to the left/right of slope.
	let dx=x1-x0,dy=y1-y0;
	// x=x0+(y-y0)*dx/dy
	if ((1-x0)*dy<=(iy0-y0)*dx) {return 0;}
	if ((0-x0)*dy>=(iy1-y0)*dx) {return (iy0-iy1)*sign;}
	// Narrow-phase. Clip to unit box.
	let x0y=y0-dy*(x0/dx);
	let x1y=y0+dy*((1-x0)/dx);
	let y0x=x0-dx*(y0/dy);
	let y1x=x0+dx*((1-y0)/dy);
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	/*if (x0<0 && x1>1) {
		return ((x0-0.5)/dx)*dy*sign;
	} else if (x0<0) {
		return ((x1*x1*0.5-x1+x0)/dx)*dy*sign;
	} else if (x1>1) {
		return -0.5*((1-x0)*(1-x0)/dx)*dy*sign;
	} else {
		return (y0-y1)*(2-x0-x1)*0.5*sign;
	}*/
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


//---------------------------------------------------------------------------------
// Test 3 - Area Clipping


function GetRowLines2(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	let x0=line.x0,y0=line.y0-py;
	let x1=line.x1,y1=line.y1-py;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0>=1 && y1>=1) || (y0<=0 && y1<=0)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let dxy=difx/dify;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y0>1) {y0=1;x0=y1x;}
	if (y1<0) {y1=0;x1=y0x;}
	if (y1>1) {y1=1;x1=y1x;}
	let next=(y0>y1?x0:x1)+(dxy<0?dxy:0);
	if (next<Math.min(line.x0,line.x1)) {next=Math.min(line.x0,line.x1);}
	if (py+1>Math.max(line.y0,line.y1)) {next=Infinity;}
	a0.next=next;
	if (x1<x0) {tmp=x0;x0=x1;x1=tmp;dyx=-dyx;}
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		dyx*=amul;
		let mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function GetRowLines3(line,py,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-10 || (y0<=py && y1<=py)) {return [a0,a1];}
	if (Math.abs(difx)<1e-10) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=py;
	y1-=py;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	let fx0=Math.floor(x0);
	let fx1=Math.floor(x1);
	x0-=fx0;
	x1-=fx1;
	a0.sort=fx0;
	if (fx0===fx1 || fx1<0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=fx1>=0?(x0+x1)*dy*0.5:0;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else {
		let dyx=amul/dxy,mul=dyx*0.5,n0=x0-1,n1=x1-1;
		if (fx0<0) {
			a0.area-=mul-(x0+fx0)*dyx;
		} else {
			a0.area-=n0*n0*mul;
			a0.areadx2+=x0*x0*mul;
		}
		a0.areadx1-=dyx;
		a1.area   +=n1*n1*mul;
		a1.areadx1+=dyx;
		a1.areadx2-=x1*x1*mul;
		a1.sort=fx1;
	}
	return [a0,a1];
}


function GetRowLines4(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?~~x0:x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	if (x<fx1 && dyx>-1e8 && dyx<1e8) {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
	} else {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
	}
	a0.areadx2+=tmp;
	return [a0,a1];
}


function GetRowRef(line,p,iw,amul) {
	let x=p%iw,y=Math.floor(p/iw);
	let area=UnitAreaCalc(line.x0,line.y0,line.x1,line.y1,x,y);
	return area*amul;
}


function GetRowLines6(l,p,iw,ih,amul) {
	//     eps     :   max err
	// .0000000001 : 9.163271e-7  6.531069e-4
	// .000000001  : 9.096675e-8
	// .00000001   : 9.234800e-9
	// .0000001    : 7.116655e-8
	// .000001     : 7.116882e-7  7.026196e-1
	// .00001      : 7.116945e-6
	// .0001       : 7.116823e-5
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// For accuracy, avoid mixing units. Ex: use (y/dy)*dx instead
	// of (y*dx)/dy or y*(dx/dy).
	l.area=0;
	l.areadx1=0;
	l.areadx2=0;
	const y=Math.floor(p/iw),xrow=y*iw,x=p-xrow;
	let tmp=0;
	// Orient upwards, then clip y to [0,1].
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	y0-=fy;y1-=fy;x0-=x;x1-=x;
	let dx=x1-x0,dy=y1-y0,nx=x1;
	if (y1>2) {nx+=((2-y1)/dy)*dx;}
	if (y1>1) {x1+=((1-y1)/dy)*dx;y1=1;}
	if (y0<0) {x0+=((0-y0)/dy)*dx;y0=0;}
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;
	let rate=dy/dx;
	let end=l.end-xrow-iw,sort=xrow;
	if (y1<=0.000001) {
		// Above.
		sort=iw*ih;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1.000001 || end<0) {
		// Vertical line or last pixel.
		let ty=(y0-y1)*sign;
		tmp=x1>0?((-0.5*x1*x1)/dx)*dy:0;
		if (end<0) {
			ty=((0.5-x1)/dx)*dy;
			l.areadx1+=rate;
		} else {
			tmp=x0>=0?(x0+x1)*ty*0.5:tmp;
		}
		l.area+=ty-tmp;
		l.areadx2+=tmp;
		sort+=iw;
	} else {
		// Line spanning multiple pixels.
		tmp=x0>0?((0.5*x0*x0)/dx)*dy:0;
		l.area-=((0.5-x0)/dx)*dy+tmp;
		l.areadx1-=rate;
		l.areadx2+=tmp;
		nx=x1;
		end=x+x1<iw?0:end;
	}
	nx+=x;
	nx=nx<0?0:nx;
	l.sort=sort+(nx<iw?~~nx:iw);
	l.end=end?0xffffffff:l.sort;
}


function GetRowLines7(l,p,iw,ih,amul) {
	//     eps     :   max err
	// .0000000001 : 9.163271e-7  4.938340e-4
	// .000000001  : 9.096675e-8
	// .00000001   : 9.234800e-9
	// .0000001    : 7.116655e-8  6.781685e-2
	// .000001     : 7.116882e-7  6.986409e-1
	// .00001      : 7.116945e-6  6.766054e-0
	// .0001       : 7.116823e-5
	//
	// With eps=.0000001
	// max dif : 9.999892e-8
	// avg dif : 1.618923e-7
	// max area: 1.0000000305493204
	// max dx1 : 9999417.385284
	// max dx2 : 4999708.692642
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),plim=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	let end=l.end-plim,sort=plim-iw,x=p-sort;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,nx=x1;
	let dxy=dx/dy,dyx=sign*(dy/dx);
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	if (y1>fy+2) {nx=y0x+2*dxy;}
	if (y1>fy+1) {x1=y0x+dxy;y1=fy+1;}
	if (y0<fy  ) {x0=y0x;y0=fy;}
	// Subtract x and fy after normalizing to row.
	y0-=fy;y1-=fy;x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dyx=-dyx;tmp=x0;x0=x1;x1=tmp;}
	if (!(y1>0.0000001 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1.0000001 || end<0) {
		// Vertical line or last pixel.
		let ty=(y0-y1)*sign;
		tmp=x1>0?-0.5*x1*x1*dyx:0;
		if (end<0) {
			ty=(0.5-x1)*dyx;
			areadx1+=dyx;
		} else {
			tmp=x0>=0?0.5*(x0+x1)*ty:tmp;
		}
		area+=ty-tmp;
		areadx2+=tmp;
		sort+=iw;
	} else {
		// Line spanning multiple pixels.
		tmp=x0>0?0.5*x0*x0*dyx:0;
		area-=(0.5-x0)*dyx+tmp;
		areadx1-=dyx;
		areadx2+=tmp;
		nx=x1;
		end=x+x1<iw?0:1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	l.end=end?0xffffffff:sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines8(l,p,iw,ih,amul) {
	// Error over 10,000,000 tests:
	// max dif : 3.143318e-14
	// sum dif : 1.333336e-14
	// max area: 1.0000000000000187
	// max dx1 : 1.0000000000000002
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	let end=l.end,sort=prow-iw,x=p-sort;
	l.end=-1;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	y0-=fy;y1-=fy;
	let nx=y1>2?y0x+2*dxy:x1;
	if (y1>1) {y1=1;x1=y0x+dxy;}
	if (y0<0) {y0=0;x0=y0x;}
	// Subtract x after normalizing to row.
	x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>0 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1) {
		// Vertical line or last pixel.
		tmp=x1>0?-(x1*x1/dx)*dy:0;
		if (end<p && end>=sort) {
			areadx1+=dyx;
			area+=((x1>0?(1-x1)*(1-x1):(1-2*x1))/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=0?0.5*(x0+x1)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<1?pixels:iw;
	} else {
		// Spanning 2+ pixels.
		tmp=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
		area-=tmp;
		if (x1>=2) {
			areadx1-=dyx;
			tmp=x0>0?(x0*x0/dx)*dy:0;
			l.end=p;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines9(l,p,iw,ih,amul) {
	// Error over 10,000,000 tests:
	// max dif : 3.018521e-14
	// sum dif : 1.379051e-14
	// max area: 1.0000000000000175
	// max dx1 : 1
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	y0-=fy;y1-=fy;
	let nx=y1>2?y0x+2*dxy:x1;
	if (y1>1) {y1=1;x1=y0x+dxy;}
	if (y0<0) {y0=0;x0=y0x;}
	// Subtract x after normalizing to row.
	let sort=prow-iw,x=p-sort;
	x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>0 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1) {
		// Vertical line or last pixel.
		tmp=x1>0?-(x1*x1/dx)*dy:0;
		//if (x>=1 && x0<-1)
		if (l.row===y) {
			areadx1+=dyx;
			area+=((x1>0?(1-x1)*(1-x1):(1-2*x1))/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=0?0.5*(x0+x1)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<1?pixels:iw;
	} else {
		// Spanning 2+ pixels.
		tmp=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
		area-=tmp;
		if (x1>=2) {
			areadx1-=dyx;
			tmp=x0>0?(x0*x0/dx)*dy:0;
			l.row=y;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines10(l,p,iw,ih,amul) {
	// Current best.
	// Error over 10,000,000 tests:
	// max dif : 1.509282e-10
	// sum dif : 1.866119e-13
	// max area: 1.0000000001509282
	// max dx1 : 1.0000000000000002
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pmax=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// Calculate row and col.
	let sort=prow-iw,c0=p-sort,c1=c0+1;
	let r0=y0<ih?~~y0:ih;
	r0=y0>y?r0:y;
	let r1=r0+1,r2=r0+2;
	// Clamp y to row. Ensure consecutive rows use the same calculations.
	let dx=x1-x0,dy=y1-y0,nx=x1;
	if (dy>1) {
		// Large numbers.
		let dxy=dx/dy,y0x=x0-y0*dxy;
		if (y1>r2) {nx=y0x+r2*dxy;}
		if (y1>r1) {x1=y0x+r1*dxy;y1=r1;}
		if (y0<r0) {x0=y0x+r0*dxy;y0=r0;}
	} else {
		// Small numbers.
		if (y1>r2) {nx=x0-((y0-r2)/dy)*dx;}
		if (y1>r1) {x1=x0-((y0-r1)/dy)*dx;y1=r1;}
		if (y0<r0) {x0=x0-((y0-r0)/dy)*dx;y0=r0;}
	}
	/*
	let dx=x1-x0,dy=y1-y0;
	let cr=x0*y1-y0*x1;
	let nx=y1>r2?(cr+r2*dx)/dy:x1;
	if (y1>r1) {x1=(cr+r1*dx)/dy;y1=r1;}
	if (y0<r0) {x0=(cr+r0*dx)/dy;y0=r0;}
	*/
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>r0 && dyx!==0)) {
		// Above or degenerate.
		sort=pmax;
	} else if (x0>=c1 || r0>y) {
		// Below or to the left.
		nx=x0;
		sort=r0*iw;
	} else if (x1<=c1) {
		// Vertical line or last pixel.
		let t0=x1-c0,t1=x1-c1;
		tmp=x1>c0?-(t0*t0/dx)*dy:0;
		if (c0>1 && x0<c0-1) {
			areadx1+=dyx;
			area+=((x1>c0?t1*t1:-t0-t1)/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=c0?0.5*(x0-c0+t0)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<r1?pmax:iw;
	} else {
		// Spanning 2+ pixels.
		let t0=x0-c0,t1=x0-c1;
		tmp=((x0>c0?t1*t1:-t0-t1)/dx)*dy;
		area-=tmp;
		if (x1>=c0+2) {
			areadx1-=dyx;
			tmp=x0>c0?(t0*t0/dx)*dy:0;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pmax;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines11(l,p,iw,ih,amul) {
	// Fails for small exponents.
	// Error over 10,000,000 tests:
	// max dif : 3.650304e-14
	// sum dif : 1.759082e-14
	// max area: 1.0000000000000193
	// max dx1 : 1.0000000000000004
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pmax=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp=0;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// Calculate row and col.
	let sort=prow-iw,c0=p-sort,c1=c0+1;
	let r0=y0<ih?~~y0:ih;
	r0=y0>y?r0:y;
	let r1=r0+1,r2=r0+2;
	// Clamp y to row. Ensure consecutive rows use the same calculations.
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	let nx=y1>r2?x0-(y0-r2)*dxy:x1;
	if (y1>r1) {x1=x0-(y0-r1)*dxy;y1=r1;}
	if (y0<r0) {x0=x0-(y0-r0)*dxy;y0=r0;}
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	let dyx=(dy/dx)*sign,dyh=dyx*0.5;
	if (!(y1>r0 && dyx!==0)) {
		// Above or degenerate.
		sort=pmax;
	} else if (x0>=c1 || r0>y) {
		// Below or to the left.
		nx=x0;
		sort=r0*iw;
	} else if (x1<=c1) {
		// Vertical line or last pixel.
		let t0=x1-c0,t1=x1-c1;
		tmp=t0>0?-t0*t0*dyh:0;
		if (c0>1 && x0<c0-1) {
			areadx1+=dyx;
			area+=(t0>0?t1*t1:-t0-t1)*dyh;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=c0?0.5*(x0-c0+t0)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<r1?pmax:iw;
	} else {
		// Spanning 2+ pixels.
		let t0=x0-c0,t1=x0-c1;
		tmp=(t0>0?t1*t1:-t0-t1)*dyh;
		area-=tmp;
		if (x1>=c0+2) {
			areadx1-=dyx;
			tmp=t0>0?t0*t0*dyh:0;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pmax;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function AreaClipTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(3);
	const maxdim=64;
	const amul=0.7117;
	let maxdif=0,sumdif=0,sumbuf=0,sumden=0;
	let maxarea=0,maxdx1=0,maxdx2=0;
	let tests=10000000;
	function getrnd(dim) {
		// Try to align near integer boundaries to cause rounding errors.
		//let degen=rnd.mod(64);
		//if (degen<3) {return [NaN,-Infinity,Infinity][degen];}
		//let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		//let dev=rnd.gets()*Math.pow(2,-rnd.mod(2000));
		// FP64 can have +-1024 exponent.
		let type=rnd.mod(128);
		let dev=rnd.gets();
		if (type===0) {dev=0;}
		else if (type<64) {dev*=Math.pow(2,20-rnd.mod(40));}
		else              {dev*=Math.pow(2,20-rnd.mod(1200));}
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxdif);
		}
		// Setup the line.
		let imgw=rnd.mod(maxdim)+1;
		let imgh=rnd.mod(maxdim)+1;
		let pixels=imgw*imgh;
		let x0=getrnd(imgw);
		let y0=getrnd(imgh);
		let x1=getrnd(imgw);
		let y1=getrnd(imgh);
		//let p=rnd.mod(pixels);
		let p=rnd.mod(imgh)*imgw;
		//if (test!==6677903) {continue;}
		let minx=Math.floor(x0<x1?x0:x1);
		let maxx=Math.floor(x0>x1?x0:x1);
		let miny=Math.floor(y0<y1?y0:y1);
		let maxy=Math.floor(y0>y1?y0:y1);
		//console.log(minx,maxx,miny,maxy,imgw,imgh);
		let firstpix=Math.max(miny,0)*imgw+Math.min(Math.max(minx,0),imgw);
		let lastpix=Math.min(Math.max(maxy+1,0),imgh)*imgw+Math.min(Math.max(maxx,0),imgw);
		if (miny>=imgh) {
			firstpix=pixels;
			lastpix=pixels;
		}
		let line={sort:0,end:0xffffffff,row:-1,x0:x0,y0:y0,x1:x1,y1:y1,area:0,areadx1:0,areadx2:0};
		// Pick a starting pixel and compare every pixel after.
		let nextrow=-1;
		let proccnt=0;
		//let area=0,areadx1=0,areadx2=0;
		let linenext=-1;
		let firstproc=1;
		for (;p<pixels;p++) {
			if (p>=nextrow) {
				nextrow=Math.floor(p/imgw)*imgw+imgw;
				line.area=0;
				line.areadx1=0;
				line.areadx2=0;
				proccnt=-firstproc;
				firstproc=0;
				/*if (line.end!==0xffffffff) {
					console.log("new row end:",line.end);
					throw "error";
				}*/
			}
			// Process the start or end of the line.
			if (p>=linenext) {
				GetRowLines10(line,p,imgw,imgh,amul);
				linenext=line.sort;
				proccnt++;
			}
			// Compare with the reference.
			let x=p%imgw,y=Math.floor(p/imgw);
			let calc=GetRowRef(line,p,imgw,amul);
			//console.log("test:",test,line.area,calc);
			let dif=Math.abs(line.area-calc);
			sumbuf+=dif;
			sumden++;
			if (sumden>1000000) {
				sumdif+=sumbuf;
				sumbuf=0;
				sumden=0;
			}
			if (maxdif<dif || isNaN(dif)) {
				maxdif=dif;
				console.log("test:",test,dif);
			}
			maxarea=Math.max(maxarea,Math.abs(line.area));
			maxdx1 =Math.max(maxdx1 ,Math.abs(line.areadx1));
			maxdx2 =Math.max(maxdx2 ,Math.abs(line.areadx2));
			if (!(dif<1e-3)) {
				console.log("test:",test);
				console.log("area:",line.area,calc);
				console.log("img :",imgw,imgh);
				console.log("x y :",x,y,p);
				console.log("line:",line);
				throw "error";
			}
			line.area+=line.areadx1+line.areadx2;
			line.areadx2=0;
			// Check bounds.
			if (proccnt>3) {
				console.log("too many row procs",proccnt);
				throw "error";
			}
			if (p<firstpix && linenext+1<firstpix) {
				console.log("test:",test);
				console.log("dim :",imgw,imgh);
				console.log("first pixel:",p,pixels,firstpix,linenext);
				console.log("area:",GetRowRef(line,firstpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				console.log("line:",line);
				throw "error";
			}
			if (p>lastpix && linenext<pixels) {
				console.log("last pixel:",p,pixels,lastpix,linenext);
				console.log("area:",GetRowRef(line,lastpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				throw "error";
			}
			let sort=line.sort;
			if (sort!==(sort>>>0) || sort<p) {
				console.log("invalid sort:",sort,p);
				throw "error";
			}
			/*let end=line.end;
			if (end!==(end>>0)) {// || (end<pixels && end>=nextrow) || end<p) {
				console.log("invalid end:",end,p,pixels,nextrow);
				throw "error";
			}*/
		}
	}
	maxdif/=amul;
	sumdif=((sumdif+sumbuf)/tests)/amul;
	maxarea/=amul;
	maxdx1/=amul;
	maxdx2/=amul;
	console.log("max dif :",maxdif);
	console.log("sum dif :",sumdif);
	console.log("max area:",maxarea);
	console.log("max dx1 :",maxdx1);
	console.log("max dx2 :",maxdx2);
}


function TestMain() {
	AreaClipTest();
	console.log("done");
}
//TestMain();

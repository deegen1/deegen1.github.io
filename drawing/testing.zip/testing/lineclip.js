/*------------------------------------------------------------------------------


lineclip.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


Baselining fast: 611 84 0


*/
/* npx eslint lineclip.js -c ../../../standards/eslint.js */


import {Random} from "../library.js";
import {Lerp,UnitAreaCalc} from "./areacalc.js";


//---------------------------------------------------------------------------------
// Single Pixel Clipping


function SingleClipNext1(x0,y0,x1,y1,px,py,imgw,imgh) {
	/*
	Basic
	calcs: 599,909,635
	waste: 583,736,152

	Skipping top, bottom, and right
	calcs:  19,288,826
	waste:   3,115,008

	Better right-side calculation
	calcs:  19,288,636
	waste:   3,114,829

	Flat line detection
	calcs:  19,287,357
	waste:   3,113,550

	Early stop on right
	calcs:  19,126,520
	waste:   2,953,037

	Lerp()
	calcs:  19,126,564
	waste:   2,953,081

	a1<imgw
	calcs:  16,866,310
	waste:   1,554,364
	*/
	// given variables
	const pix=py*imgw+px,pmax=imgh*imgw,amul=1,maxy=imgh;
	let areacon=0,areatmp=0;
	// start
	let sort=pmax;
	let sign=amul,u;
	if (y0>y1) {
		sign=-sign;
		u=x0;x0=x1;x1=u;
		u=y0;y0=y1;y1=u;
	}
	if (py<y1 && y0<maxy && y0<y1) {
		// Find the bottom of the line.
		let ny=y0>py?~~y0:py,r1=ny+1,nx=px+1;
		// Clip to the row.
		let a0=x0,a1=x1,b0=y0,b1=y1;
		if (y1>r1) {x1=Lerp(r1,b0,b1,a0,a1);y1=r1;}
		if (y0<ny) {x0=Lerp(ny,b0,b1,a0,a1);y0=ny;}
		if (x0>x1) {
			sign=-sign;
			u=x0;x0=x1;x1=u;
			u=y0;y0=y1;y1=u;
		}
		if (!(x0<nx && ny<=py)) {
			// Under or to the left. If leaning past the edge of the image, abort.
			if (x0<imgw || a1<imgw) {nx=x0;} else {ny=imgh;}
		} else if (x1<=px) {
			// To the right. Area won't change after this pixel.
			x0=Lerp(ny+2,b0,b1,a0,a1);
			nx=x0<x1?x0:x1;
			ny=b1>r1?r1:imgh;
			areacon+=(y0-y1)*sign;
		} else {
			// Overlapping - clip to the column.
			x0-=px;x1-=px;u=y0;
			if (x0<0) {y0=Lerp(px,a0,a1,b0,b1);x0=0;}
			if (x1>1) {y1=Lerp(nx,a0,a1,b0,b1);x1=1;}
			areatmp+=(u-y1+(x0+x1)*0.5*(y1-y0))*sign;
		}
		nx=nx<0?0:nx;
		sort=ny*imgw+(nx<imgw?~~nx:imgw);
		sort=sort>pix?sort:(pix+1);
	}
	return {next:sort,area:areacon+areatmp};
}


function SingleClipNext(x0,y0,x1,y1,px,py,imgw,imgh) {
	/*
	Basic
	calcs: 599,909,635
	waste: 583,736,152

	Skipping top, bottom, and right
	calcs:  19,288,826
	waste:   3,115,008

	Better right-side calculation
	calcs:  19,288,636
	waste:   3,114,829

	Flat line detection
	calcs:  19,287,357
	waste:   3,113,550

	Early stop on right
	calcs:  19,126,520
	waste:   2,953,037

	Lerp()
	calcs:  19,126,564
	waste:   2,953,081

	a1<imgw
	calcs:  16,866,310
	waste:   1,554,364

	Fast version
	calcs:  18,412,274
	waste:   1,443,448
	*/
	// given variables
	const pix=py*imgw+px,pmax=imgh*imgw,amul=1,maxy=imgh;
	let areacon=0,areatmp=0;
	// start
	let next=pmax;
	let sign=amul,u;
	if (y0>y1) {
		sign=-sign;
		u=x0;x0=x1;x1=u;
		u=y0;y0=y1;y1=u;
	}
	if (py<y1 && y0<maxy && y0<y1) {
		// Find the bottom of the line.
		let ny=y0>py?~~y0:py,r1=ny+1,r2=ny+2,nx=px+1;
		// Clip to the row. For large coordinates, use the closest endpoint to imgh/2.
		let dx=x1-x0,dy=y1-y0;
		let bx=x0,by=y0,x2=x1,y2=y1;
		if (y0+y1<imgh) {bx=x1;by=y1;}
		//if (dy>imgh*9) {bx-=by*(dx/dy);by=0;}
		if (y1>r1) {x1=bx+((r1-by)/dy)*dx;y1=r1;}
		if (y0<ny) {x0=bx+((ny-by)/dy)*dx;y0=ny;}
		if (x0>x1) {
			sign=-sign;
			u=x0;x0=x1;x1=u;
			u=y0;y0=y1;y1=u;
		}
		if (!(x0<nx && ny<=py)) {
			// Under or to the left. If leaning past the edge of the image, abort.
			if (x0<imgw || x2<imgw) {nx=x0;} else {ny=imgh;}
		} else if (x1<=px) {
			// To the right. Area won't change after this pixel.
			x0=y2>r2?bx+((r2-by)/dy)*dx:x2;
			nx=x0<x1?x0:x1;
			ny=y2>r1?r1:imgh;
			areacon+=(y0-y1)*sign;
		} else {
			// Overlapping. Clip to the column.
			x0-=px;x1-=px;u=y0;
			dx=x1-x0;dy=y1-y0;
			if (x0<0) {y0-=((x0  )/dx)*dy;x0=0;}
			if (x1>1) {y1-=((x1-1)/dx)*dy;x1=1;}
			areatmp+=(u-y1+(x0+x1)*0.5*(y1-y0))*sign;
		}
		nx=nx<0?0:nx;
		next=ny*imgw+(nx<imgw?~~nx:imgw);
		next=next>pix?next:(pix+1);
	}
	let area=areacon+areatmp;
	if (!(area>=-1 && area<=1)) {console.log(area);throw "area";}
	return {next:next,area:areacon+areatmp};
}


function SingleClipTest() {
	// We're off the line, the area should be 0 and 'next' should be the next
	// pixel.
	console.log("testing line clip prediction");
	let rnd=new Random(1);
	function rndint(i) {
		let p=rnd.getf()*16-10;
		let off=rnd.gets()*Math.pow(2,p*p*p);
		let j=rnd.mod(i*3+1)-i;
		return j+off;
	}
	let calcs=0;
	let waste=0;
	let sumerr=0;
	let sumden=0;
	//let nextcnt=0,err1cnt=0,err2cnt=0;
	for (let test=0;test<10000000;test++) {
		if (!(test%100000)) {console.log("test:",test);}
		let imgw=rnd.mod(50);
		let imgh=rnd.mod(50);
		let pixels=imgw*imgh;
		let x0=rndint(imgw),y0=rndint(imgh);
		let x1=rndint(imgw),y1=rndint(imgh);
		//if (test!==30818) {continue;}
		let calcarea=NaN;
		let calcnext=0;
		let prev=0;
		for (let pix=0;pix<pixels;pix++) {
			let px=pix%imgw,py=~~(pix/imgw);
			let area=UnitAreaCalc(x0,y0,x1,y1,px,py);
			if (px===0) {calcarea=0;prev=0;}
			let ret=SingleClipNext(x0,y0,x1,y1,px,py,imgw,imgh);
			if (calcnext<=pix) {
				calcarea=ret.area;
				calcnext=ret.next;
				calcs++;
				if (!(calcnext===(calcnext|0) && calcnext>pix)) {
					console.log("test:",test);
					console.log("next:",calcnext,pix);
					throw "error";
				}
				// Waste is when we recalculate area that hasn't changed.
				// Don't count the first pixel.
				if (Math.abs(area-prev)<=1e-20 && pix) {waste++;}
			} else {
				// Make sure we can recalulate the area and next pixel from an arbitrary pixel.
				if ((calcnext<pixels || ret.next<pixels) && Math.abs(calcnext-ret.next)>0) {
					//nextcnt++;
					console.log("test:",test);
					console.log("next:",calcnext,ret.next);
					console.log("dim :",imgw,imgh,pixels);
					console.log("x0y0:",x0,y0);
					console.log("x1y1:",x1,y1);
					throw "next error";
				}
				let err=Math.abs(calcarea-ret.area);
				if (!(err<1e-20)) {
					//err1cnt++;
					console.log("test:",test);
					console.log("area:",calcarea,ret.area,err);
					console.log("x0y0:",x0,y0);
					console.log("x1y1:",x1,y1);
					throw "area error 1";
				}
			}
			prev=area;
			let err=Math.abs(calcarea-area);
			if (Math.abs(area)>1e-10 && err===err) {
				sumerr+=err;
				sumden++;
			} else if (!(err<1e-10)) {
				//err2cnt++;
				console.log("test:",test);
				console.log("area:",area);
				console.log("calc:",calcarea);
				console.log("err :",err.toExponential(6));
				console.log("x0y0:",x0,y0);
				console.log("x1y1:",x1,y1);
				throw "area error 2";
			}
		}
	}
	//console.log("error:",nextcnt,err1cnt,err2cnt);
	sumerr/=sumden;
	console.log("calcs:",calcs);
	console.log("waste:",waste);
	console.log("err  :",sumerr.toFixed(10),sumden);
}


//---------------------------------------------------------------------------------
// Stride Test
// Calculate how many pixels can be filled with the same color.


function StrideLengthCalc1(area,areadx1,areadx2,cutoff,x,xnext) {
	// Find the first iteration where the area crosses the cutoff boundary.
	let side=area>=cutoff,nx=x,narea;
	do {narea=area+areadx2+areadx1*((++nx)-x);}
	while ((narea>=cutoff)===side && nx<xnext);
	return [nx,narea];
}


function StrideLengthCalc2(area,areadx1,areadx2,cutoff,x,xnext) {
	let astop=area+areadx2+areadx1;
	let xstop=x+1,xdif=xnext-x;
	// xdif=(xnext<xrow?xnext:xrow)-xstop;
//console.log(astart,astop);
	if (xdif>1 && (area>=cutoff)===(astop>=cutoff)) {
		let adif=(cutoff-astop)/areadx1+2;//(area>=cutoff);
//console.log("adif:",x,adif,cutoff-astart);
		xdif=(adif>2 && adif<xdif)?(~~adif):xdif;
//+(area>=cutoff)
		astop=area+areadx2+xdif*areadx1;
		xstop=x+xdif;
	}
	return [xstop,astop];
/*
	let astop=area+areadx1+areadx2;
	let pstop=p+1,pdif=(pnext<prow?pnext:prow)-pstop;
	if (pdif>0 && (area>=cutoff)===(astop>=cutoff)) {
		let adif=(cutoff-astop)/areadx1+1;
		pdif=(adif>=1 && adif<pdif)?~~adif:pdif;
		astop+=pdif*areadx1;
		pstop+=pdif;
	}
*/
}


function StrideLengthTest() {
	// If area>cutoff, how long until area+areadx2<=cutoff.
	// If any value is NaN or infinity, guarantee progression.
	// Don't let xstop become NaN, negative, or infinite.
	//
	console.log("testing stride calculation");
	let rnd=new Random(33);
	function rndcoord(min,max) {
		let p=rnd.getf()*10-8;
		let x=rnd.mod(21)-10+rnd.gets()*Math.pow(2,p*p*p);
		if ((rnd.getu32()&255)<6) {x=NaN;}
		if (min!==undefined) {
			x=x>min?x:min;
			x=x<max?x:max;
		}
		return x;
	}
	let waste=0;
	for (let test=0;test<100000;test++) {
		let cutoff =rndcoord();
		let area   =rndcoord();
		let areadx1=rndcoord();
		let areadx2=rndcoord();
		let x      =~~rndcoord(-1000,1000);
		let xnext  =~~rndcoord(-1000,1000);
		//if (xnext<x+1) {xnext=x+1;}
		if ((rnd.getu32()&63)===0) {
			// Special case to force adif=n.
			areadx2=0;
			areadx1=(cutoff-area)/(rnd.mod(10)+1);
		}
		//if (test!==9717) {continue;}
		let ret1=StrideLengthCalc1(area,areadx1,areadx2,cutoff,x,xnext);
		let ret2=StrideLengthCalc2(area,areadx1,areadx2,cutoff,x,xnext);
		let xstop1=ret1[0],astop1=ret1[1];
		let xstop2=ret2[0],astop2=ret2[1];
		if (xstop2>=x+1 && Math.abs(xstop1-xstop2)===1) {
			xstop1=xstop2;
			astop1=area+areadx2+(xstop1-x)*areadx1;
			waste++;
		}
		if (!(xstop1===xstop2) || !((isNaN(astop1) && isNaN(astop2)) || astop1===astop2)) {
			console.log("test   :",test);
			console.log("calc 1 :",xstop1,astop1);
			console.log("calc 2 :",xstop2,astop2);
			console.log("dif    :",astop1-astop2);
			console.log("cutoff :",cutoff);
			console.log("area   :",area);
			console.log("areadx1:",areadx1);
			console.log("areadx2:",areadx2);
			console.log("x      :",x);
			console.log("xnext  :",xnext);
			return;
		}
	}
	console.log("waste:",waste);
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Strides


function GetRowLines8(l,p,iw,ih,amul) {
	// Error over 10,000,000 tests:
	// max dif : 3.143318e-14
	// sum dif : 1.333336e-14
	// max area: 1.0000000000000187
	// max dx1 : 1.0000000000000002
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pixels=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp;
	let end=l.end,sort=prow-iw,x=p-sort;
	l.end=-1;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	let fy=y0<ih?y0:ih;
	fy=fy>y?~~fy:y;
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	// Use y0x for large coordinate stability.
	let y0x=x0-y0*dxy+fy*dxy;
	y0-=fy;y1-=fy;
	let nx=y1>2?y0x+2*dxy:x1;
	if (y1>1) {y1=1;x1=y0x+dxy;}
	if (y0<0) {y0=0;x0=y0x;}
	// Subtract x after normalizing to row.
	x0-=x;x1-=x;nx-=x;
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>0 && dyx!==0)) {
		// Above or degenerate.
		sort=pixels;
	} else if (x0>=1 || fy>y) {
		// Below or to the left.
		nx=x0;
		sort=fy*iw;
	} else if (x1<=1) {
		// Vertical line or last pixel.
		tmp=x1>0?-(x1*x1/dx)*dy:0;
		if (end<p && end>=sort) {
			areadx1+=dyx;
			area+=((x1>0?(1-x1)*(1-x1):(1-2*x1))/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=0?0.5*(x0+x1)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<1?pixels:iw;
	} else {
		// Spanning 2+ pixels.
		tmp=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy;
		area-=tmp;
		if (x1>=2) {
			areadx1-=dyx;
			tmp=x0>0?(x0*x0/dx)*dy:0;
			l.end=p;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx+=x;
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pixels;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines10(l,p,iw,ih,amul) {
	// Current best.
	// Error over 10,000,000 tests:
	// max dif : 1.509282e-10
	// sum dif : 1.866119e-13
	// max area: 1.0000000001509282
	// max dx1 : 1.0000000000000002
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pmax=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// Calculate row and col.
	let sort=prow-iw,c0=p-sort,c1=c0+1;
	let r0=y0<ih?~~y0:ih;
	r0=y0>y?r0:y;
	let r1=r0+1,r2=r0+2;
	// Clamp y to row. Ensure consecutive rows use the same calculations.
	let dx=x1-x0,dy=y1-y0,nx=x1;
	if (dy>1) {
		// Large numbers.
		let dxy=dx/dy,y0x=x0-y0*dxy;
		if (y1>r2) {nx=y0x+r2*dxy;}
		if (y1>r1) {x1=y0x+r1*dxy;y1=r1;}
		if (y0<r0) {x0=y0x+r0*dxy;y0=r0;}
	} else {
		// Small numbers.
		if (y1>r2) {nx=x0-((y0-r2)/dy)*dx;}
		if (y1>r1) {x1=x0-((y0-r1)/dy)*dx;y1=r1;}
		if (y0<r0) {x0=x0-((y0-r0)/dy)*dx;y0=r0;}
	}
	/*
	let dx=x1-x0,dy=y1-y0;
	let cr=x0*y1-y0*x1;
	let nx=y1>r2?(cr+r2*dx)/dy:x1;
	if (y1>r1) {x1=(cr+r1*dx)/dy;y1=r1;}
	if (y0<r0) {x0=(cr+r0*dx)/dy;y0=r0;}
	*/
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	dy*=sign;let dyx=dy/dx;dy*=0.5;
	if (!(y1>r0 && dyx!==0)) {
		// Above or degenerate.
		sort=pmax;
	} else if (x0>=c1 || r0>y) {
		// Below or to the left.
		nx=x0;
		sort=r0*iw;
	} else if (x1<=c1) {
		// Vertical line or last pixel.
		let t0=x1-c0,t1=x1-c1;
		tmp=x1>c0?-(t0*t0/dx)*dy:0;
		if (c0>1 && x0<c0-1) {
			areadx1+=dyx;
			area+=((x1>c0?t1*t1:-t0-t1)/dx)*dy;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=c0?0.5*(x0-c0+t0)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<r1?pmax:iw;
	} else {
		// Spanning 2+ pixels.
		let t0=x0-c0,t1=x0-c1;
		tmp=((x0>c0?t1*t1:-t0-t1)/dx)*dy;
		area-=tmp;
		if (x1>=c0+2) {
			areadx1-=dyx;
			tmp=x0>c0?(t0*t0/dx)*dy:0;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pmax;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function GetRowLines11(l,p,iw,ih,amul) {
	// Fails for small exponents.
	// Error over 10,000,000 tests:
	// max dif : 3.650304e-14
	// sum dif : 1.759082e-14
	// max area: 1.0000000000000193
	// max dx1 : 1.0000000000000004
	// max dx2 : 1
	//
	// fx0  fx0+1                          fx1  fx1+1
	//  +-----+-----+-----+-----+-----+-----+-----+
	//  |                              .....----  |
	//  |               .....-----'''''           |
	//  | ....-----'''''                          |
	//  +-----+-----+-----+-----+-----+-----+-----+
	//   first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Orient upwards, then clip y to [0,1].
	let area=l.area,areadx1=l.areadx1,areadx2=l.areadx2;
	const pmax=iw*ih,y=Math.floor(p/iw),prow=y*iw+iw;
	// Start
	let x0=l.x0,y0=l.y0;
	let x1=l.x1,y1=l.y1;
	let sign=amul,tmp;
	if (y0>y1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// Calculate row and col.
	let sort=prow-iw,c0=p-sort,c1=c0+1;
	let r0=y0<ih?~~y0:ih;
	r0=y0>y?r0:y;
	let r1=r0+1,r2=r0+2;
	// Clamp y to row. Ensure consecutive rows use the same calculations.
	let dx=x1-x0,dy=y1-y0,dxy=dx/dy;
	let nx=y1>r2?x0-(y0-r2)*dxy:x1;
	if (y1>r1) {x1=x0-(y0-r1)*dxy;y1=r1;}
	if (y0<r0) {x0=x0-(y0-r0)*dxy;y0=r0;}
	nx=nx<x1?nx:x1;
	if (x0>x1) {dx=-dx;tmp=x0;x0=x1;x1=tmp;}
	let dyx=(dy/dx)*sign,dyh=dyx*0.5;
	if (!(y1>r0 && dyx!==0)) {
		// Above or degenerate.
		sort=pmax;
	} else if (x0>=c1 || r0>y) {
		// Below or to the left.
		nx=x0;
		sort=r0*iw;
	} else if (x1<=c1) {
		// Vertical line or last pixel.
		let t0=x1-c0,t1=x1-c1;
		tmp=t0>0?-t0*t0*dyh:0;
		if (c0>1 && x0<c0-1) {
			areadx1+=dyx;
			area+=(t0>0?t1*t1:-t0-t1)*dyh;
		} else {
			dy=(y0-y1)*sign;
			tmp=x0>=c0?0.5*(x0-c0+t0)*dy:tmp;
			area+=dy-tmp;
		}
		areadx2+=tmp;
		sort+=y1<r1?pmax:iw;
	} else {
		// Spanning 2+ pixels.
		let t0=x0-c0,t1=x0-c1;
		tmp=(t0>0?t1*t1:-t0-t1)*dyh;
		area-=tmp;
		if (x1>=c0+2) {
			areadx1-=dyx;
			tmp=t0>0?t0*t0*dyh:0;
		}
		areadx2+=tmp;
		nx=x1;
	}
	nx=nx<0?0:nx;
	sort+=nx<iw?~~nx:iw;
	sort=sort>p?sort:pmax;
	l.sort=sort;
	// End
	l.area=area;
	l.areadx1=areadx1;
	l.areadx2=areadx2;
}


function StrideClipTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area clipping");
	let rnd=new Random(3);
	const maxdim=64;
	const amul=0.7117;
	let maxdif=0,sumdif=0,sumbuf=0,sumden=0;
	let maxarea=0,maxdx1=0,maxdx2=0;
	let tests=10000000;
	function getrnd(dim) {
		// Try to align near integer boundaries to cause rounding errors.
		//let degen=rnd.mod(64);
		//if (degen<3) {return [NaN,-Infinity,Infinity][degen];}
		//let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		//let dev=rnd.gets()*Math.pow(2,-rnd.mod(2000));
		// FP64 can have +-1024 exponent.
		let type=rnd.mod(128);
		let dev=rnd.gets();
		if (type===0) {dev=0;}
		else if (type<64) {dev*=Math.pow(2,20-rnd.mod(40));}
		else              {dev*=Math.pow(2,20-rnd.mod(1200));}
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxdif);
		}
		// Setup the line.
		let imgw=rnd.mod(maxdim)+1;
		let imgh=rnd.mod(maxdim)+1;
		let pixels=imgw*imgh;
		let x0=getrnd(imgw);
		let y0=getrnd(imgh);
		let x1=getrnd(imgw);
		let y1=getrnd(imgh);
		//let p=rnd.mod(pixels);
		let p=rnd.mod(imgh)*imgw;
		//if (test!==6677903) {continue;}
		let minx=Math.floor(x0<x1?x0:x1);
		let maxx=Math.floor(x0>x1?x0:x1);
		let miny=Math.floor(y0<y1?y0:y1);
		let maxy=Math.floor(y0>y1?y0:y1);
		//console.log(minx,maxx,miny,maxy,imgw,imgh);
		let firstpix=Math.max(miny,0)*imgw+Math.min(Math.max(minx,0),imgw);
		let lastpix=Math.min(Math.max(maxy+1,0),imgh)*imgw+Math.min(Math.max(maxx,0),imgw);
		if (miny>=imgh) {
			firstpix=pixels;
			lastpix=pixels;
		}
		let line={sort:0,end:0xffffffff,row:-1,x0:x0,y0:y0,x1:x1,y1:y1,area:0,areadx1:0,areadx2:0};
		// Pick a starting pixel and compare every pixel after.
		let nextrow=-1;
		let proccnt=0;
		//let area=0,areadx1=0,areadx2=0;
		let linenext=-1;
		let firstproc=1;
		for (;p<pixels;p++) {
			if (p>=nextrow) {
				nextrow=Math.floor(p/imgw)*imgw+imgw;
				line.area=0;
				line.areadx1=0;
				line.areadx2=0;
				proccnt=-firstproc;
				firstproc=0;
				/*if (line.end!==0xffffffff) {
					console.log("new row end:",line.end);
					throw "error";
				}*/
			}
			// Process the start or end of the line.
			if (p>=linenext) {
				GetRowLines10(line,p,imgw,imgh,amul);
				linenext=line.sort;
				proccnt++;
			}
			// Compare with the reference.
			let x=p%imgw,y=Math.floor(p/imgw);
			let calc=GetRowRef(line,p,imgw,amul);
			//console.log("test:",test,line.area,calc);
			let dif=Math.abs(line.area-calc);
			sumbuf+=dif;
			sumden++;
			if (sumden>1000000) {
				sumdif+=sumbuf;
				sumbuf=0;
				sumden=0;
			}
			if (maxdif<dif || isNaN(dif)) {
				maxdif=dif;
				console.log("test:",test,dif);
			}
			maxarea=Math.max(maxarea,Math.abs(line.area));
			maxdx1 =Math.max(maxdx1 ,Math.abs(line.areadx1));
			maxdx2 =Math.max(maxdx2 ,Math.abs(line.areadx2));
			if (!(dif<1e-3)) {
				console.log("test:",test);
				console.log("area:",line.area,calc);
				console.log("img :",imgw,imgh);
				console.log("x y :",x,y,p);
				console.log("line:",line);
				throw "error";
			}
			line.area+=line.areadx1+line.areadx2;
			line.areadx2=0;
			// Check bounds.
			if (proccnt>3) {
				console.log("too many row procs",proccnt);
				throw "error";
			}
			if (p<firstpix && linenext+1<firstpix) {
				console.log("test:",test);
				console.log("dim :",imgw,imgh);
				console.log("first pixel:",p,pixels,firstpix,linenext);
				console.log("area:",GetRowRef(line,firstpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				console.log("line:",line);
				throw "error";
			}
			if (p>lastpix && linenext<pixels) {
				console.log("last pixel:",p,pixels,lastpix,linenext);
				console.log("area:",GetRowRef(line,lastpix,imgw,amul));
				console.log("area:",GetRowRef(line,linenext,imgw,amul));
				throw "error";
			}
			let sort=line.sort;
			if (sort!==(sort>>>0) || sort<p) {
				console.log("invalid sort:",sort,p);
				throw "error";
			}
			/*let end=line.end;
			if (end!==(end>>0)) {// || (end<pixels && end>=nextrow) || end<p) {
				console.log("invalid end:",end,p,pixels,nextrow);
				throw "error";
			}*/
		}
	}
	maxdif/=amul;
	sumdif=((sumdif+sumbuf)/tests)/amul;
	maxarea/=amul;
	maxdx1/=amul;
	maxdx2/=amul;
	console.log("max dif :",maxdif);
	console.log("sum dif :",sumdif);
	console.log("max area:",maxarea);
	console.log("max dx1 :",maxdx1);
	console.log("max dx2 :",maxdx2);
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	console.log("line clipping");
	SingleClipTest();
	//StrideLengthTest();
	//StrideClipTest();
	console.log("done");
}
TestMain();

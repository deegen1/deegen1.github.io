/*------------------------------------------------------------------------------


polytests.js - v1.09

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Check performance.txt for historical data.


--------------------------------------------------------------------------------
TODO


Firefox
rect: 0.737900
oval: 2.633480
line: 1.970780
char: 2.352520

Chrome
rect: 0.542815
oval: 2.068810
line: 1.412340
char: 1.978745


*/
/* npx eslint polytests.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Vector,Transform,Input} from "../library.js";


//---------------------------------------------------------------------------------
// Test 1 - Line Overlap Area Calculation


function UnitAreaApprox(x0,y0,x1,y1,samples) {
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let miny=Math.min(y0,y1),maxy=Math.max(y0,y1);
	let rate=(x1-x0)/(y1-y0);
	let con =x0-y0*rate;
	let prev=NaN;
	let area=0;
	for (let s=0;s<=samples;s++) {
		let u=s/samples;
		if (u>=miny && u<=maxy) {
			let x=u*rate+con;
			x=x>0?x:0;
			x=x<1?1-x:0;
			if (prev===prev) {area+=prev+x;}
			prev=x;
		}
	}
	area/=2*samples;
	return (y0>y1?area:-area);
}


function UnitAreaCalc1(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	if (Math.abs(y0-y1)<1e-10) {return 0;}
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let dxy=difx/dify;
	let dyx=Math.abs(difx)>1e-10?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	tmp=0.0;
	if (y0<0.0) {
		x0=y0x;
		y0=0.0;
	} else if (y0>1.0) {
		x0=y1x;
		y0=1.0;
	}
	if (y1<0.0) {
		x1=y0x;
		y1=0.0;
	} else if (y1>1.0) {
		x1=y1x;
		y1=1.0;
	}
	if (x0<0.0) {
		tmp+=y0-x0y;
		x0=0.0;
		y0=x0y;
	} else if (x0>1.0) {
		x0=1.0;
		y0=x1y;
	}
	if (x1<0.0) {
		tmp+=x0y-y1;
		x1=0.0;
		y1=x0y;
	} else if (x1>1.0) {
		x1=1.0;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp;
}


function UnitAreaCalc12(x0,y0,x1,y1) {
	// Calculate the area to the right of the line.
	// If y0<y1, the area is negative.
	let tmp=0;
	let sign=1;
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	let difx=x1-x0;
	let dify=y1-y0;
	if (dify<1e-9 || y0>=1 || y1<=0) {return 0;}
	let dxy=difx/dify;
	let dyx=difx>1e-9?dify/difx:0;
	let x0y=y0-x0*dyx;
	let x1y=x0y+dyx;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (x1<=0) {return (y0-y1)*sign;}
	if (x0>=1) {return 0;}
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function UnitAreaCalc(x0,y0,x1,y1,px,py) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	x0-=px;y0-=py;
	x1-=px;y1-=py;
	let tmp=0,sign=1;
	//if (!(Math.abs(y0)<Infinity && Math.abs(y1)<Infinity && x1-x0!==0)) {
	//	return 0;
	//}
	if (isNaN((y1-y0)/(x1-x0))) {return 0;}
	if (x0>x1) {
		sign=-sign;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	//if (x0>=Infinity || x1>=Infinity) {return 0;}
	if (y0>y1) {
		sign=-sign;
		y0=1-y0;
		y1=1-y1;
	}
	// If we're entirely outside the bounding box.
	if (!(y0<1 && y1>0 && x0<1 && x1===x1)) {return 0;}
	let iy0=y0>0?y0:0;
	let iy1=y1<1?y1:1;
	if (x1<=0) {return (iy0-iy1)*sign;}
	// Determine if [0,1] is entirely to the left/right of slope.
	let dx=x1-x0,dy=y1-y0;
	// x=x0+(y-y0)*dx/dy
	if ((1-x0)*dy<=(iy0-y0)*dx) {return 0;}
	if ((0-x0)*dy>=(iy1-y0)*dx) {return (iy0-iy1)*sign;}
	// Narrow-phase. Clip to unit box.
	let x0y=y0-dy*(x0/dx);
	let x1y=y0+dy*((1-x0)/dx);
	let y0x=x0-dx*(y0/dy);
	let y1x=x0+dx*((1-y0)/dy);
	if (y1>1) {
		x1=y1x;
		y1=1;
	}
	if (y0<0) {
		x0=y0x;
		y0=0;
	}
	/*if (x0<0 && x1>1) {
		return ((x0-0.5)/dx)*dy*sign;
	} else if (x0<0) {
		return ((x1*x1*0.5-x1+x0)/dx)*dy*sign;
	} else if (x1>1) {
		return -0.5*((1-x0)*(1-x0)/dx)*dy*sign;
	} else {
		return (y0-y1)*(2-x0-x1)*0.5*sign;
	}*/
	tmp=0;
	if (x0<0) {
		tmp=y0-x0y;
		x0=0;
		y0=x0y;
	}
	if (x1>1) {
		x1=1;
		y1=x1y;
	}
	tmp+=(y0-y1)*(2-x0-x1)*0.5;
	return tmp*sign;
}


function UnitAreaCalc14(x0,y0,x1,y1,px,py) {
	// Calculate the area to the right of the line. Avoid divisions as much as
	// possible. If y0<y1, the area is negative.
	if (!(px===(px|0) && py===(py|0))) {
		throw `degenerate pixel coordinates: ${px}, ${py}`;
	}
	let sign=1;
	if (y0>y1) {
		sign=-1;
		let tmp=0;
		tmp=x0;x0=x1;x1=tmp;
		tmp=y0;y0=y1;y1=tmp;
	}
	// If we're outside the bounding box.
	let y0p=y0-py,y1p=y1-py;
	let x0p=x0-px,x1p=x1-px;
	if (y0p>=1 || y1p<=0 || (x0p>=1 && x1p>=1)) {return 0;}
	y0p=y0p>0?y0p:0;
	y1p=y1p<1?y1p:1;
	let areap=sign<0?(y1p-y0p):(y0p-y1p);
	if (x0p<=0 && x1p<=0) {return areap;}
	// Use arbitrary precision fractions.
	return NaN;
}


function UnitAreaTest() {
	// See if the area approximation matches the exact calculation.
	let tests=100000;
	let maxdif=0,avgdif=0;
	let rnd=new Random();
	function getrnd() {
		// Try to align near integer boundaries to cause rounding errors.
		let dev=rnd.mod(80)-40;
		return rnd.mod(20)-10+rnd.gets()*Math.pow(2,dev);
	}
	for (let test=0;test<tests;test++) {
		let x0=getrnd(),y0=getrnd();
		let x1=getrnd(),y1=getrnd();
		let px=rnd.mod(10)-5,py=rnd.mod(10)-5;
		let flag=rnd.getu32();
		if ((flag& 3)===0) {x1= x0;}
		if ((flag& 3)===1) {x1=-x0;}
		if ((flag&12)===0) {y1= y0;}
		if ((flag&12)===4) {y1=-y0;}
		//let area0=UnitAreaApprox(x0,y0,x1,y1,samples);
		let area0=UnitAreaCalc13(x0-px,y0-py,x1-px,y1-py);
		let area1=UnitAreaCalc(x0,y0,x1,y1,px,py);
		//if (isNaN(area1)) {continue;}
		let dif=Math.abs(area0-area1);
		if (maxdif<dif || !(dif===dif)) {maxdif=dif;}
		avgdif+=dif;
	}
	avgdif/=tests;
	console.log("max dif:",maxdif);
	console.log("avg dif:",avgdif);
}


//---------------------------------------------------------------------------------
// Cache Test


function getrowcache3(line,x,y,amul) {
	//
	//     fx0  fx0+1                          fx1  fx1+1
	//      +-----+-----+-----+-----+-----+-----+-----+
	//      |                              .....----  |
	//      |               .....-----'''''           |
	//      | ....-----'''''                          |
	//      +-----+-----+-----+-----+-----+-----+-----+
	//       first  dyx   dyx   dyx   dyx   dyx  last   tail
	//
	// Preprocess
	let x0=line.x0,y0=line.y0;
	let x1=line.x1,y1=line.y1;
	let tmp=0;
	let difx=x1-x0;
	let dify=y1-y0;
	let a0={area:0,areadx1:0,areadx2:0,areadx3:0,sort:0,next:Infinity};
	let a1={area:0,areadx1:0,areadx2:0,sort:Infinity};
	if (Math.abs(dify)<1e-9 || (y0<=y && y1<=y)) {return [a0,a1];}
	if (Math.abs(difx)<1e-9) {x1=x0;difx=0;}
	// let dyx=Math.abs(difx)>1e-10?dify/difx:dify;
	let dxy=difx/dify;
	if (y0>y1) {
		tmp=y0;y0=y1;y1=tmp;
		tmp=x0;x0=x1;x1=tmp;
		amul=-amul;
	}
	tmp=null;
	// Per row.
	let lx1=x1;
	y0-=y;
	y1-=y;
	let next=Infinity;
	let y0x=x0-y0*dxy;
	let y1x=y0x+dxy;
	if (y0<0) {y0=0;x0=y0x;}
	if (y1>1) {y1=1;x1=y1x;next=y1x;}
	if (x0>x1) {
		tmp=x0;x0=x1;x1=tmp;dxy=-dxy;
		next-=dxy;next=next>lx1?next:lx1;
	}
	a0.next=next;
	x=x0>x?Math.floor(x0):x;
	a0.sort=x;
	let dyx=amul/dxy,dyh=dyx*0.5;
	let fx1=Math.floor(x1);
	x0-=x;
	x1-=x>fx1?x:fx1;
	tmp=x1>0?-x1*x1*dyh:0;
	let flen=fx1-x;
	if (flen<=0) {
		// Vertical line - avoid divisions.
		let dy=(y0-y1)*amul;
		tmp=x0>=0?(x0+x1)*dy*0.5:tmp;
		a0.area+=dy-tmp;
		a0.areadx2+=tmp;
	} else if (flen===1) {
		let dy=(y0-y1)*amul;
		let tmp0=dyh-x0*dyx+(x0>0?x0*x0*dyh:0);
		a0.area+=-tmp0;
		a0.areadx2+=dy+tmp0-tmp;
		a0.areadx3+=tmp;
	} else {
		a1.area=dyh-x1*dyx-tmp;
		a1.areadx1=dyx;
		a1.areadx2=tmp;
		a1.sort=fx1;
		tmp=x0>0?x0*x0*dyh:0;
		a0.area-=dyh-x0*dyx+tmp;
		a0.areadx1-=dyx;
		a0.areadx2+=tmp;
	}
	return [a0,a1];
}


function AreaCacheTest() {
	// See if the area approximation matches the exact calculation.
	console.log("testing area cache-3");
	let rnd=new Random(1);
	let amul=0.7117;
	let tests=100000;
	let maxdif=0;
	for (let test=0;test<tests;test++) {
		let x0=rnd.getf()*200-50;
		let y0=rnd.getf()*200-50;
		let x1=rnd.getf()*200-50;
		let y1=rnd.getf()*200-50;
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(34);
			dev=dev>31?0:Math.pow(2,-dev);
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(34);
			dev=dev>31?0:Math.pow(2,-dev);
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		let minx=Math.floor(Math.min(x0,x1))-2;
		let maxx=Math.ceil( Math.max(x0,x1))+2;
		let miny=Math.floor(Math.min(y0,y1));
		let maxy=Math.ceil( Math.max(y0,y1))+2;
		let line={x0:x0,y0:y0,x1:x1,y1:y1};
		// console.log(test,x0,y0,x1,y1);
		for (let cy=miny;cy<maxy;cy++) {
			// Pick a random point on the row to start.
			let cx=rnd.mod(maxx-minx+1)+minx;
			let aobj=getrowcache3(line,cx,cy,amul);
			let a=aobj[0];
			let area=a.area,areadx1=a.areadx1,areadx2=a.areadx2,areadx3=a.areadx3;
			// Test current row start.
			cx=a.sort;
			if (Math.abs(y1-y0)>1e-9 && (cy<y0 || cy<y1) && (cy+1>y0 || cy+1>y1)) {
				let areac=UnitAreaCalc(x0-cx,y0-cy,x1-cx,y1-cy);
				if (Math.abs(areac)<1e-18) {throw "row 0: "+areac;}
			}
			// Test next row start prediction.
			let nx=a.next;
			if (nx<Infinity) {
				let areac=UnitAreaCalc(x0-nx,y0-cy-1,x1-nx,y1-cy-1);
				if (Math.abs(areac)<1e-9) {throw "next 0: "+areac;}
				areac=UnitAreaCalc(x0-(nx-1),y0-cy-1,x1-(nx-1),y1-cy-1);
				if (Math.abs(areac)>1e-9) {throw "next -1: "+areac;}
			} else if (cy+1<y0 || cy+1<y1) {
				throw "next y: "+cy+", "+y0+", "+y1;
			}
			// Test that the end of the row is really the end.
			a=aobj[1];
			let stop=a.sort<Infinity?Math.max(a.sort,cx):cx;
			let areac1=UnitAreaCalc(x0-(stop+2),y0-cy,x1-(stop+2),y1-cy);
			let areac2=UnitAreaCalc(x0-(stop+3),y0-cy,x1-(stop+3),y1-cy);
			if (Math.abs(areac1-areac2)>1e-9) {throw "tail 2: "+areac1+", "+areac2;}
			stop+=10;
			for (;cx<stop;cx++) {
				if (cx>=a.sort) {
					area+=a.area;
					areadx1+=a.areadx1;
					areadx2+=a.areadx2;
					a.sort=Infinity;
				}
				let areac=UnitAreaCalc(x0-cx,y0-cy,x1-cx,y1-cy)*amul;
				let dif=Math.abs(area-areac);
				if (maxdif<dif) {
					maxdif=dif;
					console.log(maxdif,areac,area);
				}
				area+=areadx1+areadx2;
				areadx2=areadx3;
				areadx3=0;
			}
		}
	}
	console.log("max dif: "+maxdif);
}


//---------------------------------------------------------------------------------
// Stride Test
// Calculate how many pixels can be filled with the same color.


function stridecalc1(x,xnext,area,areadx1,areadx2) {
	let base=Math.floor(area*255+0.5);
	base=Math.min(Math.max(base,0),255);
	while (x<xnext) {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
		let tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp,0),255);
		if (base!==tmp) {break;}
	}
	return x;
}


function stridecalc2(x,xnext,area,areadx1,areadx2) {
	let xdraw=x+1,tmp=0;
	if (areadx2===0) {
		tmp=Math.floor(area*255+0.5);
		tmp=Math.min(Math.max(tmp+(areadx1<0?-0.5:0.5),0.5),254.5);
		tmp=(tmp/255-area)/areadx1+x;
		xdraw=(tmp>x && tmp<xnext)?Math.ceil(tmp):xnext;
	}
	return xdraw;
}


function StrideTest() {
	console.log("testing stride calculation");
	let rnd=new Random();
	let tests=100000;
	let tmp=0;
	for (let test=0;test<tests;test++) {
		let x=rnd.mod(200)+100;
		let xnext=x+rnd.mod(100);
		let area=rnd.getf()*4-2;
		tmp=rnd.mod(31);
		tmp=tmp>16?0:(1/(1<<tmp));
		let areadx1=(rnd.getf()*4-2)*tmp;
		// tmp=rnd.mod(31);
		// tmp=tmp>16?0:(1/(1<<tmp));
		// let areadx2=(rnd.getf()*4-2)*tmp;
		let areadx2=0;
		let stride1=stridecalc1(x,xnext,area,areadx1,areadx2);
		let stride2=stridecalc2(x,xnext,area,areadx1,areadx2);
		if (stride1!==stride2) {
			console.log("bad stride: "+test);
			console.log(stride1+" != "+stride2);
			console.log("x    = "+x);
			console.log("next = "+xnext);
			console.log("area = "+area);
			console.log("dx1  = "+areadx1);
			console.log("dx2  = "+areadx2);
			return;
		}
	}
	console.log("passed");
}


function stridecalc20(area,areadx1,areadx2,cutoff,x,xnext) {
	let side=area>=cutoff;
	do {
		x++;
		area+=areadx1+areadx2;
		areadx2=0;
	} while ((area>=cutoff)===side && x<xnext);
	return [x,area];
}


function stridecalc21(area,areadx1,areadx2,cutoff,x,xnext) {
	// const cutoff=0.00390625;
	let astop=area+areadx1+areadx2;
	let xstop=x+1,xdif=xnext-xstop;
	// xdif=(xnext<xrow?xnext:xrow)-xstop;
	if (xdif>0 && (area>=cutoff)===(astop>=cutoff)) {
		let adif=(cutoff-astop)/areadx1+1;
		// xdif=(adif>=1 && adif<xdif)?Math.floor(adif):xdif;
		xdif=(adif>=1 && adif<xdif)?~~adif:xdif;
		astop+=xdif*areadx1;
		xstop+=xdif;
	}
	return [xstop,astop];
}


function StrideTest2() {
	// If area>cutoff, how long until area+areadx2<=cutoff.
	// If any value is NaN or infinity, guarantee progression.
	// Don't let xstop become NaN, negative, or infinite.
	//
	// if (area>=cutoff) {
	//      do {
	//           area+=areadx1+areadx2;
	//           areadx2=0;
	//      } while (++x<xstop);
	// }
	// x=xstop;
	// area=astop;
	//
	console.log("testing stride calculation");
	let rnd=new Random(33);
	function rndpow(min,max,special=false) {
		let flags=rnd.getu32();
		if (special) {
			let type=(flags>>>1)&63;
			if (type<4) {return 0;}
			else if (type<8) {return NaN;}
			else if (type<10) {return Infinity;}
			else if (type<12) {return -Infinity;}
		}
		let exp=rnd.getf()*(max-min)+min;
		let val=Math.pow(2,exp);
		return (flags&1)?val:-val;
	}
	for (let trial=0;trial<10000000;trial++) {
		let cutoff=rndpow(-20,4);
		let area=rndpow(-30,4,true)+cutoff;
		let areadx1=rndpow(-30,4,true);
		let areadx2=rndpow(-30,4,true);
		if ((rnd.getu32()&63)===0) {
			// Special case to force adif=1.
			areadx2=0;
			areadx1=cutoff-area;
		}
		let x=Math.round(rndpow(0,6));
		let xnext=x+Math.round(Math.abs(rndpow(0,8)));
		if (xnext<x+1) {xnext=x+1;}
		let [xstop0,astop0]=stridecalc20(area,areadx1,areadx2,cutoff,x,xnext);
		let [xstop1,astop1]=stridecalc21(area,areadx1,areadx2,cutoff,x,xnext);
		let eq=true;
		if (isNaN(astop0)!==isNaN(astop1)) {eq=false;}
		else if ((Math.abs(astop0)>=Infinity)!==(Math.abs(astop1)>=Infinity)) {eq=false;}
		else if (Math.abs(astop0-astop1)>1e-9) {eq=false;}
		if (xstop0!==xstop1 || !eq) {
			console.log("error "+trial);
			console.log("calc 0 :",xstop0,astop0);
			console.log("calc 1 :",xstop1,astop1);
			console.log("cutoff :",cutoff);
			console.log("area   :",area);
			console.log("areadx1:",areadx1);
			console.log("areadx2:",areadx2);
			console.log("x      :",x);
			console.log("xnext  :",xnext);
			return;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 2 - Fast Pixel Blending


function BlendTest1() {
	// expects alpha in [0,256], NOT [0,256).
	let samples=20000000*2;
	let arr0=new Uint32Array(samples);
	let i=0;
	for (i=0;i<samples;i+=2) {
		arr0[i+0]=(Math.random()*0x100000000)>>>0;
		arr0[i+1]=Math.floor(Math.random()*256.99);
	}
	let arr=new Uint32Array(samples);
	let arr8=new Uint8Array(arr.buffer);
	let src=(Math.random()*0x100000000)>>>0;
	let src3=(src>>>24)&0xff;
	let src2=(src>>>16)&0xff;
	let src1=(src>>> 8)&0xff;
	let src0=(src>>> 0)&0xff;
	let dst=0,a=0;
	let lh=0,hh=0,lh2=0,hh2=0;
	let hash=0,time=0,pos=0,hash0=-1;
	// ----------------------------------------
	arr.set(arr0);hash=1;
	let base=performance.now();
	for (i=0;i<samples;i+=2) {
		hash=arr[i+1];
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	base=performance.now()-base;
	console.log("baseline:",base,hash);
	console.log("Algorithm, Time, Accurate");
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(arr8[pos]*a+src0*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src1*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src2*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src3*(256-a))>>>8;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	hash0=hash;
	time=performance.now()-time-base;
	console.log("Naive RGB #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(((arr8[pos]-src0)*a)>>8)+src0;pos++;
		arr8[pos]=(((arr8[pos]-src1)*a)>>8)+src1;pos++;
		arr8[pos]=(((arr8[pos]-src2)*a)>>8)+src2;pos++;
		arr8[pos]=(((arr8[pos]-src3)*a)>>8)+src3;pos+=5;
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("Naive RGB #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src>>>8)&0x00ff00ff;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)*a+lh*(256-a))>>>8)&0x00ff00ff)+
		       ((((dst>>>8)&0x00ff00ff)*a+hh*(256-a))&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	lh2=lh<<8;
	hh=(src>>>8)&0x00ff00ff;
	hh2=hh<<8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((((dst&0x00ff00ff)-lh)*a+lh2)>>>8)&0x00ff00ff)+
		       (((((dst>>>8)&0x00ff00ff)-hh)*a+hh2)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #2",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=src&0xff00ff00;
	let d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)-lh)*a+lh)&0x00ff00ff)+
		       ((((dst&0xff00ff00)-hh)*a+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("32-bit #3",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	let mask0=0xff000000,mask1=0x00ff0000;
	let mask2=0x0000ff00,mask3=0x000000ff;
	let c0=src&mask0,c1=src&mask1;
	let c2=src&mask2,c3=src&mask3;
	d256=1.0/256.0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1]*d256;
		dst=arr[i];
		arr[i]=((((dst&mask0)-c0)*a+c0)&mask0)
		      |((((dst&mask1)-c1)*a+c1)&mask1)
		      |((((dst&mask2)-c2)*a+c2)&mask2)
		      |((((dst&mask3)-c3)*a+c3)&mask3);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("float #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=src&0x00ff00ff;
	hh=(src&0xff00ff00)>>>0;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)-hh)>>>8,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #1",time,hash===hash0);
	// ----------------------------------------
	arr.set(arr0);hash=1;pos=0;time=performance.now();
	lh=(src&0x00ff00ff)>>>0;
	hh=(src&0xff00ff00)>>>0;
	hh2=hh>>>8;
	for (i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)>>>8)-hh2,a)+hh)&0xff00ff00);
		hash=Math.imul(hash,0x1645a3d3)^arr[i];
	}
	time=performance.now()-time-base;
	console.log("imul #2",time,hash===hash0);
}


//---------------------------------------------------------------------------------
// Test 3 - Pixel compositing


let blend_rgbashift=[0,0,0,0];
(function (){
	let rgba  =new Uint8ClampedArray([0,1,2,3]);
	let rgba32=new Uint32Array(rgba.buffer);
	let col=rgba32[0];
	for (let i=0;i<32;i+=8) {blend_rgbashift[(col>>>i)&255]=i;}
})();
const [blend_r,blend_g,blend_b,blend_a]=blend_rgbashift;


function blendref(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0) {return dst;}
	sa/=255.0;
	let a=sa+(((dst>>>blend_a)&255)/255.0)*(1-sa);
	sa/=a;
	let da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast1(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	if (da===255) {
		sa/=255.0;
		da=1-sa;
		return ((255<<blend_a)|
			(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)|
			(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)|
			(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<blend_a)+
		(Math.max(Math.min(((src>>>blend_r)&255)*sa+((dst>>>blend_r)&255)*da,255),0)<<blend_r)+
		(Math.max(Math.min(((src>>>blend_g)&255)*sa+((dst>>>blend_g)&255)*da,255),0)<<blend_g)+
		(Math.max(Math.min(((src>>>blend_b)&255)*sa+((dst>>>blend_b)&255)*da,255),0)<<blend_b))>>>0;
}


function blendfast3(dst,src) {
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>blend_a)&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>blend_a)&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=255<<blend_a;
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<blend_a;
		src=(src&(~(255<<blend_a)))|da;
		dst=(dst&(~(255<<blend_a)))|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
}


const blendfast2=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	if (da===255) {
		//((imul((dst&0x00ff00ff)-coll,d)>>>8)+coll)&0x00ff00ff)+
		//((imul(((dst&0xff00ff00)>>>8)-colh2,d)+colh)&0xff00ff00);
		//return 0;
	}
	sa/=255.0;
	let a=sa+(da/255.0)*(1-sa);
	sa/=a;
	da=1-sa;
	return ((Math.max(Math.min(a*255.001,255),0)<<${blend_a})+
		(Math.max(Math.min(((src>>>${blend_r})&255)*sa+((dst>>>${blend_r})&255)*da,255),0)<<${blend_r})+
		(Math.max(Math.min(((src>>>${blend_g})&255)*sa+((dst>>>${blend_g})&255)*da,255),0)<<${blend_g})+
		(Math.max(Math.min(((src>>>${blend_b})&255)*sa+((dst>>>${blend_b})&255)*da,255),0)<<${blend_b}))>>> 0;
`.replace(/(>>>)0/g,""));


const blendfast4=new Function("dst","src",`
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	let sa=(src>>>${blend_a})&255;
	if (sa===0  ) {return dst;}
	if (sa===255) {return src;}
	let da=(dst>>>${blend_a})&255;
	if (da===0  ) {return src;}
	// Approximate blending by expanding sa from [0,255] to [0,256].
	if (da===255) {
		sa+=sa>>>7;
		src|=${(255<<blend_a)>>>0};
	} else {
		da=(sa+da)*255-sa*da;
		sa=Math.floor((sa*0xff00+(da>>>1))/da);
		da=Math.floor((da*0x00ff+0x7f00)/65025)<<${blend_a};
		src=(src&${(~(255<<blend_a)>>>0)})|da;
		dst=(dst&${(~(255<<blend_a)>>>0)})|da;
	}
	let l=dst&0x00ff00ff,h=dst&0xff00ff00;
	return ((((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&0x00ff00ff)+
		  ((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&0xff00ff00))>>>0;
`);


/* Inline blending

// Setup
let sa,sa0,sa1,sai,da,dst;
let ashift=this.rgbashift[3],amask=(255<<ashift)>>>0,namask=(~amask)>>>0;
let colrgba=this.rgba32[0]|amask,alpha=this.rgba[3]/255.0;
let coll=colrgba&0x00ff00ff,colh=colrgba&0xff00ff00,colh8=colh>>>8;

// Execution
sa0=Math.min(area,1)*alpha;
if (sa0>=0.999) {
	while (pixcol<pixstop) {
		imgdata[pixcol++]=colrgba;
	}
} else if (sa0>=1/256.0) {
	// Inlining blending is twice as fast as a blend() function.
	sai=(1-sa0)/255.0;
	sa1=256-Math.floor(sa0*256);
	while (pixcol<pixstop) {
		// Approximate blending by expanding sa from [0,255] to [0,256].
		dst=imgdata[pixcol];
		da=(dst>>>ashift)&255;
		if (da===0) {
			imgdata[pixcol++]=0xffffffff;
			continue;
		} else if (da===255) {
			sa=sa1;
		} else if (da<255) {
			da=sa0+da*sai;
			sa=256-Math.floor(Math.min(sa0/da,1)*256);
			da=Math.floor(da*255+0.5);
		}
		imgdata[pixcol++]=((
			(((Math.imul((dst&0x00ff00ff)-coll,sa)>>>8)+coll)&0x00ff00ff)+
			((Math.imul(((dst>>>8)&0x00ff00ff)-colh8,sa)+colh)&0xff00ff00)
			)&namask)|(da<<ashift);
	}
}
*/

function BlendTest2() {
	// https://en.wikipedia.org/wiki/Alpha_compositing
	// src drawn on dst
	// a = sa + da*(1-sa)
	// c = (sc*sa + dc*da*(1-sa)) / a
	// c = (sc - dc)*(sa/a) + dc
	console.log("testing blending 3");
	let am=255<<blend_a,nm=(~am)>>>0;
	let count=0;
	for (let test=0;test<1000000;test++) {
		let src=Math.floor(Math.random()*0x100000000);
		let dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		dst>>>=0;
		src>>>=0;
		let ref=blendref(dst,src);
		let calc=blendfast4(dst,src);
		let dif0=Math.abs(((ref>>>0)&255)-((calc>>>0)&255));
		let dif1=Math.abs(((ref>>>8)&255)-((calc>>>8)&255));
		let dif2=Math.abs(((ref>>>16)&255)-((calc>>>16)&255));
		let dif3=Math.abs(((ref>>>24)&255)-((calc>>>24)&255));
		count+=dif0+dif1+dif2+dif3;
		if (dif0>1 || dif1>1 || dif2>1 || dif3>1) {
			console.log("error");
			console.log(src,dst);
			console.log(ref.toString(16),calc.toString(16));
			return;
		}
	}
	console.log("sum: "+count);
	console.log("passed");
	let sum=0,dst=0,src=0;
	let t0=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendref(dst,src);
	}
	t0=performance.now()-t0;
	let t1=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast3(dst,src);
	}
	t1=performance.now()-t1;
	let t2=performance.now();
	for (let test=0;test<10000000;test++) {
		src=Math.floor(Math.random()*0x100000000);
		dst=Math.floor(Math.random()*0x100000000);
		if ((test& 3)===0) {src=(src&nm)>>>0;}
		if ((test& 3)===1) {src=(src|am)>>>0;}
		if ((test&12)===0) {dst=(dst&nm)>>>0;}
		if ((test&12)===8) {dst=(dst|am)>>>0;}
		sum^=blendfast4(dst,src);
	}
	t2=performance.now()-t2;
	console.log(sum);
	console.log(t0);
	console.log(t1);
	console.log(t2);
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Test 3 - Bezier parameterization


function BezierParam0(points,u) {
	let v=1-u;
	let cpx=v*v*v*points[0]+3*v*v*u*points[2]+3*v*u*u*points[4]+u*u*u*points[6];
	let cpy=v*v*v*points[1]+3*v*v*u*points[3]+3*v*u*u*points[5]+u*u*u*points[7];
	return [cpx,cpy];
}


function BezierParam1(points,u1) {
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let cpx=p0x+u1*(p1x+u1*(p2x+u1*p3x));
	let cpy=p0y+u1*(p1y+u1*(p2y+u1*p3y));
	return [cpx,cpy];
}


function BezierClosest(curve,point) {
	// Returns the closest u in [0,1] to the point.
	let p0x=curve[0],p0y=curve[1];
	let p1x=curve[2],p1y=curve[3];
	let p2x=curve[4],p2y=curve[5];
	let p3x=curve[6],p3y=curve[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	p0x-=point[0];p0y-=point[1];
	let segs=2048;
	let range=0.5;
	let minu=0.5,mindist=Infinity;
	while (range>1e-10) {
		let mid=minu,sden=2/(segs-1);
		for (let s=0;s<segs;s++) {
			let u=mid+range*(s*sden-1);
			u=u>0?(u<1?u:1):0;
			let dx=p0x+u*(p1x+u*(p2x+u*p3x));
			let dy=p0y+u*(p1y+u*(p2y+u*p3y));
			let dist=dx*dx+dy*dy;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
		}
		segs>>>=1;
		segs=segs>4?segs:4;
		range*=0.5;
	}
	return minu;
}


function BezierParamTest() {
	console.log("testing bezier parameterization");
	let tests=10000;
	let rnd=new Random();
	let curve=new Float64Array(8);
	let pointerr=0;
	let paramerr=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=rnd.gets()*5;
		}
		let u=rnd.getf();
		let [x0,y0]=BezierParam0(curve,u);
		let [x1,y1]=BezierParam1(curve,u);
		let dx=x1-x0,dy=y1-y0;
		let err=dx*dx+dy*dy;
		if (pointerr<err || !(err===err)) {
			pointerr=err;
		}
		let v=BezierClosest(curve,[x0,y0]);
		let [x2,y2]=BezierParam1(curve,v);
		dx=x2-x0;dy=y2-y0;
		err=dx*dx+dy*dy;
		if (paramerr<err || !(err===err)) {
			paramerr=err;
		}
	}
	console.log("point err: "+pointerr.toFixed(9));
	console.log("param err: "+paramerr.toFixed(9));
}


//---------------------------------------------------------------------------------
// Bezier Length


function BezierLength0(points) {
	// "Accurate" length calculation.
	let p0x=points[0],p0y=points[1];
	let p1x=points[2],p1y=points[3];
	let p2x=points[4],p2y=points[5];
	let p3x=points[6],p3y=points[7];
	p2x=(p2x-p1x)*3;p1x=(p1x-p0x)*3;p3x-=p0x+p2x;p2x-=p1x;
	p2y=(p2y-p1y)*3;p1y=(p1y-p0y)*3;p3y-=p0y+p2y;p2y-=p1y;
	let segs=1000;
	let lx=p0x,ly=p0y,dist=0;
	for (let s=1;s<=segs;s++) {
		let u=s/segs;
		let mx=p0x+u*(p1x+u*(p2x+u*p3x));
		let my=p0y+u*(p1y+u*(p2y+u*p3y));
		let dx=mx-lx,dy=my-ly;
		dist+=Math.sqrt(dx*dx+dy*dy);
		lx=mx;
		ly=my;
	}
	return dist;
}


function BezierLength1(points) {
	// approximate length calculation.
	let p0x=points[0],p0y=points[1];
	let c1x=points[2],c1y=points[3];
	let c2x=points[4],c2y=points[5];
	let c3x=points[6],c3y=points[7];
	let dx=0,dy=0,dist=0;
	dx=c1x-p0x;dy=c1y-p0y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	return dist*0.5;
}


function BezierLengthTest() {
	console.log("testing bezier length approximation");
	let rnd=new Random(10);
	let curve=new Array(8);
	let tests=100;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		for (let i=0;i<8;i++) {
			curve[i]=(rnd.getf()*2-1)*100;
		}
		let dist0=BezierLength0(curve);
		let dist1=BezierLength1(curve);
		let dif=Math.abs(dist0-dist1)/dist1;
		sumdif+=dif;
		console.log(dist0,dist1,dif);
	}
	console.log("dif: "+sumdif.toFixed(6));
}


//---------------------------------------------------------------------------------
// Area


function PathArea1(path) {
	let draw=new Draw(0,0);
	const curvemaxdist2=0.00001;
	let varr=path.vertarr;
	let vidx=path.vertidx;
	if (vidx<2) {return 0;}
	let lr=draw.tmpline,lrcnt=lr.length,lcnt=0;
	let movex=0,movey=0;
	let p2x=0,p2y=0,p3x=0,p3y=0;
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		let type=v.type;
		let p0x=p3x,p0y=p3y;
		p3x=v.x;
		p3y=v.y;
		let p1x=p3x,p1y=p3y;
		// Add a basic line.
		if (lrcnt<=lcnt) {
			draw.fillextend();
			lrcnt=lr.length;
		}
		let l=lr[lcnt++];
		if (type!==Draw.Path.CURVE) {
			if (type===Draw.Path.MOVE) {
				// Close any unclosed subpaths.
				p1x=movex;movex=p3x;
				p1y=movey;movey=p3y;
			}
			l.sort=0;
			l.x0=p0x;l.y0=p0y;
			l.x1=p1x;l.y1=p1y;
			if (p1x===p0x && p1y===p0y) {lcnt--;}
			continue;
		}
		// Linear decomposition of curves.
		v=varr[++i];p2x=v.x;p2y=v.y;
		v=varr[++i];p3x=v.x;p3y=v.y;
		let next=-1,next0=0;
		while (true) {
			// The curve will stay inside the bounding box of [p0,p1,p2,p3].
			// If the subcurve is outside the image, stop subdividing.
			if (next===next0) {
				l.sort=0;
				l.x0=p0x;l.y0=p0y;
				l.x1=p3x;l.y1=p3y;
				if (next<0) {break;}
				l=lr[next];
				next=l.sort;
				p0x=p3x;p1x=l.x0;p2x=l.x1;p3x=l.x2;
				p0y=p3y;p1y=l.y0;p2y=l.y1;p3y=l.y2;
			}
			next0=next;
			// Test if both control points are close to the line p0->p3.
			// Clamp to ends and filter degenerates.
			let dx=p3x-p0x,dy=p3y-p0y,den=dx*dx+dy*dy;
			let lx=p1x-p0x,ly=p1y-p0y;
			let u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d1=lx*lx+ly*ly;
			lx=p2x-p0x;ly=p2y-p0y;
			u=dx*lx+dy*ly;
			u=u>0?(u<den?u/den:1):0;
			lx-=dx*u;ly-=dy*u;
			let d2=lx*lx+ly*ly;
			d1=(d1>d2 || !(d1===d1))?d1:d2;
			if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
			// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
			if (lrcnt<=lcnt) {
				draw.fillextend();
				lrcnt=lr.length;
			}
			let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
			let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
			let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
			let n=lr[lcnt];
			n.sort=next;
			n.x0=r1x;n.x1=r2x;n.x2=p3x;
			n.y0=r1y;n.y1=r2y;n.y2=p3y;
			p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
			p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
			p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
			next=lcnt++;
		}
	}
	// Calculate the area.
	let area=0;
	for (let i=0;i<lcnt;i++) {
		let l=lr[i];
		area+=l.x0*l.y1-l.x1*l.y0;
	}
	return area*0.5;
}


function PathArea(path) {
	// Use closed form area for curve.
	let varr=path.vertarr;
	let vidx=path.vertidx;
	if (vidx<2) {return 0;}
	let movex=0,movey=0,p0x=NaN,p0y=NaN,p1x=0,p1y=0;
	let area=0;
	for (let i=0;i<=vidx;i++) {
		let v=varr[i<vidx?i:0];
		if (v.type===Draw.Path.CURVE) {v=varr[i+2];}
		p0x=p1x;p1x=v.x;
		p0y=p1y;p1y=v.y;
		// Add a basic line.
		let l={};
		l.x0=p0x;
		l.y0=p0y;
		l.x1=p1x;
		l.y1=p1y;
		if (v.type===Draw.Path.MOVE) {
			// Close any unclosed subpaths.
			l.x1=movex;movex=p1x;
			l.y1=movey;movey=p1y;
		}
		area+=p0x*l.y1-l.x1*p0y;
		if (v.type!==Draw.Path.CURVE) {continue;}
		// Linear decomposition of curves.
		v=varr[i++];let n1x=v.x,n1y=v.y;
		v=varr[i++];let n2x=v.x,n2y=v.y;
		area-=((n1x-p0x)*(2*p0y-n2y-p1y)+(n2x-p0x)*(p0y+n1y-2*p1y)
		      +(p1x-p0x)*(2*n2y+n1y-3*p0y))*0.3;
	}
	return area*0.5;
}


function PathAreaTest() {
	console.log("testing path area calculation");
	let rnd=new Random(10);
	let sumerr=0;
	let tests=1000;
	for (let test=0;test<tests;test++) {
		let path=new Draw.Path();
		let segs=rnd.mod(32);
		for (let s=0;s<segs;s++) {
			let type=rnd.mod(4);
			let x0=rnd.gets()*100,y0=rnd.gets()*100;
			if (type===0) {path.moveto(x0,y0);}
			else if (type===1) {path.lineto(x0,y0);}
			else if (type===2) {path.close();}
			else {
				let x1=rnd.gets()*100,y1=rnd.gets()*100;
				let x2=rnd.gets()*100,y2=rnd.gets()*100;
				path.curveto(x1,y1,x2,y2,x0,y0);
			}
		}
		if (path.vertidx>0 && path.vertarr[0].type!==Draw.Path.MOVE) {
			console.log("first type isn't move");
			throw "error";
		}
		let area1=PathArea1(path);
		//let area2=PathArea(path);
		//let area2=path.calcarea();
		let area2=path.area*0.5;
		let err=Math.abs(area1-area2)/Math.max(Math.abs(area1),Math.abs(area2),1e-10);
		console.log(path.vertidx,area1,area2);
		sumerr+=err;
	}
	sumerr/=tests;
	console.log("rel err: "+sumerr.toFixed(9));
}


//---------------------------------------------------------------------------------
// Heap sorting


function HeapSortTest() {
	console.log("Testing heap");
	let rnd=new Random();
	for (let test=0;test<200;test++) {
		let alloc=rnd.mod(2000);
		// Build heap.
		let maxval=100000;
		let idused=new Uint32Array(alloc);
		let lr=new Array(alloc),lcnt=0;
		let swaps=0;
		for (let i=0;i<alloc;i++) {
			let l={};
			l.id=i;
			lr[i]=l;
			l.sort=-Infinity;
			if (rnd.mod(4)===0) {continue;}
			l.sort=rnd.mod(maxval*2);
			/*let j=lcnt++;
			lr[i]=lr[j];
			let p,lp;
			while (j>0 && l.sort<(lp=lr[p=(j-1)>>1]).sort) {
				swaps++;
				lr[j]=lp;
				j=p;
			}
			lr[j]=l;*/
			lr[i]=lr[lcnt];
			lr[lcnt++]=l;
		}
		for (let i=(lcnt>>1)-1;i>=0;i--) {
			let l=lr[i],s=l.sort,p=i,j=0;
			while ((j=p+p+1)<lcnt) {
				swaps++;
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=s) {break;}
				lr[p]=lr[j];
				p=j;
			}
			lr[p]=l;
		}
		console.log("swap:",swaps,lcnt);
		while (true) {
			// Test heap properties.
			idused.fill(1);
			let cnt=0;
			for (let i=0;i<alloc;i++) {
				let l=lr[i],id=l.id;
				cnt+=idused[id];
				idused[id]=0;
				if (i>0 && i<lcnt) {
					let p=(i-1)>>1,lp=lr[p];
					if (lp.sort>l.sort) {
						throw "not sorted: "+lp.sort+", "+l.sort;
					}
				}
			}
			if (cnt!==alloc) {
				throw "object missing: "+cnt+" / "+alloc;
			}
			if (lcnt===0 || lr[0].sort>=maxval) {break;}
			// Modify top value.
			let l=lr[0];
			let type=rnd.mod(4);
			let mod=[1,2,100,maxval-l.sort+10][type];
			l.sort+=rnd.mod(mod);
			// Heap sort down.
			let i=0,j=0;
			while ((j=i+i+1)<lcnt) {
				if (j+1<lcnt && lr[j+1].sort<lr[j].sort) {j++;}
				if (lr[j].sort>=l.sort) {break;}
				lr[i]=lr[j];
				i=j;
			}
			lr[i]=l;
		}
	}
	console.log("passed");
}


//---------------------------------------------------------------------------------
// Filling Accuracy


function FillDisplayTest() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=100;
	canv.height=100;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	//let input=new Input(canv);
	let draw=new Draw(100,100);
	draw.screencanvas(canv);
	draw.fill(0,0,0,255);
	draw.setcolor(255,255,255,255);
	let x=50,y=50;
	let ang=-Math.PI*0.5,amul=-Math.PI*2*0.437600;
	let poly=new Draw.Path();
	poly.lineto(Math.cos(ang)*20+x,Math.sin(ang)*20+y);ang+=amul;
	poly.lineto(Math.cos(ang)*20+x,Math.sin(ang)*20+y);
	poly.lineto(Math.cos(ang)*26+x,Math.sin(ang)*26+y);ang-=amul;
	poly.lineto(Math.cos(ang)*26+x,Math.sin(ang)*26+y);
	draw.setcolor(255,255,255,255);
	draw.fillpoly(poly);
	draw.screenflip();
}


function FillAccuracyTest() {
	// Create a simple polygon and test fillpoly against a reference.
	//
	// pixel errors:
	// 0 : 1014632711
	// 1 : 10176815
	// 2+: 3003
	// overdraw: 65577839
	console.log("testing path fill");
	const maxdim=64,maxpixels4=maxdim*maxdim*4;
	const tests=1000000;
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	let img=draw.img;
	let data=img.data8;
	let orig=new Uint8Array(data.length);
	let rnd=new Random(1);
	function rndexp(dim) {
		// Try to align near integer boundaries to cause overflows.
		let dev=rnd.gets()*Math.pow(2,-rnd.mod(60));
		return rnd.mod(dim*2+1)-((dim*3)>>>2)+dev;
	}
	draw.setcolor(0xffffffff);
	// Add metrics
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpath.toString();
	func=func.replace("if (area>=cutoff) {","this.pixcnt++;\nif (area>=cutoff) {");
	func=func.replace("} while (++p<pstop);","this.pixcnt++;\n} while (++p<pstop);");
	window.DrawPath=Draw.Path;
	window.Draw=Draw;
	//window.Transform=Transform;
	draw.pixcnt=0;
	Draw.prototype.fillpath=parsefunction(func);
	let overdraw=0;
	let pixerr=[0,0,0];
	for (let test=0;test<tests;test++) {
		if ((test%1000)===0) {
			console.log("test:",test,pixerr.toString());
		}
		// Create the image.
		let imgw=rnd.mod(maxdim+1),imgh=rnd.mod(maxdim+1);
		let pixels=imgw*imgh,pixels4=pixels*4;
		//console.log(imgw,imgh);
		img.width=imgw;
		img.height=imgh;
		for (let i=0;i<pixels4;i++) {data[i]=(i&3)<3?0:255;}
		orig.set(data);
		// Create the path.
		let lines=rnd.mod(5)+2;
		let path=new Draw.Path();
		for (let i=0;i<lines;i++) {
			path.lineto(rndexp(imgw),rndexp(imgh));
		}
		//path.close();
		let varr=path.vertarr;
		//let move=varr[0];
		//path.lineto(move.x,move.y);
		//lines++;
		let area=PathArea(path);
		area=area<0?-255.5:255.5;
		// Fill and compare.
		draw.pixcnt=0;
		draw.fillpath(path);
		let cnt=0;
		for (let i=0;i<pixels4;i+=4) {
			let p=i>>>2,x=p%imgw,y=~~(p/imgw);
			let r=data[i+0],g=data[i+1],b=data[i+2],a=data[i+3];
			if (r!==g || r!==b || a!==255) {
				console.log(r,g,b,a);
				throw "pixel not monochrome";
			}
			let fill=0;
			for (let j=0;j<lines;j++) {
				let u=varr[j],v=varr[(j+1)%lines];
				fill+=UnitAreaCalc(u.x,u.y,v.x,v.y,x,y);
			}
			let col=Math.floor(fill*area);
			col=col>0  ?col:0  ;
			col=col<255?col:255;
			cnt+=col>0;
			let dif=Math.abs(col-r);
			dif=dif<2?dif:2;
			pixerr[dif]++;
		}
		overdraw+=draw.pixcnt-cnt;
		for (let i=pixels4;i<maxpixels4;i++) {
			if (data[i]!==orig[i]) {
				let p=i>>>2,x=p%imgw,y=~~(p/imgw);
				console.log(imgw,imgh,x,y);
				throw "overflow";
			}
		}
	}
	console.log(`pixel errors:\n0 : ${pixerr[0]}\n1 : ${pixerr[1]}\n2+: ${pixerr[2]}`);
	console.log("overdraw:",overdraw);
}


function FillCrashTest() {
	// Try and crash fillpath() with absurd values.
	console.log("testing path crashing");
	const maxdim=1024;
	const maxsegs=128;
	const tests=1000000;
	let rnd=new Random(1);
	function rndexp() {
		let degen=rnd.mod(512);
		if (degen<3) {return [NaN,Infinity,-Infinity][degen];}
		let mul=rnd.mod(8)?maxdim:Math.pow(2,rnd.gets()*1200);
		//let mul=rnd.mod(8)?maxdim:Math.pow(2,rnd.gets()*12);
		return rnd.gets()*mul;
	}
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	let img=draw.img;
	draw.setcolor(0xffffffff);
	let maxlines=0;
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxlines);
		}
		img.width=rnd.mod(maxdim+1);
		img.height=rnd.mod(maxdim+1);
		// Create the path.
		let segs=rnd.mod(maxsegs+1);
		let path=new Draw.Path();
		for (let i=0;i<segs;i++) {
			let type=rnd.mod(8);
			if (type<1 || !i) {
				path.moveto(rndexp(),rndexp());
			} else if (type<2) {
				path.close();
			} else if (type<4) {
				path.lineto(rndexp(),rndexp());
			} else if (type<6) {
				path.curveto(rndexp(),rndexp(),rndexp(),
			                  rndexp(),rndexp(),rndexp());
			}
		}
		//if (test!==1981) {continue;}
		//console.log(path.tostring());
		if (path.vertidx>0 && path.vertarr[0].type!==Draw.Path.MOVE) {
			console.log("first type not moveto");
			throw "error";
		}
		draw.fillpath(path);
		let lines=draw.tmpline.length;
		if (maxlines<lines) {
			maxlines=lines;
			console.log("max line:",maxlines);
		}
	}
}


//---------------------------------------------------------------------------------
// Stress Tests


function RectStressTest() {
	// console.log("testing ovals");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.fillrect(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("rect: "+time.toFixed(6));
	// console.log("done");
}


function OvalStressTest() {
	// console.log("testing ovals");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.filloval(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("oval: "+time.toFixed(6));
	// console.log("done");
}


function LineStressTest() {
	// console.log("testing lines");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=200000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x0=(rnd.getf()*3-1)*imgwidth;
		let y0=(rnd.getf()*3-1)*imgheight;
		let x1=(rnd.getf()*3-1)*imgwidth;
		let y1=(rnd.getf()*3-1)*imgheight;
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		draw.linewidth=rnd.getf()*10;
		draw.drawline(x0,y0,x1,y1);
	}
	time=(performance.now()-time)/1000;
	console.log("line: "+time.toFixed(6));
	// console.log("done");
}


function CharStressTest() {
	// console.log("testing characters");
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=2000000;
	let text=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~█";
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		let c=text[test%text.length];
		let s=rnd.getf()*32;
		draw.filltext(x,y,c,s);
	}
	time=(performance.now()-time)/1000;
	console.log("char: "+time.toFixed(6));
	// console.log("done");
}


function ImageStressTest() {
	let rnd=new Random(10);
	let draw=new Draw();
	let images=10;
	let imgarr=new Array(images);
	draw.setcolor(0,0,0,255);
	let amask=draw.rgba32[0],nmask=(~amask)>>>0;
	for (let i=0;i<images;i++) {
		let w=i>0?Math.floor(Math.pow(2,i*1.10)+1):0;
		let h=i>0?Math.floor(Math.pow(2,i*1.13)+1):0;
		let img=new Draw.Image(w,h);
		imgarr[i]=img;
		let data32=img.data32,datalen=data32.length,col=0;
		for (let j=0;j<datalen;j++) {
			col=rnd.getu32();
			switch (rnd.mod(4)) {
				case 0: col&=nmask; break;
				case 1: col|=amask; break;
				default: break;
			}
			data32[j]=col;
		}
	}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dstimg=imgarr[rnd.mod(images)];
		let srcimg=imgarr[rnd.mod(images)];
		draw.setimage(dstimg);
		draw.rgba32[0]=rnd.getu32();
		//let w=rnd.mod(srcimg.width*2+1);
		//let h=rnd.mod(srcimg.height*2+1);
		let x=(rnd.getf()*3-1)*dstimg.width;
		let y=(rnd.getf()*3-1)*dstimg.height;
		draw.drawimage(srcimg,x,y);//,w,h);
	}
	time=(performance.now()-time)/1000;
	console.log("image: "+time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	/*if (Draw.wasmloading===0) {
		setTimeout(TestMain,1);
		console.log("loading wasm");
		return;
	}*/
	console.log("starting polygon tests");
	//UnitAreaTest();
	//AreaClipTest();
	//AreaCacheTest();
	//BlendTest1();
	//BlendTest2();
	//BezierParamTest();
	//BezierLengthTest();
	//PathAreaTest();
	//HeapSortTest();
	//FillDisplayTest();
	//FillAccuracyTest();
	//FillCrashTest();
	RectStressTest();
	OvalStressTest();
	LineStressTest();
	CharStressTest();
	//ImageStressTest();
	console.log("done");
}
//TestMain();

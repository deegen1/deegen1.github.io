"""-----------------------------------------------------------------------------


lerp.py - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Test the accuracy of different floating point interpolation methods.

Given a line (x0,y0) (x1,y1) and a point x, find y.
y=y0+((x-x0)/(x1-x0))*(y1-y0)

If x0,x1,y0,y1 are NaN, the output should be NaN. Otherwise, always output in
bounds of [y0,y1], even if x=NaN.

If x is outside of [x0,x1], then y=[y0,y1] for x closest to [x0,x1].
If x0=x1 and x<=x0, y=min(y0,y1).
If x0=x1 and x> x0, y=max(y0,y1).
if x=nan, assume x=-inf


The different forms of y(x)
	y=y0+((x-x0)/dx)*dy
	y=y0+((x-x0)*dy)/dx
	y=y0+(x-x0)*(dy/dx)
	y=y0+x*(dy/dx)-(x0/dx)*dy
	y=y0+x*(dy/dx)-x0*(dy/dx)
	y=y0+(x/dx)*dy-x0*(dy/dx)
	y=y0+(x/dx)*dy-(x0/dx)*dy
	y=y0-(x0/dx)*dy+x*(dy/dx)
	y=y0-x0*(dy/dx)+x*(dy/dx)
	y=y0-x0*(dy/dx)+(x/dx)*dy
	y=y0-(x0/dx)*dy+(x/dx)*dy


"""

import random,math
import mpmath as mp
mp.mp.prec=2048


def LerpRef(x,x0,x1,y0,y1):
	# Use MP to interpolate
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return mp.mpf("nan")
	if x0>x1 or (x0==x1 and y0>y1):
		x0,x1=x1,x0
		y0,y1=y1,y0
	x =mp.mpf(x )
	x0=mp.mpf(x0)
	y0=mp.mpf(y0)
	x1=mp.mpf(x1)
	y1=mp.mpf(y1)
	if x<=x0 or y0==y1 or not (x==x): return y0
	elif not (x<x1): return y1
	dx=x1-x0
	u=x-x0
	v=x-x1
	if mp.fabs(u)<mp.fabs(v):
		t=u/dx
		y=(1-t)*y0+t*y1
	else:
		t=v/dx
		y=(1+t)*y1-t*y0
	if y0>y1: y0,y1=y1,y0
	y=y if y>y0 else y0
	y=y if y<y1 else y1
	return y


def Lerp1(x,x0,x1,y0,y1):
	# Rank: 88.54%
	# Bisection.
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if x0>x1:
		x0,x1=x1,x0
		y0,y1=y1,y0
	lo,hi=-0.01,1.01
	for i in range(64):
		u=(lo+hi)*0.5
		z=u*x0+(1-u)*x1
		if z>x: lo=u
		else  : hi=u
	y=u*y0+(1-u)*y1
	if y0>y1: y0,y1=y1,y0
	y=y if y>y0 else y0
	y=y if y<y1 else y1
	return y


def Lerp2(x,x0,x1,y0,y1):
	# Rank: 89.47%
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if y0==y1:
		return y0
	dx=x1-x0
	dy=y1-y0
	if dx!=0:
		y=y0+((x-x0)/dx)*dy
	else:
		y=y0 if y0<y1 else y1
	if y0>y1: y0,y1=y1,y0
	y=y if y>y0 else y0
	y=y if y<y1 else y1
	return y


def Lerp3(x,x0,x1,y0,y1):
	# Rank: 97.68%
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if x0>x1 or (x0==x1 and y0>y1):
		x0,x1=x1,x0
		y0,y1=y1,y0
	dx=x1-x0
	u=x-x0
	v=x-x1
	y=y0 if x<=x0 else y1
	if abs(u)<abs(v):
		t=u/dx
		y=(1-t)*y0+t*y1
	elif dx!=0:
		t=v/dx
		y=(1+t)*y1-t*y0
	if y0>y1: y0,y1=y1,y0
	y=y if y>y0 else y0
	y=y if y<y1 else y1
	return y


def Lerp4(x,x0,x1,y0,y1):
	# Rank: 98.81%
	# Pick the closest endpoint to x.
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	dx,dy=x1-x0,y1-y0
	l,h=y0,y1
	if l>h: l,h=y1,y0
	if dx==0: return (l if x<=x0 else h)
	u,v=x-x0,x-x1
	y=(y0+(u/dx)*dy) if abs(u)<abs(v) else (y1+(v/dx)*dy)
	y=y if y>l else l
	y=y if y<h else h
	return y


def Lerp5(x,x0,x1,y0,y1):
	# Rank: 98.90%
	# Most accurate linear interpolation.
	# y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if x0>x1 or (x0==x1 and y0>y1):
		x0,x1=x1,x0
		y0,y1=y1,y0
	y=y0 if x<=x0 else y1
	if x>x0 and x<x1:
		dy,u,v=y1-y0,x-x0,x1-x
		if u>v: y0,u=y1,-v
		y=y0+(u/(x1-x0))*dy
		y=y if y==y else y0
	return y


def Lerp6(x,x0,x1,y0,y1):
	# Rank: 98.97%
	# Most accurate linear interpolation.
	# y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	# Split up terms to keep everything as close to 1 as possible.
	# Ex: (x/dx)*dy vs x*(dy/dx)
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if x0>x1 or (x0==x1 and y0>y1):
		x0,x1=x1,x0
		y0,y1=y1,y0
	y=y1 if x>x0 else y0
	if x>x0 and x<x1:
		dx,dy,u,v=x1-x0,y1-y0,x-x0,x1-x
		if u>v: x0,y0,u=x1,y1,-v
		y=y0
		ay=abs(dy)
		ax=dx>1
		if (x>0)!=(x0>0):
			u=x
			y-=(x0/dx)*dy if (abs(x0)>ay)==ax else x0*(dy/dx)
		y+=(u/dx)*dy if (abs(u)>ay)==ax else u*(dy/dx)
		y=y if y==y else y0
	return y


def Lerp7(x,x0,x1,y0,y1):
	# Rank: 98.97%
	# Most accurate linear interpolation.
	# y=y0+((x-x0)/(x1-x0))*(y1-y0), clamp to [y0,y1].
	if not (x0==x0 and x1==x1 and y0==y0 and y1==y1):
		return float("nan")
	if x0>x1 or (x0==x1 and y0>y1):
		x0,x1=x1,x0
		y0,y1=y1,y0
	y=y1 if x>x0 else y0
	if x>x0 and x<x1:
		dx,dy,u,v=x1-x0,y1-y0,x-x0,x1-x
		if u>v: x0,y0,u=x1,y1,-v
		y=y0
		if (x>0)!=(x0>0):
			u=x
			y-=x0*(dy/dx)
		y+=(u/dx)*dy
		y=y if y==y else y0
	return y


if __name__=="__main__":
	#print(LerpRef(-1000,-1.0000000000001,-1,0,2))
	random.seed(1)
	func=[Lerp1,Lerp2,Lerp3,Lerp4,Lerp5,Lerp6,Lerp7]
	funcs=len(func)
	funccnt=[0]*funcs
	funcdif=[0]*funcs
	funcval=[0]*funcs
	coord=[0,0,0,0,0]
	for test in range(1000):
		# Generate coords. Include NaNs, Infs, and copies.
		for i in range(5):
			p=(random.random()-0.5)*18
			b=random.random()*2-1
			a=random.randrange(-10,10)
			try:
				x=a+b*math.exp(p*p*p)
			except:
				x=-float("inf")
				if   b<0.0: x=float("nan")
				elif b<0.5: x=float("inf")
			coord[i]=x
			j=random.randrange(10)
			if j<i: coord[j]=x if random.random()<0.5 else -x
		x,x0,x1,y0,y1=coord
		# Force some x to be between [x0,x1].
		u=random.random()*3-1
		if u>-0.1 and u<1.1:
			z0,z1=mp.mpf(x0),mp.mpf(x1)
			x=float(z0+u*(z1-z0))
		if x0==x0 and x1==x1 and y0==y0 and y1==y1:
			# No NaNs.
			refy=LerpRef(x,x0,x1,y0,y1)
			mindif=mp.mpf("inf")
			for i in range(funcs):
				Lerp=func[i]
				val=Lerp(x,x0,x1,y0,y1)
				# Check bounds in [y0,y1]
				if not ((val>=y0 or val>=y1) and (val<=y0 or val<=y1)):
					print("not in bounds:",i)
					print("y:",val)
					print("x0 y0:",x0,y0)
					print("x1 y1:",x1,y1)
					exit()
				val=mp.mpf(val)
				# If val=ref=inf, set dif to 0.
				if val==refy: dif=mp.mpf(0)
				else: dif=mp.fabs(val-refy)
				if mindif>dif: mindif=dif
				"""if i==5 and dif>1e+100:
					#print("")
					print(float(dif))
					#print("y    :",float(val))
					#print("refy :",float(refy))
					#print("x0 y0:",x0,y0)
					#print("x1 y1:",x1,y1)
					#print("dyx  :",abs((y1-y0)/(x1-x0)))
					#print("dy   :",abs(y1-y0))
					#print("dx   :",abs(x1-x0))"""
				funcdif[i]=dif
				funcval[i]=val
			#mindif+=1e-20
			for i in range(funcs):
				if funcdif[i]<=mindif:
					funccnt[i]+=1
			if funcdif[6]>mindif*10:
				print("")
				print([float(f) for f in funcdif])
				#print("y4   :",float(mindif))
				print("y5   :",float(funcval[5]))
				print("refy :",float(refy))
				print("x0 y0:",x0,y0)
				print("x1 y1:",x1,y1)
				#print("dyx  :",abs((y1-y0)/(x1-x0)))
				print("dy   :",abs(y1-y0))
				print("dx   :",abs(x1-x0))
		else:
			# At least one coordinate=NaN.
			for i in range(funcs):
				Lerp=func[i]
				calc=Lerp(x,x0,x1,y0,y1)
				if calc==calc:
					print("function not NaN:",i)
					print(x,x0,x1,y0,y1)
					exit()
				funccnt[i]+=1
	print("ranks:",funccnt)
	print("done")


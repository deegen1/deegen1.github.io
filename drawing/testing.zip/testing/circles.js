/*
Compare vs: M -1 0 A 1 1 0 0 1 1 0 A 1 1 0 0 1 -1 0 Z

addarc
M 1 0 C 1 0.433110331 0.720929397 0.817218064 0.309016994 0.951056516 Z
M 1 0 C 1 0.433110331 0.720929397 0.817218064 0.309016994 0.951056516 C -0.102895408 1.084894969 -0.554441129 0.938178871 -0.809016994 0.587785252 Z
M 1 0 C 1 0.433110331 0.720929397 0.817218064 0.309016994 0.951056516 C -0.102895408 1.084894969 -0.554441129 0.938178871 -0.809016994 0.587785252 C -1.06359286 0.237391634 -1.06359286 -0.237391634 -0.809016994 -0.587785252 Z
M 1 0 C 1 0.433110331 0.720929397 0.817218064 0.309016994 0.951056516 C -0.102895408 1.084894969 -0.554441129 0.938178871 -0.809016994 0.587785252 C -1.06359286 0.237391634 -1.06359286 -0.237391634 -0.809016994 -0.587785252 C -0.554441129 -0.938178871 -0.102895408 -1.084894969 0.309016994 -0.951056516 Z
M 1 0 C 1 0.551913854 0.551913854 1 0 1 C -0.551913854 1 -1 0.551913854 -1 0 C -1 -0.551913854 -0.551913854 -1 -0 -1 C 0.551913854 -1 1 -0.551913854 1 -0 Z

arcto
M 1 0 C 1 0.110383005 0.985166741 0.204036519 0.951056516 0.309016994 C 0.916946292 0.41399747 0.873898497 0.498483526 0.809016994 0.587785252 C 0.744135492 0.677086979 0.677086979 0.744135492 0.587785252 0.809016994 C 0.498483526 0.873898497 0.41399747 0.916946292 0.309016994 0.951056516 Z
M 1 0 C 1 0.220766009 0.938779999 0.409181799 0.809016994 0.587785252 C 0.67925399 0.766388705 0.518977946 0.882836068 0.309016994 0.951056516 C 0.099056043 1.019276965 -0.099056043 1.019276965 -0.309016994 0.951056516 C -0.518977946 0.882836068 -0.67925399 0.766388705 -0.809016994 0.587785252 Z
M 1 0 C 1 0.331149014 0.855690432 0.614372488 0.587785252 0.809016994 C 0.319880073 1.003661501 0.005924433 1.053387189 -0.309016994 0.951056516 C -0.623958422 0.848725843 -0.848725843 0.623958422 -0.951056516 0.309016994 C -1.053387189 -0.005924433 -1.003661501 -0.319880073 -0.809016994 -0.587785252 Z
M 1 0 C 1 0.441532018 0.728938897 0.814615619 0.309016994 0.951056516 C -0.110904909 1.087497413 -0.549490986 0.944992158 -0.809016994 0.587785252 C -1.068543003 0.230578346 -1.068543003 -0.230578346 -0.809016994 -0.587785252 C -0.549490986 -0.944992158 -0.110904909 -1.087497413 0.309016994 -0.951056516 Z
M 1 0 C 1 0.551915023 0.551915023 1 0 1 C -0.551915023 1 -1 0.551915023 -1 0 C -1 -0.551915023 -0.551915023 -1 -0 -1 C 0.551915023 -1 1 -0.551915023 1 -0 Z

addarc(x,y,ang0,ang1,xrad,yrad,lineto=false) {
	// Circular arc approximation.
	yrad=yrad??xrad;
	let turn=ang1-ang0;
	turn=turn<0?-turn:turn;
	turn=turn<Math.PI*2?turn:Math.PI*2;
	// Control point length.
	let segs=~~(turn/(Math.PI/2));
	segs=segs<3?segs+1:4;
	turn/=segs;
	let ang2=turn*turn;
	let proj=turn*(0.333338514+ang2*(0.006927896+ang2*0.000152242));
	let px=proj*xrad,py=proj*yrad;
	let c1=Math.cos(ang0),x1=c1*xrad+x;c1*=py;
	let s1=Math.sin(ang0),y1=s1*yrad+y;s1*=px;
	if (lineto) {this.lineto(x1,y1);}
	turn=ang1<ang0?-turn:turn;
	for (let s=0;s<segs;s++) {
		ang0+=turn;
		let c0=c1;c1=Math.cos(ang0);
		let s0=s1;s1=Math.sin(ang0);
		let x0=x1;x1=c1*xrad+x;c1*=py;
		let y0=y1;y1=s1*yrad+y;s1*=px;
		this.curveto(x0-s0,y0+c0,x1+s1,y1-c1,x1,y1);
	}
	return this;
}

arcto(x,y,ang0,ang1,xrad,yrad,lineto=false) {
	// Circular arc approximation.
	yrad=yrad??xrad;
	let turn=ang1-ang0;
	turn=turn>-Math.PI*2?turn:-Math.PI*2;
	turn=turn< Math.PI*2?turn: Math.PI*2;
	// Control point length.
	let c =0.087840004*turn;
	let cx=c*xrad,cy=c*yrad;
	let c1=Math.cos(ang0),x1=c1*xrad+x;c1*=cy;
	let s1=Math.sin(ang0),y1=s1*yrad+y;s1*=cx;
	if (lineto) {this.lineto(x1,y1);}
	for (let i=1;i<5;i++) {
		let ang=ang0+i*(turn/4);
		let c0=c1;c1=Math.cos(ang);
		let s0=s1;s1=Math.sin(ang);
		let x0=x1;x1=c1*xrad+x;c1*=cy;
		let y0=y1;y1=s1*yrad+y;s1*=cx;
		this.curveto(x0-s0,y0+c0,x1+s1,y1-c1,x1,y1);
	}
	return this;
}
*/
/* npx eslint circles.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random} from "../library.js";


function CircleError(points) {
	// Finds the maximum deviation from a unit circle.
	let [p0x,p0y,p1x,p1y,p2x,p2y,p3x,p3y]=points;
	let maxerr=0;
	let segs=16;
	for (let i=0;i<segs;i++) {
		let u0=i/segs,u1=(i+1)/segs;
		let segu=(u0+u1)*0.5,segerr=-1;
		let range=1/segs;
		for (let iter=0;iter<128;iter++) {
			let nextu=segu;
			for (let j=0;j<segs;j++) {
				let u=segu+(j/(segs-1)-0.5)*range;
				u=u>u0?u:u0;
				u=u<u1?u:u1;
				let v=1-u;
				let c0=u*u*u,c1=3*u*u*v,c2=3*u*v*v,c3=v*v*v;
				let x=p0x*c0+p1x*c1+p2x*c2+p3x*c3;
				let y=p0y*c0+p1y*c1+p2y*c2+p3y*c3;
				let err=Math.sqrt(x*x+y*y)-1;
				err=err<0?-err:err;
				if (segerr<err) {
					segerr=err;
					nextu=u;
				}
			}
			segu=nextu;
			range*=0.75;
		}
		if (maxerr<segerr) {maxerr=segerr;}
	}
	return maxerr;
}


function ProjPoints(ang,proj) {
	let u0=0,u1=ang;
	let x0=Math.cos(u0),y0=Math.sin(u0);
	let dx0=-y0,dy0=x0;
	let x1=Math.cos(u1),y1=Math.sin(u1);
	let dx1=y1,dy1=-x1;
	let c1x=x0+dx0*proj,c1y=y0+dy0*proj;
	let c2x=x1+dx1*proj,c2y=y1+dy1*proj;
	return [x0,y0,c1x,c1y,c2x,c2y,x1,y1];
}


function CircleApprox(segs,pos=[0,0],rad=1) {
	// [p0,d0,d1,p1]
	// c0=p0+d0*len
	// c1=p1+d1*len
	// [p0,c0,c1,p1]
	const accuracy=9;
	function trimdec(x) {
		if (Math.abs(x)<1e-10) {x=0;}
		let s=x.toFixed(accuracy);
		while (s[s.length-1]==="0") {s=s.substring(0,s.length-1);}
		if (s[s.length-1]===".") {s=s.substring(0,s.length-1);}
		return s;
	}
	function getpoints(s,proj) {
		let u0=Math.PI*2*(s/segs),u1=Math.PI*2*((s+1)/segs);
		let x0=Math.cos(u0),y0=Math.sin(u0);
		let dx0=-y0,dy0=x0;
		let x1=Math.cos(u1),y1=Math.sin(u1);
		let dx1=y1,dy1=-x1;
		let c1x=x0+dx0*proj,c1y=y0+dy0*proj;
		let c2x=x1+dx1*proj,c2y=y1+dy1*proj;
		return [x0,y0,c1x,c1y,c2x,c2y,x1,y1];
	}
	let projrange=1;
	let mindist=Infinity;
	let minproj=1;
	const tests=8192;
	for (let trial=0;trial<32;trial++) {
		let projmid=minproj;
		for (let p=0;p<101;p++) {
			let proj=projmid+((2*p/100)-1)*projrange;
			if (proj<0) {continue;}
			let [c0x,c0y,c1x,c1y,c2x,c2y,c3x,c3y]=getpoints(0,proj);
			c2x=(c2x-c1x)*3;c1x=(c1x-c0x)*3;c3x=c3x-c0x-c2x;c2x-=c1x;
			c2y=(c2y-c1y)*3;c1y=(c1y-c0y)*3;c3y=c3y-c0y-c2y;c2y-=c1y;
			let maxdist=0;
			for (let t=0;t<tests;t++) {
				let u=t/(tests-1);
				let sx=c0x+u*(c1x+u*(c2x+u*c3x));
				let sy=c0y+u*(c1y+u*(c2y+u*c3y));
				let dist=Math.sqrt(sx*sx+sy*sy)-1;
				dist=dist>0?dist:-dist;
				if (maxdist<dist) {
					maxdist=dist;
					if (mindist<maxdist) {
						break;
					}
				}
			}
			if (mindist>maxdist) {
				console.log(maxdist,proj);
				mindist=maxdist;
				minproj=proj;
			}
		}
		projrange*=0.5;
	}
	console.log("proj:",minproj);
	let str="M ";
	for (let s=0;s<segs;s++) {
		let pt=getpoints(s,minproj);
		for (let i=0;i<pt.length;i++) {pt[i]=trimdec(pt[i]*rad+pos[i&1]);}
		let [c0x,c0y,c1x,c1y,c2x,c2y,c3x,c3y]=pt;
		if (!s) {str+=c0x+" "+c0y;}
		str+=` C ${c1x} ${c1y} ${c2x} ${c2y} ${c3x} ${c3y}`;
	}
	console.log(str);
}


function OptimalProjection() {
	let projarr=[];
	for (let a=0;a<41;a++) {
		let ang=(a/80)*Math.PI;
		let minproj=1,minerr=Infinity;
		let range=1,tests=16;
		for (let iter=0;iter<128;iter++) {
			let nextproj=minproj;
			for (let test=0;test<tests;test++) {
				let proj=minproj+(test/(tests-1)-0.5)*range;
				proj=proj>0?proj:0;
				let points=ProjPoints(ang,proj);
				let err=CircleError(points);
				if (minerr>err) {
					minerr=err;
					nextproj=proj;
				}
			}
			range*=0.75;
			minproj=nextproj;
			//console.log(iter,minerr,minproj);
		}
		console.log(`(${ang},${minproj})`);
		projarr.push([ang,minproj]);
	}
	/*let str="[";
	for (let pt of projarr) {
		str+=`\n[${pt[0]},${pt[1]}],`;
	}
	str+="\n];";
	console.log(str);
	return;*/
	// Fit curve. proj(x)=tan(x*a)*b
	//let mincoef=[0.333338514,0.006927896,0.000152242];
	let mincoef=[0.3333385136967729,0.006927895728526332,0.00015224218397586327];
	let minerr=Infinity;
	let rnd=new Random();
	let nextout=-1;
	for (let iter=0;iter<100000000;iter++) {
		let maxerr=0;
		let range=iter?Math.pow(2,-rnd.mod(32)):0;
		let c0=mincoef[0]+rnd.gets()*range;
		let c1=mincoef[1]+rnd.gets()*range;
		let c2=mincoef[2]+rnd.gets()*range;
		for (let pt of projarr) {
			let ang=pt[0],ang2=ang*ang;
			//let err=ang2*(c0+ang2*(c1+ang2*(c2+c3*ang2)))-pt[1];
			let err=ang*(c0+ang2*(c1+ang2*c2))-pt[1];
			//let err=ang*(c0+ang*(c1+ang*(c2+c3*ang)))-pt[1];
			//let err=Math.tan(c0*ang)*c1-pt[1];
			err=err<0?-err:err;
			maxerr=maxerr>err?maxerr:err;
			//maxerr+=err*err;
		}
		if (minerr>maxerr) {
			minerr=maxerr;
			mincoef=[c0,c1,c2];
			if (iter>nextout) {
				nextout=iter+20000;
				console.log(iter,minerr,mincoef);
			}
		}
	}
	console.log("final:",minerr,mincoef);
	// err: 0.0000011705986983634453
	// proj(ang) = ang*(0.333338514+ang2*(0.006927896+ang2*0.000152242))
}


function ArcDemo() {
	// Draw a bounding box to see how it reacts.
	for (let i=1;i<=5;i++) {
		let ang=(i/5)*Math.PI*2;
		let path=new Draw.Path();
		path.addarc(0,0,0,ang,1,1,true);
		//path.arcto(0,0,0,ang,1,1,true);
		path.close();
		console.log(path.tostring(9));
	}
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	function update() {
		requestAnimationFrame(update);
		draw.fill(0,0,0,255);
		let ang=((performance.now()%2100)/1000)*Math.PI;
		//draw.setcolor(255,0,0);
		//draw.filloval(500,500,450,450);
		draw.setcolor(255,255,255,255);
		let path=draw.begin();
		path.moveto(500,500);
		path.addarc(500,500,0.3,0.3+ang,450,450,true);
		//path.addarc(500,500,0.3,0.3-ang,450,450,true);
		path.close();
		let segs=(path.vertidx-3)/3;
		draw.fillpath();
		draw.filltext(10,10,"segs: "+segs);
		draw.screenflip();
	}
	update();
}


function TestMain() {
	//OptimalProjection();
	ArcDemo();
}
//TestMain();
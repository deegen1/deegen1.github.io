/*

Bezier Segmentation Tests
Need at least 3 interpolation points to catch all cubic bezier cases.

*/
/* npx eslint segmenttest.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random} from "../library.js";


function BezierSegment1(curve,splitlen=3) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	// Estimate bezier length.
	let dist=0,dx=0,dy=0;
	dx=c1x-p0x;dy=c1y-p0y;dist =Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	let segs=Math.ceil(dist*0.5/splitlen+1e-10);
	// Segment the curve.
	let lr=[];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let ppx=p0x,ppy=p0y,unorm=1.0/segs,u=0;
	for (let s=0;s<segs;s++) {
		let lu=u,lx=ppx,ly=ppy;
		u+=unorm;
		ppx=p0x+u*(c1x+u*(c2x+u*c3x));
		ppy=p0y+u*(c1y+u*(c2y+u*c3y));
		lr.push({x0:lx,y0:ly,x1:ppx,y1:ppy,u0:lu,u1:u});
	}
	let l=lr[lr.length-1];
	l.u1=1;
	l.x1=curve[6];
	l.y1=curve[7];
	return lr;
}


function BezierSegment2(curve,cutoff,type,segments) {
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let den=(dx*dx+dy*dy)*cutoff;
		if (den<1e-9) {den=cutoff;dx=1;dy=0;}
		let u0=l.u0,u1=l.u1;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<segments;s++) {
			let u=u0+(u1-u0)*((s+1)/(segments+1));
			let ix=p0x+u*(c1x+u*(c2x+u*c3x));
			let iy=p0y+u*(c1y+u*(c2y+u*c3y));
			let num=dy*(ix-x0)-dx*(iy-y0);
			let dist=num*num;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u;
			}
		}
		console.log("maxdist:",maxdist);
		if (maxdist>den) {
			// we're outside the bounds
			let u=[(u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment3(curve,cutoff,type,samples) {
	// cutoff  = cutoff distance squared
	// samples = how many points on segment to sample
	// type 0  = split at 0.5
	//      1  = split at minimum distance
	//      2  = split at maximum distance
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.u0,u1=l.u1,du=(u1-u0)/(samples+1);
		let den=dx*dx+dy*dy;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<samples;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (mindist>dist) {
				mindist=dist;
				minu=u0;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u0;
			}
		}
		if (maxdist>cutoff && maxdist<Infinity) {
			// The line is too far from the curve, split it.
			let u=[(l.u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment4(curve,curvemaxdist2=0.01) {
	// Sample-and-divide test.
	let [p0x,p0y,c1x,c1y,c2x,c2y,p1x,p1y]=curve;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	l.amul=0;l.area=1;
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;let c3x=p1x-p0x-c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;let c3y=p1y-p0y-c2y;c2y-=c1y;
	for (let j=lcnt-1;j<lcnt;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.amul,u1=l.area,du=(u1-u0)*0.25;
		let den=dx*dx+dy*dy;
		let maxdist=-Infinity,mu=0,mx=0,my=0;
		for (let s=0;s<3;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (maxdist<dist) {
				maxdist=dist;
				mu=u0;
				mx=sx;
				my=sy;
			}
		}
		if (maxdist>curvemaxdist2 && maxdist<Infinity) {
			// The line is too far from the curve, so split it.
			lr.push({});
			l.x1=mx;
			l.y1=my;
			l.area=mu;
			l=lr[lcnt++];
			l.x0=mx;
			l.y0=my;
			l.x1=x1;
			l.y1=y1;
			l.amul=mu;
			l.area=u1;
			j--;
		}
	}
	for (l of lr) {l.u0=l.amul;l.u1=l.area;}
	return lr;
}


function BezierSegment5(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let [k0x,k0y,k1x,k1y,k2x,k2y,k3x,k3y]=curve;
	let lr=[{
		x0:k0x,y0:k0y,
		x1:k3x,y1:k3y,
		x2:k1x,y2:k1y,
		x3:k2x,y3:k2y,
		u0:0,u1:1
	}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	for (let j=lcnt-1;j<lcnt;j++) {
		// The curve will stay inside the bounding box of [c0,c1,c2,c3].
		// If the subcurve is outside the image, stop subdividing.
		l=lr[j];
		let c3x=l.x1,c2x=l.x3,c1x=l.x2,c0x=l.x0;
		let c3y=l.y1,c2y=l.y3,c1y=l.y2,c0y=l.y0;
		/*if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
		    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
			continue;
		}*/
		let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
		// Test if both control points are close to the line c0->c3.
		// Clamp to ends and filter degenerates.
		let lx=c1x-c0x,ly=c1y-c0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=c2x-c0x;ly=c2y-c0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		lr.push({}); // remove
		let u0=l.u0,u1=l.u1,uh=(u0+u1)*0.5; // remove
		let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
		let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
		let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
		let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
		l.x1=phx;l.x3=l2x;l.x2=l1x;
		l.y1=phy;l.y3=l2y;l.y2=l1y;
		l.u1=uh; // remove
		l=lr[lcnt++];
		l.x1=c3x;l.x3=r2x;l.x2=r1x;l.x0=phx;
		l.y1=c3y;l.y3=r2y;l.y2=r1y;l.y0=phy;
		l.u1=u1;l.u0=uh; // remove
		j--;
	}
	return lr;
}


function BezierSegment6(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	// Uses fewer variables.
	const [p0x,p0y,n0x,n0y,n1x,n1y,p1x,p1y]=curve;
	let lr=[{
		u0:0,u1:1,
		x0:p0x,y0:p0y,
		x1:p1x,y1:p1y
	}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	let q1x=n0x-p0x,q2x=n1x-p0x-2*q1x,q3x=p1x-p0x+3*(n0x-n1x);
	let q1y=n0y-p0y,q2y=n1y-p0y-2*q1y,q3y=p1y-p0y+3*(n0y-n1y);
	for (let j=lcnt-1;j<lcnt;j++) {
		if (lcnt>10000) {throw "lcnt too high";}
		// The curve will stay inside the bounding box of [c0,c1,c2,c3].
		// If the subcurve is outside the image, stop subdividing.
		// Given u0,u1 calculate c1,c2.
		l=lr[j];
		//let c0x=l.x0,c0y=l.y0,u0=l.u0;
		//let c3x=l.x1,c3y=l.y1,u1=l.u1;
		//let t0=1-u0,t1=1-u1;
		//let c1x=(t0*t0*t1)*p0x+(u0*t0*t1+t0*u0*t1+t0*t0*u1)*n0x+(u0*u0*t1+t0*u0*u1+u0*t0*u1)*n1x+u0*u0*u1*p1x;
		//let c2x=(t0*t1*t1)*p0x+(u0*t1*t1+t0*u1*t1+t0*t1*u1)*n0x+(u0*u1*t1+t0*u1*u1+u0*t1*u1)*n1x+u0*u1*u1*p1x;
		//let c1y=(t0*t0*t1)*p0y+(u0*t0*t1+t0*u0*t1+t0*t0*u1)*n0y+(u0*u0*t1+t0*u0*u1+u0*t0*u1)*n1y+u0*u0*u1*p1y;
		//let c2y=(t0*t1*t1)*p0y+(u0*t1*t1+t0*u1*t1+t0*t1*u1)*n0y+(u0*u1*t1+t0*u1*u1+u0*t1*u1)*n1y+u0*u1*u1*p1y;
		let c0x=l.x0,c0y=l.y0,u0=l.u0;
		let c3x=l.x1,c3y=l.y1,u1=l.u1;
		let u2=2*u0+u1,u3=u0+2*u1,u4=u0*u1;
		let c1x=p0x+u2*q1x+u0*(u3*q2x+u4*q3x);
		let c1y=p0y+u2*q1y+u0*(u3*q2y+u4*q3y);
		let c2x=p0x+u3*q1x+u1*(u2*q2x+u4*q3x);
		let c2y=p0y+u3*q1y+u1*(u2*q2y+u4*q3y);
		/*if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
		    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
			continue;
		}*/
		let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
		// Test if both control points are close to the line c0->c3.
		// Clamp to ends and filter degenerates.
		let lx=c1x-c0x,ly=c1y-c0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=c2x-c0x;ly=c2y-c0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half.
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		lr.push({}); // remove
		let uh=(u0+u1)*0.5;
		//let v=1-h;
		//let hx=v*v*v*p0x+3*v*v*h*n0x+3*v*h*h*n1x+h*h*h*p1x;
		//let hy=v*v*v*p0y+3*v*v*h*n0y+3*v*h*h*n1y+h*h*h*p1y;
		let hx=p0x+uh*(3*q1x+uh*(3*q2x+uh*q3x));
		let hy=p0y+uh*(3*q1y+uh*(3*q2y+uh*q3y));
		l.x1=hx;
		l.y1=hy;
		l.u1=uh;
		l=lr[lcnt++];
		l.x0=hx;l.x1=c3x;
		l.y0=hy;l.y1=c3y;
		l.u0=uh;l.u1=u1;
		j--;
	}
	return lr;
}


function BezierSegment7(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let [p0x,p0y,p1x,p1y,p2x,p2y,p3x,p3y]=curve;
	let u0=0,u1=1;
	let lr=[];
	let ci=0,cprev=-1;
	let cv=[];
	// Segment the curve.
	while (true) {
		// The curve will stay inside the bounding box of [p0,p1,p2,p3].
		// If the subcurve is outside the image, stop subdividing.
		if (cprev===ci) {
			lr.push({u0:u0,u1:u1,x0:p0x,y0:p0y,x1:p3x,y1:p3y});
			if (!ci) {break;}
			u0=u1;u1=cv[--ci];
			p0x=p3x;p1x=cv[--ci];p2x=cv[--ci];p3x=cv[--ci];
			p0y=p3y;p1y=cv[--ci];p2y=cv[--ci];p3y=cv[--ci];
		}
		cprev=ci;
		/*if ((p0x<=0 && p1x<=0 && p2x<=0 && p3x<=0) || (p0x>=iw && p1x>=iw && p2x>=iw && p3x>=iw) ||
		    (p0y<=0 && p1y<=0 && p2y<=0 && p3y<=0) || (p0y>=ih && p1y>=ih && p2y>=ih && p3y>=ih)) {
			continue;
		}*/
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let dx=p3x-p0x,dy=p3y-p0y,den=dx*dx+dy*dy;
		let lx=p1x-p0x,ly=p1y-p0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=p2x-p0x;ly=p2y-p0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
		let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		cv.push([0,0,0,0,0,0,0,0]);
		cv[ci++]=p3y;cv[ci++]=r2y;cv[ci++]=r1y;
		cv[ci++]=p3x;cv[ci++]=r2x;cv[ci++]=r1x;
		cv[ci++]=u1;
		p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
		p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
		p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
		u1=(u0+u1)*0.5;
	}
	return lr;
}


function BezierSegment8(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let [p0x,p0y,p1x,p1y,p2x,p2y,p3x,p3y]=curve;
	let u0=0,u1=1;
	let lr=[];
	function extend() {
		lr.push({u0:0,u1:0,x0:0,y0:0,x1:0,y1:0,x2:0,y2:0,sort:0});
	}
	extend();
	let l=lr[0];
	let lrcnt=1,lcnt=1;
	// Segment the curve.
	let next=-1,next0=0;
	while (true) {
		// The curve will stay inside the bounding box of [p0,p1,p2,p3].
		// If the subcurve is outside the image, stop subdividing.
		if (next===next0) {
			l.sort=0;
			l.x0=p0x;l.y0=p0y;
			l.x1=p3x;l.y1=p3y;
			l.u0=u0;l.u1=u1;//
			if (next<0) {break;}
			l=lr[next];
			u0=u1;u1=l.u1;//
			next=l.sort;
			p0x=p3x;p1x=l.x0;p2x=l.x1;p3x=l.x2;
			p0y=p3y;p1y=l.y0;p2y=l.y1;p3y=l.y2;
		}
		next0=next;
		/*if ((p0x<=0 && p1x<=0 && p2x<=0 && p3x<=0) || (p0x>=iw && p1x>=iw && p2x>=iw && p3x>=iw) ||
		    (p0y<=0 && p1y<=0 && p2y<=0 && p3y<=0) || (p0y>=ih && p1y>=ih && p2y>=ih && p3y>=ih)) {
			continue;
		}*/
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let dx=p3x-p0x,dy=p3y-p0y,den=dx*dx+dy*dy;
		let lx=p1x-p0x,ly=p1y-p0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=p2x-p0x;ly=p2y-p0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
		if (lrcnt<=lcnt) {
			extend();
			lrcnt=lr.length;
		}
		let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
		let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		let n=lr[lcnt];
		n.u1=u1;//
		n.sort=next;
		n.x0=r1x;n.x1=r2x;n.x2=p3x;
		n.y0=r1y;n.y1=r2y;n.y2=p3y;
		p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
		p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
		p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
		u1=(u0+u1)*0.5;//
		next=lcnt++;
	}
	for (let i=1;i<lcnt;i++) {
		let j=i,m=lr[i],n=null,u=m.u0;
		while (j>0 && (n=lr[j-1]).u0>u) {
			lr[j--]=n;
		}
		lr[j]=m;
		if (m.sort!==0) {throw "sort";}
	}
	return lr;
}


function BezierSegmentTest() {
	// test
	//      u0,u1 is consecutive and covers [0,1]
	//      endpoints match curve(u)
	//      intermediate points based on distance, at least 10
	let rnd=new Random(9876);
	let curve=new Float64Array(8);
	let trials=10000;
	let sumdist=0,sumsegs=0,maxdist=0,sumden=0;
	function getrnd() {
		let degen=rnd.mod(64);
		if (degen<4) {return [0,NaN,Infinity,-Infinity][degen];}
		return rnd.gets()*Math.pow(2,rnd.gets()*20);
	}
	for (let trial=0;trial<trials;trial++) {
		// Generate the curve. Try to generate subpixel curves.
		let degen=false;
		for (let i=0;i<4;i++) {
			let x=getrnd();
			let y=getrnd();
			curve[i*2+0]=x;
			curve[i*2+1]=y;
			if (!(x>-Infinity && x<Infinity && y>-Infinity && y<Infinity)) {
				degen=true;
			}
		}
		//if (trial!==65) {continue;}
		//let lr=BezierSegment1(curve);
		//let lr=BezierSegment3(curve,0.25,2,3);
		//let lr=BezierSegment3(curve,0.01,2,3);
		//let lr=BezierSegment3(curve,0.01,0,3);
		//let lr=BezierSegment3(curve,0.01,2,2);
		//let lr=BezierSegment3(curve,0.01,0,2);
		//let lr=BezierSegment4(curve);
		//let lr=BezierSegment5(curve);
		//let lr=BezierSegment6(curve);
		//let lr=BezierSegment7(curve);
		let lr=BezierSegment8(curve);
		if (degen) {
			if (lr.length!==1) {
				console.log("degen curve not single line");
				console.log("trial:",trial);
				console.log("segs :",lr.length);
				console.log("curve:",curve.toString());
				throw "error";
			}
			continue;
		}
		sumden++;
		lr.sort((l,r)=>{return l.u0-r.u0;});
		let u1=0,x1=curve[0],y1=curve[1];
		let subdist=0;
		for (let l of lr) {
			// Test if end of previous line = start of current.
			let u0=l.u0,x0=l.x0,y0=l.y0;
			if (u0!==u1 || x0!==x1 || y0!==y1) {
				console.log("lines not continuous");
				console.log(u1,x1,y1);
				console.log(u0,x0,y0);
				return;
			}
			// Test if line start is on the curve.
			let u=u0,v=1-u,uu=u*u,vv=v*v,vu=3*v*u;
			let tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6];
			let ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7];
			if (Math.abs(tx-x0)>1e-9 || Math.abs(ty-y0)>1e-9) {
				console.log("line off of curve");
				console.log(tx,ty);
				console.log(x0,y0);
				return;
			}
			// Get maximum distance from segment to curve.
			u1=l.u1;
			x1=l.x1;
			y1=l.y1;
			let dx=x1-x0,dy=y1-y0;
			let den=dx*dx+dy*dy;
			let depth=8,samples=8;
			let du=(u1-u0)*0.5,mu=(u1+u0)*0.5,md=0;
			for (let d=0;d<depth;d++) {
				let nu=mu;
				for (let s=0;s<samples;s++) {
					u=nu+du*(2*(s/(samples-1))-1);
					u=u>u0?u:u0;
					u=u<u1?u:u1;
					v=1-u;uu=u*u;vv=v*v;vu=3*v*u;
					tx=vv*v*curve[0]+vu*v*curve[2]+vu*u*curve[4]+uu*u*curve[6]-x0;
					ty=vv*v*curve[1]+vu*v*curve[3]+vu*u*curve[5]+uu*u*curve[7]-y0;
					let dist=0;
					if (den<1e-9) {
						dist=tx*tx+ty*ty;
					} else {
						dist=dy*tx-dx*ty;
						dist=(dist*dist)/den;
					}
					if (md<dist) {
						md=dist;
						mu=u;
					}
				}
				du*=0.5;
			}
			subdist=subdist>md?subdist:md;
		}
		if (u1!==1 || Math.abs(x1-curve[6])>1e-9 || Math.abs(y1-curve[7])>1e-9) {
			console.log("line end");
			console.log(u1,x1,y1);
			console.log(1,curve[6],curve[7]);
			return;
		}
		// console.log(maxdist,lr.length);
		subdist=Math.sqrt(subdist);
		maxdist=maxdist>subdist?maxdist:subdist;
		sumdist+=subdist;
		sumsegs+=lr.length;
		if (subdist>10) {
			console.log(curve,trial);
			throw "subdist: "+subdist;
		}
	}
	sumdist/=sumden;
	sumsegs/=sumden;
	let score=(sumdist+maxdist)*sumsegs;
	console.log("sumdist: "+sumdist.toFixed(6));
	console.log("maxdist: "+maxdist.toFixed(6));
	console.log("sumsegs: "+sumsegs.toFixed(6));
	console.log("score  : "+score.toFixed(6));
	console.log("done");
}


function BezierSegmentDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	// console.log(ctx);
	let curve=[100,100,600,130,100,770,600,800];
	ctx.strokeStyle="rgba(255,255,255,1.0)";
	ctx.beginPath();
	ctx.moveTo(curve[0],curve[1]);
	ctx.bezierCurveTo(curve[2],curve[3],curve[4],curve[5],curve[6],curve[7]);
	ctx.stroke();
	ctx.fillStyle="rgba(255,0,0,1.0)";
	// let points=BezierSegment1(curve,48);
	let lr=BezierSegment3(curve,0.1,2,3);
	lr.sort((l,r)=>{return l.u0-r.u0;});
	let points=[[lr[0].x0,lr[0].y0]];
	for (let l of lr) {points.push([l.x1,l.y1]);}
	console.log(points.length);
	for (let p of points) {
		ctx.beginPath();
		ctx.arc(p[0],p[1],3,0,Math.PI*2);
		ctx.fill();
	}
	ctx.strokeStyle="rgba(255,0,0,1.0)";
	ctx.beginPath();
	for (let p of points) {
		ctx.lineTo(p[0],p[1]);
	}
	ctx.stroke();
}

function TestMain() {
	BezierSegmentTest();
	//BezierSegmentDemo();
	console.log("done");
}
//TestMain();

/*------------------------------------------------------------------------------


fillpath.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


find optimal value for curvemaxdist2


Original
rect: 0.509240
oval: 1.802340
line: 1.175660
char: 1.560520

Draw 2
rect: 0.899480
oval: 3.246120
line: 2.320880
char: 2.162320

Lerp
rect: 0.894680
oval: 3.209820
line: 2.307720
char: 2.147100

fast
rect: 0.869020
oval: 3.073620
line: 1.816820
char: 1.973400


*/
/* npx eslint fillpath.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Lerp,UnitAreaCalc} from "./areacalc.js";
import {Env,Random,Transform,Input} from "../library.js";
const DrawPath=Draw.Path;


//---------------------------------------------------------------------------------
// Test Filling


class Draw1 extends Draw {

	constructor(imgw,imgh) {
		super(imgw,imgh);
	}


	fillextend() {
		// Declaring line objects this way allows engines to optimize their structs.
		this.tmpline.push({
			next:0,
			x0:0,y0:0,
			x1:0,y1:0
		});
	}


	fillpath(path,trans) {
		// Fills the current path.
		//
		// Preprocess the lines and curves. Use a binary heap to dynamically sort lines.
		// Keep as simple as possible to be efficient. Put micro optimization in WASM.
		path =path ??this.defpath;
		trans=trans??this.deftrans;
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		// Screenspace transformation.
		let mat=trans.mat;
		let matxx=mat[0],matxy=mat[1],matx=trans.vec[0];
		let matyx=mat[2],matyy=mat[3],maty=trans.vec[1];
		let det=matxx*matyy-matxy*matyx;
		// Check if trans(path) and image AABB overlap. Calculate y intercepts.
		let imgw=this.img.width,imgh=this.img.height;
		let alpha=this.rgba[3]/255,amul=det<0?-alpha:alpha;
		let w0=path.minx,w1=path.maxx;
		let h0=path.miny,h1=path.maxy;
		let cover=(w1-w0)*(h1-h0)*det*amul;
		if (!(path.vertidx>2 && imgw>0 && imgh>0 && cover>8e-6 && alpha>8e-6)) {return;}
		let vx=w0*matxx+h0*matxy+matx;
		let vy=w0*matyx+h0*matyy+maty;
		let miny=imgh,maxy=0;
		for (let i=1;i<16;i+=i) {
			let w=(3&i)?w1:w0;
			let h=(6&i)?h1:h0;
			let x0=vx,x1=vx=w*matxx+h*matxy+matx;
			let y0=vy,y1=vy=w*matyx+h*matyy+maty;
			if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (!(x0<imgw && x1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,xw=x1-imgw;
			y0-=x0<0?(x0/dx)*dy:0;
			y1-=xw>0?(xw/dx)*dy:0;
			if (y0>y1) {h=y0;y0=y1;y1=h;}
			miny=miny<y0?miny:y0;
			maxy=maxy>y1?maxy:y1;
		}
		if (!(miny<imgh && maxy>0)) {return;}
		miny=miny>0?miny:0;
		maxy=maxy<imgh?maxy:imgh;
		// Loop through the path nodes.
		let lr=this.tmpline,lrcnt=lr.length,lcnt=0;
		let subidx=0,subbnd=0;
		let movex=0,movey=0,x3=0,y3=0;
		let varr=path.vertarr;
		let vidx=path.vertidx;
		for (let i=0;i<=vidx;i++) {
			let v=varr[i<vidx?i:0];
			let type=v.type;
			let x0=x3,x1=x3=v.x*matxx+v.y*matxy+matx,x2;
			let y0=y3,y1=y3=v.x*matyx+v.y*matyy+maty,y2;
			subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>miny?4:0)|(y0<maxy?8:0);
			// Add a basic line.
			if (lrcnt<=lcnt) {
				this.fillextend();
				lrcnt=lr.length;
			}
			let l=lr[lcnt++];
			if (type!==DrawPath.CURVE) {
				if (type===DrawPath.MOVE) {
					// Close any unclosed subpaths.
					x1=movex;movex=x3;
					y1=movey;movey=y3;
					// If the subpath isn't on screen, remove it.
					lcnt=subbnd<15?subidx:lcnt;
					subidx=lcnt;
					subbnd=0;
				}
				l.x0=x0;l.y0=y0;
				l.x1=x1;l.y1=y1;
				continue;
			}
			// Linear decomposition of curves.
			v=varr[++i];x2=v.x*matxx+v.y*matxy+matx;y2=v.x*matyx+v.y*matyy+maty;
			v=varr[++i];x3=v.x*matxx+v.y*matxy+matx;y3=v.x*matyx+v.y*matyy+maty;
			let next=-1;
			let x4=x0,y4=y0,u0=0,u1=1;
			let a4=x0,b4=y0,a5=x1,b5=y1;
			while (true) {
				// Given u0 and u1, calculate control points (p5,p6) and endpoint p7.
				let v0=1-u0,v1=1-u1,a6,a7,a8,b6,b7,b8;
				a6=v1*x0+u1*x1;a7=v1*x1+u1*x2;a8=v1*x2+u1*x3;
				b6=v1*y0+u1*y1;b7=v1*y1+u1*y2;b8=v1*y2+u1*y3;
				a6=v1*a6+u1*a7;a7=v1*a7+u1*a8;
				b6=v1*b6+u1*b7;b7=v1*b7+u1*b8;
				let x5=v1*a4+u1*a5,y5=v1*b4+u1*b5;
				let x6=v0*a6+u0*a7,y6=v0*b6+u0*b7;
				let x7=v1*a6+u1*a7,y7=v1*b6+u1*b7;
				if (u1>=1) {x7=x3;y7=y3;}
				// If the subcurve is inside the image and u1-u0 hasn't collapsed, subdivide.
				if ((y4>miny || y5>miny || y6>miny || y7>miny)
				&&  (y4<maxy || y5<maxy || y6<maxy || y7<maxy)
				&&  (x4<imgw || x5<imgw || x6<imgw || x7<imgw)
				&&  (x4>0 || x5>0 || x6>0 || x7>0) && u1-u0>1e-4) {
					// Test if both control points are close to the line p4->p7.
					// Clamp to ends and filter degenerates.
					let dx=x7-x4,dy=y7-y4;
					let lx=x5-x4,ly=y5-y4;
					let d=dx*dx+dy*dy;
					let u=dx*lx+dy*ly;
					u=u>0?(u<d?u/d:1):0;
					lx-=dx*u;ly-=dy*u;
					let a=lx*lx+ly*ly;
					lx=x6-x4;ly=y6-y4;
					u=dx*lx+dy*ly;
					u=u>0?(u<d?u/d:1):0;
					lx-=dx*u;ly-=dy*u;
					let b=lx*lx+ly*ly;
					d=a>b?a:b;
					if (d>0.02) {
						if (lrcnt<=lcnt) {
							this.fillextend();
							lrcnt=lr.length;
						}
						let m=lr[lcnt];
						m.next=next;
						next=lcnt++;
						m.x0=u1;
						u1=(u0+u1)*0.5;
						continue;
					}
				}
				// Commit this segment of the curve.
				subbnd|=(x4>0?1:0)|(x4<imgw?2:0)|(y4>miny?4:0)|(y4<maxy?8:0);
				l.x0=x4;l.y0=y4;
				l.x1=x7;l.y1=y7;
				if (next<0) {break;}
				l=lr[next];
				next=l.next;
				u0=u1;u1=l.x0;
				x4=x7;y4=y7;
				a4=a6;b4=b6;
				a5=a7;b5=b7;
			}
		}
		if (!lcnt) {return;}
		// Init blending.
		let shift=this.rgbashift;
		let rshift=shift[0],gshift=shift[1],bshift=shift[2],ashift=shift[3];
		let fill=this.rgba32[0]|(255<<ashift);
		let rmul=this.rgba[0],gmul=this.rgba[1],bmul=this.rgba[2];
		amul=path.area<0?-amul:amul;
		// Process the lines row by row.
		let py=0,prow=0,pmax=Math.ceil(maxy)*imgw;
		let lnext=(~~miny)*imgw,heap=lcnt-1;
		let areacon=0;
		let imgdata=this.img.data32;
		while (lnext<pmax) {
			let pix=lnext;
			if (pix>=prow) {
				py=~~(pix/imgw);
				prow=py*imgw+imgw;
				areacon=0;
			}
			let areatmp=0;
			let px=pix-prow+imgw;
			while (pix>=lnext) {
				// Calculate the area of overlap and where to sort the line.
				// +---------+----/----+---------+
				// |         |   /.....|         |
				// |         |  /......|         |
				// |         | /.......|         |
				// +---------+/--------+---------+
				let l=lr[heap];
				let x0=l.x0,y0=l.y0;
				let x1=l.x1,y1=l.y1;
				let next=pmax;
				let sign=amul,u;
				if (y0>y1) {
					sign=-sign;
					u=x0;x0=x1;x1=u;
					u=y0;y0=y1;y1=u;
				}
				if (py<y1 && y0<maxy && y0<y1) {
					// Find the bottom of the line.
					let ny=y0>py?~~y0:py,r1=ny+1,r2=ny+2,nx=px+1;
					// Clip to the row. For large coordinates, use the closest endpoint to imgh/2.
					let dx=x1-x0,dy=y1-y0;
					let bx=x0,by=y0,x2=x1,y2=y1;
					if (y0+y1<imgh) {bx=x1;by=y1;}
					if (y1>r1) {x1=bx+((r1-by)/dy)*dx;y1=r1;}
					if (y0<ny) {x0=bx+((ny-by)/dy)*dx;y0=ny;}
					if (x0>x1) {
						sign=-sign;
						u=x0;x0=x1;x1=u;
						u=y0;y0=y1;y1=u;
					}
					if (!(x0<nx && ny<=py)) {
						// Under or to the left. If leaning past the edge of the image, abort.
						if (x0<imgw || x2<imgw) {nx=x0;} else {ny=imgh;}
					} else if (x1<=px) {
						// To the right. Area won't change after this pixel.
						x0=y2>r2?bx+((r2-by)/dy)*dx:x2;
						nx=x0<x1?x0:x1;
						ny=y2>r1?r1:imgh;
						areacon+=(y0-y1)*sign;
					} else {
						// Overlapping. Clip to the column.
						x0-=px;x1-=px;u=y0;
						dx=x1-x0;dy=y1-y0;
						if (x0<0) {y0-=((x0  )/dx)*dy;x0=0;}
						if (x1>1) {y1-=((x1-1)/dx)*dy;x1=1;}
						areatmp+=(u-y1+(x0+x1)*0.5*(y1-y0))*sign;
					}
					nx=nx<0?0:nx;
					next=ny*imgw+(nx<imgw?~~nx:imgw);
					next=next>pix?next:(pix+1);
				}
				l.next=next;
				// Heap sort down.
				if (next>=pmax) {
					let t=lr[--lcnt];
					lr[lcnt]=l;l=t;
					next=l.next;
				}
				let i=heap,j;
				while ((j=i+i+1)<lcnt) {
					let k=j+(j+1<lcnt);
					let l0=lr[j],l1=lr[k];
					let v0=l0.next,v1=l1.next;
					if (v0>v1) {v0=v1;l0=l1;j=k;}
					if (v0>=next) {break;}
					lr[i]=l0;
					i=j;
				}
				lr[i]=l;
				// During the first pass, sort from the bottom down.
				if (heap) {heap--;} else {lnext=lr[0].next;}
			}
			// Blend the pixel based on how much we're covering. 8e-6=0.5/(255*255).
			let stop=lnext<prow?lnext:prow;
			let sa=areacon+areatmp;
			sa=sa<alpha?sa:alpha;
			if (sa>0.996079) {
				do {imgdata[pix]=fill;} while (++pix<stop);
			} else if (sa>8e-6) {
				let sr=rmul*sa,sg=gmul*sa,sb=bmul*sa;
				do {
					// a = sa + da*(1-sa)
					// c = (sc*sa + dc*da*(1-sa)) / a
					let col=imgdata[pix];
					let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
					let a=sa+dmul;
					let da=a*255+0.5;a=1/a;
					let dr=(sr+dmul*((col>>>rshift)&255))*a+0.5;
					let dg=(sg+dmul*((col>>>gshift)&255))*a+0.5;
					let db=(sb+dmul*((col>>>bshift)&255))*a+0.5;
					imgdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
				} while (++pix<stop);
			}
		}
	}

}


//---------------------------------------------------------------------------------
// Stress Tests


function FillAccuracyTest() {
	// Create a simple polygon and test fillpoly against a reference.
	//
	// pixel errors:
	// 0 : 1014632647
	// 1 : 10176879
	// 2+: 3003
	// overdraw: 65577838
	//
	// Draw1
	// 0 : 1014632647
	// 1 : 10176879
	// 2+: 3003
	//
	// Draw2
	// 0 : 1014632715
	// 1 : 10176811
	// 2+: 3003
	//
	// 0 : 1024812529
	// 1 : 0
	// 2+: 0
	// overdraw: -603380
	console.log("testing path fill");
	const maxdim=64,maxpixels4=maxdim*maxdim*4;
	const tests=1000000;
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	//let draw=new Draw1(maxdim,maxdim);
	draw.setcolor(0xffffffff);
	let img=draw.img;
	let data=img.data8;
	let orig=new Uint8Array(data.length);
	let rnd=new Random(1);
	function rndexp(dim) {
		// Try to align near integer boundaries to cause overflows.
		let p=rnd.gets()*8;
		let dev=rnd.gets()*Math.pow(2,p*p*p);
		return rnd.mod(dim*3+1)-dim+dev;
	}
	let overdraw=0;
	let pixerr=[0,0,0];
	for (let test=0;test<tests;test++) {
		if ((test%1000)===0) {
			console.log("test:",test,pixerr.toString());
		}
		// Create the image.
		let imgw=rnd.mod(maxdim+1),imgh=rnd.mod(maxdim+1);
		let pixels=imgw*imgh,pixels4=pixels*4;
		img.width=imgw;
		img.height=imgh;
		for (let i=0;i<pixels4;i++) {data[i]=(i&3)<3?0:255;}
		orig.set(data);
		// Create the path.
		let lines=rnd.mod(5)+2;
		let path=new Draw.Path();
		for (let i=0;i<lines;i++) {
			path.lineto(rndexp(imgw),rndexp(imgh));
		}
		//path.close();
		let varr=path.vertarr;
		let area=path.area<0?-255:255;
		// Fill and compare.
		draw.pixcnt=0;
		draw.fillpath(path);
		let cnt=0;
		for (let i=0;i<pixels;i++) {
			let p=i<<2,px=i%imgw,py=~~(i/imgw);
			let r=data[p+0],g=data[p+1],b=data[p+2],a=data[p+3];
			if (r!==g || r!==b || a!==255) {
				console.log(r,g,b,a);
				throw "pixel not monochrome";
			}
			let fill=0,v1=varr[lines-1];
			for (let j=0;j<lines;j++) {
				let v0=v1;v1=varr[j];
				fill+=UnitAreaCalc(v0.x,v0.y,v1.x,v1.y,px,py);
			}
			let col=fill*area;
			cnt+=col>8e-6;
			col=col>  0?col:  0;
			col=col<255?col:255;
			let dif=Math.floor(Math.abs(col-r));
			dif=dif<2?dif:2;
			pixerr[dif]++;
		}
		overdraw+=draw.pixcnt-cnt;
		for (let i=pixels4;i<maxpixels4;i++) {
			if (data[i]!==orig[i]) {
				let p=i>>>2,x=p%imgw,y=~~(p/imgw);
				console.log(imgw,imgh,x,y);
				throw "overflow";
			}
		}
	}
	console.log(`pixel errors:\n0 : ${pixerr[0]}\n1 : ${pixerr[1]}\n2+: ${pixerr[2]}`);
	console.log("overdraw:",overdraw);
}


function FillCrashTest() {
	// Try and crash fillpath() with absurd values.
	console.log("testing path crashing");
	const maxdim=1024;
	const maxsegs=128;
	const tests=1000000;
	let rnd=new Random(1);
	function rndcoord() {
		let degen=rnd.mod(256);
		if (degen<3) {return [NaN,Infinity,-Infinity][degen];}
		let p=rnd.gets()*9;
		let dev=rnd.gets()*Math.pow(2,p*p*p);
		return rnd.mod(200)-100+dev;
	}
	// Drawing environment.
	let draw=new Draw(maxdim,maxdim);
	//let draw=new Draw1(maxdim,maxdim);
	let img=draw.img;
	draw.setcolor(0xffffffff);
	let maxlines=0;
	for (let test=0;test<tests;test++) {
		if ((test%10000)===0) {
			console.log("test:",test,maxlines);
		}
		img.width=rnd.mod(maxdim+1);
		img.height=rnd.mod(maxdim+1);
		// Create the path.
		let segs=rnd.mod(maxsegs+1);
		let path=new Draw.Path();
		for (let i=0;i<segs;i++) {
			let type=rnd.mod(8);
			if (type<1 || !i) {
				path.moveto(rndcoord(),rndcoord());
			} else if (type<2) {
				path.close();
			} else if (type<4) {
				path.lineto(rndcoord(),rndcoord());
			} else if (type<6) {
				path.curveto(rndcoord(),rndcoord(),rndcoord(),
			                  rndcoord(),rndcoord(),rndcoord());
			}
		}
		//if (test!==1981) {continue;}
		//console.log(path.tostring());
		if (path.vertidx>0 && path.vertarr[0].type!==Draw.Path.MOVE) {
			console.log("first type not moveto");
			throw "error";
		}
		draw.fillpath(path);
		let lines=draw.tmpline.length;
		if (maxlines<lines) {
			maxlines=lines;
			console.log("max line:",maxlines);
		}
	}
}


function FillPathDisplay() {
	// Displays an animated drawimage().
	// Create and center the canvas.
	let canvas=document.createElement("canvas");
	document.body.appendChild(canvas);
	let imgw=1000,imgh=800;
	let style=canvas.style;
	canvas.width=imgw;
	canvas.height=imgh;
	style.background="#000000";
	style.position="absolute";
	style.width =imgw+"px";
	style.height=imgh+"px";
	style.left=(window.innerWidth -imgw)*0.5+"px";
	style.top =(window.innerHeight-imgh)*0.5+"px";
	let draw=new Draw(canvas);
	//let draw=new Draw1(canvas);
	let input=new Input(canvas);
	let rnd=new Random();
	// Generate our source path.
	let r=.375,s=.275;
	let path=new Draw.Path(`
		M.35.9V.35H.9V.9ZM1 .25H.25V1H1Zm-2-.5h.75V-1H-1Z
		m.95.2H-1v.1h.95V1h.1V.05H1v-.1H.05V-1h-.1Z
	`);
	path.addoval(r-1,1-r,-r,r).addoval(1-r,r-1,-r,r).addoval(1-r,r-1,s,s);
	let trans=new Transform({scale:[50,30]});
	function update() {
		requestAnimationFrame(update);
		if (!Env.IsVisible(canvas)) {return;}
		input.update();
		draw.fill(0,0,0,255);
		draw.setcolor(40,80,40,255);
		let dim=50;
		for (let y=0;y<imgh;y+=dim) {
			for (let x=0;x<imgw;x+=dim) {
				if ((x+y)%(2*dim)) {
					draw.fillrect(x,y,dim,dim);
				}
			}
		}
		// Randomize transform.
		if (input.getkeychange(input.MOUSE.LEFT)>0 || input.getkeychange(input.KEY.SPACE)>0) {
			for (let i=0;i<4;i++) {
				trans.mat[i]=rnd.gets()*Math.pow(2,rnd.gets()*5)*15;
			}
		}
		trans.vec.set(input.getmousepos());
		let time=performance.now();
		draw.setcolor(255,0,255,255);
		draw.fillpath(path,trans);
		time=(performance.now()-time)*0.001;
		draw.setcolor(255,255,255,255);
		draw.filltext(5,5,"Click to transform",20);
		draw.filltext(5,30,"Time: "+time.toFixed(6),20);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


//---------------------------------------------------------------------------------
// Speed Tests


function RectStressTest() {
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	//let draw=new Draw1();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.fillrect(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("rect: "+time.toFixed(6));
}


function OvalStressTest() {
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	//let draw=new Draw1();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=100000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let xrad=Math.pow(2,rnd.getf()*10);
		let yrad=Math.pow(2,rnd.getf()*10);
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		draw.filloval(x,y,xrad,yrad);
	}
	time=(performance.now()-time)/1000;
	console.log("oval: "+time.toFixed(6));
}


function LineStressTest() {
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	//let draw=new Draw1();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=200000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x0=(rnd.getf()*3-1)*imgwidth;
		let y0=(rnd.getf()*3-1)*imgheight;
		let x1=(rnd.getf()*3-1)*imgwidth;
		let y1=(rnd.getf()*3-1)*imgheight;
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			x1=x0+(rnd.getf()*2-1)*dev;
		}
		if (rnd.getf()<0.25) {
			let dev=rnd.mod(30);
			dev=dev>16?0:(1/(1<<dev));
			y1=y0+(rnd.getf()*2-1)*dev;
		}
		draw.linewidth=rnd.getf()*10;
		draw.drawline(x0,y0,x1,y1);
	}
	time=(performance.now()-time)/1000;
	console.log("line: "+time.toFixed(6));
}


function CharStressTest() {
	let rnd=new Random(10);
	let imgwidth=259;
	let imgheight=257;
	let img=new Draw.Image(imgwidth,imgheight);
	let draw=new Draw();
	//let draw=new Draw1();
	draw.setimage(img);
	let data32=draw.img.data32,datalen=data32.length;
	for (let i=0;i<datalen;i++) {data32[i]=rnd.getu32();}
	let tests=2000000;
	let text=" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~█";
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		draw.rgba32[0]=rnd.getu32();
		let x=(rnd.getf()*3-1)*imgwidth;
		let y=(rnd.getf()*3-1)*imgheight;
		let c=text[test%text.length];
		let s=rnd.getf()*32;
		draw.filltext(x,y,c,s);
	}
	time=(performance.now()-time)/1000;
	console.log("char: "+time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	console.log("fillpath");
	//FillAccuracyTest();
	//FillCrashTest();
	FillPathDisplay();
	//RectStressTest();
	//OvalStressTest();
	//LineStressTest();
	//CharStressTest();
	console.log("done");
}
TestMain();

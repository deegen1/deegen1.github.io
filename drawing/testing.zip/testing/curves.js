/*

Bezier Segmentation Tests
Need at least 3 interpolation points to catch all cubic bezier cases.

Score = (estimated_length/actual_length)/segments
sqrt(curvedist)/segments
score=segments*(maxdist+1)


a=t0*t1
b=2*u0*t1+t0*u1
c=2*t0*u1+u0*t1
d=u0*u1
let c1x=(t0*a)*p0x+(t0*b)*n0x+(u0*c)*n1x+(u0*d)*p1x;
let c2x=(t1*a)*p0x+(t1*c)*n0x+(u1*b)*n1x+(u1*d)*p1x;

//let c1x=(t0*t0*t1)*p0x+(u0*t0*t1+t0*u0*t1+t0*t0*u1)*n0x+(u0*u0*t1+t0*u0*u1+u0*t0*u1)*n1x+u0*u0*u1*p1x;
//let c2x=(t0*t1*t1)*p0x+(u0*t1*t1+t0*u1*t1+t0*t1*u1)*n0x+(u0*u1*t1+t0*u1*u1+u0*t1*u1)*n1x+u0*u1*u1*p1x;


*/
/* npx eslint curves.js -c ../../../standards/eslint.js */


import {Random} from "../library.js";


function BezierSegment1(curve,splitlen=3) {
	let p0x=curve[0],p0y=curve[1];
	let c1x=curve[2],c1y=curve[3];
	let c2x=curve[4],c2y=curve[5];
	let p1x=curve[6],p1y=curve[7];
	let c3x=p1x,c3y=p1y;
	// Estimate bezier length.
	let dist,dx,dy;
	dx=c1x-p0x;dy=c1y-p0y;dist =Math.sqrt(dx*dx+dy*dy);
	dx=c2x-c1x;dy=c2y-c1y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=c3x-c2x;dy=c3y-c2y;dist+=Math.sqrt(dx*dx+dy*dy);
	dx=p0x-c3x;dy=p0y-c3y;dist+=Math.sqrt(dx*dx+dy*dy);
	let segs=Math.ceil(dist*0.5/splitlen+1e-10);
	// Segment the curve.
	let lr=[];
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let ppx=p0x,ppy=p0y,unorm=1.0/segs,u=0;
	for (let s=0;s<segs;s++) {
		let lu=u,lx=ppx,ly=ppy;
		u+=unorm;
		ppx=p0x+u*(c1x+u*(c2x+u*c3x));
		ppy=p0y+u*(c1y+u*(c2y+u*c3y));
		lr.push({x0:lx,y0:ly,x1:ppx,y1:ppy,u0:lu,u1:u});
	}
	let l=lr[lr.length-1];
	l.u1=1;
	l.x1=curve[6];
	l.y1=curve[7];
	return lr;
}


function BezierSegment2(curve,cutoff,type,segments) {
	let p0x=curve[0],p0y=curve[1];
	let c1x=curve[2],c1y=curve[3];
	let c2x=curve[4],c2y=curve[5];
	let p1x=curve[6],p1y=curve[7];
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let den=(dx*dx+dy*dy)*cutoff;
		if (den<1e-9) {den=cutoff;dx=1;dy=0;}
		let u0=l.u0,u1=l.u1;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<segments;s++) {
			let u=u0+(u1-u0)*((s+1)/(segments+1));
			let ix=p0x+u*(c1x+u*(c2x+u*c3x));
			let iy=p0y+u*(c1y+u*(c2y+u*c3y));
			let num=dy*(ix-x0)-dx*(iy-y0);
			let dist=num*num;
			if (mindist>dist) {
				mindist=dist;
				minu=u;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u;
			}
		}
		console.log("maxdist:",maxdist);
		if (maxdist>den) {
			// we're outside the bounds
			let u=[(u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment3(curve,cutoff,type,samples) {
	// cutoff  = cutoff distance squared
	// samples = how many points on segment to sample
	// type 0  = split at 0.5
	//      1  = split at minimum distance
	//      2  = split at maximum distance
	let p0x=curve[0],p0y=curve[1];
	let c1x=curve[2],c1y=curve[3];
	let c2x=curve[4],c2y=curve[5];
	let p1x=curve[6],p1y=curve[7];
	let c3x=p1x,c3y=p1y;
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y,u0:0,u1:1}];
	// Segment the curve.
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;c3x-=p0x+c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;c3y-=p0y+c2y;c2y-=c1y;
	let lend=1;
	for (let j=0;j<lend;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		let l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.u0,u1=l.u1,du=(u1-u0)/(samples+1);
		let den=dx*dx+dy*dy;
		let minu=0.5,mindist=Infinity;
		let maxu=0.5,maxdist=-Infinity;
		for (let s=0;s<samples;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (mindist>dist) {
				mindist=dist;
				minu=u0;
			}
			if (maxdist<dist) {
				maxdist=dist;
				maxu=u0;
			}
		}
		if (maxdist>cutoff && maxdist<Infinity) {
			// The line is too far from the curve, split it.
			let u=[(l.u0+u1)*0.5,minu,maxu][type];
			let hx=p0x+u*(c1x+u*(c2x+u*c3x));
			let hy=p0y+u*(c1y+u*(c2y+u*c3y));
			lr.push({x0:hx,y0:hy,x1:x1,y1:y1,u0:u,u1:u1});
			l.x1=hx;
			l.y1=hy;
			l.u1=u;
			lend++;
			j--;
		}
	}
	return lr;
}


function BezierSegment4(curve,curvemaxdist2=0.01) {
	// Sample-and-divide test.
	let p0x=curve[0],p0y=curve[1];
	let c1x=curve[2],c1y=curve[3];
	let c2x=curve[4],c2y=curve[5];
	let p1x=curve[6],p1y=curve[7];
	let lr=[{x0:p0x,y0:p0y,x1:p1x,y1:p1y}];
	let lcnt=1;
	let l=lr[0];
	// Segment the curve.
	l.amul=0;l.area=1;
	c2x=(c2x-c1x)*3;c1x=(c1x-p0x)*3;let c3x=p1x-p0x-c2x;c2x-=c1x;
	c2y=(c2y-c1y)*3;c1y=(c1y-p0y)*3;let c3y=p1y-p0y-c2y;c2y-=c1y;
	for (let j=lcnt-1;j<lcnt;j++) {
		// For each line segment between [u0,u1], sample the curve at a few spots between
		// u0 and u1 and measure the distance to the line. If it's too great, split.
		l=lr[j];
		let x0=l.x0,x1=l.x1,dx=x1-x0;
		let y0=l.y0,y1=l.y1,dy=y1-y0;
		let u0=l.amul,u1=l.area,du=(u1-u0)*0.25;
		let den=dx*dx+dy*dy;
		let maxdist=-Infinity,mu=0,mx=0,my=0;
		for (let s=0;s<3;s++) {
			// Project a point on the curve onto the line. Clamp to ends of line.
			u0+=du;
			let sx=p0x+u0*(c1x+u0*(c2x+u0*c3x)),lx=sx-x0;
			let sy=p0y+u0*(c1y+u0*(c2y+u0*c3y)),ly=sy-y0;
			let v=dx*lx+dy*ly;
			v=v>0?(v<den?v/den:1):0;
			lx-=dx*v;
			ly-=dy*v;
			let dist=lx*lx+ly*ly;
			if (maxdist<dist) {
				maxdist=dist;
				mu=u0;
				mx=sx;
				my=sy;
			}
		}
		if (maxdist>curvemaxdist2 && maxdist<Infinity) {
			// The line is too far from the curve, so split it.
			lr.push({});
			l.x1=mx;
			l.y1=my;
			l.area=mu;
			l=lr[lcnt++];
			l.x0=mx;
			l.y0=my;
			l.x1=x1;
			l.y1=y1;
			l.amul=mu;
			l.area=u1;
			j--;
		}
	}
	for (l of lr) {l.u0=l.amul;l.u1=l.area;}
	return lr;
}


function BezierSegment5(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let k0x=curve[0],k0y=curve[1];
	let k1x=curve[2],k1y=curve[3];
	let k2x=curve[4],k2y=curve[5];
	let k3x=curve[6],k3y=curve[7];
	let lr=[{
		x0:k0x,y0:k0y,
		x1:k3x,y1:k3y,
		x2:k1x,y2:k1y,
		x3:k2x,y3:k2y,
		u0:0,u1:1
	}];
	let lcnt=1;
	// Segment the curve.
	for (let j=lcnt-1;j<lcnt;j++) {
		// The curve will stay inside the bounding box of [c0,c1,c2,c3].
		// If the subcurve is outside the image, stop subdividing.
		let l=lr[j];
		let c3x=l.x1,c2x=l.x3,c1x=l.x2,c0x=l.x0;
		let c3y=l.y1,c2y=l.y3,c1y=l.y2,c0y=l.y0;
		/*if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
		    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
			continue;
		}*/
		let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
		// Test if both control points are close to the line c0->c3.
		// Clamp to ends and filter degenerates.
		let lx=c1x-c0x,ly=c1y-c0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=c2x-c0x;ly=c2y-c0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [c0,c1,c2,c3] = [c0,l1,l2,ph] + [ph,r1,r2,c3]
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		lr.push({}); // remove
		let u0=l.u0,u1=l.u1,uh=(u0+u1)*0.5; // remove
		let l1x=(c0x+c1x)*0.5,l1y=(c0y+c1y)*0.5;
		let t1x=(c1x+c2x)*0.5,t1y=(c1y+c2y)*0.5;
		let r2x=(c2x+c3x)*0.5,r2y=(c2y+c3y)*0.5;
		let l2x=(l1x+t1x)*0.5,l2y=(l1y+t1y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		let phx=(l2x+r1x)*0.5,phy=(l2y+r1y)*0.5;
		l.x1=phx;l.x3=l2x;l.x2=l1x;
		l.y1=phy;l.y3=l2y;l.y2=l1y;
		l.u1=uh; // remove
		l=lr[lcnt++];
		l.x1=c3x;l.x3=r2x;l.x2=r1x;l.x0=phx;
		l.y1=c3y;l.y3=r2y;l.y2=r1y;l.y0=phy;
		l.u1=u1;l.u0=uh; // remove
		j--;
	}
	return lr;
}


function BezierSegment6(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	// Uses fewer variables.
	let p0x=curve[0],p0y=curve[1];
	let n0x=curve[2],n0y=curve[3];
	let n1x=curve[4],n1y=curve[5];
	let p1x=curve[6],p1y=curve[7];
	let lr=[{
		u0:0,u1:1,
		x0:p0x,y0:p0y,
		x1:p1x,y1:p1y
	}];
	let lcnt=1;
	// Segment the curve.
	let q1x=n0x-p0x,q2x=n1x-p0x-2*q1x,q3x=p1x-p0x+3*(n0x-n1x);
	let q1y=n0y-p0y,q2y=n1y-p0y-2*q1y,q3y=p1y-p0y+3*(n0y-n1y);
	for (let j=lcnt-1;j<lcnt;j++) {
		if (lcnt>10000) {throw "lcnt too high";}
		// The curve will stay inside the bounding box of [c0,c1,c2,c3].
		// If the subcurve is outside the image, stop subdividing.
		// Given u0,u1 calculate c1,c2.
		let l=lr[j];
		//let c0x=l.x0,c0y=l.y0,u0=l.u0;
		//let c3x=l.x1,c3y=l.y1,u1=l.u1;
		//let t0=1-u0,t1=1-u1;
		//let c1x=(t0*t0*t1)*p0x+(u0*t0*t1+t0*u0*t1+t0*t0*u1)*n0x+(u0*u0*t1+t0*u0*u1+u0*t0*u1)*n1x+u0*u0*u1*p1x;
		//let c2x=(t0*t1*t1)*p0x+(u0*t1*t1+t0*u1*t1+t0*t1*u1)*n0x+(u0*u1*t1+t0*u1*u1+u0*t1*u1)*n1x+u0*u1*u1*p1x;
		//let c1y=(t0*t0*t1)*p0y+(u0*t0*t1+t0*u0*t1+t0*t0*u1)*n0y+(u0*u0*t1+t0*u0*u1+u0*t0*u1)*n1y+u0*u0*u1*p1y;
		//let c2y=(t0*t1*t1)*p0y+(u0*t1*t1+t0*u1*t1+t0*t1*u1)*n0y+(u0*u1*t1+t0*u1*u1+u0*t1*u1)*n1y+u0*u1*u1*p1y;
		let c0x=l.x0,c0y=l.y0,u0=l.u0;
		let c3x=l.x1,c3y=l.y1,u1=l.u1;
		let u2=2*u0+u1,u3=u0+2*u1,u4=u0*u1;
		let c1x=p0x+u2*q1x+u0*(u3*q2x+u4*q3x);
		let c1y=p0y+u2*q1y+u0*(u3*q2y+u4*q3y);
		let c2x=p0x+u3*q1x+u1*(u2*q2x+u4*q3x);
		let c2y=p0y+u3*q1y+u1*(u2*q2y+u4*q3y);
		/*if ((c0x<=0 && c1x<=0 && c2x<=0 && c3x<=0) || (c0x>=iw && c1x>=iw && c2x>=iw && c3x>=iw) ||
		    (c0y<=0 && c1y<=0 && c2y<=0 && c3y<=0) || (c0y>=ih && c1y>=ih && c2y>=ih && c3y>=ih)) {
			continue;
		}*/
		let dx=c3x-c0x,dy=c3y-c0y,den=dx*dx+dy*dy;
		// Test if both control points are close to the line c0->c3.
		// Clamp to ends and filter degenerates.
		let lx=c1x-c0x,ly=c1y-c0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=c2x-c0x;ly=c2y-c0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half.
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		lr.push({}); // remove
		let uh=(u0+u1)*0.5;
		//let v=1-h;
		//let hx=v*v*v*p0x+3*v*v*h*n0x+3*v*h*h*n1x+h*h*h*p1x;
		//let hy=v*v*v*p0y+3*v*v*h*n0y+3*v*h*h*n1y+h*h*h*p1y;
		let hx=p0x+uh*(3*q1x+uh*(3*q2x+uh*q3x));
		let hy=p0y+uh*(3*q1y+uh*(3*q2y+uh*q3y));
		l.x1=hx;
		l.y1=hy;
		l.u1=uh;
		l=lr[lcnt++];
		l.x0=hx;l.x1=c3x;
		l.y0=hy;l.y1=c3y;
		l.u0=uh;l.u1=u1;
		j--;
	}
	return lr;
}


function BezierSegment7(curve,curvemaxdist2=0.02) {
	// Curve subdivision. Allows tracking bounding box.
	let p0x=curve[0],p0y=curve[1];
	let p1x=curve[2],p1y=curve[3];
	let p2x=curve[4],p2y=curve[5];
	let p3x=curve[6],p3y=curve[7];
	let u0=0,u1=1;
	let lr=[];
	let ci=0,cprev=-1;
	let cv=[];
	// Segment the curve.
	while (true) {
		// The curve will stay inside the bounding box of [p0,p1,p2,p3].
		// If the subcurve is outside the image, stop subdividing.
		if (cprev===ci) {
			lr.push({u0:u0,u1:u1,x0:p0x,y0:p0y,x1:p3x,y1:p3y});
			if (!ci) {break;}
			u0=u1;u1=cv[--ci];
			p0x=p3x;p1x=cv[--ci];p2x=cv[--ci];p3x=cv[--ci];
			p0y=p3y;p1y=cv[--ci];p2y=cv[--ci];p3y=cv[--ci];
		}
		cprev=ci;
		/*if ((p0x<=0 && p1x<=0 && p2x<=0 && p3x<=0) || (p0x>=iw && p1x>=iw && p2x>=iw && p3x>=iw) ||
		    (p0y<=0 && p1y<=0 && p2y<=0 && p3y<=0) || (p0y>=ih && p1y>=ih && p2y>=ih && p3y>=ih)) {
			continue;
		}*/
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let dx=p3x-p0x,dy=p3y-p0y,den=dx*dx+dy*dy;
		let lx=p1x-p0x,ly=p1y-p0y;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=p2x-p0x;ly=p2y-p0y;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {continue;}
		// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
		/*if (lrcnt<=lcnt) {
			lr=this.fillresize(lcnt+1);
			lrcnt=lr.length;
		}*/
		let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
		let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		cv.push([0,0,0,0,0,0,0,0]);
		cv[ci++]=p3y;cv[ci++]=r2y;cv[ci++]=r1y;
		cv[ci++]=p3x;cv[ci++]=r2x;cv[ci++]=r1x;
		cv[ci++]=u1;
		p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
		p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
		p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
		u1=(u0+u1)*0.5;
	}
	return lr;
}


function BezierSegment8(curve,curvemaxdist2=0.02,imgw,miny,maxy) {
	// Curve subdivision. Allows tracking bounding box.
	let x0=curve[0],y0=curve[1];
	let x1=curve[2],y1=curve[3];
	let x2=curve[4],y2=curve[5];
	let x3=curve[6],y3=curve[7];
	let u0=0,u1=1;
	let lr=[];
	function extend() {
		lr.push({u0:0,u1:0,x0:0,y0:0,x1:0,y1:0,x2:0,y2:0,next:0});
	}
	extend();
	let l=lr[0];
	let lrcnt=1,lcnt=1;
	// Segment the curve.
	let next=-1,next0=0;
	while (true) {
		if (lcnt>10000) {throw "too deep";}//remove
		// The curve will stay inside the bounding box of [0,1,2,3].
		// If the subcurve is outside the image, stop subdividing.
		if (next===next0) {
			//subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>miny?4:0)|(y0<maxy?8:0);
			l.x0=x0;l.y0=y0;
			l.x1=x3;l.y1=y3;
			l.u0=u0;l.u1=u1;//remove
			if (next<0) {break;}
			l=lr[next];
			u0=u1;u1=l.u1;//remove
			next=l.next;
			x0=x3;x1=l.x0;x2=l.x1;x3=l.x2;
			y0=y3;y1=l.y0;y2=l.y1;y3=l.y2;
		}
		next0=next;
		if (!(x0>0 || x1>0 || x2>0 || x3>0)
		||  !(x0<imgw || x1<imgw || x2<imgw || x3<imgw)
		||  !(y0>miny || y1>miny || y2>miny || y3>miny)
		||  !(y0<maxy || y1<maxy || y2<maxy || y3<maxy)
		) {continue;}
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let dx=x3-x0,dy=y3-y0;
		let lx=x1-x0,ly=y1-y0;
		let d=dx*dx+dy*dy;
		let u=dx*lx+dy*ly;
		u=u>0?(u<d?u/d:1):0;
		lx-=dx*u;ly-=dy*u;
		let a=lx*lx+ly*ly;
		lx=x2-x0;ly=y2-y0;
		u=dx*lx+dy*ly;
		u=u>0?(u<d?u/d:1):0;
		lx-=dx*u;ly-=dy*u;
		let b=lx*lx+ly*ly;
		d=(a>b || !(a===a))?a:b;
		if (!(d>curvemaxdist2 && d<Infinity)) {continue;}
		// Split the curve in half. [0,1,2,3] = [0,1h,2h,3h] + [3h,4,5,3]
		if (lrcnt<=lcnt) {
			extend();
			lrcnt=lr.length;
		}
		let xt=(x1+x2)*0.5,yt=(y1+y2)*0.5;
		let x5=(x2+x3)*0.5,y5=(y2+y3)*0.5;
		let x4=(xt+x5)*0.5,y4=(yt+y5)*0.5;
		let n=lr[lcnt];
		n.u1=u1;//remove
		n.next=next;
		n.x0=x4;n.x1=x5;n.x2=x3;
		n.y0=y4;n.y1=y5;n.y2=y3;
		x1=(x0+x1)*0.5;y1=(y0+y1)*0.5;
		x2=(x1+xt)*0.5;y2=(y1+yt)*0.5;
		x3=(x2+x4)*0.5;y3=(y2+y4)*0.5;
		u1=(u0+u1)*0.5;//remove
		next=lcnt++;
	}
	for (let i=1;i<lcnt;i++) {
		let j=i,m=lr[i],n,u=m.u0;
		while (j>0 && (n=lr[j-1]).u0>u) {lr[j--]=n;}
		lr[j]=m;
		//if (m.next!==0) {throw "next";}
	}
	return lr;
}


function BezierSegment9(curve,curvemaxdist2=0.02) {
	// V9: Shorter variable names. Used for pointinside() test.
	// Curve subdivision. Allows tracking bounding box.
	let x0=curve[0],y0=curve[1];
	let x1=curve[2],y1=curve[3];
	let x2=curve[4],y2=curve[5];
	let x3=curve[6],y3=curve[7];
	let u0=0,u1=1;
	let d=10;
	let c=new Array();
	function extend() {
		let l=d+10;
		if (l>10000000) {throw "length";}
		if (l<c.length) {
			l+=l;
			while (c.length<l) {c.push(0);}
		}
	}
	extend();
	// Segment the curve.
	let pop=false;
	let n=0;
	while (true) {
		// The curve will stay inside the bounding box of [p0,p1,p2,p3].
		// If the subcurve is outside the image, stop subdividing.
		if (pop) {
			//subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>min?4:0)|(y0<max?8:0);
			pop=false;
			c[n++]=x0;c[n++]=x1;c[n++]=x2;c[n++]=x3;
			c[n++]=y0;c[n++]=y1;c[n++]=y2;c[n++]=y3;
			c[n++]=u0;c[n++]=u1;
			if (n>=d) {break;}
			let e=n+10;
			u1=c[--e];u0=c[--e];
			y3=c[--e];y2=c[--e];y1=c[--e];y0=c[--e];
			x3=c[--e];x2=c[--e];x1=c[--e];x0=c[  e];
		}
		/*if ((x0<=0 && x1<=0 && x2<=0 && x3<=0) || (x0>=iw && x1>=iw && x2>=iw && x3>=iw) ||
		    (y0<=0 && y1<=0 && y2<=0 && y3<=0) || (y0>=ih && y1>=ih && y2>=ih && y3>=ih)) {
			continue;
		}*/
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let dx=x3-x0,dy=y3-y0,den=dx*dx+dy*dy;
		let lx=x1-x0,ly=y1-y0;
		let u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d1=lx*lx+ly*ly;
		lx=x2-x0;ly=y2-y0;
		u=dx*lx+dy*ly;
		u=u>0?(u<den?u/den:1):0;
		lx-=dx*u;ly-=dy*u;
		let d2=lx*lx+ly*ly;
		d1=(d1>d2 || !(d1===d1))?d1:d2;
		if (!(d1>curvemaxdist2 && d1<Infinity)) {pop=true;continue;}
		// Split the curve in half: [0,1,2,3] = [0,1,2,3] + [3,4,5,6]
		let xt=(x1+x2)*0.5,yt=(y1+y2)*0.5;
		let x5=(x2+x3)*0.5,y5=(y2+y3)*0.5;
		let x4=(xt+x5)*0.5,y4=(yt+y5)*0.5;
		let x6=x3,y6=y3;
		let u2=u1;//
		u1=(u0+u1)*0.5;//
		x1=(x0+x1)*0.5;y1=(y0+y1)*0.5;
		x2=(x1+xt)*0.5;y2=(y1+yt)*0.5;
		x3=(x2+x4)*0.5;y3=(y2+y4)*0.5;
		extend();
		c[d++]=x3;c[d++]=x4;c[d++]=x5;c[d++]=x6;
		c[d++]=y3;c[d++]=y4;c[d++]=y5;c[d++]=y6;
		c[d++]=u1;c[d++]=u2;//
	}
	let lr=new Array(~~(d/10));
	for (let i=0,p=0;p<d;i++,p+=10) {
		u0=c[p+8];
		let j=i,l;
		while (j>0 && (l=lr[j-1]).u0>u0) {lr[j--]=l;}
		lr[j]={
			u0:u0    ,u1:c[p+9],
			x0:c[p+0],y0:c[p+4],
			x1:c[p+3],y1:c[p+7]
		};
	}
	return lr;
}


function BezierSegment10(curve) {
	// Curve subdivision. Allows tracking bounding box.
	let p0x=curve[0],p0y=curve[1];
	let p1x=curve[2],p1y=curve[3];
	let p2x=curve[4],p2y=curve[5];
	let p3x=curve[6],p3y=curve[7];
	let u0=0,u1=1;
	let lr=[];
	function extend() {
		lr.push({u0:0,u1:0,x0:0,y0:0,x1:0,y1:0,x2:0,y2:0,sort:0});
	}
	extend();
	let l=lr[0];
	let lrcnt=1,lcnt=1;
	// Segment the curve.
	function calc(x0,y0,x1,y1) {
		x1-=x0;y1-=y0;
		return Math.sqrt(x1*x1+y1*y1);
		//return Math.abs(x1)+Math.abs(y1);
	}
	let next=-1,next0=0;
	while (true) {
		if (lcnt>10000) {throw "too deep";} /////////
		// The curve will stay inside the bounding box of [p0,p1,p2,p3].
		// If the subcurve is outside the image, stop subdividing.
		if (next===next0) {
			//subbnd|=(x0>0?1:0)|(x0<imgw?2:0)|(y0>min?4:0)|(y0<max?8:0);
			l.sort=0;
			l.x0=p0x;l.y0=p0y;
			l.x1=p3x;l.y1=p3y;
			l.u0=u0;l.u1=u1;//
			if (next<0) {break;}
			l=lr[next];
			u0=u1;u1=l.u1;//
			next=l.sort;
			p0x=p3x;p1x=l.x0;p2x=l.x1;p3x=l.x2;
			p0y=p3y;p1y=l.y0;p2y=l.y1;p3y=l.y2;
		}
		next0=next;
		/*if ((p0x<=0 && p1x<=0 && p2x<=0 && p3x<=0) || (p0x>=iw && p1x>=iw && p2x>=iw && p3x>=iw) ||
		    (p0y<=0 && p1y<=0 && p2y<=0 && p3y<=0) || (p0y>=ih && p1y>=ih && p2y>=ih && p3y>=ih)) {
			continue;
		}*/
		// Test if both control points are close to the line p0->p3.
		// Clamp to ends and filter degenerates.
		let ld=calc(p0x,p0y,p1x,p1y)+calc(p1x,p1y,p2x,p2y)+calc(p2x,p2y,p3x,p3y);
		let rd=calc(p0x,p0y,p3x,p3y);
		if (!(ld>rd+0.01 && ld<Infinity)) {continue;}
		// Split the curve in half. [p0,p1,p2,p3] = [p0,l1,l2,ph] + [ph,r1,r2,p3]
		if (lrcnt<=lcnt) {
			extend();
			lrcnt=lr.length;
		}
		let t1x=(p1x+p2x)*0.5,t1y=(p1y+p2y)*0.5;
		let r2x=(p2x+p3x)*0.5,r2y=(p2y+p3y)*0.5;
		let r1x=(t1x+r2x)*0.5,r1y=(t1y+r2y)*0.5;
		let n=lr[lcnt];
		n.u1=u1;//
		n.sort=next;
		n.x0=r1x;n.x1=r2x;n.x2=p3x;
		n.y0=r1y;n.y1=r2y;n.y2=p3y;
		p1x=(p0x+p1x)*0.5;p1y=(p0y+p1y)*0.5;
		p2x=(p1x+t1x)*0.5;p2y=(p1y+t1y)*0.5;
		p3x=(p2x+r1x)*0.5;p3y=(p2y+r1y)*0.5;
		u1=(u0+u1)*0.5;//
		next=lcnt++;
	}
	for (let i=1;i<lcnt;i++) {
		let j=i,m=lr[i],n,u=m.u0;
		while (j>0 && (n=lr[j-1]).u0>u) {
			lr[j--]=n;
		}
		lr[j]=m;
		if (m.sort!==0) {throw "sort";}
	}
	return lr;
}


function BezierSegment11(curve,curvemaxdist2,imgw,miny,maxy) {
	// Curve subdivision. Allows tracking bounding box.
	let x0=curve[0],y0=curve[1];
	let x1=curve[2],y1=curve[3];
	let x2=curve[4],y2=curve[5];
	let x3=curve[6],y3=curve[7];
	let loops=0;
	let lr=[];
	function fillextend() {
		lr.push({next:0,u0:0,u1:0,x0:0,y0:0,x1:0,y1:0});
	}
	fillextend();
	let lcnt=1,lrcnt=lr.length,l=lr[0];
	// Segment the curve
	let next=-1;
	let x4=x0,y4=y0,u0=0,u1=1;
	let a4=x0,b4=y0,a5=x1,b5=y1;
	while (true) {
		// Given u0 and u1, calculate control points (p5,p6) and endpoint p7.
		let v0=1-u0,v1=1-u1,a6,a7,a8,b6,b7,b8;
		a6=v1*x0+u1*x1;a7=v1*x1+u1*x2;a8=v1*x2+u1*x3;
		b6=v1*y0+u1*y1;b7=v1*y1+u1*y2;b8=v1*y2+u1*y3;
		a6=v1*a6+u1*a7;a7=v1*a7+u1*a8;
		b6=v1*b6+u1*b7;b7=v1*b7+u1*b8;
		let x5=v1*a4+u1*a5,y5=v1*b4+u1*b5;
		let x6=v0*a6+u0*a7,y6=v0*b6+u0*b7;
		let x7=v1*a6+u1*a7,y7=v1*b6+u1*b7;
		if (u1>=1) {x7=x3;y7=y3;}
		if (++loops>100000) {//remove
			console.log("cnt:",lcnt,loops);
			console.log("bnd:",imgw,miny,maxy);
			console.log("4:",x4,y4);
			console.log("5:",x5,y5);
			console.log("6:",x6,y6);
			console.log("7:",x7,y7);
			console.log("u:",u0,u1);
			console.log("curve:",curve);
			throw "too deep";
		}
		// If the subcurve is inside the image and u1-u0 hasn't collapsed, subdivide.
		if ((y4>miny || y5>miny || y6>miny || y7>miny)
		&&  (y4<maxy || y5<maxy || y6<maxy || y7<maxy)
		&&  (x4<imgw || x5<imgw || x6<imgw || x7<imgw)
		&&  (x4>0 || x5>0 || x6>0 || x7>0) && u1-u0>1e-4) {
			// Test if both control points are close to the line p4->p7.
			// Clamp to ends and filter degenerates.
			let dx=x7-x4,dy=y7-y4;
			let lx=x5-x4,ly=y5-y4;
			let d=dx*dx+dy*dy;
			let u=dx*lx+dy*ly;
			u=u>0?(u<d?u/d:1):0;
			lx-=dx*u;ly-=dy*u;
			let a=lx*lx+ly*ly;
			lx=x6-x4;ly=y6-y4;
			u=dx*lx+dy*ly;
			u=u>0?(u<d?u/d:1):0;
			lx-=dx*u;ly-=dy*u;
			let b=lx*lx+ly*ly;
			d=a>b?a:b;
			if (d>curvemaxdist2) {
				if (lrcnt<=lcnt) {
					fillextend();
					lrcnt=lr.length;
				}
				let m=lr[lcnt];
				m.next=next;
				next=lcnt++;
				m.x0=u1;
				u1=(u0+u1)*0.5;
				//u1=u0+(u1-u0)*(0.1+0.8*(a<d?a/d:1));
				//d=a+b;
				//u1=u0+(u1-u0)*(0.9-0.8*(a<d?a/d:0.5));
				continue;
			}
		}
		// Commit this segment of the curve.
		//subbnd|=(x4>0?1:0)|(x4<imgw?2:0)|(y4>miny?4:0)|(y4<maxy?8:0);
		l.u0=u0;l.u1=u1;//remove
		l.x0=x4;l.y0=y4;
		l.x1=x7;l.y1=y7;
		if (next<0) {break;}
		l=lr[next];
		next=l.next;
		u0=u1;u1=l.x0;
		x4=x7;y4=y7;
		a4=a6;b4=b6;
		a5=a7;b5=b7;
	}
	for (let i=1;i<lcnt;i++) {
		let j=i,m=lr[i],n,u=m.u0;
		while (j>0 && (n=lr[j-1]).u0>u) {lr[j--]=n;}
		lr[j]=m;
	}
	return lr;
}


function BezierSegmentTest() {
	// test
	//      u0,u1 is consecutive and covers [0,1]
	//      endpoints match curve(u)
	//      intermediate points based on distance, at least 10
	let rnd=new Random(9876);
	let curve=new Float64Array(8);
	let sumdist=0,sumsegs=0,maxdist=0,sumden=0,maxsegs=0;
	let score=0;
	function getcoord() {
		let degen=rnd.mod(64);
		if (degen<4) {return [0,NaN,Infinity,-Infinity][degen];}
		let p=rnd.gets()*9;
		return rnd.mod(200)-100+rnd.gets()*Math.pow(2,p*p*p);
		//return rnd.mod(200)-100+rnd.gets()*Math.pow(2,rnd.gets()*10);
	}
	for (let test=0;test<10000000;test++) {
		if (!(test%100000)) {console.log(test);}
		// Generate the curve. Try to generate subpixel curves.
		let degen=false;
		let large=false;
		for (let i=0;i<4;i++) {
			let x=getcoord();
			let y=getcoord();
			curve[i*2+0]=x;
			curve[i*2+1]=y;
			if (!(x>-Infinity && x<Infinity && y>-Infinity && y<Infinity)) {
				degen=true;
				large=true;
			}
			if (x*x+y*y>1e+15) {large=true;}
		}
		// Bounds
		let minx=0;
		let maxx=rnd.getf()*1e+8;
		let miny=rnd.gets()*1e+8;
		let maxy=rnd.gets()*1e+8;
		if (miny>maxy) {let tmp=miny;miny=maxy;maxy=tmp;}
		//if (test!==341) {continue;}
		//let lr=BezierSegment1(curve);
		//let lr=BezierSegment3(curve,0.25,2,3);
		//let lr=BezierSegment3(curve,0.01,2,3);
		//let lr=BezierSegment3(curve,0.01,0,3);
		//let lr=BezierSegment3(curve,0.01,2,2);
		//let lr=BezierSegment3(curve,0.01,0,2);
		//let lr=BezierSegment4(curve);
		//let lr=BezierSegment5(curve);
		//let lr=BezierSegment6(curve);
		//let lr=BezierSegment7(curve);
		//let lr=BezierSegment8(curve,0.02,maxx,miny,maxy);
		//let lr=BezierSegment9(curve);
		//let lr=BezierSegment10(curve);
		let lr=BezierSegment11(curve,0.02,maxx,miny,maxy);
		let segs=lr.length;
		maxsegs=maxsegs>segs?maxsegs:segs;
		if (degen) {
			if (segs!==1) {
				console.log("degen curve not single line");
				console.log("test :",test);
				console.log("segs :",segs);
				console.log("curve:",curve);
				throw "error";
			}
			continue;
		}
		let cx0=curve[0],cy0=curve[1],cx1=curve[2],cy1=curve[3];
		let cx2=curve[4],cy2=curve[5],cx3=curve[6],cy3=curve[7];
		let u1=0,x1=cx0,y1=cy0;
		let subdist=0;
		for (let l of lr) {
			// Test if end of previous line = start of current.
			let u0=l.u0,x0=l.x0,y0=l.y0;
			if (!(u0===u1 && x0===x1 && y0===y1)) {
				console.log("consecutive lines not continuous");
				console.log("prev:",u1,x1,y1);
				console.log("next:",u0,x0,y0);
				throw "error";
			}
			u1=l.u1;x1=l.x1;y1=l.y1;
			if (!(u0<=u1)) {
				console.log("u0->u1 not monotonic");
				console.log("u0:",u0);
				console.log("u1:",u1);
				throw "error";
			}
			// Test if line start is on the curve.
			let u=u0,v=1-u,a0,a1,a2,b0,b1,b2;
			a0=v*cx0+u*cx1;a1=v*cx1+u*cx2;a2=v*cx2+u*cx3;
			b0=v*cy0+u*cy1;b1=v*cy1+u*cy2;b2=v*cy2+u*cy3;
			a0=v*a0+u*a1;a1=v*a1+u*a2;
			b0=v*b0+u*b1;b1=v*b1+u*b2;
			let tx=v*a0+u*a1,ty=v*b0+u*b1;
			let errx=(tx>0?tx:-tx)*1e-15;
			let erry=(ty>0?ty:-ty)*1e-15;
			if (!(x0>=tx-errx && x0<=tx+errx && y0>=ty-erry && y0<=ty+erry)) {
				console.log("line off of curve");
				console.log("ref :",tx,ty);
				console.log("calc:",x0,y0);
				throw "error";
			}
			// If we're in the image, get the maximum distance from segment to curve.
			let in0=x0>minx && x0<maxx && y0>miny && y0<maxy;
			let in1=x1>minx && x1<maxx && y1>miny && y1<maxy;
			if ((!in0 && !in1) || large) {continue;}
			let dx=x1-x0,dy=y1-y0;
			let den=dx*dx+dy*dy;
			let du=u1-u0,mu=(u1+u0)*0.5,md=0;
			let depth=16,samples=7;
			for (let d=0;d<depth;d++) {
				let nu=mu;
				for (let s=0;s<samples;s++) {
					u=nu+du*(s/(samples-1)-0.5);
					u=u>u0?u:u0;
					u=u<u1?u:u1;
					v=1-u;
					a0=v*cx0+u*cx1;a1=v*cx1+u*cx2;a2=v*cx2+u*cx3;
					b0=v*cy0+u*cy1;b1=v*cy1+u*cy2;b2=v*cy2+u*cy3;
					a0=v*a0+u*a1;a1=v*a1+u*a2;
					b0=v*b0+u*b1;b1=v*b1+u*b2;
					tx=v*a0+u*a1-x0;ty=v*b0+u*b1-y0;
					u=tx*dx+ty*dy;
					u=u>0?(u<den?u/den:1):0;
					tx-=dx*u;ty-=dy*u;
					let dist=tx*tx+ty*ty;
					if (md<dist) {
						md=dist;
						mu=u;
					}
				}
				du*=0.5;
			}
			subdist=subdist>md?subdist:md;
		}
		if (!(u1===1 && x1===cx3 && y1===cy3)) {
			console.log("line end");
			console.log("calc:",u1,x1,y1);
			console.log("ref :",1,cx3,cy3);
			throw "error";
		}
		if (!large && !degen) {
			sumden++;
			subdist=Math.sqrt(subdist);
			maxdist=maxdist>subdist?maxdist:subdist;
			sumdist+=subdist;
			sumsegs+=segs;
			score+=subdist*segs;
		}
	}
	score/=sumden;
	sumdist/=sumden;
	sumsegs/=sumden;
	//let score=(sumdist+maxdist)*sumsegs;
	console.log("sumden :",sumden);
	console.log("sumdist:",sumdist.toFixed(6));
	console.log("maxdist:",maxdist.toFixed(6));
	console.log("sumsegs:",sumsegs.toFixed(6));
	console.log("maxsegs:",maxsegs);
	console.log("score  :",score.toFixed(6));
}


function BezierSegmentDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let ctx=canv.getContext("2d");
	// console.log(ctx);
	let curve=[100,100,600,130,100,770,600,800];
	ctx.strokeStyle="rgba(255,255,255,1.0)";
	ctx.beginPath();
	ctx.moveTo(curve[0],curve[1]);
	ctx.bezierCurveTo(curve[2],curve[3],curve[4],curve[5],curve[6],curve[7]);
	ctx.stroke();
	ctx.fillStyle="rgba(255,0,0,1.0)";
	// let points=BezierSegment1(curve,48);
	let lr=BezierSegment11(curve,0.1,1000,-1000,1000);
	let points=[[lr[0].x0,lr[0].y0]];
	for (let l of lr) {points.push([l.x1,l.y1]);}
	console.log(points.length);
	for (let p of points) {
		ctx.beginPath();
		ctx.arc(p[0],p[1],3,0,Math.PI*2);
		ctx.fill();
	}
	ctx.strokeStyle="rgba(255,0,0,1.0)";
	ctx.beginPath();
	for (let p of points) {
		ctx.lineTo(p[0],p[1]);
	}
	ctx.stroke();
}


function TestMain() {
	//BezierSegmentTest();
	BezierSegmentDemo();
	console.log("done");
}
TestMain();

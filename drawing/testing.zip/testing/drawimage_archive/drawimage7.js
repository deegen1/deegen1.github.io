function drawimage7(draw,srcimg,offx,offy,trans) {
	// For a given destination pixel, use trans^-1 to project it onto the source and
	// use area calculations to average the color.
	// det(trans) = pixel area
	//
	//                 .
	//               .' '.
	//             .'     '.
	//  +--+      '.        '.
	//  |  |  ->    '.        '.
	//  +--+          '.       .'
	//                  '.   .'
	//                    '.'
	//
	if (trans===undefined) {trans=draw.deftrans;}
	else if (!(trans instanceof Transform)) {trans=new Transform(trans);}
	let dstimg=draw.img;
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	const eps0=1e-6,eps1=1-eps0;
	// src->dst transformation.
	let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
	let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
	let det=matxx*matyy-matxy*matyx;
	let alpha=det*draw.rgba[3]/(2*255*255);
	if (!(srcw*srch*(alpha>0?alpha:-alpha)>1e-8 && dstw && dsth)) {return;}
	// dst->src transformation.
	let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
	let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	matxx*=srcw;matxy*=srch;
	matyx*=srcw;matyy*=srch;
	let min=dsth,max=0;
	let vx=matx,vy=maty;
	for (let i=1;i<16;i+=i) {
		let x0=vx,x1=vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
		let y0=vy,y1=vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		if (!(x0<dstw && x1>0)) {continue;}
		let dx=x1-x0,dy=y1-y0,xw=x1-dstw;
		y0-=x0<0?(x0/dx)*dy:0;
		y1-=xw>0?(xw/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	if (!(min<dsth && max>0)) {return;}
	min+=eps0;max+=eps1;
	let dstminy=min>0?~~min:0;
	let dstmaxy=max<dsth?~~max:dsth;
	// Iterate over dst rows.
	let shift=draw.rgbashift;
	let rshift=shift[0],gshift=shift[1],bshift=shift[2],ashift=shift[3];
	let dstdata=dstimg.data32;
	let srcdata=srcimg.data32;
	for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
		// Calculate dst x bounds for the row.
		min=dstw;max=0;
		vx=matx;vy=maty-dsty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,x1=vx=((3&i)?matxx:0)+((6&i)?matxy:0)+matx;
			let y0=vy,y1=vy=((3&i)?matyx:0)+((6&i)?matyy:0)+maty-dsty;
			if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (!(y0<1 && y1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,yh=y1-1;
			x0-=y0<0?(y0/dy)*dx:0;
			x1-=yh>0?(yh/dy)*dx:0;
			if (x0>x1) {y0=x0;x0=x1;x1=y0;}
			min=min<x0?min:x0;
			max=max>x1?max:x1;
		}
		min+=eps0;max+=eps1;
		let dstminx=min>0?~~min:0;
		let dstmaxx=max<dstw?~~max:dstw;
		let dstrow=dsty*dstw;
		for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
			// Project the dst pixel to src and calculate AABB.
			let invx0=dstx*invxx+dsty*invxy+invx;
			let invy0=dstx*invyx+dsty*invyy+invy;
			vx=invx0;vy=invy0;
			min=srch;max=0;
			for (let i=1;i<16;i+=i) {
				// Calculate transformed pixel vertices.
				let x0=vx,x1=vx=((3&i)?invxx:0)+((6&i)?invxy:0)+invx0;
				let y0=vy,y1=vy=((3&i)?invyx:0)+((6&i)?invyy:0)+invy0;
				if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
				if (!(x0<srcw && x1>0)) {continue;}
				let dx=x1-x0,dy=y1-y0,xw=x1-srcw;
				y0-=x0<0?(x0/dx)*dy:0;
				y1-=xw>0?(xw/dx)*dy:0;
				if (y0>y1) {xw=y0;y0=y1;y1=xw;}
				min=min<y0?min:y0;
				max=max>y1?max:y1;
			}
			min+=eps0;max+=eps1;
			let srcminy=min>0?~~min:0;
			let srcmaxy=max<srch?~~max:srch;
			// Iterate over src rows.
			let sa=0,sr=0,sg=0,sb=0;
			for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
				// Calculate (miny,maxy) from dst to src.
				let srcy0=invy0-srcy;
				vx=invx0;vy=srcy0;
				min=srcw;max=0;
				for (let i=1;i<16;i+=i) {
					// Calculate transformed pixel vertices.
					let x0=vx,x1=vx=((3&i)?invxx:0)+((6&i)?invxy:0)+invx0;
					let y0=vy,y1=vy=((3&i)?invyx:0)+((6&i)?invyy:0)+srcy0;
					if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
					if (!(y0<1 && y1>0)) {continue;}
					let dx=x1-x0,dy=y1-y0,yh=y1-1;
					x0-=y0<0?(y0/dy)*dx:0;
					x1-=yh>0?(yh/dy)*dx:0;
					if (x0>x1) {yh=x0;x0=x1;x1=yh;}
					min=min<x0?min:x0;
					max=max>x1?max:x1;
				}
				min+=eps0;max+=eps1;
				let srcminx=min>0?~~min:0;
				let srcmaxx=max<srcw?~~max:srcw;
				// Sum the src pixels.
				let srcrow=srcy*srcw;
				for (let srcx=srcminx;srcx<srcmaxx;srcx++) {
					let srcx0=invx0-srcx,sx=srcx0,sy=srcy0;
					let area=0;
					for (let i=1;i<16;i+=i) {
						// Calculate transformed pixel vertices.
						let sign=alpha;
						let x0=sx,x1=sx=((3&i)?invxx:0)+((6&i)?invxy:0)+srcx0;
						let y0=sy,y1=sy=((3&i)?invyx:0)+((6&i)?invyy:0)+srcy0;
						if (y0>y1) {x1=x0;x0=sx;y1=y0;y0=sy;sign=-sign;}
						if (!(y0<1 && y1>0)) {continue;}
						// Clip to unit row.
						let dx=x1-x0,dy=y1-y0,yh=y1-1;
						if (y0<0) {x0-=(y0/dy)*dx;y0=0;}
						if (yh>0) {x1-=(yh/dy)*dx;y1=1;}
						if (x0>x1) {yh=x0;x0=x1;x1=yh;dx=-dx;}
						// Calculate area to the right.
						if (x0>=1) {continue;}
						if (x1<1) {
							// Vertical line or last pixel.
							let tmp=x1>0?-(x1*x1/dx)*dy*sign:0;
							let h=(y0-y1)*sign;
							tmp=x0>=0?(x0+x1)*h:tmp;
							area+=2*h-tmp;
						} else {
							area-=((x0>0?(1-x0)*(1-x0):(1-2*x0))/dx)*dy*sign;
						}
					}
					// Scale pixel color by the area and premultiply alpha.
					let col=srcdata[srcrow+srcx];
					let smul=area*((col>>>ashift)&255);
					sr+=smul*((col>>>rshift)&255);
					sg+=smul*((col>>>gshift)&255);
					sb+=smul*((col>>>bshift)&255);
					sa+=smul;
				}
			}
			// Blend with dst. Note alpha*det already averages the src colors.
			if (sa>1e-5) {
				// a = sa + da*(1-sa)
				// c = (sc*sa + dc*da*(1-sa)) / a
				sa=sa<1?sa:1;
				let pix=dstrow+dstx;
				let col=dstdata[pix];
				let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
				let a=sa+dmul;
				let da=a*255+0.5;a=1/a;
				let dr=(sr+dmul*((col>>>rshift)&255))*a+0.5;
				let dg=(sg+dmul*((col>>>gshift)&255))*a+0.5;
				let db=(sb+dmul*((col>>>bshift)&255))*a+0.5;
				dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
			}
		}
	}
}

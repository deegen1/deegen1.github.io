class Draw8 extends Draw {

	drawimage(srcimg,offx,offy,trans) {
		// For a given destination pixel, use trans^-1 to project it onto the source and
		// use area calculations to average the color.
		// det(trans) = pixel area
		//
		//                 .
		//               .' '.
		//             .'     '.
		//  +--+      '.        '.
		//  |  |  ->    '.        '.
		//  +--+          '.       .'
		//                  '.   .'
		//                    '.'
		//
		trans=trans??this.deftrans;
		if (!(trans instanceof Transform)) {trans=new Transform(trans);}
		let dstimg=this.img;
		let dstw=dstimg.width,dsth=dstimg.height;
		let srcw=srcimg.width,srch=srcimg.height;
		// src->dst transformation.
		let matxx=trans.mat[0],matxy=trans.mat[1],matx=trans.vec[0]+offx;
		let matyx=trans.mat[2],matyy=trans.mat[3],maty=trans.vec[1]+offy;
		let det=matxx*matyy-matxy*matyx;
		let alpha=det*this.rgba[3]/(2*255*255);
		if (!(srcw*srch*(alpha>0?alpha:-alpha)>8e-6 && dstw>0 && dsth>0)) {return;}
		// dst->src transformation.
		let invxx= matyy/det,invxy=-matxy/det,invx=-matx*invxx-maty*invxy;
		let invyx=-matyx/det,invyy= matxx/det,invy=-matx*invyx-maty*invyy;
		// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
		matxx*=srcw;matxy*=srch;
		matyx*=srcw;matyy*=srch;
		let min=dsth,max=0;
		let vx=matx,vy=maty;
		for (let i=1;i<16;i+=i) {
			let x0=vx,x1=vx=((i&3)?matxx:0)+((i&6)?matxy:0)+matx;
			let y0=vy,y1=vy=((i&3)?matyx:0)+((i&6)?matyy:0)+maty;
			if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
			if (!(x0<dstw && x1>0)) {continue;}
			let dx=x1-x0,dy=y1-y0,xw=x1-dstw;
			y0-=x0<0?(x0/dx)*dy:0;
			y1-=xw>0?(xw/dx)*dy:0;
			if (y0>y1) {x0=y0;y0=y1;y1=x0;}
			min=min<y0?min:y0;
			max=max>y1?max:y1;
		}
		if (!(min<dsth && max>0)) {return;}
		let dstminy=min>0?~~min:0;
		let dstmaxy=max<dsth?Math.ceil(max):dsth;
		// Precompute pixel AABB offsets.
		let pixminx=(invxx<0?invxx:0)+(invxy<0?invxy:0);
		let pixminy=(invyx<0?invyx:0)+(invyy<0?invyy:0);
		let pixmaxy=(invyx>0?invyx:0)+(invyy>0?invyy:0);
		// Iterate over dst rows.
		let shift=this.rgbashift;
		let rshift=shift[0],gshift=shift[1],bshift=shift[2],ashift=shift[3];
		let dstdata=dstimg.data32;
		let srcdata=srcimg.data32;
		for (let dsty=dstminy;dsty<dstmaxy;dsty++) {
			// Calculate dst x bounds for the row.
			min=dstw;max=0;
			vx=matx;vy=maty-dsty;
			for (let i=1;i<16;i+=i) {
				let x0=vx,x1=vx=((i&3)?matxx:0)+((i&6)?matxy:0)+matx;
				let y0=vy,y1=vy=((i&3)?matyx:0)+((i&6)?matyy:0)+maty-dsty;
				if (y0>y1) {x1=x0;x0=vx;y1=y0;y0=vy;}
				if (!(y0<1 && y1>0)) {continue;}
				let dx=x1-x0,dy=y1-y0,yh=y1-1;
				x0-=y0<0?(y0/dy)*dx:0;
				x1-=yh>0?(yh/dy)*dx:0;
				if (x0>x1) {y0=x0;x0=x1;x1=y0;}
				min=min<x0?min:x0;
				max=max>x1?max:x1;
			}
			let dstminx=min>0?~~min:0;
			let dstmaxx=max<dstw?Math.ceil(max):dstw;
			for (let dstx=dstminx;dstx<dstmaxx;dstx++) {
				// Project the dst pixel to src and estimate the AABB.
				let invx0=dstx*invxx+dsty*invxy+invx;
				let invy0=dstx*invyx+dsty*invyy+invy;
				min=invx0+pixminx;let srcminx=min>0?~~min:0;
				min=invy0+pixminy;let srcminy=min>0?~~min:0;
				max=invy0+pixmaxy;let srcmaxy=max<srch?Math.ceil(max):srch;
				// Iterate over src rows.
				let sa=0,sr=0,sg=0,sb=0;
				for (let srcy=srcminy;srcy<srcmaxy;srcy++) {
					// Sum the src pixels.
					for (let srcx=srcminx;srcx<srcw;srcx++) {
						min=srcw;max=0;
						let sx=invx0-srcx,sy=invy0-srcy,srcx0=sx,srcy0=sy,area=0;
						for (let i=1;i<16;i+=i) {
							// Calculate transformed pixel vertices.
							let sign=alpha;
							let x0=sx,x1=sx=((i&3)?invxx:0)+((i&6)?invxy:0)+srcx0;
							let y0=sy,y1=sy=((i&3)?invyx:0)+((i&6)?invyy:0)+srcy0;
							if (y0>y1) {x1=x0;x0=sx;y1=y0;y0=sy;sign=-sign;}
							if (!(y0<1 && y1>0)) {continue;}
							// Clip to unit row.
							let dx=x1-x0,dy=y1-y0,yh=y1-1;
							if (y0<0) {x0-=(y0/dy)*dx;y0=0;}
							if (yh>0) {x1-=(yh/dy)*dx;y1=1;}
							if (x0>x1) {yh=x0;x0=x1;x1=yh;dx=-dx;}
							min=min<x0?min:x0;
							max=max>x1?max:x1;
							// Calculate area to the right.
							if (x1<1) {
								// Vertical line or last pixel.
								let h=y1-y0,tmp=x1>0?(x1*x1/dx)*dy:0;
								area-=(h+h-(x0<0?tmp:(x1+x0)*h))*sign;
							} else if (x0<1) {
								x1=1-x0;
								area-=((x0>0?x1*x1:x1-x0)/dx)*dy*sign;
							}
						}
						// Skip pixels if we are too far left or right.
						if (max<=0) {break;}
						if (min>=1) {srcx+=(~~min)-1;continue;}
						// Scale pixel color by the area and premultiply alpha.
						let col=srcdata[srcy*srcw+srcx];
						let smul=area*((col>>>ashift)&255);
						sr+=smul*((col>>>rshift)&255);
						sg+=smul*((col>>>gshift)&255);
						sb+=smul*((col>>>bshift)&255);
						sa+=smul;
						if (max<=1) {break;}
					}
				}
				// Blend with dst. Note alpha*det already averages the src colors.
				if (sa>8e-6) {
					// a = sa + da*(1-sa)
					// c = (sc*sa + dc*da*(1-sa)) / a
					sa=sa<1?sa:1;
					let pix=dsty*dstw+dstx;
					let col=dstdata[pix];
					let dmul=(((col>>>ashift)&255)*0.003921569)*(1-sa);
					let a=sa+dmul;
					let da=a*255+0.5;a=1/a;
					let dr=(sr+dmul*((col>>>rshift)&255))*a+0.5;
					let dg=(sg+dmul*((col>>>gshift)&255))*a+0.5;
					let db=(sb+dmul*((col>>>bshift)&255))*a+0.5;
					dstdata[pix]=(da<<ashift)|(dr<<rshift)|(dg<<gshift)|(db<<bshift);
				}
			}
		}
	}

}
/*------------------------------------------------------------------------------


font.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


 : 0.000000
!: 0.000595
": 0.000256
#: 0.000974
$: 0.002521
%: 0.003052
&: 0.002462
': 0.000118
(: 0.000879
): 0.000851
*: 0.000750
+: 0.000618
,: 0.000362
-: 0.000373
.: 0.000472
/: 0.000378
0: 0.003003
1: 0.001246
2: 0.002104
3: 0.003774
4: 0.000964
5: 0.003695
6: 0.002486
7: 0.000938
8: 0.003128
9: 0.002214
:: 0.001093
;: 0.000824
<: 0.000561
=: 0.000528
>: 0.000548
?: 0.001402
@: 0.003661
A: 0.000914
B: 0.002866
C: 0.001647
D: 0.000872
E: 0.000901
F: 0.000777
G: 0.003435
H: 0.001171
I: 0.001009
J: 0.000660
K: 0.000958
L: 0.001040
M: 0.002080
N: 0.002320
O: 0.003251
P: 0.002086
Q: 0.003298
R: 0.001952
S: 0.001323
T: 0.000809
U: 0.003262
V: 0.000639
W: 0.001646
X: 0.000930
Y: 0.000935
Z: 0.001096
[: 0.001024
\: 0.000542
]: 0.000996
^: 0.000352
_: 0.000247
`: 0.000085
a: 0.002293
b: 0.003324
c: 0.003841
d: 0.002549
e: 0.002011
f: 0.000498
g: 0.002416
h: 0.001796
i: 0.001011
j: 0.001215
k: 0.000959
l: 0.000783
m: 0.002170
n: 0.001602
o: 0.001618
p: 0.003138
q: 0.002715
r: 0.000996
s: 0.001222
t: 0.000661
u: 0.001426
v: 0.000897
w: 0.000984
x: 0.000712
y: 0.001088
z: 0.000549
{: 0.002325
|: 0.000740
}: 0.002469
~: 0.000777
█: 0.000000

font err: 0.001466
font der: 0
size    : 9285

orig err: 0.001081
orig max: 0.002802 @


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint font.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random} from "../library.js";


function FontInspect(fontpath,erroraccept={}) {
	// See how closely a font matches reference images.
	let fontdef=Draw.Font.deffont;
	let glyphs={};
	let fontidx=0,fontlen=fontdef.length;
	function token(eol) {
		let c=0;
		while (fontidx<fontlen && (c=fontdef.charCodeAt(fontidx))<=32 && c!==10) {fontidx++;}
		let i=fontidx;
		while (fontidx<fontlen && fontdef.charCodeAt(fontidx)>eol) {fontidx++;}
		return fontdef.substring(i,fontidx);
	}
	token(10); fontidx++; // name
	token(10); fontidx++; // info
	let scale=parseFloat(token(10));
	let special={"SPC":32};
	let loaded=0;
	while (fontidx<fontlen) {
		fontidx++;
		let chr=token(32);
		if (chr.length<=0) {continue;}
		chr=special[chr]??chr.charCodeAt(0);
		let g={};
		g.width=parseInt(token(32));
		g.pathstr=token(10);
		g.path=new Draw.Path(g.pathstr);
		g.chr=String.fromCharCode(chr);
		g.num=chr;
		g.img=null;
		// Queue loading the images.
		let img=new Image();
		img.onload=function() {
			g.img=img;
			loaded--;
		};
		img.onerror=function() {
			loaded--;
		};
		img.src=fontpath+g.num.toString().padStart(3,"0")+".png";
		glyphs[g.num]=g;
		loaded++;
	}
	// Once all images have loaded (or failed), process them.
	function process() {
		console.log("loading font:",loaded);
		if (loaded>0) {
			setTimeout(process,1);
			return;
		}
		let draw=new Draw();
		let fonterr=0;
		let fontder=0;
		let dercutoff=0.93;
		//let dercutoff=Math.cos(-0.15*Math.PI);
		let results=[];
		for (let g of Object.values(glyphs)) {
			console.log("processing:",g.num,g.chr);
			let img=g.img;
			//if (g.chr!=="~") {continue;}
			if (img===null) {
				console.log("Image file not found");
				throw "error";
			}
			let iw=img.width,ih=img.height,pixels=iw*ih;
			if (iw!==g.width || ih!==scale) {
				console.log("width :",iw,g.width);
				console.log("height:",ih,scale);
				throw "dimensions mismatch";
			}
			// Get the alpha values from the source image.
			let canv=document.createElement("canvas");
			let ctx=canv.getContext("2d");
			canv.width=iw;
			canv.height=ih;
			ctx.drawImage(img,0,0);
			let srcpix=ctx.getImageData(0,0,iw,ih).data;
			canv.remove();
			// See how the pixels differ.
			let dstimg=new Draw.Image(iw,ih);
			let path=g.path;
			draw.setimage(dstimg);
			draw.fill(0,0,0,255);
			draw.setcolor(255,255,255,255);
			draw.fillpath(path);
			let dstdata=dstimg.data8;
			let sumder=0;
			let sumerr=0;
			for (let i=0;i<pixels;i++) {
				let j=i*4;
				let srcc=(srcpix[j+0]+srcpix[j+1]+srcpix[j+2])/(3*255);
				let dstc=dstdata[j+0]/255;
				let u=dstc-srcc;
				sumerr+=u<0?-u:u;
				dstdata[j+0]=u<0?Math.round(-u*255):0;
				dstdata[j+1]=0;
				dstdata[j+2]=u>0?Math.round(u*255):0;
				dstdata[j+3]=255;
			}
			// Find any consecutive curves that don't have parallel derivatives.
			let vidx=path.vertidx;
			let varr=path.vertarr;
			let next=-1,end=-1,start=0,phase=0;
			const MOVE=0,CLOSE=1,CURVE=3;
			for (let idx=0;idx<vidx;idx++) {
				// Find the bounds of the current subpath.
				let type=varr[idx].type;
				if (type===CLOSE) {
					continue;
				} else if (type===CURVE) {
					// Don't look at neighbors of control points.
					phase=(phase+1)%3;
					if (phase) {continue;}
				}
				if (next<=idx) {
					start=idx;
					for (let j=idx;j<vidx;j++) {
						if (varr[j].type===CLOSE) {
							end=j;
							break;
						}
					}
					next=end+1;
					if (next<=idx) {
						console.log("could not find close");
						throw "error";
					}
					if (varr[start].type!==MOVE) {
						console.log("first vertex not MOVE",varr[start].type,start,vidx,varr[start-1].type);
						throw "error";
					}
					// If we close when the previous point is already on move.
					let p=varr[end-1],e=varr[end];
					if (p.x===e.x && p.y===e.y) {
						end--;
					}
				}
				let v0=null,v1=null,v2=null;
				for (let i=-1;i<2;i++) {
					let j=idx+i;
					j=j<start?j-start+end:j;
					j=j>=end ?j-end+start:j;
					if (j<start || j>=end) {
						console.log(idx,start,end,next);
						throw "range";
					}
					v0=v1;v1=v2;v2=varr[j];
				}
				if (/*v0.type!==CURVE && */v1.type!==CURVE && v2.type!==CURVE) {continue;}
				let dx0=v1.x-v0.x,dy0=v1.y-v0.y,l0=dx0*dx0+dy0*dy0;
				let dx1=v2.x-v1.x,dy1=v2.y-v1.y,l1=dx1*dx1+dy1*dy1;
				let len=l0*l1;
				let dot=dx0*dx1+dy0*dy1,dot2=dot*dot;
				dot/=Math.sqrt(len);
				if (dot>dercutoff && dot2<len) {
					// console.log("sub  :",path);
					console.log("dot  :",dot);
					console.log("coord:",v0.x,v0.y,v1.x,v1.y,v2.x,v2.y);
					console.log("dif  :",dx0,dy0,dx1,dy1);
					sumder++;
				}
			}
			// Error out if we're too off.
			let accept=erroraccept[g.chr]??[0.004,0];
			let avgerr=sumerr/pixels;
			let limiterr=accept[0];
			let limitder=accept[1];
			fonterr+=avgerr;
			results.push([g.chr,avgerr]);
			console.log("err: "+avgerr.toFixed(6));
			console.log("der: "+sumder.toString()+" / "+limitder);
			// console.log((new Draw.Path()).addoval(361,116,67,67).tostring(0));
			if (avgerr>limiterr || sumder>limitder) {
				// Display a heatmap of differences.
				canv=document.createElement("canvas");
				document.body.appendChild(canv);
				canv.style.background="#000000";
				canv.style.position="absolute";
				canv.style.top="0px";
				canv.style.left="0px";
				canv.width=g.width;
				canv.height=scale;
				canv.style.width=canv.width+"px";
				canv.style.height=canv.height+"px";
				let cdata=new Uint8ClampedArray(dstimg.data8.buffer);
				let idata=new ImageData(cdata,dstimg.width,dstimg.height);
				ctx=canv.getContext("2d");
				ctx.putImageData(idata,0,0);
				throw "err too great";
			}
		}
		let out="";
		//results.sort((a,b)=>a[1]-b[1]);
		for (let g of results) {
			out+=`${g[0]}: ${g[1].toFixed(6)}\n`;
		}
		console.log(out);
		fonterr/=Object.values(glyphs).length;
		console.log("font err: "+fonterr.toFixed(6));
		console.log("font der: "+fontder);
		console.log("size    : "+fontdef.length);
		console.log("done");
	}
	process();
}


function AngErr(path) {
	// Multiply pixel error if curve derivatives are off.
	let vidx=path.vertidx;
	let varr=path.vertarr;
	let dercutoff=0.97;
	//let dercutoff=Math.cos(-0.15*Math.PI);
	const CLOSE=1,CURVE=3;
	let sumang=1;
	let next=-1,end=-1,start=0,phase=0;
	for (let idx=0;idx<vidx;idx++) {
		// Find the bounds of the current subpath.
		let type=varr[idx].type;
		if (type===CLOSE) {
			continue;
		} else if (type===CURVE) {
			// Don't look at neighbors of control points.
			phase=(phase+1)%3;
			if (phase) {continue;}
		}
		if (next<=idx) {
			start=idx;
			for (let j=idx;j<vidx;j++) {
				if (varr[j].type===CLOSE) {
					end=j;
					break;
				}
			}
			next=end+1;
			// If we close when the previous point is already on move.
			let p=varr[end-1],e=varr[end];
			if (p.x===e.x && p.y===e.y) {
				end--;
			}
		}
		let v0=null,v1=null,v2=null;
		for (let i=-1;i<2;i++) {
			let j=idx+i;
			j=j<start?j-start+end:j;
			j=j>=end ?j-end+start:j;
			if (j<start || j>=end) {
				console.log(idx,start,end,next);
				throw "range";
			}
			v0=v1;v1=v2;v2=varr[j];
		}
		if (/*v0.type!==CURVE && */v1.type!==CURVE && v2.type!==CURVE) {continue;}
		let dx0=v1.x-v0.x,dy0=v1.y-v0.y,l0=dx0*dx0+dy0*dy0;
		let dx1=v2.x-v1.x,dy1=v2.y-v1.y,l1=dx1*dx1+dy1*dy1;
		let len=l0*l1;
		let dot=dx0*dx1+dy0*dy1,dot2=dot*dot;
		dot/=Math.sqrt(len);
		if (dot>dercutoff && dot2<len) {
			sumang+=(1-dot)*1000+1;
			//console.log(dot,idx,v1.x,v1.y,v2.x,v2.y);
		}
	}
	//throw "error";
	return sumang;
}


function FontFit(fontpath,focus) {
	// See how closely a font matches reference images.
	let fontdef=Draw.Font.deffont;
	let glyphs={};
	let rnd=new Random();
	let fontidx=0,fontlen=fontdef.length;
	function token(eol) {
		let c=0;
		while (fontidx<fontlen && (c=fontdef.charCodeAt(fontidx))<=32 && c!==10) {fontidx++;}
		let i=fontidx;
		while (fontidx<fontlen && fontdef.charCodeAt(fontidx)>eol) {fontidx++;}
		return fontdef.substring(i,fontidx);
	}
	token(10); fontidx++; // name
	token(10); fontidx++; // info
	token(10); // scale
	let special={"SPC":32};
	let loaded=0;
	while (fontidx<fontlen) {
		fontidx++;
		let chr=token(32);
		if (chr.length<=0) {continue;}
		chr=special[chr]??chr.charCodeAt(0);
		let g={};
		g.width=parseInt(token(32));
		g.pathstr=token(10);
		g.path=new Draw.Path(g.pathstr);
		g.chr=String.fromCharCode(chr);
		g.num=chr;
		g.img=null;
		// Queue loading the images.
		let img=new Image();
		img.onload=function() {
			g.img=img;
			loaded--;
		};
		img.onerror=function() {
			loaded--;
		};
		img.src=fontpath+g.num.toString().padStart(3,"0")+".png";
		glyphs[g.num]=g;
		loaded++;
	}
	// Once all images have loaded (or failed), process them.
	function process() {
		console.log("loading font:",loaded);
		if (loaded>0) {
			setTimeout(process,1);
			return;
		}
		let improved="";
		let outpath="";
		let draw=new Draw();
		for (let g of Object.values(glyphs)) {
			console.log("processing:",g.num,g.chr);
			let img=g.img;
			if (focus && !focus[g.chr]) {continue;}
			if (img===null) {
				console.log("Image file not found");
				throw "error";
			}
			let iw=img.width,ih=img.height,pixels=iw*ih;
			// Get the alpha values from the source image.
			let canv=document.createElement("canvas");
			let ctx=canv.getContext("2d");
			canv.width=iw;
			canv.height=ih;
			ctx.drawImage(img,0,0);
			let srcpix=ctx.getImageData(0,0,iw,ih).data;
			let srcdata=new Array(pixels);
			for (let i=0,j=0;i<pixels;i++,j+=4) {
				srcdata[i]=(srcpix[j+0]+srcpix[j+1]+srcpix[j+2])/3;
			}
			canv.remove();
			// See how the pixels differ.
			let dstimg=new Draw.Image(iw,ih);
			draw.setimage(dstimg);
			let path=g.path;
			draw.setcolor(255,255,255,255);
			draw.fill(0,0,0,255);
			draw.fillpath(path);
			let dstdata=dstimg.data8;
			let minerr=0;
			for (let i=0;i<pixels;i++) {
				let dif=dstdata[i*4]-srcdata[i];
				minerr+=dif<0?-dif:dif;
			}
			minerr/=pixels*255;
			let mulerr=AngErr(path);
			minerr*=mulerr;
			let origerr=minerr;
			console.log(g.chr,minerr,mulerr);
			let minpath=new Draw.Path(path);
			// Look at neighbors to determine what direction we can move to maintain
			// derivative.
			let vidx=minpath.vertidx;
			let varr=minpath.vertarr;
			let movecopy=new Array(vidx);
			let move=0;
			for (let idx=0;idx<vidx;idx++) {
				// If v.x=m.x and v.y=m.y, preserve that when m moves.
				let v=varr[idx];
				movecopy[idx]=-1;
				if (v.type===Draw.Path.MOVE) {
					move=idx;
				} else {
					let m=varr[move];
					if (v.x===m.x && v.y===m.y) {
						movecopy[idx]=move;
					}
				}
			}
			let movearr=[0,0,0,0];
			let sets=vidx*250;
			for (let set=0;set<sets;set++) {
				if ((set&255)===0) {console.log("set:",set,sets);}
				let setpath=new Draw.Path(minpath);
				setpath.minx=0;setpath.maxx=iw;
				setpath.miny=0;setpath.maxy=ih;
				varr=setpath.vertarr;
				let idx=set%vidx;
				let span=6-((~~(set/vidx))%6);
				for (let i=0;i<span;i++) {
					let v=varr[idx];
					if (v.type===Draw.Path.CLOSE) {
						do {
							v=varr[--idx];
						} while (v.type!==Draw.Path.MOVE);
					}
					movearr[i]=idx++;
				}
				for (let trial=0;trial<40;trial++) {
					for (let i=0;i<span;i++) {
						let j=movearr[i];
						let v=varr[j];
						v.x=Math.round(v.x+rnd.getnorm()*1);
						v.y=Math.round(v.y+rnd.getnorm()*1);
					}
					// Replicate move changes.
					for (let i=0;i<vidx;i++) {
						let j=movecopy[i];
						if (j>=0) {
							let v=varr[i],m=varr[j];
							v.x=m.x;v.y=m.y;
						}
					}
					draw.fill(0,0,0,255);
					draw.fillpath(setpath);
					let avgerr=0;
					for (let i=0;i<pixels;i++) {
						let dif=dstdata[i<<2]-srcdata[i];
						avgerr+=dif<0?-dif:dif;
					}
					avgerr/=pixels*255;
					let mul=AngErr(setpath);
					avgerr*=mul;
					if (minerr>avgerr) {
						minerr=avgerr;
						minpath=new Draw.Path(setpath);
						console.log(`${set}/${sets}: ${minerr}`,mul);
						console.log(minpath.tostring());
					}
				}
			}
			let pathstr=g.pathstr;
			if (minerr<origerr) {
				improved+=`${g.chr}: ${origerr.toFixed(6)} -> ${minerr.toFixed(6)}\n`;
				pathstr=minpath.tostring();
			}
			outpath+=`${g.chr} ${iw} ${pathstr}\n`;
			// Double check our results.
			let avgerr=0;
			path=new Draw.Path(pathstr);
			draw.fill(0,0,0,255);
			draw.fillpath(path);
			for (let i=0;i<pixels;i++) {
				let dif=dstdata[i<<2]-srcdata[i];
				avgerr+=dif<0?-dif:dif;
			}
			avgerr/=pixels*255;
			avgerr*=AngErr(path);
			if (avgerr!==minerr) {
				console.log(avgerr,minerr);
				throw "error";
			}
		}
		console.log(outpath);
		console.log(improved);
		console.log("done");
	}
	process();
}


function FontDemo() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	//let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	draw.fill(0,0,0,255);
	draw.setcolor(255,0,0,255);
	let text=
		"███████████████████████████████████\n"+
		"█ !\"#$%&'()*+,-./0123456789:;<=>? █\n"+
		"█ @ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^ █\n"+
		"█ `abcdefghijklmnopqrstuvwxyz{|}~ █\n"+
		"█ █                               █\n"+
		"███████████████████████████████████";
	draw.filltext(400,200,text);
	draw.setcolor(255,255,255,255);
	//text="hello\b\b\b\b\bworld";
	//draw.filltext(400,500,text);
	draw.screenflip();
}


function TestMain() {
	//FontInspect("./font/reference/",{"@":[0.004,1],"g":[0.004,1]});
	//FontFit("./font/reference/",{"@":true});
	FontDemo();
	console.log("done");
}
//TestMain();

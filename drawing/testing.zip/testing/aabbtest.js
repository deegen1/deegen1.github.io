/*------------------------------------------------------------------------------


aabbtest.js - v1.09

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


*/
/* npx eslint aabbtest.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Vector,Transform,Input} from "../library.js";


function AABBCheck0(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if any lines intersect.
	let imglines=[
		[0,0,imgwidth,0],
		[imgwidth,0,imgwidth,imgheight],
		[imgwidth,imgheight,0,imgheight],
		[0,imgheight,0,0]
	];
	let polylines=[
		[bndx,bndy,bndx+bnddx0,bndy+bnddy0],
		[bndx+bnddx0,bndy+bnddy0,bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1],
		[bndx+bnddx0+bnddx1,bndy+bnddy0+bnddy1,bndx+bnddx1,bndy+bnddy1],
		[bndx+bnddx1,bndy+bnddy1,bndx,bndy]
	];
	for (let il=0;il<4;il++) {
		let [i0x,i0y,i1x,i1y]=imglines[il];
		i1x-=i0x;
		i1y-=i0y;
		for (let pl=0;pl<4;pl++) {
			let [p0x,p0y,p1x,p1y]=polylines[pl];
			p1x-=p0x;
			p1y-=p0y;
			let den=i1x*p1y-i1y*p1x;
			p0x-=i0x;
			p0y-=i0y;
			let u=p0x*i1y-p0y*i1x;
			if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
				u=p0x*p1y-p0y*p1x;
				if ((den>0 && u>0 && u<den) || (den<0 && u<0 && u>den)) {
					return true;
				}
			}
		}
	}
	// Either they are not overlapping, or one is entirely inside the other.
	let midx=bndx+(bnddx0+bnddx1)*0.5;
	let midy=bndy+(bnddy0+bnddy1)*0.5;
	if (midx>=0 && midx<=imgwidth && midy>=0 && midy<=imgheight) {
		return true;
	}
	midx=imgwidth*0.5;
	midy=imgheight*0.5;
	let parity=0;
	for (let pl=0;pl<4;pl++) {
		let [p0x,p0y,p1x,p1y]=polylines[pl];
		p0x-=midx;
		p0y-=midy;
		p1x-=midx;
		p1y-=midy;
		let sign=p0x*p1y-p0y*p1x;
		if (sign<-1e-10) {parity--;}
		if (sign> 1e-10) {parity++;}
	}
	return parity===-4 || parity===4;
}


function AABBCheck1(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx+(bnddx0<0?bnddx0:0)+(bnddx1<0?bnddx1:0);
	let miny=bndy+(bnddy0<0?bnddy0:0)+(bnddy1<0?bnddy1:0);
	let maxx=bndx+(bnddx0>0?bnddx0:0)+(bnddx1>0?bnddx1:0);
	let maxy=bndy+(bnddy0>0?bnddy0:0)+(bnddy1>0?bnddy1:0);
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck2(imgwidth,imgheight,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || minx>=imgwidth || maxy<=0 || miny>=imgheight) {
		return false;
	}
	// Test if the poly AABB has a separating axis.
	let cross=bnddx1*bnddy0-bnddy1*bnddx0;
	let mini=0,maxi=0;
	if (bnddy0<0) {mini+= imgwidth*bnddy0;} else {maxi+= imgwidth*bnddy0;}
	if (bnddx0>0) {mini-=imgheight*bnddx0;} else {maxi-=imgheight*bnddx0;}
	let minp=bndx*bnddy0-bndy*bnddx0,maxp=minp;
	if (cross<0) {minp+=cross;} else {maxp+=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	// Axis 2.
	mini=0;maxi=0;
	if (bnddy1<0) {mini+= imgwidth*bnddy1;} else {maxi+= imgwidth*bnddy1;}
	if (bnddx1>0) {mini-=imgheight*bnddx1;} else {maxi-=imgheight*bnddx1;}
	minp=bndx*bnddy1-bndy*bnddx1;maxp=minp;
	if (cross>0) {minp-=cross;} else {maxp-=cross;}
	if (mini>=maxp || minp>=maxi) {return false;}
	return true;
}


function AABBCheck3(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	if (bnddx0<0) {maxx-=ih*bnddx0;} else {minx-=ih*bnddx0;}
	if (bnddy0<0) {minx+=iw*bnddy0;} else {maxx+=iw*bnddy0;}
	if (bnddx1<0) {maxy-=ih*bnddx1;} else {miny-=ih*bnddx1;}
	if (bnddy1<0) {miny+=iw*bnddy1;} else {maxy+=iw*bnddy1;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck4(iw,ih,aabb,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bndx=aabb[0]*matxx+aabb[1]*matxy+matx;
	let bndy=aabb[0]*matyx+aabb[1]*matyy+maty;
	let bnddx0=aabb[2]*matxx,bnddy0=aabb[2]*matyx;
	let bnddx1=aabb[3]*matxy,bnddy1=aabb[3]*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx,maxx=bndx,miny=bndy,maxy=bndy;
	if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
	if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
	if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
	if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
	if (maxx<=0 || iw<=minx || maxy<=0 || ih<=miny) {
		return false;
	}
	// Test if the poly OBB has a separating axis.
	let cross=bnddx0*bnddy1-bnddy0*bnddx1,tmp=0;
	minx=cross<0?cross:0; maxx=cross-minx; maxy=-minx; miny=-maxx;
	tmp=ih*bnddx0; if (tmp<0) {maxx-=tmp;} else {minx-=tmp;}
	tmp=iw*bnddy0; if (tmp<0) {minx+=tmp;} else {maxx+=tmp;}
	tmp=ih*bnddx1; if (tmp<0) {maxy-=tmp;} else {miny-=tmp;}
	tmp=iw*bnddy1; if (tmp<0) {miny+=tmp;} else {maxy+=tmp;}
	let projx=bndx*bnddy0-bndy*bnddx0;
	let projy=bndx*bnddy1-bndy*bnddx1;
	if (maxx<=projx || projx<=minx || maxy<=projy || projy<=miny) {
		return false;
	}
	return true;
}


function AABBCheck5(iw,ih,poly,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Define the transformed bounding box.
	let bx=poly.minx,by=poly.miny;
	let bndx=bx*matxx+by*matxy+matx;
	let bndy=bx*matyx+by*matyy+maty;
	bx=poly.maxx-bx;by=poly.maxy-by;
	let bndxx=bx*matxx,bndxy=bx*matyx;
	let bndyx=by*matxy,bndyy=by*matyy;
	// Test if the image AABB has a separating axis.
	let minx=bndx-iw,maxx=bndx;
	if (bndxx<0) {minx+=bndxx;} else {maxx+=bndxx;}
	if (bndyx<0) {minx+=bndyx;} else {maxx+=bndyx;}
	if (!(minx<0 && 0<maxx)) {return;}
	let miny=bndy-ih,maxy=bndy;
	if (bndxy<0) {miny+=bndxy;} else {maxy+=bndxy;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	// Test if the poly OBB has a separating axis.
	let cross=bndxx*bndyy-bndxy*bndyx;
	minx=bndy*bndxx-bndx*bndxy;maxx=minx;
	bndxx*=ih;bndxy*=iw;
	if (cross<0) {minx+=cross;} else {maxx+=cross;}
	if (bndxx<0) {maxx-=bndxx;} else {minx-=bndxx;}
	if (bndxy<0) {minx+=bndxy;} else {maxx+=bndxy;}
	if (!(minx<0 && 0<maxx)) {return;}
	miny=bndy*bndyx-bndx*bndyy;maxy=miny;
	bndyx*=ih;bndyy*=iw;
	if (cross<0) {maxy-=cross;} else {miny-=cross;}
	if (bndyx<0) {maxy-=bndyx;} else {miny-=bndyx;}
	if (bndyy<0) {miny+=bndyy;} else {maxy+=bndyy;}
	if (!(miny<0 && 0<maxy)) {return;}
	return true;
}


function AABBCheck6(imgw,imgh,poly,trans) {
	let matxx=trans[0],matxy=trans[1],matx=trans[2];
	let matyx=trans[3],matyy=trans[4],maty=trans[5];
	// Check if trans(src) and dst AABB overlap. Calculate y intercepts.
	let min=Infinity,max=-Infinity;
	let vx=0,vy=0;
	for (let i=0;i<5;i++) {
		let w=((i+1)&2)?poly.maxx:poly.minx;
		let h=((i  )&2)?poly.maxy:poly.miny;
		let x0=vx,y0=vy;
		vx=w*matxx+h*matxy+matx;
		vy=w*matyx+h*matyy+maty;
		let x1=vx,y1=vy;
		if (x0>x1) {x1=x0;x0=vx;y1=y0;y0=vy;}
		let dx=x1-x0,dy=y1-y0;
		if (!(dx>=0 && dy===dy)) {return;}
		if (!i || x0>=imgw || x1<0) {continue;}
		y0+=x0<0?-(x0/dx)*dy:0;
		y1+=x1>imgw?((imgw-x1)/dx)*dy:0;
		if (y0>y1) {x0=y0;y0=y1;y1=x0;}
		min=min<y0?min:y0;
		max=max>y1?max:y1;
	}
	if (!(min<imgh && max>0)) {return;}
	//let dstminy=min>0?~~min:0;
	//let dstmaxy=max<imgh?Math.ceil(max):imgh;
	return true;
}


function BoundingBoxTest() {
	console.log("testing bounding boxes");
	let rnd=new Random(10);
	function getrnd() {
		return rnd.gets()*Math.pow(2,rnd.gets()*20);
	}
	let tests=1000000;
	let trans=[1,0,0,0,1,0];
	let difcnt=[0,0,0,0,0,0,0];
	let overlap=0;
	for (let test=0;test<tests;test++) {
		let imgwidth=Math.abs(getrnd());
		let imgheight=Math.abs(getrnd());
		for (let i=0;i<6;i++) {trans[i]=getrnd();}
		let x0=getrnd(),x1=getrnd();
		let y0=getrnd(),y1=getrnd();
		let aabb={
			minx:x0<x1?x0:x1,
			maxx:x0<x1?x1:x0,
			miny:y0<y1?y0:y1,
			maxy:y0<y1?y1:y0
		};
		aabb.dx=aabb.maxx-aabb.minx;
		aabb.dy=aabb.maxy-aabb.miny;
		aabb[0]=aabb.minx;
		aabb[1]=aabb.miny;
		aabb[2]=aabb.dx;
		aabb[3]=aabb.dy;
		let ref=AABBCheck5(imgwidth,imgheight,aabb,trans)===true;
		difcnt[0]+=AABBCheck0(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[1]+=AABBCheck1(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[2]+=AABBCheck2(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[3]+=AABBCheck3(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[4]+=AABBCheck4(imgwidth,imgheight,aabb,trans)===ref;
		difcnt[5]+=(AABBCheck5(imgwidth,imgheight,aabb,trans)===true)===ref;
		difcnt[6]+=(AABBCheck6(imgwidth,imgheight,aabb,trans)===true)===ref;
		overlap+=ref;
		/*if ((AABBCheck6(imgwidth,imgheight,aabb,trans)===true)!==ref) {
			console.log(imgwidth,imgheight);
			console.log(aabb);
			console.log(trans);
			throw "mismatch";
		}*/
		// NaN tests.
		let coord=rnd.mod(4);
		if (coord===0) {aabb.minx=NaN;}
		if (coord===1) {aabb.miny=NaN;}
		if (coord===2) {aabb.maxx=NaN;}
		if (coord===3) {aabb.maxy=NaN;}
		if (AABBCheck6(imgwidth,imgheight,aabb,trans)) {
			console.log("NaN passed");
			throw "error";
		}
	}
	for (let i=0;i<difcnt.length;i++) {
		console.log(`dif ${i}  : ${difcnt[i]}`);
	}
	console.log("overlap: "+overlap);
	console.log("done");
}


function BoundingBoxSpeedTest() {
	console.log("testing bounding box speed");
	let rnd=new Random(10);
	function getrnd(pos) {
		let type=rnd.getu32();
		if ((type&15)===0) {return 0;}
		let ret=Math.pow(2,rnd.getf()*16-8);
		return ((type&16) || pos)?ret:-ret;
	}
	let randmask=(1<<20)-1;
	let rands=randmask+100;
	let randarr=new Float64Array(rands);
	let randabs=new Float64Array(rands);
	for (let i=0;i<rands;i++) {
		randarr[i]=getrnd();
		randabs[i]=Math.abs(randarr[i]);
	}
	let tests=10000000;
	let trans=[1,0,0,0,1,0];
	let aabb=[0,0,0,0];
	let overlap=0;
	let t0=performance.now();
	let r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck0(imgwidth,imgheight,aabb,trans);
	}
	let t1=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck1(imgwidth,imgheight,aabb,trans);
	}
	let t2=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck2(imgwidth,imgheight,aabb,trans);
	}
	let t3=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck3(imgwidth,imgheight,aabb,trans);
	}
	let t4=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck4(imgwidth,imgheight,aabb,trans);
	}
	let t5=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck5(imgwidth,imgheight,aabb,trans);
	}
	let t6=performance.now();
	r=0;
	for (let test=0;test<tests;test++) {
		r&=randmask;
		let imgwidth=randabs[r++];
		let imgheight=randabs[r++];
		for (let i=0;i<6;i++) {trans[i]=randarr[r++];}
		aabb[0]=randarr[r++]; aabb[1]=randarr[r++];
		aabb[2]=randabs[r++]; aabb[3]=randabs[r++];
		overlap+=AABBCheck6(imgwidth,imgheight,aabb,trans);
	}
	let t7=performance.now();
	console.log("overlaps: ",overlap);
	console.log("t0: "+(t1-t0).toFixed(6));
	console.log("t1: "+(t2-t1).toFixed(6));
	console.log("t2: "+(t3-t2).toFixed(6));
	console.log("t3: "+(t4-t3).toFixed(6));
	console.log("t4: "+(t5-t4).toFixed(6));
	console.log("t5: "+(t6-t5).toFixed(6));
	console.log("t6: "+(t7-t6).toFixed(6));
	console.log("done");
}


function BoundingBoxDemo() {
	// Draw a bounding box to see how it reacts.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let input=new Input(canv);
	let draw=new Draw(1000,1000);
	draw.screencanvas(canv);
	let subimg=new Draw.Image(250,200);
	let trans=new Transform(2);
	let rnd=new Random();
	function parsefunction(str) {
		let reg=/.*?\((.*?)\)[ \n\t]{([\s\S]*)}/gmi;
		let match=reg.exec(str);
		if (match) {return new Function(match[1].split(","),match[2]);}
		return null;
	}
	let func=Draw.prototype.fillpoly.toString();
	Draw.colbnd=[0,0,0,0,0,0];
	Draw.colret=-1;
	func=func.replace("=by*matyy;",`=by*matyy; Draw.colret=0;
	                   Draw.colbnd=[bndx,bndy,bndxx,bndxy,bndyx,bndyy];`);
	for (let i=1;i<10;i++) {func=func.replace("return;","Draw.colret="+i+";return ;");}
	window.DrawPoly=Draw.Path;
	window.Draw=Draw;
	window.Transform=Transform;
	Draw.prototype.fillpoly=parsefunction(func);
	function update() {
		setTimeout(update,15);
		input.update();
		draw.fill(0,0,0,255);
		let mpos=input.getmousepos();
		let mx=mpos[0];
		let my=mpos[1];
		if (mx===-Infinity) {mx=0;}
		if (my===-Infinity) {my=0;}
		draw.pushstate();
		draw.setcolor(255,0,0,255);
		trans.vec.set([mx,my]);
		draw.settransform(trans);
		draw.filloval(0,0,100,50);
		let imgx=(draw.img.width-subimg.width)*0.5;
		let imgy=(draw.img.height-subimg.height)*0.5;
		draw.pushstate();
		draw.setimage(subimg);
		draw.fill(128,128,128,255);
		draw.setcolor(200,0,0,255);
		trans.vec.set([mx-imgx,my-imgy]);
		draw.settransform(trans);
		draw.filloval(0,0,100,50);
		let ret=Draw.colret;
		let aabb=Draw.colbnd.slice();
		draw.popstate();
		draw.drawimage(subimg,imgx,imgy);
		draw.popstate();
		draw.setcolor(255,255,255,255);
		let x0=aabb[0]+imgx,y0=aabb[1]+imgy;
		let x1=x0+aabb[2],y1=y0+aabb[3];
		let x2=x1+aabb[4],y2=y1+aabb[5];
		let x3=x0+aabb[4],y3=y0+aabb[5];
		draw.drawline(x0,y0,x1,y1);
		draw.drawline(x1,y1,x2,y2);
		draw.drawline(x2,y2,x3,y3);
		draw.drawline(x3,y3,x0,y0);
		draw.filltext(10,10,"col: "+ret);
		draw.screenflip();
		if (input.getkeychange(input.MOUSE.LEFT)>0) {
			trans.set({
				ang:rnd.getf()*Math.PI*2,
				scale:[rnd.gets()*4,rnd.gets()*4],
				vec:[rnd.gets()*100,rnd.gets()*100]
			});
		}
	}
	update();
}


function TestMain() {
	BoundingBoxTest();
	//BoundingBoxSpeedTest();
	//BoundingBoxDemo();
}
//TestMain();
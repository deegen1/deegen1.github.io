/*------------------------------------------------------------------------------


drawimagef.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint drawimagef.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Transform,Input} from "../library.js";


//---------------------------------------------------------------------------------
// Helper Functions


class AreaImage {

	constructor(width,height) {
		this.width=width;
		this.height=height;
		this.data=new Float64Array(width*height);
		this.clear();
	}


	clear() {
		let data=this.data;
		let i=this.width*this.height;
		if (i>data.length) {
			throw `invalid dimensions: ${i}, ${data.length}`;
		}
		while (i>7) {
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
		}
		while (i>0) {
			data[--i]=0;
		}
		this.readidx=0;
		this.writeidx=0;
		this.lockmax=-1;
	}


	lockrow(y) {
		if (!(y>=0 && y<this.height && y===(y|0))) {
			throw `invalid y: ${y}`;
		}
		let w=this.width,i=y*w;
		this.readidx=-i;
		this.writeidx=-i;
		this.lockmax=i+w;
	}


	write(i,val) {
		let r=this.readidx,w=this.writeidx;
		if (w<=0) {
			if (i<-w || !(i===(i|0))) {throw `non consecutive write: ${i} != ${w}`;}
			w=i;
		}
		if (!(i===w && i<this.lockmax)) {
			throw `Write OOB: ${w} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=++w;
		this.readidx=w>r?w:r;
		this.data[i]=val;
	}


	read(i) {
		let r=this.readidx,w=this.writeidx;
		if (r<=0) {
			if (i<-r || !(i===(i|0))) {throw `non consecutive read: ${i} != ${r}`;}
			r=i;
		}
		if (!(i===r && i<this.lockmax)) {
			throw `Read OOB: ${r} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=w>r?w:r;
		this.readidx=r+1;
		return this.data[i];
	}

}


function AABBOverlap(x0,y0,w0,h0,x1,y1,w1,h1) {
	// Return the area overlap of 2 rectangles.
	if (w0<0) {x0+=w0;w0=-w0;}
	if (y0<0) {y0+=h0;h0=-h0;}
	if (w1<0) {x1+=w1;w1=-w1;}
	if (y1<0) {y1+=h1;h1=-h1;}
	w0+=x0;h0+=y0;
	w1+=x1;h1+=y1;
	let x=x0>x1?x0:x1;
	let y=y0>y1?y0:y1;
	let w=w0<w1?w0:w1;
	let h=h0<h1?h0:h1;
	w-=x;h-=y;
	return (h>0 && w>0)?h*w:0;
}


//---------------------------------------------------------------------------------
// Fill Functions


function FillRect1(dstimg,rx,ry,rw,rh,trans) {
	// V1: Try and fill every pixel.
	let parr=[0,0,0,0,0,0,0,0],r1=rx+rw,r2=ry+rh,p=null;
	p=trans.apply([rx,ry]);parr[0]=p[0];parr[1]=p[1];
	p=trans.apply([r1,ry]);parr[2]=p[0];parr[3]=p[1];
	p=trans.apply([r1,r2]);parr[4]=p[0];parr[5]=p[1];
	p=trans.apply([rx,r2]);parr[6]=p[0];parr[7]=p[1];
	let imgw=dstimg.width,imgh=dstimg.height;
	for (let y=0;y<imgh;y++) {
		dstimg.lockrow(y);
		for (let x=0;x<imgw;x++) {
			let area=0;
			let x1=parr[6],y1=parr[7];
			for (let i=0;i<8;i+=2) {
				let x0=x1,y0=y1;
				x1=parr[i];y1=parr[i+1];
				area+=UnitAreaCalc(x0,y0,x1,y1,x,y);
			}
			area=area<0?-area:area;
			dstimg.write(y*imgw+x,area);
		}
	}
}


//---------------------------------------------------------------------------------


function DisplayRectTest() {
	// Test drawing a transformed rectangle.
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let imgw=draw.img.width;
	let imgh=draw.img.height;
	draw.fill(0,0,0,255);
	let rnd=new Random();
	let trans=new Transform(2);
	// Randomize transform.
	for (let i=0;i<4;i++) {
		trans.mat[i]=rnd.gets();
	}
	for (let i=0;i<2;i++) {
		trans.vec[i]=rnd.mod(imgw);
	}
	let dstdata=draw.img.data32;
	let dstarea=new AreaImage(imgw,imgh);
	let areadata=dstarea.data;
	let srcimg=new AreaImage(100,100);
	FillRect4(dstarea,srcimg,trans);
	for (let y=0;y<imgh;y++) {
		for (let x=0;x<imgw;x++) {
			let i=y*imgw+x;
			let area=areadata[i];
			let val=area>0?(area*255.9|0):0;
			dstdata[i]=val|(val<<8)|(val<<16)|(val<<24)|0xff000000;
		}
	}
	draw.screenflip();
}


function TestRectFill() {
	let tests=200000;
	let maxbits=10,maxdim=1<<maxbits;
	let dst=new AreaImage(maxdim,maxdim);
	let src=new AreaImage(maxdim,maxdim);
	let rnd=new Random(1);
	let trans=new Transform(2);
	function rndpow(min,max) {
		return rnd.gets()*Math.pow(2,rnd.getf()*(max-min)+min);
	}
	let maxdif=0;
	let sumdif=0;
	for (let test=0;test<tests;test++) {
		let dimw=1<<rnd.mod(maxbits+1);
		let dimh=1<<rnd.mod(maxbits+1);
		let dstw=rnd.mod(dimw+1);
		let dsth=rnd.mod(dimh+1);
		dimw=1<<rnd.mod(maxbits+1);
		dimh=1<<rnd.mod(maxbits+1);
		let srcw=rnd.mod(dimw+1);
		let srch=rnd.mod(dimh+1);
		dst.width=dstw;dst.height=dsth;
		src.width=srcw;src.height=srch;
		dst.clear();
		src.clear();
		let drawx=(rnd.getf()*3-1)*dimw;
		let drawy=(rnd.getf()*3-1)*dimh;
		let draww=(rnd.getf()*3-1)*dimw;
		let drawh=(rnd.getf()*3-1)*dimh;
		let align=rnd.getu32();
		if (align&1) {drawx=Math.round(drawx);}
		if (align&2) {drawy=Math.round(drawy);}
		if (align&4) {draww=Math.round(draww);}
		if (align&8) {drawh=Math.round(drawh);}
		FillRect1(dst1,drawx,drawy,draww,drawh);
		let pixels=dstw*dsth;
		let data1=dst1.data,data2=dst2.data;
		for (let i=0;i<pixels;i++) {
			let v1=data1[i],v2=data2[i];
			let dif=v1-v2;
			dif=dif<0?-dif:dif;
			sumdif+=dif;
			if (maxdif<dif) {
				maxdif=dif;
				//console.log("dif:",test,maxdif,sumdif);
			}
		}
	}
	console.log("max dif:",maxdif);
	console.log("sum dif:",sumdif);
}


//---------------------------------------------------------------------------------
// Old drawimage functions.


function drawimagef(draw,src,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dst=draw.img;
	let dstw=dst.width,dsth=dst.height;
	let srcw=src.width,srch=src.height;
	// Define src bounding box.
	dx=dx??0;
	dy=dy??0;
	dw=(isNaN(dw) || dw>srcw)?srcw:dw;
	dh=(isNaN(dh) || dh>srch)?srch:dh;
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw+=dx;
	dh+=dy;
	// Clamp to dst image.
	let sx=0,sy=0;
	let ix=Math.floor(dx),ax1=dx-ix,ax0=1-ax1;
	let iy=Math.floor(dy),ay1=dy-iy,ay0=1-ay1;
	if (ix<0) {sx=-ix;ix=0;}
	if (iy<0) {sy=-iy;iy=0;}
	let iw=(dw>dstw?dstw:Math.ceil(dw))-ix;
	let ih=(dh>dsth?dsth:Math.ceil(dh))-iy;
	if (iw<=0 || ih<=0 || sx>=srcw || sy>=srch) {return;}
	//
	let dstdata=dst.data32,didx=iy*dstw+ix;//,dinc=dstw-iw;
	let srcdata=src.data32,sidx=sy*srcw+sx;//,sinc=srcw-iw;
	let ystop=didx+dstw*ih,xstop=didx+iw;
	let area00=ax0*ay0*1.001/255;
	let area10=ax1*ay0*1.001/255;
	let area01=ax0*ay1*1.001/255;
	let area11=ax1*ay1*1.001/255;
	//let amul=draw.rgba[3];
	//let ashift=draw.rgbashift[3],namask=(~(255<<ashift))>>>0;
	//let maskl=0x00ff00ff&namask,maskh=0xff00ff00&namask;
	//iw=dst.width;
	while (didx<ystop) {
		let stop0=sidx+srcw-sx;
		let stop1=++sy<srch?stop0:0;
		let s10=srcdata[sidx];
		let s11=sidx<stop1?srcdata[sidx+srcw]:0;
		while (didx<xstop) {
			// Interpolate 2x2 source pixels.
			/*srow++;
			let s00=s10,s01=s11;
			s10=srow<stop0?srcdata[srow]:0;
			s11=srow<stop1?srcdata[srow+sw]:0;
			// m00 = alpha00 * area00
			const m=0x00ff00ff;
			let cl=imul(s00&m,m00)+imul(s01&m,m01)+imul(s10&m,m10)+imul(s11&m,m11);
			let ch=imul((s00>>>8)&m,m00)+imul((s01>>>8)&m,m01)+imul((s10>>>8)&m,m10)+imul((s11>>>8)&m,m11);
			src=(ch&0xff00ff00)|((cl>>>8)&m);
			let sa=(src>>>ashift)&255;
			if (sa<=0) {drow++;continue;}
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			// Approximate blending by expanding sa from [0,255] to [0,256].
			src&=namask;
			let tmp=dstdata[drow];
			let da=(tmp>>>ashift)&255;
			sa*=amul;
			da=sa*255+da*(65025-sa);
			sa=(sa*65280+(da>>>1))/da;
			da=((da+32512)/65025)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[drow++]=da|
				(((imul((src&m)-l,sa)>>>8)+l)&maskl)|
				((imul(((src>>>8)&m)-(h>>>8),sa)+h)&maskh);*/
			sidx++;
			dstdata[didx++]=0xffffffff;
		}
		xstop+=dstw;
		didx+=dstw-iw;
		sidx+=srcw-iw;
	}
}


//---------------------------------------------------------------------------------
// drawimage tests


function DrawImageDisplay() {
	// Displays an animated drawimage().
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let input=new Input(canv);
	let rnd=new Random();
	// Generate our source image.
	let srcw=100,srch=91;
	let srcimg=new Draw.Image(srcw,srch);
	draw.pushstate();
	draw.setimage(srcimg);
	draw.fill(0,0,0,0);
	draw.setcolor(255,0,0,128);
	draw.fillrect(0,0,srcw,1);
	draw.setcolor(0,255,0,200);
	draw.fillrect(srcw-1,0,1,srch);
	draw.setcolor(0,0,255,255);
	draw.fillrect(0,srch-1,srcw,1);
	draw.setcolor(255,255,255,64);
	draw.fillrect(0,0,1,srch);
	draw.setcolor(40,40,200,200);
	draw.filloval(srcw*0.5,srch*0.5,Math.min(srcw,srch)*0.45);
	draw.setcolor(200,40,40,255);
	draw.fillrect(srcw-30,srch-30,30,30);
	draw.setcolor(255,255,255,255);
	draw.filltext(5,5,"Hello\nWorld",24);
	draw.popstate();
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		let dstw=draw.img.width;
		let dsth=draw.img.width;
		draw.setcolor(40,40,80,255);
		let dim=50;
		for (let y=0;y<dsth;y+=dim) {
			for (let x=0;x<dstw;x+=dim) {
				if ((x+y)%(2*dim)) {
					draw.fillrect(x,y,dim,dim);
				}
			}
		}
		let mpos=input.getmousepos();
		let mx=mpos[0],my=mpos[1];
		let time=performance.now();
		//draw.drawimage(srcimg,0,0,trans);
		drawimagef(draw,srcimg,mx,my);
		let area=AABBOverlap(0,0,dstw,dsth,mx,my,srcw,srch);
		time=(performance.now()-time)*0.001;
		draw.setcolor(255,255,255,255);
		//draw.filltext(5,5,"Time: "+time.toFixed(6),20);
		draw.filltext(5,5,area.toFixed(6),20);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


function ImageStressTest() {
	// Stress Draw.drawimage().
	console.log("stress testing drawimage()");
	let rnd=new Random(10);
	let draw=new Draw();
	let maxbits=8,maxdim=1<<maxbits;
	let dstimg=new Draw.Image(maxdim,maxdim);
	let srcimg=new Draw.Image(maxdim,maxdim);
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	draw.setimage(dstimg);
	let pixels=dstimg.width*dstimg.height;
	for (let i=0;i<pixels;i++) {dstdata[i]=rnd.getu32();}
	pixels=srcimg.width*srcimg.height;
	for (let i=0;i<pixels;i++) {srcdata[i]=rnd.getu32();}
	let trans=new Transform(2);
	let tests=2000000;
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dimw=1<<rnd.mod(maxbits+1);
		let dimh=1<<rnd.mod(maxbits+1);
		dstimg.width =rnd.mod(dimw+1);
		dstimg.height=rnd.mod(dimh+1);
		dimw=1<<rnd.mod(maxbits+1);
		dimh=1<<rnd.mod(maxbits+1);
		srcimg.width =rnd.mod(dimw+1);
		srcimg.height=rnd.mod(dimh+1);
		for (let i=0;i<4;i++) {
			trans.mat[i]=rnd.gets()*Math.pow(2,rnd.gets()*20);
		}
		trans.vec[0]=(rnd.getf()*3-1)*dstimg.width;
		trans.vec[1]=(rnd.getf()*3-1)*dstimg.height;
		draw.rgba32[0]=rnd.getu32();
		draw.drawimage(srcimg,0,0,trans);
		//drawimage1(draw,srcimg,0,0,trans);
		//drawimage2(draw,srcimg,0,0,trans);
		//drawimage3(draw,srcimg,0,0,trans);
		//drawimage4(draw,srcimg,0,0,trans);
		//drawimage5(draw,srcimg,0,0,trans);
		//drawimage6(draw,srcimg,0,0,trans);
	}
	time=(performance.now()-time)/1000;
	console.log("image: "+time.toFixed(6));
}


function ImageSpeedTest() {
	// Stress Draw.drawimage().
	console.log("speed testing drawimage()");
	let rnd=new Random(10);
	let draw=new Draw();
	let maxbits=9,maxdim=1<<maxbits;
	let dstimg=new Draw.Image(maxdim,maxdim);
	let srcimg=new Draw.Image(maxdim,maxdim);
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	//let amask=(255<<draw.rgbashift[3])>>>0;
	draw.setimage(dstimg);
	let pixels=dstimg.width*dstimg.height;
	for (let i=0;i<pixels;i++) {dstdata[i]=rnd.getu32();}
	pixels=srcimg.width*srcimg.height;
	for (let i=0;i<pixels;i++) {srcdata[i]=rnd.getu32();}
	let trans=new Transform(2);
	let tests=10000;
	// Set to remove transforms.
	let isometric=0;
	let maxscale=isometric?-1:6;
	let outstr="";
	for (let scale=-1;scale<=maxscale;scale++) {
		let pot=scale-(maxscale>>1);
		let mag=Math.pow(2,pot);
		let matxx=1,matxy=0;
		let matyx=0,matyy=1;
		let time=performance.now();
		for (let test=0;test<tests;test++) {
			// Limit src dimensions to maxdim/2 and draw it in the center.
			let dimw=1<<rnd.mod(maxbits+1);
			let dimh=1<<rnd.mod(maxbits+1);
			let srcw=rnd.mod(dimw+1);
			let srch=rnd.mod(dimh+1);
			srcimg.width=srcw;
			srcimg.height=srch;
			// Create a unit area transform.
			if (scale>=0) {
				let ang=rnd.getf()*Math.PI*2;
				let xmul=(rnd.mod(2)*2-1)*mag;
				let ymul=(rnd.mod(2)*2-1)*mag;
				trans.mat[0]=matxx= xmul*Math.cos(ang);
				trans.mat[1]=matxy=-xmul*Math.sin(ang);
				trans.mat[2]=matyx= ymul*Math.sin(ang);
				trans.mat[3]=matyy= ymul*Math.cos(ang);
			}
			// Calculate AABB and center.
			let minx=Infinity,maxx=-Infinity;
			let miny=Infinity,maxy=-Infinity;
			for (let i=0;i<4;i++) {
				let x0=((3>>i)&1)?srcw:0;
				let y0=((6>>i)&1)?srch:0;
				let x=matxx*x0+matxy*y0;
				let y=matyx*x0+matyy*y0;
				minx=minx<x?minx:x;
				maxx=maxx>x?maxx:x;
				miny=miny<y?miny:y;
				maxy=maxy>y?maxy:y;
			}
			// Randomly place the image if it's small, otherwise center.
			let xdev=Math.max(maxdim-(maxx-minx),1)*0.5;
			let ydev=Math.max(maxdim-(maxy-miny),1)*0.5;
			let x=(maxdim-minx-maxx)*0.5+rnd.gets()*xdev;
			let y=(maxdim-miny-maxy)*0.5+rnd.gets()*ydev;
			// Align to integer boundary.
			if (scale<0) {x=Math.round(x);y=Math.round(y);}
			trans.vec[0]=x;
			trans.vec[1]=y;
			draw.rgba32[0]=rnd.getu32();
			draw.drawimage(srcimg,0,0,trans);
			//drawimagei(draw,srcimg,0,0);
			//drawimagef(draw,srcimg,0,0);
			//drawimage1(draw,srcimg,0,0,trans);
			//drawimage2(draw,srcimg,0,0,trans);
			//drawimage3(draw,srcimg,0,0,trans);
			//drawimage4(draw,srcimg,0,0,trans);
			//drawimage5(draw,srcimg,0,0,trans);
			//drawimage6(draw,srcimg,0,0,trans);
		}
		let timestr=((performance.now()-time)*0.001).toFixed(4);
		let type=scale<0?"iso ":`2^${pot.toString().padStart(2,' ')}`;
		console.log(type+": "+timestr);
		outstr+="  |  "+timestr.padStart(7," ");
	}
	console.log(outstr);
}


function TestMain() {
	console.log("drawimagef");
	//TestRectFill();
	DrawImageDisplay();
	//ImageStressTest();
	//ImageSpeedTest();
	console.log("done");
}
//TestMain();

/*------------------------------------------------------------------------------


drawimagei.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


test rejection
test clamping
	check if sx>=srcw is needed, NaN, inf
speed for 100% random
speed for 25% 0, 25% 255, 50% random

FF
1: 17.905800 17.485740
2: 17.043560 16.640740
3: 19.836040 19.585680
4: 17.621620 16.458300
5: 17.516000 18.582220
6: 16.437780 16.415820

CR
1: 11.698955 11.561460
2: 11.668255 11.499580
3: 12.072435 11.958625
4: 12.412985 11.672515
5: 10.970165 10.971000
6: 11.810065 11.825495


*/
/* npx eslint drawimagei.js -c ../../../standards/eslint.js */


import {Draw} from "../drawing.js";
import {Random,Input} from "../library.js";


//---------------------------------------------------------------------------------
// Helper Functions


class AreaImage {

	constructor(width,height) {
		this.data=new Float64Array(width*height);
		this.reset(width,height);
	}


	reset(w,h) {
		let data=this.data;
		this.width=w;
		this.height=h;
		let i=w*h;
		if (!(i===i) || i<0 || i>data.length) {
			throw `invalid dimensions: ${i}, ${data.length}`;
		}
		while (i>7) {
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
			data[--i]=0;data[--i]=0;
		}
		while (i>0) {
			data[--i]=0;
		}
		this.readidx=0;
		this.writeidx=0;
		this.lockmax=-1;
	}


	lockrow(y) {
		if (!(y>=0 && y<this.height && y===(y|0))) {
			throw `invalid y: ${y}`;
		}
		let w=this.width,i=y*w;
		this.readidx=-i;
		this.writeidx=-i;
		this.lockmax=i+w;
	}


	write(i,val) {
		let r=this.readidx,w=this.writeidx;
		if (w<=0) {
			if (i<-w || !(i===(i|0))) {throw `non consecutive write: ${i} != ${w}`;}
			w=i;
		}
		if (!(i===w && i<this.lockmax)) {
			throw `Write OOB: ${w} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=++w;
		this.readidx=w>r?w:r;
		this.data[i]=val;
	}


	read(i) {
		let r=this.readidx,w=this.writeidx;
		if (r<=0) {
			if (i<-r || !(i===(i|0))) {throw `non consecutive read: ${i} != ${r}`;}
			r=i;
		}
		if (!(i===r && i<this.lockmax)) {
			throw `Read OOB: ${r} != ${i} < ${this.lockmax}`;
		}
		this.writeidx=w>r?w:r;
		this.readidx=r+1;
		return this.data[i];
	}


	compare(img) {
		let w=this.width,h=this.height;
		if (img.width!==w || img.height!==h) {
			throw `different dimensions: (${w},${h}) != (${img.width},${img.height})`;
		}
		let data1=this.data,data2=img.data;
		let pixels=w*h;
		let err=0;
		for (let i=0;i<pixels && err<Infinity;i++) {
			let dif=data1[i]-data2[i];
			dif=dif<0?-dif:dif;
			err=err>dif?err:dif;
		}
		return err;
	}

}


//---------------------------------------------------------------------------------
// Fill testing


function DrawFill1(dstimg,srcimg,dx,dy,dw,dh) {
	// Very basic fill function.
	dx=Math.round(dx);
	dy=Math.round(dy);
	dw=Math.round(dw);
	dh=Math.round(dh);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	let minx=dx,maxx=dx+dw;
	let miny=dy,maxy=dy+dh;
	if (!(minx>-Infinity && minx<maxx && maxx<Infinity)) {return;}
	if (!(miny>-Infinity && miny<maxy && maxy<Infinity)) {return;}
	let dstw=dstimg.width,dsth=dstimg.height;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstdata=dstimg;
	let srcdata=srcimg;
	for (dy=0;dy<dsth;dy++) {
		let sy=dy-miny;
		if (sy<0 || sy>=srch || dy>=maxy) {continue;}
		dstdata.lockrow(dy);
		srcdata.lockrow(sy);
		for (dx=0;dx<dstw;dx++) {
			let sx=dx-minx;
			if (sx>=0 && sx<srcw && dx<maxx) {
				srcdata.write(sy*srcw+sx,1);
				dstdata.write(dy*dstw+dx,1);
			}
		}
	}
}


function DrawFill2(dstimg,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject
	// let amul=draw.rgba[3];
	if (dw<=0 || dh<=0) {return;}
	// Setup
	let area=0,maxarea=Math.min(srcw*srch,dstw*dsth)+1;
	let dstdata=dstimg,srcdata=srcimg;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	while (didx<ystop) {
		srcimg.lockrow(~~(sidx/srcw));
		dstimg.lockrow(~~(didx/dstw));
		while (didx<xstop) {
			srcdata.read(sidx);
			srcdata.write(sidx,1);
			dstdata.write(didx,1);
			sidx++;
			didx++;
			area++;
			if (area>maxarea) {throw "runaway";}
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
	if (!area) {throw "empty fill";}
}


function TestDrawFill() {
	console.log("testing filling");
	let tests=200000;
	let maxbits=10,maxdim=1<<maxbits;
	let dst1=new AreaImage(maxdim,maxdim);
	let dst2=new AreaImage(maxdim,maxdim);
	let src1=new AreaImage(maxdim,maxdim);
	let src2=new AreaImage(maxdim,maxdim);
	let rnd=new Random(1);
	for (let test=0;test<tests;test++) {
		if (!(test&0xfff)) {console.log("test:",test);}
		// Randomize dimensions and draw position.
		let dimw=1<<rnd.mod(maxbits+1);
		let dimh=1<<rnd.mod(maxbits+1);
		let dstw=rnd.mod(dimw+1);
		let dsth=rnd.mod(dimh+1);
		let drawx=(rnd.getf()*3-1)*dimw;
		let drawy=(rnd.getf()*3-1)*dimh;
		let draww=(rnd.getf()*3-1)*dimw;
		let drawh=(rnd.getf()*3-1)*dimh;
		dimw=1<<rnd.mod(maxbits+1);
		dimh=1<<rnd.mod(maxbits+1);
		let srcw=rnd.mod(dimw+1);
		let srch=rnd.mod(dimh+1);
		// Test filling.
		dst1.reset(dstw,dsth);
		dst2.reset(dstw,dsth);
		src1.reset(srcw,srch);
		src2.reset(srcw,srch);
		DrawFill1(dst1,src1,drawx,drawy,draww,drawh);
		DrawFill2(dst2,src2,drawx,drawy,draww,drawh);
		// Compare dst and src.
		if (dst1.compare(dst2)!==0) {throw "dst dif";}
		if (src1.compare(src2)!==0) {throw "src dif";}
	}
}


//---------------------------------------------------------------------------------
// Old drawimage functions.


function drawimagei1(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	// Intersection of src and dst.
	let sx=0,sy=0;
	dw=(dw<srcw?dw:srcw)+dx;
	if (dx<0) {sx=-dx;dx=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<srch?dh:srch)+dy;
	if (dy<0) {sy=-dy;dy=0;}
	dh=(dh<dsth?dh:dsth)-dy;
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let drow=dy*dstw+dx,dinc=dstw-dw;
	let srow=sy*srcw+sx,sinc=srcw-dw;
	let ystop=drow+dstw*dh,xstop=drow+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	while (drow<ystop) {
		while (drow<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[srow++];
			let sa=(src>>>ashift)&255;
			if (sa<=0) {drow++;continue;}
			let tmp=dstdata[drow];
			let da=(tmp>>>ashift)&255;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			// imul() implicitly cast floor().
			sa*=amul;
			da=sa*255+da*(65025-sa);
			sa=(sa*65280+(da>>>1))/da;
			da=((da+32512)/65025)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[drow++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dstw;
		drow+=dinc;
		srow+=sinc;
	}
}


function drawimagei2(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	// Setup
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	while (didx<ystop) {
		while (didx<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[sidx++];
			let sa=(src>>>ashift)&255;
			if (sa<=0) {didx++;continue;}
			let tmp=dstdata[didx];
			let da=(tmp>>>ashift)&255;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			// imul() implicitly cast floor().
			sa*=amul;
			da=sa*255+da*(65025-sa);
			sa=(sa*65280+(da>>>1))/da;
			da=((da+32512)/65025)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[didx++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
}


function drawimagei3(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject if out of bounds.
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	// Setup blending.
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	let smul=(amul/255)/255;
	let dmul=1/255;
	while (didx<ystop) {
		while (didx<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[sidx++]>>>0;
			let sa=(src>>>ashift)&255;
			if (sa<=0) {didx++;continue;}
			let tmp=dstdata[didx]>>>0;
			let da=((tmp>>>ashift)&255)*dmul;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			// imul() implicitly cast floor().
			sa*=smul;
			da=sa+da*(1-sa);
			sa=~~((sa/da)*256+0.5);
			da=(da*255+0.5)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[didx++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
}


function drawimagei4(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject if out of bounds.
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	// Setup blending.
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	while (didx<ystop) {
		while (didx<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[sidx++];
			let sa=((src>>>ashift)&255)*amul;
			if (sa>=65025) {
				dstdata[didx]=src;
			} else if (sa>=255) {
				let tmp=dstdata[didx];
				let da=(tmp>>>ashift)&255;
				// Approximate blending by expanding sa from [0,255] to [0,256].
				// imul() implicitly cast floor().
				da=sa*255+da*(65025-sa);
				sa=(sa*65280+(da>>>1))/da;
				da=((da+32512)/65025)<<ashift;
				let l=tmp&0x00ff00ff;
				let h=tmp&0xff00ff00;
				dstdata[didx]=da|
					(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
					((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
			}
			didx++;
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
}


function drawimagei5(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject if out of bounds.
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	// Setup blending.
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	while (didx<ystop) {
		while (didx<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[sidx++];
			let sa=((src>>>ashift)&255)*amul;
			let tmp=dstdata[didx];
			let da=(tmp>>>ashift)&255;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			// imul() implicitly cast floor().
			da=sa*255+da*(65025-sa)+1;
			sa=(sa*65280+(da>>>1))/da;
			//da=((da+32512)/65025)<<ashift;
			da=(da*0.000015379+0.5)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[didx++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
}


function drawimagei6(draw,srcimg,dx,dy,dw,dh) {
	// Draw an image with alpha blending.
	let dstimg=draw.img;
	let srcw=srcimg.width,srch=srcimg.height;
	let dstw=dstimg.width,dsth=dstimg.height;
	// Calculate src AABB.
	dx=Math.round(dx??0);
	dy=Math.round(dy??0);
	dw=Math.round(dw??srcw);
	dh=Math.round(dh??srch);
	if (dw<0) {dx+=dw;dw=-dw;}
	if (dh<0) {dy+=dh;dh=-dh;}
	dw=(dw<srcw?dw:srcw)+dx;
	dh=(dh<srch?dh:srch)+dy;
	// Clamp to dst.
	let sx=0,sy=0;
	if (dx<0) {sx=-dx;dx=0;}
	if (dy<0) {sy=-dy;dy=0;}
	dw=(dw<dstw?dw:dstw)-dx;
	dh=(dh<dsth?dh:dsth)-dy;
	// Reject if out of bounds.
	let amul=draw.rgba[3];
	if (dw<=0 || dh<=0 || amul<=0) {return;}
	// Setup blending.
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let didx=dy*dstw+dx,dinc=dstw-dw;
	let sidx=sy*srcw+sx,sinc=srcw-dw;
	let ystop=didx+dstw*dh,xstop=didx+dw;
	let ashift=draw.rgbashift[3],amask=(255<<ashift)>>>0;
	let maskl=0x00ff00ff&(~amask),maskh=0xff00ff00&(~amask);
	while (didx<ystop) {
		while (didx<xstop) {
			// a = sa + da*(1-sa)
			// c = (sc*sa + dc*da*(1-sa)) / a
			let src=srcdata[sidx++];
			let sa=Math.imul(((src>>>ashift)&255),amul);
			let tmp=dstdata[didx];
			let da=(tmp>>>ashift)&255;
			// Approximate blending by expanding sa from [0,255] to [0,256].
			// imul() implicitly cast floor().
			da=Math.imul(sa,255)+Math.imul(da,65025-sa)+1;
			sa=((Math.imul(sa,65280)>>>0)+(da>>>1))/da;
			//da=((da+32512)/65025)<<ashift;
			da=(da*0.000015379+0.5)<<ashift;
			let l=tmp&0x00ff00ff;
			let h=tmp&0xff00ff00;
			dstdata[didx++]=da|
				(((Math.imul((src&0x00ff00ff)-l,sa)>>>8)+l)&maskl)|
				((Math.imul(((src>>>8)&0x00ff00ff)-(h>>>8),sa)+h)&maskh);
		}
		xstop+=dstw;
		didx+=dinc;
		sidx+=sinc;
	}
}


//---------------------------------------------------------------------------------
// Tests


function ImageSpeedTest() {
	// Stress Draw.drawimage().
	console.log("speed testing drawimagei()");
	let maxbits=9,maxdim=1<<maxbits;
	let draw=new Draw(maxdim,maxdim);
	let dstimg=draw.img;
	let srcimg=new Draw.Image(maxdim,maxdim);
	let dstdata=dstimg.data32,srcdata=srcimg.data32;
	let ashift=draw.rgbashift[3],amask=(~(255<<ashift))>>>0;
	let tests=10000000;
	let funcarr=[
		drawimagei1,
		drawimagei2,
		drawimagei3,
		drawimagei4,
		drawimagei5,
		drawimagei6
	];
	let funcs=funcarr.length;
	let ret=new Array(funcs);
	for (let f=0;f<funcs*3;f++) {
		// mode 0: warmup
		// mode 1: random
		// mode 2: 33% 0, 33% 255, 33% other
		let id=f%funcs;
		let mode=~~(f/funcs);
		let func=funcarr[id];
		// Randomize pixels.
		let rnd=new Random(10);
		let pixels=dstimg.width*dstimg.height;
		for (let i=0;i<pixels;i++) {dstdata[i]=rnd.getu32();}
		pixels=srcimg.width*srcimg.height;
		for (let i=0;i<pixels;i++) {
			let col=rnd.getu32();
			if (mode===2) {
				let t=rnd.mod(3);
				let a=(col>>>ashift)&255;
				if (t===1) {a=0;}
				else if (t===2) {a=255;}
				else {a=(a%254)+1;}
				col=(col&amask)|(a<<ashift);
			}
			srcdata[i]=col;
		}
		draw.rgba32[0]=0xffffffff;
		let time=performance.now();
		for (let test=0;test<tests;test++) {
			// Randomize dimensions.
			let dimw=1<<rnd.mod(maxbits+1);
			let dimh=1<<rnd.mod(maxbits+1);
			let srcw=rnd.mod(dimw+1);
			let srch=rnd.mod(dimh+1);
			dimw=1<<rnd.mod(maxbits+1);
			dimh=1<<rnd.mod(maxbits+1);
			let dstw=rnd.mod(dimw+1);
			let dsth=rnd.mod(dimh+1);
			srcimg.width=srcw;srcimg.height=srch;
			dstimg.width=dstw;dstimg.height=dsth;
			// Randomly place the image.
			let x=srcw<dstw?rnd.mod(dstw-srcw+1):0;
			let y=srch<dsth?rnd.mod(dsth-srch+1):0;
			if (mode!==2) {draw.rgba32[0]=rnd.getu32();}
			func(draw,srcimg,x,y);
		}
		time=(performance.now()-time)*0.001;
		if (mode) {
			ret[id]+=time.toFixed(6).padStart(10," ");
		} else {
			ret[id]=`${id+1}:`;
		}
	}
	let out=ret.join("\n");
	console.log(out);
}


function DrawImageDisplay() {
	// Displays an animated drawimage().
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let input=new Input(canv);
	// Generate our source image.
	let srcw=100,srch=91;
	let srcimg=new Draw.Image(srcw,srch);
	draw.pushstate();
	draw.setimage(srcimg);
	draw.fill(0,0,0,0);
	draw.setcolor(255,0,0,128);
	draw.fillrect(0,0,srcw,1);
	draw.setcolor(0,255,0,200);
	draw.fillrect(srcw-1,0,1,srch);
	draw.setcolor(0,0,255,255);
	draw.fillrect(0,srch-1,srcw,1);
	draw.setcolor(255,255,255,64);
	draw.fillrect(0,0,1,srch);
	draw.setcolor(40,40,200,200);
	draw.filloval(srcw*0.5,srch*0.5,Math.min(srcw,srch)*0.45);
	draw.setcolor(200,40,40,255);
	draw.fillrect(srcw-30,srch-30,30,30);
	draw.setcolor(255,255,255,255);
	draw.filltext(5,5,"Hello\nWorld",24);
	draw.popstate();
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		let dstw=draw.img.width;
		let dsth=draw.img.width;
		draw.setcolor(40,40,80,255);
		let dim=50;
		for (let y=0;y<dsth;y+=dim) {
			for (let x=0;x<dstw;x+=dim) {
				if ((x+y)%(2*dim)) {
					draw.fillrect(x,y,dim,dim);
				}
			}
		}
		let mpos=input.getmousepos();
		let mx=mpos[0],my=mpos[1];
		let time=performance.now();
		drawimagei6(draw,srcimg,mx,my);
		time=(performance.now()-time)*0.001;
		draw.setcolor(255,255,255,255);
		draw.filltext(5,5,"Time: "+time.toFixed(6),20);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


//---------------------------------------------------------------------------------
// Main


function TestMain() {
	console.log("drawimagei");
	//TestDrawFill();
	ImageSpeedTest();
	//DrawImageDisplay();
	console.log("done");
}
//TestMain();

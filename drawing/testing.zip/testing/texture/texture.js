/*------------------------------------------------------------------------------


texture.js - v1.00

Copyright 2026 Alec Dee
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
History


--------------------------------------------------------------------------------
TODO


turn bricks into stars, rad = sqrt(area)
larger = bluer
small = grey


*/
/* npx eslint texture.js -c ../../standards/eslint.js */


import {Random,Draw} from "./library.js";


function RenderVoronoi(img,rnd) {
	// Wrap around
	if (rnd===undefined) {rnd=new Random();}
	let draww=img.width,drawh=img.height;
	let pixels=draww*drawh;
	let data=img.data8;
	function modwh(x) {return x-Math.round(x/draww)*draww;}
	function modw( x) {return x-Math.floor(x/draww)*draww;}
	function modhh(x) {return x-Math.round(x/drawh)*drawh;}
	function modh( x) {return x-Math.floor(x/drawh)*drawh;}
	// Voronoi bricks
	let nodemap=(new Array(pixels)).fill(null);
	let distmap=(new Array(pixels)).fill(Infinity);
	let nodearr=[];
	let nodequeue=[];
	function addpix(node,px,py) {
		px=modw(px);
		py=modh(py);
		let pix=py*draww+px;
		let dx=modwh(px+0.5-node.x);
		let dy=modhh(py+0.5-node.y);
		let dist=dx*dx+dy*dy;
		if (distmap[pix]>dist) {
			nodequeue.push(pix);
			distmap[pix]=dist;
			nodemap[pix]=node;
		}
	}
	// Create seeds.
	let seeds=~~(draww*drawh/200);
	for (let s=0;s<seeds;s++) {
		let node={x:rnd.getf()*draww,y:rnd.getf()*drawh,col:0,size:0};
		addpix(node,Math.floor(node.x),Math.floor(node.y));
		nodearr.push(node);
	}
	// Fill by distance.
	for (let i=0;i<nodequeue.length;i++) {
		let pix=nodequeue[i];
		let node=nodemap[pix];
		let px=pix%draww,py=~~(pix/draww);
		let dx=1,dy=0;
		for (let d=0;d<4;d++) {
			addpix(node,px+dx,py+dy);
			let t=dx;dx=-dy;dy=t;
		}
	}
	// Color by size.
	for (let i=0;i<pixels;i++) {nodemap[i].size++;}
	nodearr.sort((l,r)=>l.size-r.size);
	let norm=nodearr[~~(nodearr.length*0.95)].size;
	for (let node of nodearr) {
		node.col=Math.min(node.size/norm,1);
		node.size=-1;
	}
	for (let i=0;i<pixels;i++) {
		let node=nodemap[i];
		node.size=i;
		let px=i%draww,py=~~(i/draww);
		let x0=node.x,y0=node.y;
		let tx=modwh(px+0.5-x0);
		let ty=modhh(py+0.5-y0);
		// see if we're near another border
		let u=1;
		for (let oy=-2;oy<3;oy++) {
			let my=modh(py+oy)*draww;
			for (let ox=-2;ox<3;ox++) {
				let mx=modw(px+ox);
				let n=nodemap[my+mx];
				if (n.size>=i) {continue;}
				n.size=i;
				let x1=n.x,y1=n.y;
				let dx=modwh(x1-x0);
				let dy=modhh(y1-y0);
				let d=dx*dx+dy*dy;
				let v=tx*dx+ty*dy;
				d=Math.sqrt(d);
				v=Math.abs(v/d-d*0.5);//*0.5;
				u=u<v?u:v;
			}
		}
		let j=i*4;
		let c=u*node.col*50;
		data[j++]=c;
		data[j++]=c;
		data[j++]=c;
		data[j++]=255;
	}
}


function RenderFungi(img,rnd) {
	if (rnd===undefined) {rnd=new Random();}
	let draww=img.width,drawh=img.height;
	let pixels=draww*drawh;
	let data=img.data8;
	function modw(x) {return x-Math.floor(x/draww)*draww;}
	function modh(x) {return x-Math.floor(x/drawh)*drawh;}
	// Fungi Splash
	let timemap=(new Array(pixels)).fill(-1);
	let pixqueue=(new Array(pixels)).fill(0);
	let nbrarr=(new Array(9)).fill(0);
	let seeds=Math.ceil(pixels*0.00003);
	let qidx=0;
	for (let i=0;i<seeds;i++) {
		let p=rnd.mod(pixels);
		pixqueue[qidx++]=p;
		timemap[p]=rnd.getf();
	}
	while (qidx>0) {
		let i=rnd.mod(qidx);
		let p=pixqueue[i];
		pixqueue[i]=pixqueue[--qidx];
		let px=p%draww,py=~~(p/draww);
		let nidx=0;
		for (let dy=-1;dy<2;dy++) {
			let ty=modh(py+dy)*draww;
			for (let dx=-1;dx<2;dx++) {
				let tx=modw(px+dx);
				let n=ty+tx;
				if (timemap[n]<0) {
					nbrarr[nidx++]=n;
				}
			}
		}
		if (nidx>0) {
			let n=nbrarr[rnd.mod(nidx)];
			let t=timemap[p]+rnd.getf()*0.1;
			t-=Math.floor(t);
			timemap[n]=t;
			if (nidx>1) {
				pixqueue[qidx++]=p;
			}
			pixqueue[qidx++]=n;
		}
	}
	for (let i=0;i<pixels;i++) {
		let c=75*timemap[i];
		let j=i*4;
		data[j++]=c;
		data[j++]=c;
		data[j++]=c;
		data[j++]=255;
	}
}


function RenderIce(img,rnd) {
	// Ice crystals
	if (rnd===undefined) {rnd=new Random();}
	let draww=img.width,drawh=img.height;
	let pixels=draww*drawh;
	let data=img.data8;
	function modw(x) {return x-Math.floor(x/draww)*draww;}
	function modh(x) {return x-Math.floor(x/drawh)*drawh;}
	// Ice crystals
	let timemap=(new Array(pixels)).fill(-1);
	let pixqueue=(new Array(pixels)).fill(0);
	let nbrarr=(new Array(9)).fill(0);
	let qidx=0,seeds=Math.round(pixels*0.0003);
	for (let i=0;i<seeds;i++) {
		let p=rnd.mod(pixels);
		pixqueue[qidx++]=p;
		timemap[p]=rnd.getf();
	}
	while (qidx>0) {
		let i=rnd.mod(qidx);
		let p=pixqueue[i];
		pixqueue[i]=pixqueue[--qidx];
		let px=p%draww,py=~~(p/draww);
		let nidx=0;
		for (let dy=-1;dy<2;dy++) {
			let ty=modh(py+dy)*draww;
			for (let dx=-1;dx<2;dx++) {
				let tx=modw(px+dx);
				let n=ty+tx;
				if (timemap[n]<0) {
					nbrarr[nidx++]=n;
				}
			}
		}
		if (nidx>0) {
			let n=nbrarr[rnd.mod(nidx)];
			let t=timemap[p]+rnd.gets()*0.1;
			t-=Math.floor(t);
			timemap[n]=t;
			if (nidx>1) {
				pixqueue[qidx++]=p;
			}
			pixqueue[qidx++]=n;
		}
	}
	for (let i=0;i<pixels;i++) {
		let t=timemap[i];
		t=1-2*Math.abs(0.5-t);
		let j=i*4;
		data[j++]=50*t+25;
		data[j++]=100*t+25;
		data[j++]=128;
		data[j++]=255;
	}
}


function RenderRoots(img,rnd) {
	// Roots -<//\\//
	if (rnd===undefined) {rnd=new Random();}
	let draww=img.width,drawh=img.height;
	let pixels=draww*drawh;
	let data=img.data8;
	function modw(x) {return x-Math.floor(x/draww)*draww;}
	function modh(x) {return x-Math.floor(x/drawh)*drawh;}
	// Roots -<//\\//
	let seedmap=(new Array(pixels)).fill(0);
	let branchprob=0.04,branchang=1.0,turnmul=0.1;
	let seeds=~~(draww*drawh*0.0005),sidx=0,maxseeds=10000;
	let seedarr=(new Array(maxseeds)).fill(null);
	while (sidx<seeds) {
		let ang=rnd.getf()*Math.PI*2,x=rnd.getf()*draww,y=rnd.getf()*drawh;
		let seed={x:x,y:y,life:1,ang:ang};
		seedarr[sidx++]=seed;
		seed={x:x,y:y,life:1,ang:ang+Math.PI};
		seedarr[sidx++]=seed;
	}
	while (sidx>0) {
		let stop=sidx;
		sidx=0;
		for (let s=0;s<stop;s++) {
			let seed=seedarr[s];
			let life=seed.life;
			if (life<=0.02) {continue;}
			let x=modw(seed.x);
			let y=modh(seed.y);
			let ang=seed.ang;
			seedarr[sidx++]=seed;
			while (rnd.getf()<life*branchprob && stop<maxseeds) {
				life*=0.95;
				let child={x:x,y:y,life:life,ang:ang+rnd.getnorm()*branchang};
				seedarr[stop++]=child;
			}
			// Draw root.
			let ix=~~x,iy=~~y;
			for (let dy=0;dy<2;dy++) {
				let ty=modh(iy+dy)*draww;
				for (let dx=0;dx<2;dx++) {
					let tx=modw(ix+dx);
					let pix=ty+tx;
					seedmap[pix]=(life+seedmap[pix])*0.5;
				}
			}
			// Move faster the more we've branched.
			let move=rnd.getf()*0.9+0.1;
			seed.x=x+Math.cos(ang)*move;
			seed.y=y+Math.sin(ang)*move;
			seed.life=life-rnd.getf()*0.01;
			ang=ang+rnd.getnorm()*turnmul;
			seed.ang=ang-Math.floor(ang/(Math.PI*2))*(Math.PI*2);
		}
	}
	for (let i=0;i<pixels;i++) {
		let t=seedmap[i]*3;
		let j=i*4;
		data[j++]=51*t;
		data[j++]=40*t;
		data[j++]=22*t;
		data[j++]=255;
	}
}


function SpeedTest() {
	let rnd=new Random(0);
	let draw=new Draw(4000,4000);
	let img=draw.img;
	let t0=performance.now();
	RenderVoronoi(img,rnd);
	let t1=performance.now();
	RenderFungi(img,rnd);
	let t2=performance.now();
	RenderIce(img,rnd);
	let t3=performance.now();
	RenderRoots(img,rnd);
	let t4=performance.now();
	t4=(t4-t3)*0.001;
	t3=(t3-t2)*0.001;
	t2=(t2-t1)*0.001;
	t1=(t1-t0)*0.001;
	console.log("t1:",t1.toFixed(6));
	console.log("t2:",t2.toFixed(6));
	console.log("t3:",t3.toFixed(6));
	console.log("t4:",t4.toFixed(6));
}


function main() {
	let rnd=new Random(0);
	let draw=new Draw(1024,1024);
	let img=new Draw.Image(256,256);
	RenderVoronoi(img,rnd);
	//RenderFungi(img,rnd);
	//RenderIce(img,rnd);
	//RenderRoots(img,rnd);
	for (let x=0;x<1024;x+=256) {
		for (let y=0;y<1024;y+=256) {
			draw.drawimage(img,x,y);
		}
	}
	draw.img.savefile("tile.tga");
	//SpeedTest();
}
main();


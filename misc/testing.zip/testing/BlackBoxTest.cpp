/*

BlackBoxTest.cpp - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Compiling


Fast:
g++ -O3 BlackBoxTest.cpp -o test -lm

Debug:
rm test; g++ -fsanitize=address -fsanitize=undefined BlackBoxTest.cpp -o test
-lm; ./test

cl /O2 /DSDL_MAIN_HANDLED BlackBoxTest.cpp /I "C:\SDL2\include" /link \
/LIBPATH:"C:\SDL2\lib\x64" SDL2.lib SDL2main.lib /SUBSYSTEM:CONSOLE


--------------------------------------------------------------------------------
TODO:

create test function
create opt function
create test suite
enable multithreading

#if defined(_MSC_VER)!=0
	#include <intrin.h>
	#define _Thread_local __declspec(thread)
#else
	#include <x86intrin.h>
#endif


*/

#if defined(__GNUC__)
	#pragma GCC diagnostic error "-Wall"
	#pragma GCC diagnostic error "-Wextra"
	#pragma GCC diagnostic error "-Wpedantic"
	#pragma GCC diagnostic error "-Wformat=1"
	#pragma GCC diagnostic error "-Wconversion"
	#pragma GCC diagnostic error "-Wshadow"
	#pragma GCC diagnostic error "-Wundef"
	#pragma GCC diagnostic error "-Winit-self"
#elif defined(_MSC_VER)
	#pragma warning(push,4)
#endif

#define _CRT_SECURE_NO_WARNINGS
#ifdef _MSC_VER
	#include <windows.h>
#endif

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <inttypes.h>
#include <time.h>
#include <cstdarg>
#include <string.h>
#include <vector>


typedef  uint8_t  u8;
typedef uint16_t u16;
typedef  int32_t s32;
typedef uint32_t u32;
typedef  int64_t s64;
typedef uint64_t u64;
typedef    float f32;
typedef   double f64;


//---------------------------------------------------------------------------------
// Helper Functions


f64 GetTime(void) {
	static u64 timeoff=0;
	static f64 timeres=0.0;
	static f64 timelast=0.0;
	if (timeres==0.0) {
		#if defined(_WIN32) || defined(_WIN64)
			u64 freq=0;
			if (QueryPerformanceCounter((LARGE_INTEGER*)&freq)!=0 && QueryPerformanceFrequency((LARGE_INTEGER*)&freq)!=0 && freq!=0) {
				timeres=1.0/((f64)freq);
			}
			FILETIME off;
			QueryPerformanceCounter((LARGE_INTEGER*)&timeoff);
			GetSystemTimeAsFileTime(&off);
			timeoff-=(((((u64)off.dwHighDateTime)<<32)+((u64)off.dwLowDateTime))/10000000ULL-0x2b6109100ULL)*freq;
		#elif defined(__APPLE__) || defined(__MACH__)
			timeoff=0;
			timeres=1.0/1000000.0;
		#elif defined(__linux__)
			timeoff=0;
			timeres=1.0/1000000000.0;
		#else
			timeoff=(u32)time(0);
			timeres=1.0;
		#endif
	}
	#if defined(_WIN32) || defined(_WIN64)
		u64 time;
		QueryPerformanceCounter((LARGE_INTEGER*)&time);
		f64 ret=((f64)(time-timeoff))*timeres;
	#elif defined(__APPLE__) || defined(__MACH__)
		struct timeval t;
		gettimeofday(&t,0);
		f64 ret=((f64)(((u64)t.tv_sec)*1000000ULL   +((u64)t.tv_usec)-timeoff))*timeres;
	#elif defined(__linux__)
		struct timespec t;
		clock_gettime(CLOCK_REALTIME,&t);
		f64 ret=((f64)(((u64)t.tv_sec)*1000000000ULL+((u64)t.tv_nsec)-timeoff))*timeres;
	#else
		f64 ret=((f64)(((u32)time(0))-((u32)timeoff)))*timeres;
	#endif
	// Make sure our return times are monotonic.
	timelast=timelast>ret?timelast:ret;
	return timelast;
}


//---------------------------------------------------------------------------------
// PRNG


class Random {
public:
	u64 state_;
	u64 inc_;

	Random(void) {seed();}


	Random(u64 seed_) {seed(seed_);}


	~Random(void) {}


	void seed(void) {seed((u64)clock());}


	void seed(u64 seed) {
		state_=0;
		inc_  =seed;
		state_=getu64();
		inc_  =getu64()|1;
	}


	static u64 hashu64(u64 val) {
		// Returns a 64 bit hash of val.
		val+=0x9464b849fa901cd9ULL;
		val+=val<<21;val^=val>>44;
		val+=val<<18;val^=val>>30;
		val+=val<<25;val^=val>>33;
		val+=val<<40;val^=val>> 5;
		val+=val<<10;val^=val>>16;
		return val;
	}


	static u32 hashu32(u32 val) {
		// Returns a 32 bit hash of val.
		val+=0xf0ce0984;
		val+=val<<17;val^=val>>11;
		val+=val<< 5;val^=val>> 7;
		val+=val<< 9;val^=val>>14;
		val+=val<<10;val^=val>> 6;
		val+=val<< 7;val^=val>> 9;
		return val;
	}


	u64 getu64(void) {
		// Returns a random, uniformly distributed 64 bit integer.
		return hashu64(state_+=inc_);
	}


	u32 getu32(void) {
		// Returns a random, uniformly distributed 32 bit integer.
		return hashu32((u32)(state_+=inc_));
	}


	u64 modu64(u64 mod) {
		// Returns a random, unbiased integer in [0,mod).
		// Use rejection sampling: rand-(rand%mod)<=-mod.
		assert(mod>0);
		u64 rand,rem,nmod=0-mod;
		do {
			rand=getu64();
			rem=rand%mod;
		} while (rand-rem>nmod);
		return rem;
	}


	u32 modu32(u32 mod) {
		// Returns a random, unbiased integer in [0,mod).
		// Use rejection sampling: rand-(rand%mod)<=-mod.
		assert(mod>0);
		u32 rand,rem,nmod=0-mod;
		do {
			rand=getu32();
			rem=rand%mod;
		} while (rand-rem>nmod);
		return rem;
	}


	f64 getf64(void) {
		// Returns a 64 bit float in [0,1).
		// If the integer is greater than 2^52, floating point conversion will take longer.
		return ((f64)(getu64()>>12))*(1.0/4503599627370496.0);
	}


	f32 getf32(void) {
		// Returns a 32 bit float in [0,1).
		// If the integer is greater than 2^23, floating point conversion will take longer.
		return ((f32)(getu64()>>41))*(1.0f/8388608.0f);
	}


	f64 getnorm(void) {
		// Transform a uniform distribution to a normal one via sqrt(2)*erfinv(2*u-1).
		// erfinv credit: njuffa, https://stackoverflow.com/a/49743348
		f64 u=getf64()*2-1,t=log(1-u*u),p;
		if (t<-6.125) {
			p=    4.294932181e-10;
			p=p*t+4.147083705e-8;
			p=p*t+1.727466590e-6;
			p=p*t+4.017907374e-5;
			p=p*t+5.565679449e-4;
			p=p*t+4.280807652e-3;
			p=p*t+6.833279087e-3;
			p=p*t-3.742661647e-1;
			p=p*t+1.187962704e+0;
		} else {
			p=    7.691594063e-9;
			p=p*t+2.026362239e-7;
			p=p*t+1.736297774e-6;
			p=p*t+1.597546919e-7;
			p=p*t-7.941244165e-5;
			p=p*t-2.088759943e-4;
			p=p*t+3.273461437e-3;
			p=p*t+1.631897530e-2;
			p=p*t-3.281194328e-1;
			p=p*t+1.253314090e+0;
		}
		return p*u;
	}

};


//---------------------------------------------------------------------------------
// Test Functions

/*
void SphereInit(f64* x,i32 n) {
	// Typical initialization values for the sphere function.
	return [random.uniform(-5.12,5.12) for i in range(n)]
}


def SphereFunc(x):
	# Hypershpere. F(x)=0 at x={0,0,0,...}.
	s=0.0
	for y in x: s+=y*y
	return s


def RastriginInit(n):
	# Typical initialization values for the Rastrigin function.
	return [random.uniform(-5.12,5.12) for i in range(n)]


def RastriginFunc(x):
	# Rastrigin function. F(x)=0 at x={0,0,0,...}.
	s,pi,cos=0.0,math.pi*2.0,math.cos
	for y in x: s+=10.0+y*y-10.0*cos(pi*y)
	return s


def RosenbrockInit(n):
	# Typical initialization values for the Rosenbrock function.
	return [random.uniform(-5,10) for i in range(n)]


def RosenbrockFunc(x):
	# Rosenbrock function. F(x)=0 at x={1,1,1,...}.
	s=0.0
	for i in range(len(x)-1):
		a,b=x[i],x[i+1]
		b,a=b-a*a,a-1
		s+=100.0*b*b+a*a
	return s


def NNAct(x):
	# Neural network activation function.
	if x>1.0: return 1.0
	return x if x>0.0 else 0.0


def NNInit(n):
	# Intialization values for neural network functions.
	return [random.uniform(-1,1) for i in range(n)]


def NNXorBasicFunc(w):
	# Neural network approximation of the xor function. Requires len(w) to be a
	# multiple of 8.
	n=len(w)
	assert(n%8==0)
	bits=n//8+1
	err=0.0
	bitmasks=1<<bits
	for bitmask in range(bitmasks):
		expect,tmpmask=bitmask,bitmask
		n4,wpos=float(tmpmask&1),0
		for i in range(1,bits):
			tmpmask>>=1
			expect^=tmpmask
			n0=NNAct(n4) if i>1 else n4
			n1=float(tmpmask&1)
			n2=NNAct(n0*w[wpos+0]+n1*w[wpos+1]+w[wpos+2])
			n3=NNAct(n0*w[wpos+3]+n1*w[wpos+4]+w[wpos+5])
			n4=n2*w[wpos+6]+n3*w[wpos+7]
			wpos+=8
		n4-=expect&1
		err+=n4*n4
	return err


def NNXorRobustFunc(w):
	# Neural network approximation of the xor function for noisy inputs. Robust
	# networks can handle noise of +-0.25. Requires len(w) to be a multiple of 8.
	n=len(w)
	assert(n%8==0)
	eps=random.random()*0.15+0.05
	noise=(-eps,1.0-eps,eps,1.0+eps)
	bits=n//8+1
	err=0.0
	bitmasks=1<<(2*bits)
	for bitmask in range(bitmasks):
		expect,tmpmask=bitmask,bitmask
		n4,wpos=noise[tmpmask&3],0
		for i in range(1,bits):
			tmpmask>>=2
			expect^=tmpmask
			n0=NNAct(n4) if i>1 else n4
			n1=noise[tmpmask&3]
			n2=NNAct(n0*w[wpos+0]+n1*w[wpos+1]+w[wpos+2])
			n3=NNAct(n0*w[wpos+3]+n1*w[wpos+4]+w[wpos+5])
			n4=n2*w[wpos+6]+n3*w[wpos+7]
			wpos+=8
		n4-=expect&1
		err+=n4*n4
	return err


def ErfinvInit(n):
	return [random.uniform(-10,10) for i in range(n)]


def ErfinvFunc(coefvec):
	# Optimize the expression (mat*coefs+vec)*coefs.
	# The matrix and vector values are based off of a polynomial least squares
	# regression computation for the erfinv function.
	coefs=len(coefvec)
	vecmul,vecval=-1.84,1.5
	matmul,rowval=-1.53,1.1
	err=0.0
	for i in range(coefs):
		sum=vecval
		colval=rowval
		for j in range(coefs):
			sum+=colval*coefvec[j]
			colval*=matmul
		err+=sum*coefvec[i]
		vecval*=vecmul
		rowval*=matmul
	return err
*/

/*
def BBPSON(F,x,iters,params=(40,400,.8)):
	# params=particles,lifespan,lifeinc
	dim=len(x)
	particles,lifespan,lifeinc=params
	gpart,gerr,gpos,pos=None,F(x),x,x[:]
	class Particle(object):
		def __init__(self):
			self.pos=x[:]
			self.err=gerr
			self.life=lifespan
	partarr=[Particle() for i in range(particles)]
	for iter in range(iters-1):
		# Find the best neighbor. Look at +-2^n.
		idx,off=iter%particles,1
		p=partarr[idx]
		n=None if p.life<=0 else p
		while off<particles:
			t=partarr[(idx+off)%particles]
			if n is None or n.err>t.err: n=t
			off=-off<<(off<0)
		npos,ppos=n.pos,p.pos
		if p.life<=0: p.life,ppos=lifespan,npos
		# Find a new position between the particle and its best neighbor.
		# If best=self, jitter with cauchy distribution.
		u=math.sqrt(random.random()) if npos is ppos else 1
		#dev=(1-u)*abs(math.tan((random.random()-0.5)*3.141592652))
		dev=(1-u)*math.exp(random.random()*60-30)
		for i in range(dim):
			l,g=ppos[i],npos[i]
			pos[i]=random.gauss((l+g)*0.5,abs(l-g*u)+dev)
		err=F(pos)
		# Update the particle and global best positions.
		if p.life==lifespan or p.err>err:
			if gerr>err: gerr,gpart=err,p
			elif gpart is p: gpart,gpos,p.pos=None,p.pos,gpos
			p.err,p.pos,pos=err,pos,p.pos
			p.life+=lifeinc
		p.life-=1
	x[:]=gpart.pos if gpart else gpos
	return gerr
*/

//---------------------------------------------------------------------------------
// Main


int main() {
	f64 time=GetTime();
	Random rnd;
	for (u32 i=0;i<100;i++) {
		printf("%f\n",rnd.getnorm());
	}
	time=GetTime()-time;
	printf("time: %f\n",time);
	printf("done\n");
	return 0;
}

function HeapSort(arr,start,end) {
	let heap=start+((end-start)>>>1);
	end--;
	let off=1-start;
	while (end>start) {
		let node,child;
		let nval;
		if (heap>start) {
			// Build the heap.
			node=--heap;
			nval=arr[node];
		} else {
			// Pop the greatest element to the end of the array.
			node=heap;
			nval=arr[end];
			arr[end--]=arr[heap];
		}
		// Heap sort the top element down.
		// 2*(node-start)+start+1 = 2*node-start+1
		while ((child=(node<<1)+off)<=end) {
			let cval=arr[child];
			if (child<end) {
				let rval=arr[child+1];
				if (cval<rval) {
					cval=rval;
					child++;
				}
			}
			if (nval>=cval) {break;}
			arr[node]=cval;
			node=child;
		}
		arr[node]=nval;
	}
}


function IntroSort(arr,start,end) {
	for (let i=start+1;i<end;i++) {
		let nval=arr[i],j=i;
		while (j>start && arr[j-1]>nval) {
			arr[j]=arr[j-1];
			j--;
		}
		arr[j]=nval;
	}
}


function TestSort() {
	console.log("testing heap sort");
	let rnd=new Random();
	let maxlen=128,tests=100000;
	let arr0=new Array(maxlen);
	let arr1=new Array(maxlen);
	for (let test=0;test<tests;test++) {
		if ((test%(tests>>>3))===0) {console.log("test:",test);}
		let start=rnd.modu32(maxlen+1);
		let end=rnd.modu32(maxlen+1);
		if (start>end) {
			let tmp=end;
			end=start;
			start=tmp;
		}
		for (let i=0;i<maxlen;i++) {
			let x=(rnd.getu32()%33)-16;
			arr0[i]=x;
			arr1[i]=x;
		}
		IntroSort(arr0,start,end);
		HeapSort(arr1,start,end);
		for (let i=0;i<maxlen;i++) {
			if (arr0[i]!==arr1[i]) {
				for (let j=start;j<end;j++) {console.log(j,arr0[j],arr1[j]);}
				console.log("unsorted:",arr0[i],arr1[i]);
				console.log("index:",start,end,i);
				throw "error";
			}
		}
	}
	console.log("done");
}
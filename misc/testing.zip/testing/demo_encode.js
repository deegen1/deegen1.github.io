/*------------------------------------------------------------------------------


demo_encode.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Encrypts and base 64 encodes a string to use in a URL.
Tests if encrypt/decrypt is working.

node demo_encode.js


*/
/* npx eslint demo_encode.js -c ../../../standards/eslint.js */


function hashfunc(h) {
	h+=0x66daacfd;
	h=Math.imul(h^(h>>>16),0xf8b7629f);
	h=Math.imul(h^(h>>> 8),0xcbc5c2b5);
	h=Math.imul(h^(h>>>24),0xf5a5bda5);
	return h>>>0;
}


function hashinv(h) {
	h=Math.imul(h,0x380ae22d);h^=h>>>24;
	h=Math.imul(h,0x40049b9d);h^=h>>> 8;h^=h>>>16;
	h=Math.imul(h,0x14e3395f);h^=h>>>16;
	h-=0x66daacfd;
	return h>>>0;
}


function encode(key,str) {
	if ((key>>>0)!==key) {
		console.log("key not integer:",key);
		throw "error";
	}
	// Encrypt the string.
	let enc=new Array(str.length+4);
	let hash=key;
	for (let i=0;i<str.length;i++) {
		let c=str.charCodeAt(i);
		if (!(c>=0 && c<256)) {
			console.log("Invalid character:",i,c);
			throw "error";
		}
		enc[i+4]=((c-hash)&255)>>>0;
		hash=hashfunc(hash+c);
	}
	enc[0]=(hash>>>24);
	enc[1]=(hash>>>16)&255;
	enc[2]=(hash>>> 8)&255;
	enc[3]=(hash>>> 0)&255;
	// Base 64 encode.
	let enc64="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
	let buf=0,bits=0;
	let out="";
	for (let b of enc) {
		if ((b|0)!==b || b<0 || b>255) {
			console.log("invalid byte:",b);
			throw "error";
		}
		buf=(buf<<8)+b;
		bits+=8;
		while (bits>5) {
			bits-=6;
			let v=buf>>>bits;
			out+=enc64[v];
			buf&=(1<<bits)-1;
		}
	}
	if (bits>0) {
		let v=buf<<(6-bits);
		out+=enc64[v];
	}
	return out;
}


function decode(key,arg) {
	// Decrypt index.html?abcdefg. Also handle hex codes.
	let enc64="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
	let dec64=[];
	for (let i=0;i<enc64.length;i++) {dec64[enc64.charCodeAt(i)]=i;}
	let enc16="0123456789ABCDEFabcdef";
	let dec16=[];
	for (let i=0;i<enc16.length;i++) {dec16[enc16.charCodeAt(i)]=i>15?i-6:i;}
	let buf=0,bits=0;
	let hash=key,chk=0,read=0;
	let text="";
	//let arg=window.location.search;
	for (let i=0;i<arg.length;i++) {
		let c=arg.charCodeAt(i);
		if (c===37) {
			// %XX format
			let h=dec16[arg.charCodeAt(i+1)];
			let l=dec16[arg.charCodeAt(i+2)];
			if (h>=0 && l>=0) {c=h*16+l;i+=2;}
		}
		// Get 6 bits from out base 64 character.
		let d=dec64[c];
		if (d>=0) {
			buf=(buf<<6)+d;
			bits+=6;
		}
		if (bits<8) {continue;}
		// Decrypt a byte.
		bits-=8;
		c=buf>>>bits;
		buf&=(1<<bits)-1;
		if (read++<4) {chk=(chk<<8)|c;continue;}
		c=(c+hash)&255;
		hash+=c+0x66daacfd;
		hash=Math.imul(hash^(hash>>>16),0xf8b7629f);
		hash=Math.imul(hash^(hash>>> 8),0xcbc5c2b5);
		hash=Math.imul(hash^(hash>>>24),0xf5a5bda5);
		text+=String.fromCharCode(c);
	}
	return (hash^chk)?"":text;
}


function stresstest() {
	console.log("stress testing encoding");
	let tests=10000;
	for (let test=0;test<tests;test++) {
		let text="",raw=[];
		let len=Math.random()*100|0;
		for (let i=0;i<len;i++) {
			let c=Math.random()*256|0;
			c=c>0?c:0;
			c=c<255?c:255;
			raw.push(c);
			text+=String.fromCharCode(c);
		}
		let key=(Math.random()*0x100000000)>>>0;
		let enc=encode(key,text);
		let dec=decode(key,enc);
		//console.log(enc);
		if (dec!==text) {
			console.log("couldn't decode:");
			console.log("text:",text);
			console.log("raw :",raw);
			console.log("enc :",enc);
			console.log("dec :",dec);
			throw "error";
		}
	}
	console.log("passed");
}


function makekey(str) {
	let key=0;
	for (let i=0;i<str.length;i++) {
		key=(key<<8)|str.charCodeAt(i);
	}
	key>>>=0;
	console.log("key: 0x"+key.toString(16));
	return key;
}


function main() {
	//stresstest();
	let text="Hello\nWorld";
	let key=makekey("dust");
	let enc=encode(key,text);
	let dec=decode(key,enc);
	if (dec!==text) {
		console.log(text);
		console.log(dec);
		throw "can't decrypt";
	}
	console.log("index.html?"+enc);
}
main();
/*------------------------------------------------------------------------------


vector_test.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint vector_test.js -c ../../../standards/eslint.js */
/* global Random, Vector, Matrix, Transform */


function ManualRotation(x,y,z) {
	let cs=Math.cos,sn=Math.sin;
	let elem=[
		cs(z)*cs(y),cs(z)*sn(y)*sn(x)-sn(z)*cs(x)
	];
}


function VectorTest() {
	let a=new Vector([ 2.0,-1.0,1.1]);
	let b=new Vector([-0.5, 0.0,5.0]);
	console.log(a.mag());
	console.log(a.tostring());
	console.log(a.randomize());
	let c=new Vector(a);
	a[0]=1;
	console.log("a: "+a.tostring());
	console.log("c: "+c.tostring());
	console.log(a.mul(b));
	let mat=Matrix.fromangles([1,2,3]);
	console.log(mat);
	console.log(mat.mul(2));
	a=new Vector(3);
	console.log(a.tostring());
	/*let a=new Vector(40);
	let b;
	a.randomize();
	let t0=performance.now();
	for (let i=0;i<1000000;i++) {
		b=new Vector(a);
	}
	t0=performance.now()-t0;
	console.log(t0);
	console.log(b);*/
	a=new Vector(3);
	a.isub(1);
	console.log(a.tostring());
}


function MatrixTest() {
	let rnd=new Random();
	let a=new Matrix(4,4);
	for (let i=0;i<a.length;i++) {a[i]=rnd.getf()*10-5;}
	let d0=a.det();
	let b=a.inv();
	let d1=b.det();
	let c=a.mul(b);
	console.log(a);
	console.log(b);
	console.log(c);
	console.log("det:",d0,d1,1/d0);
	console.log("unit:",Matrix.fromangles([0.1,0.2,0.3]).det(),1*1*1);
	console.log("unit:",Matrix.fromangles([0.1,0.2,0.3]).mul(3).det(),3*3*3);
}


function TransformTest1() {
	let vec=new Vector([3,1]);
	let mat=new Matrix(2,2);
	let trans=new Transform({vec:vec,ang:[0]});
	trans.scale(10).shift([-1,-1]);
	console.log(trans.vec);
	console.log(trans.mat);
	let point=new Vector([1,1]);
	console.log(trans.apply(point));
}


function RandomizeArr(arr,rnd) {
	let len=arr.length;
	for (let i=0;i<len;i++) {
		arr[i]=(rnd.getf()-0.5)*20;
	}
	return arr;
}


function RandomizeTrans(trans,rnd) {
	RandomizeArr(trans.mat,rnd);
	RandomizeArr(trans.vec,rnd);
	return trans;
}


function TransformTest() {
	let rnd=new Random();
	// Apply test
	for (let test=0;test<1000;test++) {
		let dim=rnd.modu32(10);
		let a=new Transform(dim);
		let b=new Transform(dim);
		RandomizeTrans(a,rnd);
		RandomizeTrans(b,rnd);
		let c=a.apply(b);
		let p=RandomizeArr(Array(dim),rnd);
		let pab=a.apply(b.apply(p));
		let pc=c.apply(p);
		let dist=pab.dist2(pc);
		if (!(dist<1e-10)) {
			console.log("dim :",dim);
			console.log("dist:",dist);
			console.log("pab :",pab);
			console.log("pc  :",pc);
			throw "error";
		}
	}
	// Inverse test
	for (let test=0;test<1000;test++) {
		let dim=rnd.modu32(10);
		let trans=new Transform(dim);
		RandomizeTrans(trans,rnd);
		let inv=trans.inv();
		let p0=RandomizeArr(new Vector(dim),rnd);
		let p1=trans.apply(p0);
		let p2=inv.apply(p1);
		let dist=p0.dist2(p2);
		if (!(dist<1e-10)) {
			console.log("dim :",dim);
			console.log("dist:",dist);
			console.log("p0  :",p0);
			console.log("p2  :",p2);
			throw "error";
		}
	}
	console.log("passed");
}


function TransformSpeedTest() {
	// FF: 5.778500
	// CR: 4.144885
	let rnd=new Random(10);
	let dim=10;
	let tests=20000000;
	let trans=new Transform(dim);
	RandomizeTrans(trans,rnd);
	trans.vec.set(0);
	let vec=new Vector(dim);
	RandomizeArr(vec,rnd);
	vec.set(0);
	let t0=performance.now();
	for (let i=0;i<tests;i++) {
		vec=trans.apply(vec);
	}
	t0=(performance.now()-t0)/1000;
	console.log("vec :",vec);
	console.log("time:",t0.toFixed(6));
}

//VectorTest();
MatrixTest();
//TransformTest1();
//TransformTest();
//TransformSpeedTest();

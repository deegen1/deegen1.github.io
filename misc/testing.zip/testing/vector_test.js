/*------------------------------------------------------------------------------


vector_test.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint vector_test.js -c ../../../standards/eslint.js */


import {Random} from "../random.js";
import {Vector,Matrix,Transform} from "../vector.js";


//---------------------------------------------------------------------------------
// Helper


function RandomizeArr(arr,rnd) {
	if (!rnd) {rnd=new Random();}
	let len=arr.length;
	for (let i=0;i<len;i++) {
		arr[i]=(rnd.getf()-0.5)*20;
	}
	return arr;
}


function RandomizeMat(mat,rank,rnd) {
	if (!rnd) {rnd=new Random();}
	let rows=mat.rows,cols=mat.cols,elems=rows*cols;
	let dim=rows<cols?rows:cols;
	if (rank===undefined) {rank=dim;}
	rank=rank<dim?rank:dim;
	// Init the matrix.
	for (let i=0;i<elems;i++) {mat[i]=0;}
	for (let r=0;r<rank;r++) {
		let row=r*cols;
		mat[row+r]=1;
		for (let c=rank;c<cols;c++) {
			mat[row+c]=rnd.getf();
		}
	}
	if (rank===1 && rows===1 && cols===1) {mat[0]=rnd.getf()+1;}
	if (rows<2) {return mat;}
	// Random row operations.
	let iters=(rows+cols)*2;
	for (let iter=0;iter<iters;iter++) {
		let dst=(iter%rows)*cols;
		let src=(dst+cols+rnd.mod(rows-1)*cols)%elems;
		let mul=rnd.gets()*2;
		if (mul>-0.001 && mul<0.001) {mul=1;}
		let max=0;
		for (let i=0;i<cols;i++) {
			let x=mat[dst+i]+mat[src+i]*mul;
			let a=x<0?-x:x;
			max=max>a?max:a;
			mat[dst+i]=x;
		}
		if (max>1e-10) {
			for (let i=0;i<cols;i++) {
				mat[dst+i]/=max;
			}
		}
	}
}


function RandomizeTrans(trans,rnd) {
	if (!rnd) {rnd=new Random();}
	RandomizeArr(trans.mat,rnd);
	RandomizeArr(trans.vec,rnd);
	return trans;
}


function ManualRotation(x,y,z) {
	let cs=Math.cos,sn=Math.sin;
	let elem=[
		cs(z)*cs(y),cs(z)*sn(y)*sn(x)-sn(z)*cs(x)
	];
}


//---------------------------------------------------------------------------------
// Vector


function VectorTest() {
	let a=new Vector([ 2.0,-1.0,1.1]);
	let b=new Vector([-0.5, 0.0,5.0]);
	console.log(a.mag());
	console.log(a.tostring());
	console.log(a.randomize());
	let c=new Vector(a);
	a[0]=1;
	console.log("a: "+a.tostring());
	console.log("c: "+c.tostring());
	console.log(a.mul(b));
	let mat=Matrix.fromangles([1,2,3]);
	console.log(mat);
	console.log(mat.mul(2));
	a=new Vector(3);
	console.log(a.tostring());
	/*let a=new Vector(40);
	let b;
	a.randomize();
	let t0=performance.now();
	for (let i=0;i<1000000;i++) {
		b=new Vector(a);
	}
	t0=performance.now()-t0;
	console.log(t0);
	console.log(b);*/
	//a=new Vector(3);
	//a.isub(1);
	//console.log(a.tostring());
}


function VectorSpeed() {
	//    1   2.261397
	//    2   2.002029
	//    3   1.860232
	//   16   1.527310
	//   64   1.765386
	//  256   2.910473
	// 1024   5.851625
	console.log("testing vector speed");
	let rnd=new Random(1);
	for (let d=0;d<7;d++) {
		let dim=d<3?d+1:(1<<(2*d-2)),dim2=dim+2;
		let tests=10000000/Math.sqrt(dim2);
		let u=new Vector(dim);
		let v=new Vector(dim);
		RandomizeArr(u,rnd);
		RandomizeArr(v,rnd);
		let t0=performance.now();
		let sum=0;
		for (let test=0;test<tests;test++) {
			sum^=u.add(v).min(u).max(v).neg().sub(v).mul(test).norm().cmp(sum);
		}
		let t1=performance.now();
		t1=(t1-t0)/1000;
		console.log(`${dim.toFixed().padStart(4," ")}  ${t1.toFixed(6).padStart(9," ")}`);
		// Prevent optimizing out sum.
		u[0]=sum;
		u.norm();
	}
}


//---------------------------------------------------------------------------------
// Matrix


function MatrixTest() {
	let rnd=new Random();
	let a=new Matrix(4,4);
	for (let i=0;i<a.length;i++) {a[i]=rnd.getf()*10-5;}
	let d0=a.det();
	let b=a.inv();
	let d1=b.det();
	let c=a.mul(b);
	console.log(a);
	console.log(b);
	console.log(c);
	console.log("det:",d0,d1,1/d0,c.det());
	console.log("unit:",Matrix.fromangles([0.1,0.2,0.3]).det(),1*1*1);
	console.log("unit:",Matrix.fromangles([0.1,0.2,0.3]).mul(3).det(),3*3*3);
	// Set
	a=new Matrix(3,2);
	b=new Matrix(4,6);
	RandomizeArr(a);
	RandomizeArr(b);
	console.log("init");
	console.log(a);
	console.log(b);
	console.log("after set()");
	a.set(b);
	a[0]=0;
	console.log(a);
	console.log(b);
}


function MatrixInverseTest() {
	console.log("testing matrix inverse");
	let rnd=new Random(1);
	for (let test=0;test<1000;test++) {
		let rows=rnd.mod(11),cols=rnd.mod(11);
		//let rows=3,cols=3;
		if (!rnd.mod(10)) {cols=rows;}
		let rank=rnd.mod(rows+cols+1);
		//let rank=3;
		rank=rank<rows?rank:rows;
		rank=rank<cols?rank:cols;
		let mat=new Matrix(rows,cols);
		RandomizeMat(mat,rank,rnd);
		//if (test!==22) {continue;}
		let det=mat.det();
		let inv=null;
		try {inv=mat.inv();}
		catch {inv=null;}
		let hasinv=rank===rows && rank===cols;
		if ((!inv)===hasinv || (Math.abs(det)>1e-10)!==hasinv) {
			console.log("false inverse:",inv!==null,hasinv);
			console.log("iter:",test);
			console.log("det :",det);
			console.log("dim :",rows,cols);
			console.log("rank:",rank);
			console.log(mat);
			throw "error";
		}
		if (inv) {
			let detinv=inv.det();
			let deterr=Math.abs(det*detinv-1);
			let mul=mat.mul(inv);
			let err=0;
			for (let r=0,i=0;r<rows;r++) {
				for (let c=0;c<cols;c++) {
					let x=mul[i++]-(r===c?1:0);
					err+=x*x;
				}
			}
			console.log("identity err:",err,deterr);
			if (err>1e-10 || deterr>1e-10) {
				console.log("det err:",deterr);
				//console.log(mul);
				for (let r=0;r<rows;r++) {
					let str="";
					for (let c=0;c<cols;c++) {
						let x=mul[r*cols+c];
						if (Math.abs(x)<1e-10) {x=0;}
						str+=x.toFixed(3)+"  ";
					}
					console.log(str);
				}
				throw "id err";
			}
		}
	}
}


function MatrixInverseSpeed() {
	//    1  28.032811  23.807206
	//    2  16.688651  14.406766
	//    3  12.273613   9.281040
	//   16  11.714105   4.747532
	//   64  12.850897   4.480603
	//  256  13.787336   4.866885
	// 1024  13.162800   4.453193
	console.log("testing bulk matrix speed");
	let rnd=new Random(1);
	for (let d=0;d<7;d++) {
		let dim=d<3?d+1:(1<<(2*d-2)),dim2=dim+2;
		let tests=Math.round(10000000000/(dim2*dim2*dim2));
		let a=new Matrix(dim,dim);
		//let b=new Matrix(dim,dim);
		RandomizeMat(a,dim,rnd);
		// Large matrix determinants tend to 0.
		a.imul(1500/dim);
		//RandomizeMat(b,dim,rnd);
		let t0=performance.now();
		let sum1=0;
		for (let test=0;test<tests;test++) {
			sum1=a.inv()[0]-sum1;
		}
		let t1=performance.now();
		let sum2=0;
		for (let test=0;test<tests;test++) {
			sum2=a.det()-sum2;
		}
		let t2=performance.now();
		t2=(t2-t1)/1000;
		t1=(t1-t0)/1000;
		console.log(`${dim.toFixed().padStart(4," ")}  ${t1.toFixed(6).padStart(9," ")}  ${t2.toFixed(6).padStart(9," ")}`);
		// Prevent optimizing out sum1 and sum2.
		a[0]=sum1+sum2;
		a.det();
	}
}


//---------------------------------------------------------------------------------
// Transform


function TransformTest1() {
	let vec=new Vector([3,1]);
	let mat=new Matrix(2,2);
	let trans=new Transform({vec:vec,ang:[0]});
	trans.scale(10).shift([-1,-1]);
	console.log(trans.vec);
	console.log(trans.mat);
	let point=new Vector([1,1]);
	console.log(trans.apply(point));
}


function TransformTest() {
	let rnd=new Random();
	// Apply test
	for (let test=0;test<1000;test++) {
		let dim=rnd.mod(10);
		let a=new Transform(dim);
		let b=new Transform(dim);
		RandomizeTrans(a,rnd);
		RandomizeTrans(b,rnd);
		let c=a.apply(b);
		let p=RandomizeArr(Array(dim),rnd);
		let pab=a.apply(b.apply(p));
		let pc=c.apply(p);
		let dist=pab.dist2(pc);
		if (!(dist<1e-10)) {
			console.log("dim :",dim);
			console.log("dist:",dist);
			console.log("pab :",pab);
			console.log("pc  :",pc);
			throw "error";
		}
	}
	// Inverse test
	for (let test=0;test<1000;test++) {
		let dim=rnd.mod(10);
		let trans=new Transform(dim);
		RandomizeTrans(trans,rnd);
		let inv=trans.inv();
		let p0=RandomizeArr(new Vector(dim),rnd);
		let p1=trans.apply(p0);
		let p2=inv.apply(p1);
		let dist=p0.dist2(p2);
		if (!(dist<1e-10)) {
			console.log("dim :",dim);
			console.log("dist:",dist);
			console.log("p0  :",p0);
			console.log("p2  :",p2);
			throw "error";
		}
	}
	console.log("passed");
}


function TransformSpeedTest() {
	// Dim: 2
	// vec   time: 1.371973
	// trans time: 0.513582
	//
	// Dim: 10
	// vec   time: 4.777966
	// trans time: 4.541177
	let rnd=new Random(10);
	let dim=10;
	let a=new Transform(dim);
	let b=new Transform(dim);
	let vec=b.vec;
	RandomizeTrans(b,rnd);
	console.log("in :",vec.mag(),b.mat.det(),b.vec.mag());
	let t0=performance.now();
	for (let i=0;i<20000000;i++) {
		vec=a.apply(vec);
	}
	let t1=performance.now();
	for (let i=0;i<2000000;i++) {
		b=a.apply(b);
	}
	let t2=performance.now();
	t2=(t2-t1)/1000;
	t1=(t1-t0)/1000;
	console.log("out:",vec.mag(),b.mat.det(),b.vec.mag());
	console.log("vec   time:",t1.toFixed(6));
	console.log("trans time:",t2.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main


function main() {
	console.log("testing vector operations");
	//VectorTest();
	//VectorSpeed();
	//MatrixTest();
	//MatrixInverseTest();
	//MatrixInverseSpeed();
	//TransformTest1();
	//TransformTest();
	TransformSpeedTest();
	console.log("done");
}
main();


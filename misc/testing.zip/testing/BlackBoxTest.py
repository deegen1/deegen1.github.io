"""

BlackBoxTest.py - v2.00

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Optimize a function without knowing how it works.

Stats for iters=1000000, trials=1000:

   Func   |   Time    |   Sphere     |    Rast     |    Rosen    |    Poly5    |   Poly10    |    XorB8    |   XorB16    |    XorR
----------+-----------+--------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------
  BBPSON  |  267.222  |  1.657e-66   |  2.531e-65  |  2.484e+01  |  4.401e-06  |  6.705e+04  |  2.400e-02  |  1.872e-01  |  9.072e-02
  BBPSO   |   19.825  |  4.606e-167  |  5.970e-03  |  1.874e-01  |  1.295e-02  |  2.985e+10  |  0.000e+00  |  1.349e-01  |  1.054e-01
  PSO     |   16.557  |  5.179e-63   |  5.912e-01  |  4.465e-01  |  1.130e-03  |  3.251e+09  |  1.000e-03  |  1.687e-01  |  1.137e-01
  APSO    |  335.784  |  4.887e-59   |  4.378e+00  |  3.191e-01  |  1.311e-05  |  1.580e+09  |  3.377e-01  |  1.420e+00  |  1.769e+00
  SNES    |   15.584  |  0.000e+00   |  3.092e+01  |  3.929e+00  |  2.586e+00  |  1.293e+11  |  2.248e-01  |  1.270e+00  |  1.253e+00
  Basic   |   13.541  |  3.754e-08   |  2.616e+02  |  1.151e+01  |  2.583e+00  |  2.363e+13  |  2.159e-01  |  1.269e+00  |  8.912e-01


--------------------------------------------------------------------------------
TODO


Find better way of generating new positions.
Only operate on a few values instead of all of them.


"""

import math,random,time,multiprocessing


#---------------------------------------------------------------------------------
# Test Functions


def SphereInit(n):
	# Typical initialization values for the sphere function.
	return [random.uniform(-5.12,5.12) for i in range(n)]


def SphereSol(n):
	return [0.0]*n


def SphereFunc(x):
	# Hypershpere. F(x)=0 at x={0,0,0,...}.
	s=0.0
	for y in x: s+=y*y
	return s


def RastriginInit(n):
	# Typical initialization values for the Rastrigin function.
	return [random.uniform(-5.12,5.12) for i in range(n)]


def RastriginSol(n):
	return [0.0]*n


def RastriginFunc(x):
	# Rastrigin function. F(x)=0 at x={0,0,0,...}.
	s,pi,cos=0.0,math.pi*2,math.cos
	for y in x: s+=10*(1-cos(pi*y))+y*y
	return s


def RosenbrockInit(n):
	# Typical initialization values for the Rosenbrock function.
	return [random.uniform(-5,10) for i in range(n)]


def RosenbrockSol(n):
	return [1.0]*n


def RosenbrockFunc(x):
	# Rosenbrock function. F(x)=0 at x={1,1,1,...}.
	s=0.0
	for i in range(len(x)-1):
		a,b=x[i],x[i+1]
		b,a=b-a*a,a-1
		s+=100*b*b+a*a
	return s


def NNAct(x):
	# Neural network activation function.
	if x>1.0: return 1.0
	return x if x>0.0 else 0.0


def NNInit(n):
	# Intialization values for neural network functions.
	return [random.uniform(-1,1) for i in range(n)]


def NNXorSol(n):
	return [25,25,-12,25,25,-37,1,-1]*(n//8)


def NNXorBasicFunc(w):
	# Neural network approximation of the xor function. Requires len(w) to be a
	# multiple of 8.
	n=len(w)
	assert(n%8==0)
	bits=n//8+1
	err=0.0
	bitmasks=1<<bits
	for bitmask in range(bitmasks):
		expect,tmpmask=bitmask,bitmask
		n4,wpos=float(tmpmask&1),0
		for i in range(1,bits):
			tmpmask>>=1
			expect^=tmpmask
			n0=NNAct(n4) if i>1 else n4
			n1=float(tmpmask&1)
			n2=NNAct(n0*w[wpos+0]+n1*w[wpos+1]+w[wpos+2])
			n3=NNAct(n0*w[wpos+3]+n1*w[wpos+4]+w[wpos+5])
			n4=n2*w[wpos+6]+n3*w[wpos+7]
			wpos+=8
		n4-=expect&1
		err+=n4*n4
	return err


def NNXorRobustFunc(w):
	# Neural network approximation of the xor function for noisy inputs. Robust
	# networks can handle noise of +-0.25. Requires len(w) to be a multiple of 8.
	n=len(w)
	assert(n%8==0)
	eps=random.random()*0.15+0.05
	noise=(-eps,1.0-eps,eps,1.0+eps)
	bits=n//8+1
	err=0.0
	bitmasks=1<<(2*bits)
	for bitmask in range(bitmasks):
		expect,tmpmask=bitmask,bitmask
		n4,wpos=noise[tmpmask&3],0
		for i in range(1,bits):
			tmpmask>>=2
			expect^=tmpmask
			n0=NNAct(n4) if i>1 else n4
			n1=noise[tmpmask&3]
			n2=NNAct(n0*w[wpos+0]+n1*w[wpos+1]+w[wpos+2])
			n3=NNAct(n0*w[wpos+3]+n1*w[wpos+4]+w[wpos+5])
			n4=n2*w[wpos+6]+n3*w[wpos+7]
			wpos+=8
		n4-=expect&1
		err+=n4*n4
	return err


def PolyInit(n):
	return [random.uniform(-10,10) for i in range(n)]


def PolySol(n):
	# F(x)=0 at x={-.213,-.213^2,...}
	coef=[0]*n
	c=1
	for i in range(n):
		c*=-0.213
		coef[i]=c
	return coef


def PolyFunc(coefvec):
	# Minimize the squared error with a polynomial.
	err=0.0
	n=len(coefvec)
	for i in range(n):
		d,c,x,x0=0,1,1,i
		for j in range(n):
			c*=-0.213
			d+=x*(coefvec[j]-c)
			x*=x0
		err+=d*d
	return err


def TestFunctionSolutions():
	# Make sure the test functions have solutions.
	for f in range(6):
		print("\nTest: {0}".format(f))
		if f==0: func,sol,rng=SphereFunc,SphereSol,range(0,51)
		if f==1: func,sol,rng=RastriginFunc,RastriginSol,range(0,51)
		if f==2: func,sol,rng=RosenbrockFunc,RosenbrockSol,range(0,51)
		if f==3: func,sol,rng=NNXorBasicFunc,NNXorSol,range(0,33,8)
		if f==4: func,sol,rng=NNXorRobustFunc,NNXorSol,range(8,33,8)
		if f==5: func,sol,rng=PolyFunc,PolySol,range(0,11)
		for n in rng:
			err=func(sol(n))
			print("err {0}: {1}".format(n,err))
			assert(err==0.0)


#---------------------------------------------------------------------------------
# Parameter Testing


def TestParamsUnpack(args):
	# Unpack the argument array supplied to the multithreaded testing pool.
	f,name,dim,optfunc,iters,params=args
	if   name=="Sphere"     : func,init=SphereFunc,SphereInit
	elif name=="Rastrigin"  : func,init=RastriginFunc,RastriginInit
	elif name=="Rosenbrock" : func,init=RosenbrockFunc,RosenbrockInit
	elif name=="Poly"       : func,init=PolyFunc,PolyInit
	elif name=="NNXorBasic" : func,init=NNXorBasicFunc,NNInit
	elif name=="NNXorRobust": func,init=NNXorRobustFunc,NNInit
	else: raise NotImplementedError("Unrecognized function: "+name)
	start=time.time()
	if params is None: err=optfunc(func,init(dim),iters)
	else: err=optfunc(func,init(dim),iters,params)
	if not abs(err)<float("inf"): err=float("inf")
	# print("{0:10}: {1:.6e}".format(name,err))
	return (f,err,time.time()-start)


def TestParams(optfunc,iters,trials,params=None,threaded=False):
	# Test an optimization function against various optimization functions. Each
	# function will take a real vector as input and return a real number that needs to
	# be minimized.
	#
	# (function,display name,dimension)
	funcs=(
		("Sphere","Sphere",30),("Rastrigin","Rast",30),
		("Rosenbrock","Rosen",30),("Poly","Poly5",5),
		("Poly","Poly10",10),("NNXorBasic","XorB8",8),
		("NNXorBasic","XorB16",16),("NNXorRobust","XorR",8)
	)
	funcn=len(funcs)
	# Queue up functions based on the number of trials.
	args=[]
	for f in range(funcn):
		name,disp,dim=funcs[f]
		args+=[(f,name,dim,optfunc,iters,params)]*trials
	if threaded:
		# Using all cores can slow things down.
		cores=(multiprocessing.cpu_count()+1)//2
		pool=multiprocessing.Pool(cores)
		results=pool.imap_unordered(TestParamsUnpack,args)
		pool.close()
		pool.join()
	else:
		results=[TestParamsUnpack(arg) for arg in args]
	errsum=[0.0]*funcn
	avgtime=0.0
	for f,nerr,ntime in results:
		errsum[f]+=nerr
		avgtime+=ntime
	# Display the results.
	colstr="Time"
	errstr="{0:.6}".format(avgtime/trials)
	pad=max(len(errstr),len(colstr))+4
	colline="{0:^{1}}|".format(colstr,pad)
	errline="{0:^{1}}|".format(errstr,pad)
	for f in range(funcn):
		colstr=funcs[f][1]
		errsum[f]/=trials
		errstr="{0:.3e}".format(errsum[f])
		pad=max(len(errstr),len(colstr))+4
		colline+="{0:^{1}}|".format(colstr,pad)
		errline+="{0:^{1}}|".format(errstr,pad)
	print(colline+"\n"+errline)
	return errsum


#---------------------------------------------------------------------------------
# Parameter Searching


def ParamDisplay():
	# Display trends of different parameters.
	import matplotlib.pyplot as plt
	# Parse the data and add a column for rank.
	with open("output.txt") as f: data=f.read()
	lines=[l.strip() for l in data.split("\n") if l.strip()]
	points=[[0]+[float(x) for x in l.split(",")] for l in lines]
	for p in points:
		for j in [1,2,3]: p[j]=int(round(p[j]))
		#p[2]/=1-p[3]
	# Sort the data and add the ranks. Allow anything within +10% to be in the same
	# rank.
	colsort=4
	cols=len(points[0])
	for c in range(colsort,cols):
		if c!=9: continue
		points.sort(key=lambda x:x[c])
		rank,rankval=-1,-float("inf")
		for p in points:
			val=p[c]
			if rankval<val:
				rankval=val+abs(val)*0.1
				rank+=1
			p[0]+=rank
	points.sort(key=lambda x:x[0])
	points=points[:(len(points)*95//100)]
	for p in points[:100]:
		print(p)
	# Plot the data.
	axis=plt.gca()
	xpnt=[p[2] for p in points]
	ypnt=[p[0] for p in points]
	plt.plot(xpnt,ypnt,"o")
	plt.show()


def ParamSearch():
	# Find optimal parameters for an optimizer.
	# Randomly shuffle parameters in a range and try them.
	parambnd=[
		[list(range(100,400,10)),-1],
		[list(range(40,840,40)),-1],
		[[x/100 for x in range(51,100,2)],-1]
	]
	params=[0]*3
	for c in range(20000):
		for i in range(3):
			arr,pos=parambnd[i]
			if pos<0 or pos>=len(arr):
				pos=0
				random.shuffle(arr)
			parambnd[i][1]=pos+1
			params[i]=arr[pos]
		print("{}, {}, {}, {:.2f}".format(c,*params))
		results=TestParams(BBPSON,1000000,10,params,True)
		with open("output.txt","a") as f:
			f.write("{},{},{:.2f}".format(*params)+"".join([",{:9e}".format(x) for x in results])+"\n")


#---------------------------------------------------------------------------------
# Dummy Optimizer


def BasicOpt(F,x,iters):
	# Simple gaussian perturbation solver.
	n,gerr=len(x),F(x)
	y,g=[0]*n,x
	gauss=random.gauss
	for iter in range(iters):
		d=math.exp(random.random()*20-10)
		for i in range(n): y[i]=gauss(g[i],d)
		yerr=F(y)
		if gerr>yerr: y,g,gerr=g,y,yerr
	x[:]=g
	return gerr


#---------------------------------------------------------------------------------
# Particle Swarm Optimization
#
# Detecting particle convergence by their euclidean distances won't work. For the
# Rastrigin function, there's a lot of local minima with the same values but at
# different coordinates.


def PSO(F,x,iters,params=(40,2000,4,5,0.644392,1.587432,1.5005519,1.0,1.0)):
	# params=particles,lifespan,lifeinc,lifedec,w,c1,c2,posscale,velscale
	def cauchy(): return math.tan((random.random()-0.5)*3.141592652)
	def randvec(arr,dev):
		norm=1e-20
		for i in range(dim):
			v=random.gauss(0.0,1.0)
			arr[i]=v
			norm+=v*v
		norm=dev/math.sqrt(norm)
		for i in range(dim): arr[i]*=norm
	class Particle(object):
		def __init__(self):
			self.pos=[0.0]*dim
			self.vel=[0.0]*dim
			self.locpos=[0.0]*dim
			self.life=0
	dim=len(x)
	particles=params[0]
	lifespan,lifeinc,lifedec=params[1:4]
	w,c1,c2,pscale,vscale=params[4:9]
	partarr=[Particle() for i in range(particles)]
	glberror,glbpos,glbmag=F(x),list(x),sum(y*y for y in x)
	for iter in range(iters):
		p=partarr[iter%particles]
		pos,vel=p.pos,p.vel
		if p.life<=0:
			randvec(pos,dim*pscale*cauchy())
			randvec(vel,dim*vscale*cauchy())
			for i in range(dim): pos[i]+=glbpos[i]
			p.life=lifespan
		else:
			locpos=p.locpos
			for i in range(dim):
				r1,r2=random.random(),random.random()
				vel[i]=w*vel[i]+r1*c1*(locpos[i]-pos[i])+r2*c2*(glbpos[i]-pos[i])
				pos[i]+=vel[i]
		error,mag=F(pos),sum(y*y for y in pos)
		if p.life==lifespan or p.locerror>error or (p.locerror>=error and p.locmag>mag):
			p.locerror,p.locpos[:],p.locmag=error,pos,mag
			p.life+=lifeinc
		p.life-=lifedec
		if glberror>error or (glberror>=error and glbmag>mag):
			glberror,glbpos[:],glbmag=error,pos,mag
	return glberror


def APSO(F,x,iters,params=(40,2000,4,5,0.644392,1.587432,1.5005519,1.0,1.0)):
	# params=particles,lifespan,lifeinc,lifedec,w,c1,c2,posscale,velscale
	def cauchy(): return math.tan((random.random()-0.5)*3.141592652)
	def randvec(arr,dev):
		norm=1e-20
		for i in range(dim):
			v=random.gauss(0.0,1.0)
			arr[i]=v
			norm+=v*v
		norm=dev/math.sqrt(norm)
		for i in range(dim): arr[i]*=norm
	class Particle(object):
		def __init__(self):
			self.pos=[0.0]*dim
			self.vel=[0.0]*dim
			self.locpos=[0.0]*dim
			self.life=0
	dim=len(x)
	particles=params[0]
	lifespan,lifeinc,lifedec=params[1:4]
	w,c1,c2,pscale,vscale=params[4:9]
	partarr=[Particle() for i in range(particles)]
	glberror,glbpos=F(x),list(x)
	for iter in range(iters):
		rank=iter%particles
		p=partarr[iter%particles]
		pos=p.pos
		vel=p.vel
		new=0
		if p.life<=0:
			randvec(pos,dim*pscale*cauchy())
			randvec(vel,dim*vscale*cauchy())
			for i in range(dim): pos[i]+=glbpos[i]
			p.life=300+random.randrange(301)
			new=1
		else:
			locpos=p.locpos
			for i in range(dim):
				vel[i]=0.7*vel[i]+(random.random()/(rank+1))*(locpos[i]-pos[i])
				px=0.0
				for j in range(particles):
					q=partarr[j]
					if p.error>q.locerror:
						px+=(random.random()/(j+1))*(q.locpos[i]-pos[i])
				vel[i]+=px
				pos[i]+=vel[i]
		p.error=F(pos)
		if new or p.locerror>p.error:
			p.locerror,p.locpos[:]=p.error,pos
		p.life-=1
		if glberror>p.error:
			glberror,glbpos[:]=p.error,pos
		i=iter%particles
		while i and p.error<partarr[i-1].error:
			partarr[i]=partarr[i-1]
			i-=1
		partarr[i]=p
	return glberror


def BBPSO(F,x,iters,params=(40,2000,4,5)):
	# params=particles,lifespan,lifeinc,lifedec,w,c1,c2,posscale,velscale
	def cauchy(): return math.tan((random.random()-0.5)*3.141592652)
	def randvec(arr,dev):
		norm=1e-20
		for i in range(dim):
			v=random.gauss(0.0,1.0)
			arr[i]=v
			norm+=v*v
		norm=dev/math.sqrt(norm)
		for i in range(dim): arr[i]*=norm
	class Particle(object):
		def __init__(self):
			self.pos=[0.0]*dim
			self.locpos=[0.0]*dim
			self.life=0
	dim=len(x)
	particles,lifespan,lifeinc,lifedec=params
	partarr=[Particle() for i in range(particles)]
	glberror,glbpos,glbmag=F(x),list(x),sum(y*y for y in x)
	for iter in range(iters):
		p=partarr[iter%particles]
		pos=p.pos
		if p.life<=0:
			randvec(pos,dim*cauchy())
			for i in range(dim): pos[i]+=glbpos[i]
			p.life=lifespan
		else:
			locpos=p.locpos
			for i in range(dim):
				l,g=locpos[i],glbpos[i]
				pos[i]=random.gauss((l+g)*0.5,l-g)
		error,mag=F(pos),sum(y*y for y in pos)
		if p.life==lifespan or p.locerror>error or (p.locerror>=error and p.locmag>mag):
			p.locerror,p.locpos[:],p.locmag=error,pos,mag
			p.life+=lifeinc
		p.life-=lifedec
		if glberror>error or (glberror>=error and glbmag>mag):
			glberror,glbpos[:],glbmag=error,pos,mag
	return glberror


def BBPSON(F,x,iters,params=(200,200,.99)):
	# Bare bones particle swarms with neighbors.
	dim=len(x)
	particles,lifespan,lifeinc=params
	devmax,nbrmax=math.log(1e+30),(particles+4)//3
	gpart,gerr,gpos,pos=None,F(x),x,x[:]
	class Particle(object):
		def __init__(self):
			self.pos=x[:]
			self.err=gerr
			self.life=0
	partarr=[Particle() for i in range(particles)]
	for iter in range(iters-1):
		# Find the best neighbor. Look at +-2^n.
		idx,off=iter%particles,1
		p=partarr[idx]
		n=None if p.life<=0 else p
		while off<nbrmax:
			t=partarr[(idx+off)%particles]
			if n is None or n.err>t.err: n=t
			off=-off<<(off<0)
		npos,ppos=n.pos,p.pos
		if p.life<=0: p.life,p.err,ppos=lifespan,None,npos
		p.life-=1
		# Find a new position between the particle and its best neighbor.
		# If best=self, jitter with an exponential distribution.
		u,dx=random.random(),0
		if ppos is npos:
			u,v=u,random.random()
			dx=math.exp(min((2*v-1)/(v*(1-v)),devmax))
			p.life+=lifeinc
		for i in range(dim):
			px,nx=ppos[i],npos[i]
			pos[i]=random.gauss((px+nx)*0.5,abs(px-nx*u)+dx)
		err=F(pos)
		# Update the particle and global best positions.
		if p.err is None or p.err>err:
			if gerr>err: gpart,gerr=p,err
			elif gpart is p: gpart,gpos,p.pos=None,p.pos,gpos
			p.err,p.pos,pos=err,pos,p.pos
	x[:]=gpart.pos if gpart else gpos
	return gerr


#---------------------------------------------------------------------------------
# Evolution Strategies


def SNES(F,x,iters,params=(1.0,)):
	# Train the network to fit a given data set using Seperable NES. Adapted from
	# Natural Evolution Strategies by Wierstra, Schaul, Glasmachers, Sun, Peters, and
	# Schmidhuber.
	learn=params[0]
	gauss=random.gauss
	dim=len(x)
	samples=4+int(3*math.log(dim))
	learn*=0.5*(3.0+math.log(dim))/(5*math.sqrt(dim))
	# Instead of using the direct values from our fitness function, the samples are
	# sorted by fitness and given a utility value from their sorted position.
	off=math.log(samples*0.5+1)
	utility=[max(off-math.log(i+1),0) for i in range(samples)]
	norm,off=sum(utility),1.0/samples
	for i in range(samples): utility[i]=utility[i]/norm-off
	samplearr=[[0.0]*dim for i in range(samples)]
	mean,dev=list(x),[1.0]*dim
	point,fitness=[0.0]*dim,[0.0]*samples
	minpoint,minfitness=list(mean),F(mean)
	for iter in range(0,iters,samples):
		# Generate a random sampling of points in normal(mean,dev).
		for i in range(samples):
			sample=samplearr[i]
			for j in range(dim):
				sample[j]=gauss(0,1)
				point[j]=mean[j]+dev[j]*sample[j]
			# Find the fitness of the new point and sort it.
			j,fit=i,F(point)
			while j and fit<fitness[j-1]:
				fitness[j]=fitness[j-1]
				samplearr[j]=samplearr[j-1]
				j-=1
			fitness[j]=fit
			samplearr[j]=sample
		# Check if we have a new optimal point.
		if minfitness>fitness[0]:
			minfitness=fitness[0]
			sample=samplearr[0]
			for i in range(dim):
				minpoint[i]=mean[i]+dev[i]*sample[i]
		# Compute gradients.
		for i in range(dim):
			mgrad,dgrad=0.0,0.0
			for j in range(samples):
				u,s=utility[j],samplearr[j][i]
				mgrad+=u*s
				dgrad+=u*(s*s-1.0)
			# Update the mean and deviation for our next sampling.
			mean[i]+=mgrad*dev[i]
			dev[i]*=math.exp(learn*dgrad)
	return minfitness


#---------------------------------------------------------------------------------
# Main


if __name__=="__main__":
	start=time.time()
	# TestFunctionSolutions()
	TestParams(BasicOpt,1000000,1000,None,True)
	TestParams(PSO,1000000,1000,None,True)
	TestParams(APSO,1000000,100,None,True)
	TestParams(BBPSO,1000000,1000,None,True)
	TestParams(BBPSON,1000000,1000,None,True)
	TestParams(SNES,1000000,1000,None,True)
	# ParamSearch()
	# ParamDisplay()
	print("time : {:.6f}".format(time.time()-start))


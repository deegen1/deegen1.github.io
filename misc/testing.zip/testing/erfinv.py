"""

erfinv.py - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Training program for a fast erfinv() function.

randomize coefs within range
pick best and make it the center
lower range by .98
run again

compare matrix output with eq output
try floating point
highest coef must be positive

pip3 install mpmath

(mat*coef+vec)*coef+con


"""

import math,time,random
from mpmath import mp


#---------------------------------------------------------------------------------
# Test functions


def calcerf(x):
	# Fast convergence of erf(x).
	# https://www.sciencedirect.com/science/article/pii/S0890540112000697
	eps=1e-50
	val=x/math.sqrt(math.pi)
	sum=val
	ln2=math.log(2.0)
	x2 =2*x*x
	e2 =1-x*x/ln2
	i  =1
	while val<-eps or val>eps:
		i+=2
		val*=x2/i
		sum+=val
		# Stagger applying exp(-x*x) to keep values near 1.
		while val>1.0 and e2<=-1:
			e2 +=1
			sum*=0.5
			val*=0.5
	sum*=math.exp(e2*ln2)
	return sum


def TestSqrError():
	"""
	We can reduce the least squared error between the points and polynomial to a
	matrix-vector equation. Given

		(f(x)-p(x))^2 = f(x)^2-2*f(x)*p(x)+p(x)^2

		p(x)=x*(c0+c1*z(x)+c2*z(x)^2+...)
		z(x)=log(1-x^2)

	We transform it into (M*coef+v)*coef. The goal is to minimize this dot product.


	f(x)^2 = sum y^2 for all y

	2*x*f(x)*p(x) =
	2*x(i)*y(i)*(c0+c1*z(i)+c2*z(i)^2+...)
	N(i)=2*x(i)*y(i)
	z(i)=log(1-x(i)^2)
	c0*N(i)+c1*(z(i)*N(i))+c2*(z(i)^2*N(i))+...
	vec[0]=-c0*(sum 2*x(i)*y(i)*z(i)^0)
	vec[1]=-c1*(sum 2*x(i)*y(i)*z(i)^1)
	vec[2]=-c2*(sum 2*x(i)*y(i)*z(i)^2)
	...

	x^2*p(x)^2
	x^2*(c0+c1*z(x)+c2*z(x)^2+...)*(c0+c1*z(x)+c2*z(x)^2+...)
	x^2*cn*z(x)^n*(c0+c1*z(x)+c2*z(x)^2+...)
	cn*c0*x^2*z(x)^n+cn*c1*x^2*z(x)^(n+1)+cn*c2*x^2*z(i)^(n+2)+...
	for i in range(n):
		for j in range(i+1):
			sum=0
			for k in range(points)
				sum+=x^2*z(x)^(i+j)
			mat[i][j]=sum
			mat[j][i]=sum

	err=mp.mpf(sum_y)
	for i in range(n):
		row=mat[i]
		sum=mp.mpf(vec[i])
		for j in range(n): sum+=coef[j]*row[j]
		err+=coef[i]*sum
	"""
	print("Testing mean squared error")
	random.seed(1)
	maxdif=mp.mpf(0)
	sumdif=mp.mpf(0)
	regtime=0
	mattime=0
	trials=100
	for trial in range(trials):
		print("Trial:",trial)
		coefs=random.randrange(12)+1
		# Create the points.
		points=random.randrange(8192)+1
		pscale,poff=mp.mpf(".999999999998"),mp.mpf(".000000000001")
		erftbl=[]
		for i in range(points):
			y=mp.mpf(random.random())*pscale+poff
			x=mp.mpf(random.random()*10-5)
			erftbl+=[[y,x]]
		# Expected sum
		coefvec=[random.random() for c in range(coefs)]
		coefrev=[mp.mpf(c) for c in coefvec[::-1]]
		time0=time.time()
		expsum=mp.mpf(0)
		for e in erftbl:
			x,y=e
			l=mp.log(1-x*x)
			cy=mp.mpf(0)
			for c in coefvec: cy=cy*l+c
			cy*=x
			dif=cy-y
			expsum+=dif*dif
		expsum/=points
		regtime+=time.time()-time0
		# print("ops:",(2+coefs-1)*len(erftbl))
		# Test splitting
		"""sum1,sum2,sum3=mp.mpf(0),mp.mpf(0),mp.mpf(0)
		for e in erftbl:
			x,y,l=e[0],e[1],e[2]
			cy=mp.mpf(0)
			for c in coefvec: cy=cy*l+c
			cy*=x
			# dif*dif:
			sum1+=y*y
			sum2+=-2*y*cy
			sum3+=cy*cy"""
		# print(sum1+sum2+sum3)
		# Precompute error matrix and vectors.
		errcon=mp.mpf(0)
		errvec=[mp.mpf(0) for c in range(coefs)]
		errmat=[[mp.mpf(0) for c in range(coefs)] for c in range(coefs)]
		z=[mp.mpf(0) for c in range(coefs)]
		for e in erftbl:
			x,y=e
			z[0],l=x,mp.log(1-x*x)
			for i in range(1,coefs): z[i]=z[i-1]*l
			errcon+=y*y
			for i in range(coefs):
				errvec[i]+=y*z[i]
				for j in range(i+1):
					errmat[i][j]+=z[i]*z[j]
		# Clean up our precomputed structures.
		errcon/=points
		for i in range(coefs):
			errvec[i]=(-2*errvec[i])/points
			for j in range(i+1):
				val=errmat[i][j]/points
				errmat[i][j]=val
				errmat[j][i]=val
		# Fast error calculation.
		time0=time.time()
		err=mp.mpf(errcon)
		for r in range(coefs):
			row=errmat[r]
			sumr=mp.mpf(errvec[r])
			for c in range(coefs):
				sumr+=row[c]*coefrev[c]
			err+=sumr*coefrev[r]
		mattime+=time.time()-time0
		# print("ops:",coefs*(coefs+1))
		dif=abs(expsum-err)
		print("dif:",repr(dif),"\n")
		if maxdif<dif: maxdif=dif
		sumdif+=dif
	print("------------------------------\nResults:\n")
	print("maxdif:",repr(maxdif),"\n")
	print("sumdif:",repr(sumdif),"\n")
	print("poly   time: {0:.6f}".format(regtime))
	print("matrix time: {0:.6f}".format(mattime))


#---------------------------------------------------------------------------------
# Main script


def BBO(F,x,iters,disp,params=(40,2000,4,5,0.644392,1.587432,1.5005519,1,1)):
	# params=particles,lifespan,lifeinc,lifedec,w,c1,c2,posscale,velscale
	def variance():
		# Cauchy distribution.
		# return math.tan((random.random()-0.5)*3.141592652)
		mag=math.exp(random.random()*36-20)
		return -mag if random.randrange(2) else mag
	def randvec(arr,dev):
		norm=0
		while norm<1e-9:
			norm=0
			for i in range(dim):
				v=random.gauss(0.0,1.0)
				arr[i]=v
				norm+=v*v
		norm=dev/math.sqrt(norm)
		for i in range(dim): arr[i]*=norm
	class Particle(object):
		def __init__(self):
			self.pos=[0.0]*dim
			self.vel=[0.0]*dim
			self.locpos=[0.0]*dim
			self.life=0
	dim=len(x)
	particles=params[0]
	lifespan,lifeinc,lifedec=params[1:4]
	w,c1,c2,pscale,vscale=params[4:9]
	partarr=[Particle() for i in range(particles)]
	glberror,glbpos,glbmag=F(x),list(x),sum(y*y for y in x)
	print("{}: fit: {:.6e}\n{}".format(0,float(mp.sqrt(glberror)),disp(glbpos)))
	printtime,printerr=time.time(),glberror
	updated=False
	for iter in range(1,iters):
		p=partarr[iter%particles]
		pos,vel=p.pos,p.vel
		if p.life<=0:
			randvec(pos,dim*pscale*variance())
			randvec(vel,dim*vscale*variance())
			for i in range(dim): pos[i]+=glbpos[i]
			p.life=lifespan
		else:
			locpos=p.locpos
			for i in range(dim):
				r1,r2=random.random(),random.random()
				vel[i]=w*vel[i]+r1*c1*(locpos[i]-pos[i])+r2*c2*(glbpos[i]-pos[i])
				pos[i]+=vel[i]
		error,mag=F(pos),sum(y*y for y in pos)
		if p.life==lifespan or p.locerror>error or (p.locerror>=error and p.locmag>mag):
			p.locerror,p.locpos[:],p.locmag=error,pos[:],mag
			p.life+=lifeinc
		p.life-=lifedec
		if glberror>error or (glberror>=error and glbmag>mag):
			glberror,glbpos[:],glbmag=error,p.locpos[:],mag
			updated=True
		if updated and time.time()-printtime>=1:
			print("{}: fit: {:.6e}\n{}".format(iter,float(mp.sqrt(glberror)),disp(glbpos)))
			updated=False
			printtime=time.time()
	if updated and time.time()-printtime>=1:
		print("{}: fit: {:.6e}\n{}".format(iter,float(mp.sqrt(glberror)),disp(glbpos)))
	return glbpos


def BBPSON(F,x,iters,disp,params=(200,200,.99)):
	# Bare bones particle swarms with neighbors.
	dim=len(x)
	particles,lifespan,lifeinc=params
	devmax,nbrmax=math.log(1e+30),(particles+4)//3
	gpart,gerr,gpos,pos=None,F(x),x,x[:]
	class Particle(object):
		def __init__(self):
			self.pos=x[:]
			self.err=gerr
			self.life=0
	partarr=[Particle() for i in range(particles)]
	print("{}: fit: {:.6e}\n{}".format(0,float(gerr),disp(gpos)))
	printtime,printerr=time.time(),gerr
	for iter in range(iters-1):
		# Find the best neighbor. Look at +-2^n.
		idx,off=iter%particles,1
		p=partarr[idx]
		n=None if p.life<=0 else p
		while off<nbrmax:
			t=partarr[(idx+off)%particles]
			if n is None or n.err>t.err: n=t
			off=-off<<(off<0)
		npos,ppos=n.pos,p.pos
		if p.life<=0: p.life,p.err,ppos=lifespan,None,npos
		p.life-=1
		# Find a new position between the particle and its best neighbor.
		# If best=self, jitter with an exponential distribution.
		u,dx=random.random(),0
		if ppos is npos:
			u,v=u,random.random()
			dx=math.exp(min((2*v-1)/(v*(1-v)),devmax))
			p.life+=lifeinc
		for i in range(dim):
			px,nx=ppos[i],npos[i]
			pos[i]=random.gauss((px+nx)*0.5,abs(px-nx*u)+dx)
		err=F(pos)
		# Update the particle and global best positions.
		if p.err is None or p.err>err:
			if gerr>err: gpart,gerr=p,err
			elif gpart is p: gpart,gpos,p.pos=None,p.pos,gpos
			p.err,p.pos,pos=err,pos,p.pos
		if printerr!=gerr and time.time()-printtime>=1:
			tpos=gpart.pos if gpart else gpos
			print("{}: fit: {:.6e}\n{}".format(iter,float(gerr),disp(tpos)))
			printerr=gerr
			printtime=time.time()
	x[:]=gpart.pos if gpart else gpos
	if printerr!=gerr:
		print("{}: fit: {:.6e}\n{}".format(iter,float(gerr),disp(x)))
	return gerr


def TrainBodyPoly0(coefcnt):
	# Train an n-th degree polynomial to approximate erfinv(x) for x<some_limit.
	# All values are small enough to use fast float-64 math.
	limit=0
	erfbnd=[mp.mpf(x) for x in [0,.25,.5,.75,1,2,32]]
	erftbl=[]
	steps=1024
	for i in range(1,len(erfbnd)):
		a=erfbnd[i-1]
		b=(erfbnd[i]-a)/steps
		for s in range(steps):
			x=mp.mpf(a+b*s)
			y=mp.erf(x)
			# dx=0.5*mp.sqrt(mp.pi)*mp.exp(x*x)
			l=mp.log(1-y*y)
			erftbl+=[float(y),float(x),float(l)]
	# erftbl+=[mp.mpf(1),mp.mpf("inf")]
	def coefstr(params):
		coefstr=["{0:+.9e}".format(p) for p in params]
		ret=""
		for i in range(len(params)-1):
			ret+="\ty=("+("y" if ret else " ")
			ret+=coefstr[i]+")*x\n"
		ret="if x<{0:.9f}:\n".format(params[-1])+ret
		ret+="["+",".join(coefstr[:-1])+"]\n"
		return ret
	def fitness(params):
		# Simulate converting to and from strings.
		params[-1]=.991
		coefs=[float("{0:+.9e}".format(c)) for c in params[:-1]]
		limit=params[-1]
		if limit<0.01: return (float("inf"),float("inf"),float("inf"))
		maxerr=float(0)
		avgerr=float(0)
		maxdy =0
		avgdy =0
		den=0
		prevcy,prevey,prevx=0,0,0
		for i in range(0,len(erftbl),3):
			x=erftbl[i]
			if x>limit: break
			z=erftbl[i+2]
			cy=float(0)
			for c in coefs:
				cy*=z
				cy+=c
			# cy*=x
			ey=erftbl[i+1]
			if den:
				dx=x-prevx
				dy=abs(((ey-prevey)-(cy-prevcy))/dx)*0.5
				if maxdy<dy: maxdy=dy
				avgdy+=dy
			prevx =x
			prevcy=cy
			prevey=ey
			dif=abs(cy-ey)
			if maxerr<dif: maxerr=dif
			avgerr+=dif
			den+=1
		if den>0: avgerr/=den
		if den>1: avgdy/=den-1
		fitness=(maxerr+avgerr+avgdy) # /(limit*limit*limit)
		return (fitness,maxerr,avgerr,maxdy,avgdy)
	x=[0,0,0,0]
	while len(x)<=coefcnt:
		x=[0,0]+x
		x=BBO(fitness,x,len(x)*1000000,coefstr)


def TrainBodyPoly1(coefs):
	# For fine tuning of coefs from poly1.
	coefs=10
	limit=0.99
	erfbnd=[mp.mpf(x) for x in [0,.25,.5,.75,1,2,8]]
	erftbl=[]
	steps=1024
	for i in range(1,len(erfbnd)):
		a=erfbnd[i-1]
		b=(erfbnd[i]-a)/steps
		for s in range(steps):
			x=mp.mpf(a+b*s)
			y=mp.erf(x)
			erftbl+=[[y,x]]
	# Precompute error matrix and vectors.
	errcon=mp.mpf(0)
	errvec=[mp.mpf(0) for c in range(coefs)]
	errmat=[[mp.mpf(0) for c in range(coefs)] for c in range(coefs)]
	z=[mp.mpf(0) for c in range(coefs)]
	points=0
	for e in erftbl:
		x,y=e
		if x>limit: continue
		points+=1
		z[0],l=x,mp.log(1-x*x)
		for i in range(1,coefs): z[i]=z[i-1]*l
		errcon+=y*y
		for i in range(coefs):
			errvec[i]+=y*z[i]
			for j in range(i+1):
				errmat[i][j]+=z[i]*z[j]
	print("points:",points)
	# Clean up our precomputed structures.
	errcon/=points
	for i in range(coefs):
		errvec[i]=(-2*errvec[i])/points
		for j in range(i+1):
			val=errmat[i][j]/points
			errmat[i][j]=val
			errmat[j][i]=val
	def coefstr(coefvec):
		coefstr=["{0:+.9e}".format(c) for c in coefvec]
		ret=""
		for s in coefstr:
			ret+="\ty="+("y*z" if ret else "   ")+s+"\n"
		ret="if x<{0:.9f}:\n".format(limit)+ret+"\ty=y*x\n"
		ret+="["+",".join(coefstr)+"]\n"
		return ret
	def fitness(coefvec):
		# Calculate the error. weight = 1/err
		coefrev=[mp.mpf("{0:+.9e}".format(c)) for c in coefvec[::-1]]
		err=mp.mpf(errcon)
		for r in range(coefs):
			row=errmat[r]
			sumr=mp.mpf(errvec[r])
			for c in range(coefs):
				sumr+=row[c]*coefrev[c]
			err+=sumr*coefrev[r]
		err=mp.sqrt(err)
		return err
	# t0=time.time()
	x=[0]*coefs
	BBPSON(fitness,x,1000000,coefstr)
	# print(time.time()-t0)


def TrainBodyPoly10(coefs):
	# For fine tuning of coefs from poly1.
	limit=0
	erfbnd=[mp.mpf(x) for x in [0,.25,.5,.75,1,2,8]]
	erftbl=[]
	steps=1024
	for i in range(1,len(erfbnd)):
		a=erfbnd[i-1]
		b=(erfbnd[i]-a)/steps
		for s in range(steps):
			x=mp.mpf(a+b*s)
			y=mp.erf(x)
			# dx=0.5*mp.sqrt(mp.pi)*mp.exp(x*x)
			l=mp.log(1-y*y)
			erftbl+=[y,x,l]
	def coefstr(params):
		coefstr=["{0:+.9e}".format(p) for p in params]
		ret=""
		for i in range(len(params)-1):
			ret+="\ty=("+("y" if ret else " ")
			ret+=coefstr[i]+")*x\n"
		ret="if x<{0:.9f}:\n".format(params[-1])+ret
		ret+="["+",".join(coefstr[:-1])+"]\n"
		return ret
	def fitness(params):
		# Simulate converting to and from strings.
		params[-1]=.991
		coefs=[mp.mpf("{0:+.9e}".format(c)) for c in params[:-1]]
		limit=params[-1]
		if limit<0.01: return mp.mpf("inf")
		limit=mp.mpf(limit)
		avgerr=mp.mpf(0)
		den=0
		for i in range(0,len(erftbl),3):
			x=erftbl[i]
			if x>limit: break
			z=erftbl[i+2]
			cy=mp.mpf(0)
			for c in coefs:
				cy*=z
				cy+=c
			cy*=x
			ey=erftbl[i+1]
			dif=cy-ey
			avgerr+=dif*dif
			den+=1
		return avgerr/den
	t0=time.time()
	BBO(fitness,[0]*coefs+[.991],100000,coefstr)
	print(time.time()-t0)


def TrainBodyPoly2(coefvec):
	# For fine tuning of coefs from poly1.
	limit=0.991
	erfbnd=[mp.mpf(x) for x in [0,.25,.5,.75,1,2,8]]
	erftbl=[]
	steps=1024
	for i in range(1,len(erfbnd)):
		a=erfbnd[i-1]
		b=(erfbnd[i]-a)/steps
		for s in range(steps):
			x=mp.mpf(a+b*s)
			y=mp.erf(x)
			if y<=limit:
				# dx=0.5*mp.sqrt(mp.pi)*mp.exp(x*x)
				l=mp.log(1-y*y)
				erftbl+=[[y,x,l]]
	# Simulate converting to and from strings.
	vec=[mp.mpf(c) for c in coefvec]
	maxerr=mp.mpf(0)
	avgerr=mp.mpf(0)
	sqrerr=mp.mpf(0)
	for tbl in erftbl:
		x,y,z=tbl
		cy=mp.mpf(0)
		for c in vec:
			cy*=z
			cy+=c
		cy*=x
		dif=abs(cy-y)
		if maxerr<dif: maxerr=dif
		avgerr+=dif
		sqrerr+=dif*dif
	points=len(erftbl)
	avgerr/=points
	sqrerr=mp.sqrt(sqrerr/points)
	print("max: {0:.6e}".format(float(maxerr)))
	print("avg: {0:.6e}".format(float(avgerr)))
	print("sqr: {0:.6e}".format(float(sqrerr)))


def TrainTailPoly():
	pass


def CalcErfinv(x):
	#coefs=[4.294932181e-10,4.147083705e-8,1.727466590e-6,4.017907374e-5,5.565679449e-4,4.280807652e-3,6.833279087e-3,-3.742661647e-1,1.187962704e+0]
	#coefs=[7.691594063e-9,2.026362239e-7,1.736297774e-6,1.597546919e-7,-7.941244165e-5,-2.088759943e-4,3.273461437e-3,1.631897530e-2,-3.281194328e-1,1.253314090e+0]
	#coefs=[+6.797323731e-04,+5.110667608e-03,+8.108022160e-03,-1.486283698e-02,-3.990901401e-02,-2.632201247e-01,+8.833398051e-01]
	#y,z=0,math.log(1-x*x+1e-30)
	#for c in coefs: y=y*z+c
	#return y*x
	#58607042: fit: 1.272295e-02
	z=abs(x)
	if z<0.70:
		y=   -9.586323119e-02
		y=y*z+1.636381253e-01
		y=y*z+2.135194872e-01
		y=y*z-2.936856441e-02
		y=y*z+1.728701241e-01
		y=y*z+3.214050487e-02
		y=y*z+8.809994176e-01
		y=y*z
	else:
		y=   +7.998535977e+00
		y=y*z-7.594065005e+00
		y=y*z-1.370037250e+00
		y=y*z+1.866560823e-01
		y=y*z+1.179373857e+00
		y=y*z+1.539123778e+00
		y=y*z-3.463432700e-01
		y=y*z+2.592382218e-01
	return y if x>0 else -y


def ErfinvDraw():
	import matplotlib.pyplot as plt
	axis=plt.gca()
	axis.set_xlim([-1,1])
	axis.set_ylim([-2,2])
	erfbnd=[mp.mpf(x) for x in [0,.25,.5,.75,1,2,16]]
	erfpnt=[]
	steps=1024
	for i in range(1,len(erfbnd)):
		a=erfbnd[i-1]
		b=(erfbnd[i]-a)/steps
		for s in range(steps):
			x=a+b*s
			y=mp.erf(x)
			if not x: continue
			erfpnt+=[[float(y),float(x)],[-float(y),-float(x)]]
	erfpnt.sort()
	xpnt=[p[0] for p in erfpnt]
	ypnt=[p[1] for p in erfpnt]
	plt.plot(xpnt,ypnt)
	xpnt=[]
	ypnt=[]
	steps=1024
	for x0 in range(-steps,steps+1):
		x=x0/steps
		xpnt+=[x]
		ypnt+=[CalcErfinv(x)]
	plt.plot(xpnt,ypnt)
	plt.show()


if __name__=="__main__":
	mp.prec=1024
	# TestSqrError()
	ErfinvDraw()
	# 100000, 6.210823e-4, time: 27.5399
	#TrainBodyPoly1(9)
	# TrainBodyPoly10(7)
	#coefs=[7.691594063e-9,2.026362239e-7,1.736297774e-6,1.597546919e-7,-7.941244165e-5,-2.088759943e-4,3.273461437e-3,1.631897530e-2,-3.281194328e-1,1.253314090e+0]
	# coefs=[c/math.sqrt(2) for c in coefs]
	# fit: 3.252234e-03
	#coefs=[+1.126310475e-03,+8.949953614e-03,+1.712732839e-02,-1.763242630e-02,-6.974862900e-02,-2.891510648e-01,+8.784082263e-01]
	# TrainBodyPoly2(coefs)

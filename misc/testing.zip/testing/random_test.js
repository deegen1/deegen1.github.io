/*------------------------------------------------------------------------------


random_test.js - v1.01

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


*/
/* npx eslint random_test.js -c ../../../standards/eslint.js */


import {Random} from "../random.js";


//---------------------------------------------------------------------------------
// erfinv()


function ErfInv1(x) {
	// Returns a normally distributed random variable. This function uses a linear
	// piecewise approximation of sqrt(2)*erfinv((x+1)*0.5) to quickly compute values.
	// Find the greatest y[i]<=x, then return x*m[i]+b[i].
	const xmbarr=[
		0.0000000000,2.1105791e+05,-5.4199832e+00,0.0000056568,6.9695708e+03,-4.2654963e+00,
		0.0000920071,7.7912181e+02,-3.6959312e+00,0.0007516877,1.6937928e+02,-3.2375953e+00,
		0.0032102442,6.1190088e+01,-2.8902816e+00,0.0088150936,2.8470915e+01,-2.6018590e+00,
		0.0176252084,1.8800444e+01,-2.4314149e+00,0.0283040851,1.2373531e+01,-2.2495070e+00,
		0.0466319112,8.6534303e+00,-2.0760316e+00,0.0672857680,6.8979540e+00,-1.9579131e+00,
		0.0910495504,5.3823501e+00,-1.8199180e+00,0.1221801449,4.5224728e+00,-1.7148581e+00,
		0.1540346442,3.9141567e+00,-1.6211563e+00,0.1900229058,3.4575317e+00,-1.5343871e+00,
		0.2564543024,2.8079448e+00,-1.3677978e+00,0.3543675790,2.6047685e+00,-1.2957987e+00,
		0.4178358886,2.5233767e+00,-1.2617903e+00,0.5881852711,2.6379475e+00,-1.3291791e+00,
		0.6397157999,2.7530438e+00,-1.4028080e+00,0.7303095074,3.3480131e+00,-1.8373198e+00,
		0.7977016349,3.7812818e+00,-2.1829389e+00,0.8484734402,4.7872429e+00,-3.0364702e+00,
		0.8939255135,6.2138677e+00,-4.3117665e+00,0.9239453541,7.8175201e+00,-5.7934537e+00,
		0.9452687641,1.0404724e+01,-8.2390571e+00,0.9628624602,1.4564418e+01,-1.2244270e+01,
		0.9772883839,2.3567788e+01,-2.1043159e+01,0.9881715750,4.4573121e+01,-4.1800032e+01,
		0.9948144543,1.0046744e+02,-9.7404506e+01,0.9980488575,2.5934959e+02,-2.5597666e+02,
		0.9994697975,1.0783868e+03,-1.0745796e+03,0.9999882905,1.3881171e+05,-1.3880629e+05
	];
	x=(x+1)/2;
	let i=48;
	i+=x<xmbarr[i]?-24:24;
	i+=x<xmbarr[i]?-12:12;
	i+=x<xmbarr[i]?-6:6;
	i+=x<xmbarr[i]?-3:3;
	i+=x<xmbarr[i]?-3:0;
	return (x*xmbarr[i+1]+xmbarr[i+2])/Math.sqrt(2);
}


function ErfInv2(u) {
	// Credit: njuffa, https://stackoverflow.com/a/49743348
	let t=Math.log(1-u*u),p=0;
	if (t<-6.125) {
		p=    3.03697567e-10;
		p=p*t+2.93243101e-8;
		p=p*t+1.22150334e-6;
		p=p*t+2.84108955e-5;
		p=p*t+3.93552968e-4;
		p=p*t+3.02698812e-3;
		p=p*t+4.83185798e-3;
		p=p*t-2.64646143e-1;
		p=p*t+8.40016484e-1;
	} else {
		p=    5.43877832e-9;
		p=p*t+1.43285448e-7;
		p=p*t+1.22774793e-6;
		p=p*t+1.12963626e-7;
		p=p*t-5.61530760e-5;
		p=p*t-1.47697632e-4;
		p=p*t+2.31468678e-3;
		p=p*t+1.15392581e-2;
		p=p*t-2.32015476e-1;
		p=p*t+8.86226892e-1;
	}
	return p*u;
}


function ErfInv3(u) {
	// ErfInv2(u)*sqrt(2)
	// Credit: njuffa, https://stackoverflow.com/a/49743348
	let t=Math.log(1-u*u),p=0;
	if (t<-6.125) {
		p=    4.294932181e-10;
		p=p*t+4.147083705e-8;
		p=p*t+1.727466590e-6;
		p=p*t+4.017907374e-5;
		p=p*t+5.565679449e-4;
		p=p*t+4.280807652e-3;
		p=p*t+6.833279087e-3;
		p=p*t-3.742661647e-1;
		p=p*t+1.187962704e+0;
	} else {
		p=    7.691594063e-9;
		p=p*t+2.026362239e-7;
		p=p*t+1.736297774e-6;
		p=p*t+1.597546919e-7;
		p=p*t-7.941244165e-5;
		p=p*t-2.088759943e-4;
		p=p*t+3.273461437e-3;
		p=p*t+1.631897530e-2;
		p=p*t-3.281194328e-1;
		p=p*t+1.253314090e+0;
	}
	return p*u;
}


function ErfInvTest() {
	//let x=1-1e-9;
	//console.log(ErfInv1(x));
	//console.log(ErfInv2(x));
	let max=0;
	let samples=100000000;
	let s2=Math.sqrt(2);
	for (let s=0;s<samples;s++) {
		let u=((s/(samples-1))-0.5)*1.99999999;
		let e0=ErfInv2(u)*s2;
		let e1=ErfInv3(u);
		let err=Math.abs(e0-e1);
		if (err>1e-10) {err/=Math.abs(e0);}
		if (max<err || isNaN(err)) {
			max=err;
			console.log("max:",max);
		}
	}
	console.log("max:",max);
}


//---------------------------------------------------------------------------------
// Normal Distribution Functions


const xmbarr=[
	0.0000000000,2.1105791e+05,-5.4199832e+00,0.0000056568,6.9695708e+03,-4.2654963e+00,
	0.0000920071,7.7912181e+02,-3.6959312e+00,0.0007516877,1.6937928e+02,-3.2375953e+00,
	0.0032102442,6.1190088e+01,-2.8902816e+00,0.0088150936,2.8470915e+01,-2.6018590e+00,
	0.0176252084,1.8800444e+01,-2.4314149e+00,0.0283040851,1.2373531e+01,-2.2495070e+00,
	0.0466319112,8.6534303e+00,-2.0760316e+00,0.0672857680,6.8979540e+00,-1.9579131e+00,
	0.0910495504,5.3823501e+00,-1.8199180e+00,0.1221801449,4.5224728e+00,-1.7148581e+00,
	0.1540346442,3.9141567e+00,-1.6211563e+00,0.1900229058,3.4575317e+00,-1.5343871e+00,
	0.2564543024,2.8079448e+00,-1.3677978e+00,0.3543675790,2.6047685e+00,-1.2957987e+00,
	0.4178358886,2.5233767e+00,-1.2617903e+00,0.5881852711,2.6379475e+00,-1.3291791e+00,
	0.6397157999,2.7530438e+00,-1.4028080e+00,0.7303095074,3.3480131e+00,-1.8373198e+00,
	0.7977016349,3.7812818e+00,-2.1829389e+00,0.8484734402,4.7872429e+00,-3.0364702e+00,
	0.8939255135,6.2138677e+00,-4.3117665e+00,0.9239453541,7.8175201e+00,-5.7934537e+00,
	0.9452687641,1.0404724e+01,-8.2390571e+00,0.9628624602,1.4564418e+01,-1.2244270e+01,
	0.9772883839,2.3567788e+01,-2.1043159e+01,0.9881715750,4.4573121e+01,-4.1800032e+01,
	0.9948144543,1.0046744e+02,-9.7404506e+01,0.9980488575,2.5934959e+02,-2.5597666e+02,
	0.9994697975,1.0783868e+03,-1.0745796e+03,0.9999882905,1.3881171e+05,-1.3880629e+05
];
function RandomGetNorm1(rnd) {
	// Returns a normally distributed random variable. This function uses a linear
	// piecewise approximation of sqrt(2)*erfinv(2*x-1) to quickly compute values.
	// Find the greatest y[i]<=x, then return x*m[i]+b[i].
	let x=rnd.getf(),i=48;
	i+=x<xmbarr[i]?-24:24;
	i+=x<xmbarr[i]?-12:12;
	i+=x<xmbarr[i]?-6:6;
	i+=x<xmbarr[i]?-3:3;
	i+=x<xmbarr[i]?-3:0;
	return x*xmbarr[i+1]+xmbarr[i+2];
}


function RandomGetNorm2(rnd) {
	// Transform a uniform distribution to a normal one via sqrt(2)*erfinv(2*u-1).
	// erfinv credit: njuffa, https://stackoverflow.com/a/49743348
	let u=(rnd.getu32()-2147483647.5)*(1/2147483648);
	let t=Math.log(1-u*u),p=0;
	if (t<-6.125) {
		p=    3.03697567e-10;
		p=p*t+2.93243101e-8;
		p=p*t+1.22150334e-6;
		p=p*t+2.84108955e-5;
		p=p*t+3.93552968e-4;
		p=p*t+3.02698812e-3;
		p=p*t+4.83185798e-3;
		p=p*t-2.64646143e-1;
		p=p*t+8.40016484e-1;
	} else {
		p=    5.43877832e-9;
		p=p*t+1.43285448e-7;
		p=p*t+1.22774793e-6;
		p=p*t+1.12963626e-7;
		p=p*t-5.61530760e-5;
		p=p*t-1.47697632e-4;
		p=p*t+2.31468678e-3;
		p=p*t+1.15392581e-2;
		p=p*t-2.32015476e-1;
		p=p*t+8.86226892e-1;
	}
	return p*u*1.414213562;
}


function RandomGetNorm3(rnd) {
	// Box-Muller transform.
	let r=rnd.getf();
	r=Math.sqrt(-2*Math.log(r>1e-30?r:1e-30));
	return Math.cos(6.283185307*rnd.getf())*r;
}


function RandomGetNorm4(rnd) {
	// Box-Muller transform.
	let u=0,v=0,d=0;
	do {
		u=rnd.getf();
		v=rnd.getf();
		d=u*u+v*v;
	} while (d<1e-10 || d>1);
	d=u*Math.sqrt(-Math.log(d)/d);
	return u>v?d:-d;
}


//---------------------------------------------------------------------------------
// Tests


function DistTest() {
	// Test against cdf.
	// import math
	// def phi(x): return (1+math.erf(x/math.sqrt(2)))*0.5
	// arr=[0]+[phi(i/5-5) for i in range(51)]+[1]
	// ",".join(["{0:.8e}".format(arr[i+1]-arr[i]) for i in range(len(arr)-1)])
	console.log("testing normal distribution");
	let cdftable=[
		2.86651572e-07,5.06676580e-07,1.31912655e-06,3.30008921e-06,7.93320511e-06,
		1.83254928e-05,4.06768021e-05,8.67605462e-05,1.77820676e-04,3.50208672e-04,
		6.62760094e-04,1.20523230e-03,2.10605769e-03,3.53634790e-03,5.70591159e-03,
		8.84668443e-03,1.31801872e-02,1.88689726e-02,2.59573675e-02,3.43130110e-02,
		4.35855837e-02,5.32001447e-02,6.23977192e-02,7.03251406e-02,7.61620322e-02,
		7.92597094e-02,7.92597094e-02,7.61620322e-02,7.03251406e-02,6.23977192e-02,
		5.32001447e-02,4.35855837e-02,3.43130110e-02,2.59573675e-02,1.88689726e-02,
		1.31801872e-02,8.84668443e-03,5.70591159e-03,3.53634790e-03,2.10605769e-03,
		1.20523230e-03,6.62760094e-04,3.50208672e-04,1.77820676e-04,8.67605462e-05,
		4.06768021e-05,1.83254928e-05,7.93320511e-06,3.30008921e-06,1.31912655e-06,
		5.06676580e-07,2.86651572e-07
	];
	let cdfs=cdftable.length-1,cdfmul=5,cdfoff=25+1;
	let cdfsum=(new Array(cdfs+1)).fill(0);
	let samples=100000000;
	let rnd=new Random();
	for (let s=0;s<samples;s++) {
		let norm=rnd.getnorm();
		let i=Math.floor(norm*cdfmul+cdfoff);
		if (i<1) {
			cdfsum[0]++;
		} else if (i>=cdfs) {
			cdfsum[cdfs]++;
		} else {
			cdfsum[i]++;
		}
	}
	let avgerr=0;
	for (let i=0;i<=cdfs;i++) {
		let expect=cdftable[i]*samples;
		let result=cdfsum[i];
		let dif=Math.abs(expect-result)/expect;
		avgerr+=dif;
		console.log(i+": "+dif.toFixed(10));
	}
	console.log("avg: "+(avgerr/(cdfs+1)).toFixed(6));
}


function NormSpeedTest() {
	let rnd=new Random();
	let trials=10000000;
	let sum0=0;
	let t0=performance.now();
	for (let i=0;i<trials;i++) {
		sum0+=RandomGetNorm1(rnd);
	}
	let sum1=0;
	let t1=performance.now();
	for (let i=0;i<trials;i++) {
		sum1+=RandomGetNorm2(rnd);
	}
	let sum2=0;
	let t2=performance.now();
	for (let i=0;i<trials;i++) {
		sum2+=RandomGetNorm3(rnd);
	}
	let sum3=0;
	let t3=performance.now();
	for (let i=0;i<trials;i++) {
		sum3+=RandomGetNorm4(rnd);
	}
	let sum4=0;
	let t4=performance.now();
	for (let i=0;i<trials;i++) {
		sum4+=rnd.getnorm();
	}
	let t5=performance.now();
	t5=(t5-t4)/1000;
	t4=(t4-t3)/1000;
	t3=(t3-t2)/1000;
	t2=(t2-t1)/1000;
	t1=(t1-t0)/1000;
	console.log("time 1: "+t1.toFixed(6)+", "+sum0);
	console.log("time 2: "+t2.toFixed(6)+", "+sum1);
	console.log("time 3: "+t3.toFixed(6)+", "+sum2);
	console.log("time 4: "+t4.toFixed(6)+", "+sum3);
	console.log("time 5: "+t5.toFixed(6)+", "+sum4);
}


//const LUTHash=new Uint32Array(256);
function InitBoxHash() {
	let rnd=new Random();
	let box=new Uint32Array(256);
	for (let i=0;i<256;i++) {
		let j=rnd.mod(i+1);
		box[i]=box[j];
		box[j]=(rnd.getu32()&0xffffff00)|i;
	}
	let out="const box=[\n";
	for (let i=0;i<256;i++) {
		if ((i&7)===0) {out+="\t";}
		let v=box[i];
		out+="0x"+v.toString(16).padStart(8,'0')+",";
		if ((i&7)===7) {out+="\n";}
	}
	out+="];\n";
	console.log(out);
}


const BOX=new Uint32Array([
	0x4ec5d5d4,0x311194a3,0x09963f00,0x200777fd,0xcdab20b6,0x362d2dae,0xdd387162,0x9f68e7c8,
	0x54c8df8c,0xebb58775,0xde170fc5,0x850836e4,0xb5d90827,0x149b34ef,0xc5676345,0x2be3baf4,
	0xf8053128,0x6370cc78,0xd1ac7056,0xe048e11c,0x6e20dce0,0xbf57e6fe,0xd1935896,0xd2e275d3,
	0x6c7e8148,0x8a939f10,0x86832cfc,0x05fe563e,0x03a5722d,0xbbceabe3,0x9af0ce59,0xb1f3e42c,
	0x26eded43,0x2a7bb2b7,0x9fa77906,0x7a4b138a,0xe3388f0a,0x57885c38,0x93dac680,0x4c1d42b8,
	0xd2fcc81f,0x6e6e9fc4,0x81e0564d,0x47dc286d,0x584b116f,0x96ef1016,0x62679b98,0x1fde7433,
	0x68b3bf91,0x870517e1,0x50a13e86,0x1bea704b,0x294ece97,0xf59586a8,0x45dbc773,0x03d3816c,
	0x5fe73588,0x780ddacc,0xa608527a,0xe663dcbd,0x7d3da67c,0xff420e79,0x4d26b093,0xe4289dab,
	0xed65df8b,0x4c3b1f1a,0xce4411e2,0xf268be77,0x416c7939,0xc376b118,0xc364f1a9,0xb613d5fa,
	0xeea301d7,0x0b384640,0x689f32b4,0x7cdd292b,0x8741a368,0x09a2c246,0x94369149,0xf4b1c308,
	0xa03ec7f5,0xdab0c203,0x48e88fec,0xe64c4b44,0x3bacf620,0x20848fbb,0x77051358,0x13704ea2,
	0x91db3caf,0x29d8c605,0x4addaf7e,0xd6d25390,0x93bb56ee,0x9b366d5f,0x2eba7b4f,0x933c0a85,
	0x97118faa,0x93c1b92a,0xe86f9a5e,0x475901ea,0x5e242c94,0x2ddd8813,0xd9abbca5,0xa37aa80c,
	0x7598e8a7,0x2c4dd2ed,0xaca521b1,0x6dcd85c1,0x774fb88f,0xc9168266,0xd31c38cd,0x25643736,
	0xba5e8104,0x4951e364,0x8d8f95bf,0xbbbff8f2,0x01d396e9,0xb44f62e6,0x18eb5bc6,0x3b2e4832,
	0xb2364a3f,0x093fec0e,0x644e5ec0,0x8a5627b2,0xaa112421,0xacf93bc7,0xe60bcc35,0x574771d1,
	0xa44359a6,0x75b39e1b,0xf574d8e8,0xd018eed6,0x0d0ee93c,0x3894ea5c,0x85e3320b,0xc3ce5492,
	0x96764bd0,0xd55b86f0,0x8ae12cf1,0xeb0d4fde,0xb97a5317,0x2119aa52,0xce2672c2,0x5ae4609d,
	0x241820ad,0x35e4cd14,0xfe403722,0xf8ee1482,0x9944f407,0x8f9e1e5b,0xa1b23a87,0x3816b7f3,
	0xd53acdba,0xfe18c78d,0xfabfbb23,0xcd124b15,0x09464d37,0x738f8ae7,0x1885ccf6,0xabf28ea4,
	0x159c201d,0x53330c31,0x5f76bc02,0x472ad9f7,0xf56f309b,0x55361e54,0xc355c255,0xcd7ab3b9,
	0x3bc89519,0x76a0be47,0xf44e8684,0x60aabe25,0x54f432b5,0x5ef35550,0xcf4d467d,0x25b4a163,
	0x17bd2a24,0x83c9d4c3,0x5f19a67b,0x7a20b141,0x5e37a43b,0x23685101,0x3e518eeb,0xde45c36a,
	0x778dc5d2,0x61deb61e,0xb064e09f,0xbd677b83,0xa0ab67cb,0x4ad3c96b,0xd8def35d,0xa2033c11,
	0x3df6c426,0x58cbde9e,0xfc40ec0f,0x2d4c4570,0xae882c74,0x0ad69cff,0xb998329a,0x08ef52ac,
	0x9e8b2334,0x1bd99ca0,0xb1435c89,0x575f7aca,0x0be8e209,0xe6c433e5,0x5612b629,0x94fa1fcf,
	0x7d01987f,0xf1a7ab4a,0x2daafb4c,0xd8470ebc,0xcdebc15a,0x9329683a,0xb50883d9,0xe188ae99,
	0xb9cf033d,0xfef678b3,0x2a6649f9,0x2e3e26dd,0x7e75c695,0xf8db8d71,0x929b3c42,0x80508660,
	0xd2ce408e,0xa6de3ad5,0x5578d92f,0x757760dc,0x9ebe9ddb,0x4eb45272,0x429ca10d,0x9b5e4a69,
	0x00e9b5f8,0x7e2dbdd8,0x00b4ab81,0xa9f99a51,0x112c63b0,0x4b29f2fb,0x5f657053,0xaef888a1,
	0xc69a3665,0xa1f71b67,0x127cfc6e,0xfe6efcbe,0x0dde2e57,0x4d4e9976,0x73f296da,0xe8b64ace,
	0x79874edf,0xd4241830,0xaf745a9c,0x6dfbafc9,0x282cd72e,0x2a841161,0x42463512,0x71f06d4e
]);
function BoxHash(h){
	h=(h<<8)+BOX[h>>>24];
	h=(h<<8)+BOX[h>>>24];
	h=(h<<8)+BOX[h>>>24];
	h=(h<<8)+BOX[h>>>24];
	return h>>>0;
}


function OldHashu32(val) {
	val+=0x66daacfd;
	val=Math.imul(val^(val>>>16),0xf8b7629f);
	val=Math.imul(val^(val>>> 8),0xcbc5c2b5);
	val=Math.imul(val^(val>>>24),0xf5a5bda5);
	return val>>>0;
}


function HashSpeedTest() {
	let rnd=new Random();
	let trials=100000000;
	let sum=0;
	let t0=performance.now();
	for (let i=0;i<trials;i++) {
		sum^=OldHashu32(i);
	}
	let t1=performance.now();
	for (let i=0;i<trials;i++) {
		sum^=Random.hashu32(i);
	}
	let t2=performance.now();
	for (let i=0;i<trials;i++) {
		sum^=BoxHash(i);
	}
	let t3=performance.now();
	t3=(t3-t2)/1000;
	t2=(t2-t1)/1000;
	t1=(t1-t0)/1000;
	console.log("sum:",sum);
	console.log("time 1: "+t1.toFixed(6));
	console.log("time 2: "+t2.toFixed(6));
	console.log("time 3: "+t3.toFixed(6));
}


function main() {
	//ErfInvTest();
	//DistTest();
	//SpeedTest();
	//InitBoxHash();
	HashSpeedTest();
}
main();
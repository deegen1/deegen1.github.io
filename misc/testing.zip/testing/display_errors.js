export function DisplayErrors() {
	// For use when the web console is not available.
	let used=0;
	window.addEventListener("error",function (evt) {
		if (used++) {return;}
		let namearr=["file","line","error","stack"];
		let valarr =[evt.filename,evt.lineno,evt.error,evt.error.stack];
		let replace=[["&","&amp;"],["<","&lt;"],[">","&gt;"],["\n","<br>"]];
		let table="<table style='position:absolute;top:0;left:0;background-color:#000000;"+
			     "color:#ffffff;font-family:monospace,monospace;'>\n";
		let tdstyle="<td style='padding:0.3rem;background-color:#202020;vertical-align:top";
		for (let i=0;i<4;i++) {
			let val=valarr[i].toString();
			for (let r of replace) {val=val.replace(new RegExp(r[0],"g"),r[1]);}
			table+=`<tr>${tdstyle};color:#ff8080'>${namearr[i]}:</td>${tdstyle}'>${val}</td></tr>\n`;
		}
		table+="</table>";
		document.body.innerHTML+=table;
	});
}
// DisplayErrors();

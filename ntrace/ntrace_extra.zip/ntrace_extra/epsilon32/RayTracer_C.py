# RayTracer_C.py -- v1.00 -- Alec Dee, akdee144@gmail.com

import sys,RayTracer_C_Ext
sys.path.insert(0,"../../")
from RayTracer import *

if __name__=="__main__":
	import time
	highquality=False
	pixels,rays,sphere=((1200,1<<15,1<<13),(600,1<<15,1<<17))[highquality]
	start=time.time()
	path="./render3d.bmp"
	hpi=math.pi*0.5
	sc=Scene(3,pixels,pixels)
	sc.raysperpixel=rays
	sc.setcamera((278,273,800),(0,0,0),37.5)
	lightmat=MeshMaterial((1.0,1.0,1.0),25.0)
	wallmat =MeshMaterial((0.9,0.9,0.9))
	rightmat=MeshMaterial((0.2,0.9,0.2))
	leftmat =MeshMaterial((0.9,0.2,0.2))
	mirmat  =MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0)
	submat  =MeshMaterial((0.4,0.4,0.9),0.0,0.0,0.0,1.0,1.0,5.0)
	glassmat=MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0,1.0,1.5)
	sc.addcube((130,0.2,105),lightmat,Transform((278,548.7,-279.5)))
	sc.addcube((556,559.2),wallmat,Transform((278,0,-279.6),(0,0,hpi)))
	sc.addcube((556,559.2),wallmat,Transform((278,548.8,-279.6),(0,0,-hpi)))
	sc.addcube((556,-548.8),wallmat,Transform((278,274.4,-559.2)))
	sc.addcube((559.2,548.8),leftmat,Transform((0,274.4,-279.6),(0,hpi,0)))
	sc.addcube((559.2,548.8),rightmat,Transform((556,274.4,-279.6),(0,-hpi,0)))
	# sc.addcube((166,166,166),submat,Transform((371,83,-168.5),(0,0.2856,0)))
	sc.addsphere((250,280,-370),100,sphere,glassmat)
	# sc.addsphere((135,125,-125),80,sphere,glassmat)
	print("rendering {0} triangles".format(sc.mesh.faces))
	sc.mesh.buildbvh()
	start=time.time()
	RayTracer_C_Ext.render(sc)
	# sc.render(threaded,True)
	print("time: {0:.6f}".format(time.time()-start))
	print("saving image to "+path)
	sc.savebmp(path)


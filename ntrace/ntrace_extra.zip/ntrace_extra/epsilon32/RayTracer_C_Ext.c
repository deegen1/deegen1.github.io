// RayTracer_C_Ext.c -- v1.00 -- Alec Dee, akdee144@gmail.com

// TODO:
// link openmp
// pragma omp parallel for
// -O2
// thread safe rng
// remove return values from vectors

#include <Python.h>
#include <math.h>
#include <stdio.h>
#include <x86intrin.h>
// #include <stdatomic.h>
#include <string.h>

// Enable all warnings, then disable erroneous warnings.
#if defined(__GNUC__)!=0
	#pragma GCC diagnostic warning "-Wall"
	// Clang does not know about some GCC pragmas. Must be called after -Wall.
	#if defined(__clang__)!=0
		#pragma clang diagnostic ignored "-Wunknown-pragmas"
	#endif
	#pragma GCC diagnostic warning "-Wextra"
	// Enable standard C compliance.
	#pragma GCC diagnostic warning "-Wpedantic"
	// Warn if a local declaration shadows a parent delcaration.
	#pragma GCC diagnostic warning "-Wshadow"
	// Warn if using undefined values in the preprocessor.
	#pragma GCC diagnostic warning "-Wundef"
	// Warn if "int x=x;".
	#pragma GCC diagnostic warning "-Winit-self"
	// Ignore warnings for unused function parameters.
	#pragma GCC diagnostic ignored "-Wunused-parameter"
	// Ignore warnings for "int x=0;*((float*)&x)=0;"
	#pragma GCC diagnostic ignored "-Wstrict-aliasing"
	// Ignore warnings for
	//      void test(u32 len) {
	//           u32 val;
	//           for (u32 i=0;i<len;i++) val=(i&7)?val>>8:sfrand32();
	//           printf("%d",val);
	//      }
	#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
	// Ignore warnings for multi-line comments.
	#pragma GCC diagnostic ignored "-Wcomment"
	// Allowed unused return values.
	#pragma GCC diagnostic ignored "-Wunused-result"
#elif defined(_MSC_VER)!=0
	// Set warning level 4.
	#pragma warning(push,4)
	// Ignore warnings when taking the negation of an unsigned int.
	#pragma warning(disable:4146)
	// MSVC considers fopen to be unsafe.
	#pragma warning(disable:4996)
#endif

//---------------------------------------------------------------------------------
// Declarations
//---------------------------------------------------------------------------------

typedef   signed      char  s8;
typedef unsigned      char  u8;
typedef   signed     short s16;
typedef unsigned     short u16;
typedef   signed       int s32;
typedef unsigned       int u32;
typedef   signed long long s64;
typedef unsigned long long u64;
typedef              float f32;
typedef             double f64;

#define DIM 3
#define RT_TYPE_NONE  0
#define RT_TYPE_MATL  1
#define RT_TYPE_VERT  2
#define RT_TYPE_FACE  3
#define RT_TYPE_INST  4
#define RT_TYPE_BVH   5
#define RT_TYPE_MESH  6
#define RT_TYPE_SCENE 7

typedef struct rtvec_t rtvec;
typedef struct rtmat_t rtmat;
typedef struct rtray_t rtray;
typedef struct rtmaterial_t rtmaterial;
typedef struct rtvert_t rtvert;
typedef struct rtface_t rtface;
typedef struct rtinst_t rtinst;
typedef struct rtbvhnode_t rtbvhnode;
typedef struct rtmesh_t rtmesh;
typedef struct rtscene_t rtscene;
typedef struct rtpymaplink_t rtpymaplink;

struct rtvec_t
{
	f32 elem[DIM];
};

struct rtmat_t
{
	f32 elem[DIM*DIM];
};

struct rtbvhnode_t
{
	rtpymaplink* pymap;
	rtbvhnode* parent;
	void* left;
	void* right;
	rtvec bbmin;
	rtvec bbmax;
	s32 type;
	s32 axis;
	s32 testray;
};

struct rtray_t
{
	rtvec pos;
	rtvec dir;
	f32 inv[DIM];
	f32 min;
	f32 max;
	rtface* face;
	rtvec facenorm;
	rtmaterial* facemat;
};

struct rtmaterial_t
{
	rtpymaplink* pymap;
	f32 color[3];
	f32 luminosity;
	f32 reflectprob;
	f32 diffusion;
	f32 refractprob;
	f32 refractindex;
	f32 scatterlen;
	f32 absorbprob;
};

struct rtvert_t
{
	rtpymaplink* pymap;
	rtvec pos;
};

struct rtface_t
{
	rtpymaplink* pymap;
	rtvert* vert[DIM];
	rtvec norm;
	rtvec bary[DIM-1];
	rtmaterial* mat;
};

struct rtinst_t
{
	rtpymaplink* pymap;
	rtmesh* mesh;
	rtmaterial* matl;
	rtmat transmat;
	rtvec transoff;
	rtmat invmat;
	rtvec invoff;
};

struct rtmesh_t
{
	rtpymaplink* pymap;
	s32 dim;
	s32 verts;
	rtvert* vertarr;
	s32 faces;
	rtface* facearr;
	s32 insts;
	rtinst* instarr;
	s32 bvhnodes;
	rtbvhnode* bvhnodearr;
	rtbvhnode* bvhroot;
};

struct rtscene_t
{
	rtpymaplink* pymap;
	s32 dim;
	u32 raysperpixel;
	u32 maxbounces;
	s32 imgwidth;
	s32 imgheight;
	s32 imgpixels;
	f32* imgrgb;
	rtmesh* mesh;
	rtvec campos;
	rtvec cambl;
	rtvec camu;
	rtvec camv;
};

rtmesh* rtmeshcreate(void);
void rtmeshfree(rtmesh* mesh);
void rtmeshloadpy(rtmesh* mesh,PyObject* pymesh);
rtbvhnode* rtbvhloadpyarr(PyObject* pybvh,s32 nodes);
void rtbvhraypick(rtbvhnode* root,rtray* ray);
void rtscenefree(rtscene* scene);
void rtmatlfree(rtmaterial* mat);

//---------------------------------------------------------------------------------
// Helper Functions
//---------------------------------------------------------------------------------

#define rtassert(cond) rtassert0((cond)!=0,__FILE__,__LINE__)
void rtassert0(u32 cond,const char* file,int line)
{
	if (cond==0)
	{
		printf("assert failed:\nfile: %s\nline: %d\n",file,line);
		exit(1);
	}
}

s64 rt_alloc_count=0;

void* rtalloc(u32 size)
{
	if (size==0) {return 0;}
	rt_alloc_count++;
	return malloc(size);
}

void rtfree(void* mem)
{
	if (mem==0) {return;}
	rt_alloc_count--;
	free(mem);
}

u64 rtrand64(void)
{
	// static atomic_uint_fast64_t state=ATOMIC_VAR_INIT(0);
	static u64 state=0;
	static u64 inc=1;
	static u32 init=0;
	if (init==0)
	{
		init=1;
		state=__rdtsc();
		inc=rtrand64()|1;
	}
	u64 hash=state+=inc;
	hash=(hash>>31)|(hash<<33);
	hash^=hash>>34;
	hash*=0x77289737111f5371ULL;
	hash=(hash>>42)|(hash<<22);
	hash^=hash>>12;
	hash*=0x2cd3001685ece1f9ULL;
	hash=(hash>>55)|(hash<<9);
	hash^=hash>>20;
	hash*=0xc80b46d2e9ec9f8dULL;
	hash=(hash>>32)|(hash<<32);
	return hash;
}

f32 rtrandf(void)
{
	// Generate a 32 bit float in [0,1). The mantissa for IEEE 32 bit floats is 23
	// bits, so use a 23 bit integer and cast it to [0,1).
	return ((f32)(rtrand64()&0x007fffff))*(1.0/8388608.0);
}

f32 rtrandr(f32 min,f32 max)
{
	// Generate a 32 bit float in the range [min,max).
	return rtrandf()*(max-min)+min;
}

u32 rtrandmod(u32 min,u32 max)
{
	// Generate a 32 bit int in the range [min,max).
	rtassert(min<max);
	return rtrand64()%(max-min)+min;
}

f64 rtrandn(void)
{
	// Linear piecewise approximation of a normally distributed random variable.
	// Since this function is called so often, and accuracy is not too important,
	// so it is worthwhile to use an approximation. See erfinv()*ssqrt(2).
	static const f64 xmbarr[96]=
	{
		0.0000000000,2.3132004e+05,-5.4199832e+00,0.0000074380,6.4939428e+02,-3.7042586e+00,
		0.0010642654,1.4185658e+02,-3.1641038e+00,0.0030604827,7.6693368e+01,-2.9646729e+00,
		0.0063663560,3.9596546e+01,-2.7285013e+00,0.0130377750,2.2310338e+01,-2.5031276e+00,
		0.0243126778,1.3432234e+01,-2.2872771e+00,0.0435126525,8.8343954e+00,-2.0872130e+00,
		0.0690178823,6.4346059e+00,-1.9215846e+00,0.0999642302,5.1427710e+00,-1.7924473e+00,
		0.1294612062,4.3036652e+00,-1.6838156e+00,0.1731623577,3.5659976e+00,-1.5560794e+00,
		0.2278318291,3.0970294e+00,-1.4492335e+00,0.2882968075,2.7630908e+00,-1.3529601e+00,
		0.3769428714,2.5314264e+00,-1.2656358e+00,0.6223366304,2.7404219e+00,-1.3957014e+00,
		0.6958874445,2.9992279e+00,-1.5758012e+00,0.7579283124,3.4360880e+00,-1.9069099e+00,
		0.8146371414,4.0929738e+00,-2.4420335e+00,0.8598771943,4.8929589e+00,-3.1299224e+00,
		0.8928133625,6.0584144e+00,-4.1704566e+00,0.9242924097,8.1605798e+00,-6.1134722e+00,
		0.9498424387,1.1285929e+01,-9.0820612e+00,0.9651538648,1.4668166e+01,-1.2346441e+01,
		0.9741275327,1.9190741e+01,-1.6752005e+01,0.9827110684,2.8612869e+01,-2.6011235e+01,
		0.9897039383,4.6206407e+01,-4.3423628e+01,0.9942778582,8.0321519e+01,-7.7343529e+01,
		0.9972854418,1.8539153e+02,-1.8212833e+02,0.9992535423,7.5807932e+02,-7.5438862e+02,
		0.9998994392,6.2036755e+03,-6.1994372e+03,0.9999952427,2.5459531e+05,-2.5458989e+05
	};
	// Find the greatest y[i]<x, then return x*m[i]+b[i].
	f64 x=rtrandf();
	const f64* xmb=xmbarr+48;
	xmb+=x<*xmb?-24:24;
	xmb+=x<*xmb?-12:12;
	xmb+=x<*xmb?-6:6;
	xmb+=x<*xmb?-3:3;
	xmb+=x<*xmb?-3:0;
	return x*xmb[1]+xmb[2];
}

//---------------------------------------------------------------------------------
// Python Setup
//---------------------------------------------------------------------------------
// "self" refers to the module.
// "args" contains all the arguments passed to the python function.
//
// In the python documentation, if an object it a new reference, we need to call
// decref. If an object is a borrowed reference, do nothing.

// https://docs.python.org/3/c-api/object.html
// https://docs.python.org/3/c-api/float.html
// https://docs.python.org/3/c-api/list.html

static PyObject* render(PyObject* self,PyObject* args);

static PyMethodDef methoddefs[]=
{
	{"render",render,METH_VARARGS,"N/A"},
	{NULL,NULL,0,NULL}
};

static struct PyModuleDef moduledef=
{
	PyModuleDef_HEAD_INIT,
	"RayTracer_C_Ext",
	"RayTracer C extensions",
	-1,
	methoddefs,
	NULL,
	NULL,
	NULL,
	NULL
};

PyMODINIT_FUNC PyInit_RayTracer_C_Ext(void)
{
	return PyModule_Create(&moduledef);
}

f32 pygetf32(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	f32 x=PyFloat_AsDouble(elem);
	Py_DECREF(elem);
	return x;
}

s32 pygets32(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	s32 x=PyLong_AsLong(elem);
	Py_DECREF(elem);
	return x;
}

PyObject* pygetobj(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	rtassert(elem->ob_refcnt>1);
	Py_DECREF(elem);
	return elem;
}

struct rtpymaplink_t
{
	rtpymaplink* next;
	PyObject* pyobj;
	void* rtobj;
	u32 type;
};

rtpymaplink** rtpymap=0;
const u32 rtpymaplen=1<<24;

u32 rtpymaphash(PyObject* pyobj)
{
	u64 hash=*((u64*)&pyobj);
	hash=(hash>>31)|(hash<<33);
	hash^=hash>>34;
	hash*=0x77289737111f5371ULL;
	hash=(hash>>42)|(hash<<22);
	hash^=hash>>12;
	hash*=0x2cd3001685ece1f9ULL;
	hash=(hash>>55)|(hash<<9);
	hash^=hash>>20;
	hash*=0xc80b46d2e9ec9f8dULL;
	hash=(hash>>32)|(hash<<32);
	return hash%rtpymaplen;
}

void* rtpymapget(PyObject* pyobj)
{
	if (rtpymap==0) {return 0;}
	u32 hash=rtpymaphash(pyobj);
	rtpymaplink* link=rtpymap[hash];
	while (link && link->pyobj!=pyobj) {link=link->next;}
	if (link) {return link->rtobj;}
	return 0;
}

rtpymaplink* rtpymapadd(PyObject* pyobj,void* rtobj,u32 type)
{
	rtassert(pyobj!=0 && rtobj!=0);
	if (rtpymap==0)
	{
		rtpymap=rtalloc(sizeof(rtpymaplink*)*rtpymaplen);
		for (u32 i=0;i<rtpymaplen;i++) {rtpymap[i]=0;}
	}
	u32 hash=rtpymaphash(pyobj);
	rtpymaplink** root=rtpymap+hash;
	rtpymaplink* link=rtalloc(sizeof(rtpymaplink));
	link->next=*root;
	link->pyobj=pyobj;
	link->rtobj=rtobj;
	link->type=type;
	*root=link;
	return link;
}

void rtpymapfree(void)
{
	// Free objects in reverse order, so their free calls can mark objects that the
	// map doesn't need to free.
	for (s32 order=7;order>-1;order--)
	{
		for (u32 i=0;i<rtpymaplen;i++)
		{
			rtpymaplink* link=rtpymap[i];
			while (link)
			{
				rtpymaplink* next=link->next;
				s32 type=link->type;
				if (type==order)
				{
					void* obj=link->rtobj;
					if (type==RT_TYPE_MATL ) {rtmatlfree(obj);}
					// if (type==RT_TYPE_VERT ) {rtvertfree(obj);}
					// if (type==RT_TYPE_FACE ) {rtfacefree(obj);}
					// if (type==RT_TYPE_INST ) {rtinstfree(obj);}
					// if (type==RT_TYPE_BVH  ) {rtbvhfree(obj);}
					if (type==RT_TYPE_MESH ) {rtmeshfree(obj);}
					if (type==RT_TYPE_SCENE) {rtscenefree(obj);}
				}
				if (order==0) {rtfree(link);}
				link=next;
			}
		}
	}
	rtfree(rtpymap);
	rtpymap=0;
}

void rtpymapnofree(rtpymaplink* link)
{
	if (link) {link->type=RT_TYPE_NONE;}
}

//---------------------------------------------------------------------------------
// Algebra
//---------------------------------------------------------------------------------
// Helper classes for matrix/vector linear algebra.

void rtvecloadpy(rtvec* vec,PyObject* pyvec)
{
	PyObject* pyelem=pygetobj(pyvec,"elem");
	for (int i=0;i<DIM;i++)
	{
		PyObject* obj=PyList_GetItem(pyelem,i);
		vec->elem[i]=PyFloat_AsDouble(obj);
	}
}

void rtvecloadpyname(rtvec* vec,PyObject* pyobj,const char* name)
{
	rtvecloadpy(vec,pygetobj(pyobj,name));
}

rtvec* rtvecset(rtvec* u,rtvec* v)
{
	for (u32 i=0;i<DIM;i++) {u->elem[i]=v->elem[i];}
	return u;
}

rtvec* rtveczero(rtvec* u)
{
	for (u32 i=0;i<DIM;i++) {u->elem[i]=0.0;}
	return u;
}

rtvec* rtvecadd(rtvec* r,rtvec* u,rtvec* v)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]+v->elem[i];}
	return r;
}

rtvec* rtvecaddmul(rtvec* r,rtvec* u,rtvec* v,f32 mul)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]+v->elem[i]*mul;}
	return r;
}

rtvec* rtvecsub(rtvec* r,rtvec* u,rtvec* v)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]-v->elem[i];}
	return r;
}

rtvec* rtvecneg(rtvec* r,rtvec* u)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=-u->elem[i];}
	return r;
}

rtvec* rtvecscale(rtvec* r,rtvec* u,f32 scale)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]*scale;}
	return r;
}

f32 rtvecdot(rtvec* u,rtvec* v)
{
	f32 r=0.0;
	for (u32 i=0;i<DIM;i++) {r+=u->elem[i]*v->elem[i];}
	return r;
}

f32 rtvecmag(rtvec* u)
{
	f32 r=0.0;
	for (u32 i=0;i<DIM;i++) {r+=u->elem[i]*u->elem[i];}
	return sqrt(r);
}

rtvec* rtvecrand(rtvec* r)
{
	f32 mag;
	do
	{
		mag=0.0;
		for (u32 i=0;i<DIM;i++)
		{
			f32 x=rtrandn();
			r->elem[i]=x;
			mag+=x*x;
		}
	}
	while(mag<=1e-20);
	mag=1.0/sqrt(mag);
	for (u32 i=0;i<DIM;i++) {r->elem[i]*=mag;}
	return r;
}

rtvec* rtvecnorm(rtvec* r,rtvec* u)
{
	f32 mag=rtvecmag(u);
	if (mag<=1e-20) {rtvecrand(r);}
	else {rtvecscale(r,u,1.0/mag);}
	return r;
}

void rtmatloadpy(rtmat* mat,PyObject* pymat)
{
	PyObject* pyelem=pygetobj(pymat,"elem");
	for (int i=0;i<DIM*DIM;i++)
	{
		PyObject* obj=PyList_GetItem(pyelem,i);
		mat->elem[i]=PyFloat_AsDouble(obj);
	}
}

void rtmatloadpyname(rtmat* mat,PyObject* pyobj,const char* name)
{
	rtmatloadpy(mat,pygetobj(pyobj,name));
}

rtvec* rtvecmatmul(rtvec* r,rtmat* mat,rtvec* u)
{
	f32 tmp[DIM];
	f32* me=mat->elem;
	for (u32 i=0;i<DIM;i++)
	{
		f32 s=0.0;
		for (u32 j=0;j<DIM;j++) {s+=(*me++)*u->elem[j];}
		tmp[i]=s;
	}
	memcpy(r->elem,tmp,sizeof(f32)*DIM);
	return r;
}

//---------------------------------------------------------------------------------
// Rays
//---------------------------------------------------------------------------------

void rtrayprecalc(rtray* ray)
{
	ray->min=1e-10;
	ray->face=0;
	ray->facemat=0;
	// For AABB collision detection.
	f32* dir=ray->dir.elem;
	f32* inv=ray->inv;
	for (u32 i=0;i<DIM;i++)
	{
		f32 d=dir[i];
		if (fabs(d)>1e-20) {inv[i]=1.0/d;}
		else {inv[i]=1.0/0.0;}
	}
}

//---------------------------------------------------------------------------------
// Materials
//---------------------------------------------------------------------------------

rtmaterial* rtmatlcreate(void)
{
	rtmaterial* mat=rtalloc(sizeof(rtmaterial));
	memset(mat,0,sizeof(rtmaterial));
	return mat;
}

void rtmatlfree(rtmaterial* mat)
{
	rtfree(mat);
}

void rtmatlloadpy(rtmaterial* mat,PyObject* pymat)
{
	mat->pymap=rtpymapadd(pymat,mat,RT_TYPE_MATL);
	PyObject* pycolor=pygetobj(pymat,"color");
	for (u32 i=0;i<3;i++)
	{
		PyObject* obj=PyList_GetItem(pycolor,i);
		mat->color[i]=PyFloat_AsDouble(obj);
	}
	mat->luminosity=pygetf32(pymat,"luminosity");
	mat->reflectprob=pygetf32(pymat,"reflectprob");
	mat->diffusion=pygetf32(pymat,"diffusion");
	mat->refractprob=pygetf32(pymat,"refractprob");
	mat->refractindex=pygetf32(pymat,"refractindex");
	mat->scatterlen=pygetf32(pymat,"scatterlen");
	mat->absorbprob=pygetf32(pymat,"absorbprob");
}

//---------------------------------------------------------------------------------
// Faces
//---------------------------------------------------------------------------------

void rtvertloadpy(rtvert* vert,PyObject* pyvert)
{
	vert->pymap=rtpymapadd(pyvert,vert,RT_TYPE_VERT);
	rtvecloadpyname(&vert->pos,pyvert,"pos");
}

void rtfaceloadpy(rtface* face,PyObject* pyface)
{
	face->pymap=rtpymapadd(pyface,face,RT_TYPE_FACE);
	// load vertices
	PyObject* pyvertarr=pygetobj(pyface,"vertarr");
	for (u32 i=0;i<DIM;i++)
	{
		PyObject* pyvert=PyList_GetItem(pyvertarr,i);
		face->vert[i]=rtpymapget(pyvert);
		rtassert(face->vert[i]);
	}
	// load normal and barycentric vectors
	rtvecloadpyname(&face->norm,pyface,"norm");
	PyObject* pybaryarr=pygetobj(pyface,"bary");
	for (u32 i=0;i<DIM-1;i++)
	{
		PyObject* pybary=PyList_GetItem(pybaryarr,i);
		rtvecloadpy(&face->bary[i],pybary);
	}
	// load material
	PyObject* pymat=pygetobj(pyface,"mat");
	face->mat=rtpymapget(pymat);
	if (face->mat==0 && PyObject_IsTrue(pymat)==1)
	{
		face->mat=rtmatlcreate();
		rtmatlloadpy(face->mat,pymat);
	}
}

void rtfaceintersect(rtface* face,rtray* ray)
{
	// Return the distance from the ray origin to the face. Return false if the ray
	// misses.
	// First, project the ray onto the face's plane. We have (pos+u*dir)*norm=v0*norm,
	// thus u=-(pos-v0)*norm/(dir*norm).
	f32 den=rtvecdot(&ray->dir,&face->norm);
	if (fabs(den)<=1e-20) {return;}
	rtvec p;
	rtvecsub(&p,&ray->pos,&face->vert[0]->pos);
	f32 dist=-rtvecdot(&p,&face->norm)/den;
	if (dist<ray->min || dist>=ray->max) {return;}
	rtvecaddmul(&p,&p,&ray->dir,dist);
	// Make sure the barycentric coordinates of the point are within the face.
	f32 s=0.0;
	for (u32 i=0;i<DIM-1;i++)
	{
		f32 u=rtvecdot(face->bary+i,&p);
		s+=u;
		if (u<0.0 || s>1.0) {return;}
	}
	ray->max=dist;
	ray->face=face;
	rtvecset(&ray->facenorm,&face->norm);
	ray->facemat=face->mat;
}

//---------------------------------------------------------------------------------
// Mesh Instances
//---------------------------------------------------------------------------------

void rtinstloadpy(rtinst* inst,PyObject* pyinst)
{
	inst->pymap=rtpymapadd(pyinst,inst,RT_TYPE_INST);
	// Find the target mesh. If it's not found, load it.
	PyObject* pymesh=pygetobj(pyinst,"mesh");
	inst->mesh=rtpymapget(pymesh);
	if (inst->mesh==0)
	{
		inst->mesh=rtmeshcreate();
		rtmeshloadpy(inst->mesh,pymesh);
	}
	// load any custom materials
	PyObject* pymatl=pygetobj(pyinst,"mat");
	inst->matl=rtpymapget(pymatl);
	if (inst->matl==0)
	{
		inst->matl=rtmatlcreate();
		rtmatlloadpy(inst->matl,pymatl);
	}
	// load the forward transform
	PyObject* pytrans=pygetobj(pyinst,"transform");
	rtmatloadpyname(&inst->transmat,pytrans,"mat");
	rtvecloadpyname(&inst->transoff,pytrans,"off");
	// load the inverse transform
	PyObject* pyinv=pygetobj(pyinst,"inv");
	rtmatloadpyname(&inst->invmat,pyinv,"mat");
	rtvecloadpyname(&inst->invoff,pyinv,"off");
}

void rtinstintersect(rtinst* inst,rtray* ray)
{
	// Apply the inverse instance transform to put the ray in the mesh's local space.
	// Don't normalize the direction here or distance metrics will be thrown off.
	rtray nray;
	rtvecmatmul(&nray.pos,&inst->invmat,&ray->pos);
	rtvecadd(&nray.pos,&nray.pos,&inst->invoff);
	rtvecmatmul(&nray.dir,&inst->invmat,&ray->dir);
	nray.max=ray->max;
	rtbvhraypick(inst->mesh->bvhroot,&nray);
	if (nray.face)
	{
		ray->max=nray.max;
		ray->face=nray.face;
		ray->facemat=nray.facemat;
		rtvecmatmul(&ray->facenorm,&inst->transmat,&nray.facenorm);
		rtvecnorm(&ray->facenorm,&ray->facenorm);
		if (inst->matl) {ray->facemat=inst->matl;}
	}
}

//---------------------------------------------------------------------------------
// Meshes
//---------------------------------------------------------------------------------

rtmesh* rtmeshcreate(void)
{
	rtmesh* mesh=rtalloc(sizeof(rtmesh));
	mesh->pymap=0;
	mesh->verts=0;
	mesh->vertarr=0;
	mesh->faces=0;
	mesh->facearr=0;
	mesh->insts=0;
	mesh->instarr=0;
	mesh->bvhnodes=0;
	mesh->bvhnodearr=0;
	mesh->bvhroot=0;
	return mesh;
}

void rtmeshfree(rtmesh* mesh)
{
	rtpymapnofree(mesh->pymap);
	rtfree(mesh->bvhnodearr);
	rtfree(mesh->instarr);
	rtfree(mesh->facearr);
	rtfree(mesh->vertarr);
	rtfree(mesh);
}

void rtmeshloadpy(rtmesh* mesh,PyObject* pymesh)
{
	// add to map
	mesh->pymap=rtpymapadd(pymesh,mesh,RT_TYPE_MESH);
	// load vertices
	mesh->verts=pygets32(pymesh,"verts");
	printf("verts: %d\n",mesh->verts);
	mesh->vertarr=rtalloc(sizeof(rtvert)*mesh->verts);
	PyObject* pyvertarr=pygetobj(pymesh,"vertarr");
	for (s32 i=0;i<mesh->verts;i++)
	{
		rtvert* vert=mesh->vertarr+i;
		PyObject* pyvert=PyList_GetItem(pyvertarr,i);
		rtvertloadpy(vert,pyvert);
	}
	// load all faces
	//      err if vert not found
	//      load material if not in map
	mesh->faces=pygets32(pymesh,"faces");
	printf("faces: %d\n",mesh->faces);
	mesh->facearr=rtalloc(sizeof(rtface)*mesh->faces);
	PyObject* pyfacearr=pygetobj(pymesh,"facearr");
	for (s32 i=0;i<mesh->faces;i++)
	{
		rtface* face=mesh->facearr+i;
		PyObject* pyface=PyList_GetItem(pyfacearr,i);
		rtfaceloadpy(face,pyface);
	}
	// load all insts
	//      load mesh if not in map
	mesh->insts=pygets32(pymesh,"insts");
	printf("insts: %d\n",mesh->insts);
	mesh->instarr=rtalloc(sizeof(rtinst)*mesh->insts);
	PyObject* pyinstarr=pygetobj(pymesh,"instarr");
	for (s32 i=0;i<mesh->insts;i++)
	{
		rtinst* inst=mesh->instarr+i;
		PyObject* pyinst=PyList_GetItem(pyinstarr,i);
		rtinstloadpy(inst,pyinst);
	}
	// load bvh
	//      use python to determine type
	PyObject_CallMethod(pymesh,"buildbvh",NULL);
	PyObject* pybvh=pygetobj(pymesh,"bvh");
	mesh->bvhnodes=pygets32(pybvh,"nodes");
	mesh->bvhnodearr=rtbvhloadpyarr(pybvh,mesh->bvhnodes);
	mesh->bvhroot=rtpymapget(pygetobj(pybvh,"root"));
}

//---------------------------------------------------------------------------------
// BVH
//---------------------------------------------------------------------------------

#define RT_BVH_DIVIDE 0
#define RT_BVH_FACE   1
#define RT_BVH_INST   2

void rtbvhnodeloadpy(rtbvhnode* node,PyObject* pynode)
{
	// load parent/child links for later mapping
	node->pymap=rtpymapadd(pynode,node,RT_TYPE_BVH);
	node->parent=(rtbvhnode*)pygetobj(pynode,"parent");
	node->left=(void*)pygetobj(pynode,"left");
	node->right=(void*)pygetobj(pynode,"right");
	rtvecloadpyname(&node->bbmin,pynode,"bbmin");
	rtvecloadpyname(&node->bbmax,pynode,"bbmax");
	node->type=pygets32(pynode,"type");
	node->axis=pygets32(pynode,"axis");
	node->testray=pygets32(pynode,"testray");
}

rtbvhnode* rtbvhloadpyarr(PyObject* pybvh,s32 nodes)
{
	rtbvhnode* nodearr=rtalloc(sizeof(rtbvhnode)*nodes);
	PyObject* pybvhnodearr=pygetobj(pybvh,"nodearr");
	for (s32 i=0;i<nodes;i++)
	{
		PyObject* pybvhnode=PyList_GetItem(pybvhnodearr,i);
		rtbvhnodeloadpy(nodearr+i,pybvhnode);
	}
	for (s32 i=0;i<nodes;i++)
	{
		rtbvhnode* node=nodearr+i;
		node->parent=rtpymapget((PyObject*)node->parent);
		node->left=rtpymapget((PyObject*)node->left);
		node->right=rtpymapget((PyObject*)node->right);
	}
	return nodearr;
}

u32 rtbvhnodeintersect(rtbvhnode* node,rtray* ray)
{
	// Project the box onto the ray. The intersection of all projections will give us
	// the range of u where the ray intersects the box. If the intersection of all the
	// ranges is null, then the ray misses the box.
	//
	//             b3
	//              '. b2
	//              . '.              ray=pos+u*dir
	//              .  .'.            ranges: [b0,b1] [b2,b3]
	//              .  .  '.
	//      +----------+. . '.b1
	//      |          |      '.
	//      |          |        '.
	//      |          |          '.
	//      |          |            '.
	//      +----------+. . . . . . . '.b0
	//
	// Want pos[i]+u*dir[i]=box[i], thus u=(box[i]-pos[i])/dir[i].
	// We spend almost half of our time in this function, so optimize it.
	f32 *raypos=ray->pos.elem,*rayinv=ray->inv;
	f32 *bbmin=node->bbmin.elem,*bbmax=node->bbmax.elem;
	f32 u0=ray->min,u1=ray->max;
	for (u32 i=0;i<DIM;i++)
	{
		f32 p=raypos[i],d=rayinv[i];
		f32 b0=(bbmin[i]-p)*d;
		f32 b1=(bbmax[i]-p)*d;
		if (d<0) {d=b0;b0=b1;b1=d;}
		u0=u0<b0?b0:u0;
		u1=u1>b1?b1:u1;
		if (u0>u1) {return 0;}
	}
	return 1;
}

void rtbvhraypick(rtbvhnode* root,rtray* ray)
{
	// Finds the nearest surface that the ray intersects. Surface information is
	// returned in the ray object.
	rtbvhnode *node=0,*next=root;
	rtrayprecalc(ray);
	f32* raydir=ray->dir.elem;
	while (next!=0)
	{
		rtbvhnode* prev=node;
		node=next;
		next=node->parent;
		u32 down=prev==next;
		s32 type=node->type;
		// Check if we're intersecting the current node.
		if (down && node->testray && rtbvhnodeintersect(node,ray)==0) {continue;}
		void *nl=node->left,*nr=node->right,*tmp;
		if (type==RT_BVH_DIVIDE)
		{
			// This is a dividing node. Determine which child to visit first using the dividing
			// axis and sign of the ray. Note that a better heuristic won't greatly help here.
			if (raydir[node->axis]<0) {tmp=nl;nl=nr;nr=tmp;}
			if (down) {next=nl;}
			else if (prev==nl) {next=nr;}
		}
		else if (type==RT_BVH_FACE)
		{
			// We are intersecting a mesh face.
			rtfaceintersect(nl,ray);
		}
		else if (type==RT_BVH_INST)
		{
			// We are intersecting a mesh instance.
			rtinstintersect(nl,ray);
		}
	}
}

//---------------------------------------------------------------------------------
// Scene
//---------------------------------------------------------------------------------

rtscene* rtscenecreate(s32 dim,s32 imgwidth,s32 imgheight)
{
	rtassert(dim==DIM);
	rtscene* scene=rtalloc(sizeof(rtscene));
	memset(scene,0,sizeof(rtscene));
	scene->pymap=0;
	scene->raysperpixel=128;
	scene->maxbounces=16;
	scene->dim=dim;
	scene->imgwidth=imgwidth;
	scene->imgheight=imgheight;
	scene->imgpixels=imgwidth*imgheight;
	u32 size=imgwidth*imgheight*3*sizeof(f32);
	scene->imgrgb=rtalloc(size);
	memset(scene->imgrgb,0,size);
	scene->mesh=rtmeshcreate();
	return scene;
}

void rtscenefree(rtscene* scene)
{
	rtpymapnofree(scene->pymap);
	rtmeshfree(scene->mesh);
	rtfree(scene->imgrgb);
	rtfree(scene);
}

void rtsceneloadpy(rtscene* scene,PyObject* pyscene)
{
	scene->pymap=rtpymapadd(pyscene,scene,RT_TYPE_SCENE);
	s32 imgwidth=pygets32(pyscene,"imgwidth");
	s32 imgheight=pygets32(pyscene,"imgheight");
	scene->raysperpixel=pygets32(pyscene,"raysperpixel");
	scene->maxbounces=pygets32(pyscene,"maxbounces");
	scene->dim=pygets32(pyscene,"dim");
	rtassert(scene->dim==DIM);
	scene->imgwidth=imgwidth;
	scene->imgheight=imgheight;
	scene->imgpixels=imgwidth*imgheight;
	u32 size=imgwidth*imgheight*3*sizeof(f32);
	rtfree(scene->imgrgb);
	scene->imgrgb=rtalloc(size);
	memset(scene->imgrgb,0,size);
	rtvecloadpyname(&scene->campos,pyscene,"campos");
	rtvecloadpyname(&scene->cambl ,pyscene,"cambl");
	rtvecloadpyname(&scene->camu  ,pyscene,"camu");
	rtvecloadpyname(&scene->camv  ,pyscene,"camv");
	rtmeshloadpy(scene->mesh,pygetobj(pyscene,"mesh"));
}

void rtsceneraytrace(rtscene* scene,rtray* ray,f32* rgb)
{
	// Shoot a ray into the scene, and follow it as it bounces around. Track what
	// material we're inside of for ambient properties of the medium.
	// Situations to consider:
	//      Coplanar faces will be fairly common.
	//      Rays may start inside a mesh.
	//      Inside-out geometry will define an infinitely large space.
	rtvec stmp;
	rtvec* tmpvec=&stmp;
	rtmaterial* ambient=0;
	f32 col[3]={1.0,1.0,1.0};
	f32 ret[3]={0.0,0.0,0.0};
	rtvec* pos=&ray->pos;
	rtvec* dir=&ray->dir;
	f32 inf=1.0/0.0;
	for (s32 bounce=scene->maxbounces;bounce>0;bounce--)
	{
		// Find the closest face the ray collides with. If we can't find one, or the ray
		// gets absorbed, abort.
		ray->max=inf;
		rtbvhraypick(scene->mesh->bvhroot,ray);
		f32 dist=ray->max;
		rtvec* norm=&ray->facenorm;
		rtmaterial* mat=ray->facemat;
		if (mat==0) {mat=ambient;}
		if (mat==0) {break;}
		if (rtrandf()<mat->absorbprob) {break;}
		f32 cosi=norm==0?0.0:rtvecdot(dir,norm);
		s32 inside=cosi>0.0;
		if (bounce==inside) {break;}
		if (inside) {ambient=mat;}
		// Perform scattering before interacting with the face. Use the Beer-Lambert
		// scattering law to limit scattering length.
		u32 scatter=0;
		if (ambient && ambient->scatterlen<inf)
		{
			f32 scatterlen=-log(rtrandf())*ambient->scatterlen;
			if (dist>scatterlen) {dist=scatterlen;scatter=1;}
		}
		// If we didn't hit anything or scatter, we escape into the void.
		if (dist>=inf) {break;}
		rtvecaddmul(pos,pos,dir,dist);
		// If we're performing subsurface scattering, randomly bounce around.
		if (scatter)
		{
			rtvecrand(dir);
			continue;
		}
		f32 ior=mat->refractindex;
		if (inside)
		{
			// We're inside and pointing out.
			rtvecneg(norm,norm);
		}
		else
		{
			// We're outside and pointing in.
			cosi=-cosi;
			ior=1.0/ior;
			f32* matcol=mat->color;
			f32 matlum=mat->luminosity;
			for (u32 i=0;i<3;i++)
			{
				col[i]*=matcol[i];
				ret[i]+=matlum*col[i];
			}
		}
		/*f32 refractprob=0.0;,cost;
		if (rtrandf()<mat->refractprob)
		{
			//Perform refraction and determine if we have total internal reflection.
			f32 disc=1.0-ior*ior*(1.0-cosi*cosi);
			if (disc>0.0)
			{
				cost=sqrt(disc);
				//Fresnel reflectance equations.
				f32 a=ior*cost;
				f32 rs=(cosi-a)/(cosi+a);
				a=ior*cosi;
				f32 rp=(a-cost)/(a+cost);
				refractprob=1.0-(rs*rs+rp*rp)*0.5;
			}
		}
		if (rtrandf()<refractprob)
		{
			//Refraction.
			rtvecscale(dir,dir,ior);
			rtvecaddmul(dir,dir,norm,ior*cosi-cost);
			ambient=inside?0:mat;
		}
		else */if (1)// rtrandf()<mat->reflectprob)
		{
			// Lambertian scattering.
			if (mat->diffusion<0.2)
			{
				rtvec cen;
				cen.elem[0]=250;
				cen.elem[1]=280;
				cen.elem[2]=-370;
				rtvecsub(&cen,pos,&cen);
				rtvecnorm(norm,&cen);
				cosi=-rtvecdot(norm,dir);
			}
			rtvecrand(tmpvec);
			if (rtvecdot(tmpvec,norm)<0.0) {rtvecneg(tmpvec,tmpvec);}
			rtvecaddmul(dir,dir,norm,2.0*cosi);
			// rtvecsub(tmpvec,tmpvec,dir);
			// rtvecaddmul(dir,dir,tmpvec,mat->diffusion);
		}
		rtvecnorm(dir,dir);
	}
	for (u32 i=0;i<3;i++) {rgb[i]+=ret[i];}
}

void rtscenerender(rtscene* scene)
{
	u32 rpp=scene->raysperpixel;
	f32 norm=1.0/rpp;
	rtvec* campos=&scene->campos;
	rtvec* cambl=&scene->cambl;
	rtvec* camu=&scene->camu;
	rtvec* camv=&scene->camv;
	s32 imgwidth=scene->imgwidth;
	s32 pixels=scene->imgpixels;
	// #pragma omp parallel for
	s32 minx=10000,maxx=0;
	s32 miny=10000,maxy=0;
	for (s32 i=0;i<pixels;i++)
	{
		s32 x=i%imgwidth;
		s32 y=i/imgwidth;
		f32* rgb=scene->imgrgb+i*3;
		memset(rgb,0,3*sizeof(f32));
		// if (x<90 || x>190 || y<100 || y>190) {continue;}
		if (x<403 || x>711 || y<434 || y>743) {continue;}
		// for (u32 j=0;j<3;j++) {rgb[j]=1.0;}
		// continue;
		// Print progress every pixel.
		printf("\rprogress: %.2f%%",i*100.0/pixels);
		fflush(stdout);
		rtray ray;
		rtvec *raypos=&ray.pos,*raydir=&ray.dir;
		for (u32 r=0;r<rpp;r++)
		{
			f32 u=x+rtrandf(),v=y+rtrandf();
			rtvecset(raypos,campos);
			rtvecset(raydir,cambl);
			rtvecaddmul(raydir,raydir,camu,u);
			rtvecaddmul(raydir,raydir,camv,v);
			rtvecnorm(raydir,raydir);
			rtsceneraytrace(scene,&ray,rgb);
		}
		u32 color=0;
		for (u32 j=0;j<3;j++) {rgb[j]*=norm;color|=rgb[j]>0.001;}
		if (color)
		{
			minx=minx<x?minx:x;
			maxx=maxx>x?maxx:x;
			miny=miny<y?miny:y;
			maxy=maxy>y?maxy:y;
		}
	}
	printf("x: %d, %d\n",minx,maxx);
	printf("y: %d, %d\n",miny,maxy);
	printf("\n");
}

static PyObject* render(PyObject* self,PyObject* args)
{
	// Load and render scene.
	PyObject* pyscene;
	PyArg_ParseTuple(args,"O",&pyscene);
	rtscene* scene=rtscenecreate(DIM,0,0);
	rtsceneloadpy(scene,pyscene);
	rtscenerender(scene);
	// Transfer pixels to python.
	PyObject* pyrgb=pygetobj(pyscene,"imgrgb");
	u32 rgb=scene->imgwidth*scene->imgheight*3;
	for (u32 i=0;i<rgb;i++)
	{
		PyObject* obj=PyFloat_FromDouble(scene->imgrgb[i]);
		PyList_SetItem(pyrgb,i,obj);
	}
	// Clean up.
	// rtscenefree(scene);
	rtpymapfree();
	printf("mem: %lld\n",rt_alloc_count);
	Py_RETURN_NONE;
}


# Prereqs
# Linux:
#      sudo apt-get install python3-dev python3-pip python3-setuptools
# Windows:
#      MSVC CRT SDK, C++ Core Features, python language support, universal C
#      runtime, C++ 20XX build tools
#
# To install:
#      python3 setup.py build;python3 -m pip install .

from distutils.core import setup,Extension
from distutils.command.build_ext import build_ext

class build_ext_subclass(build_ext):
	def build_extensions(self):
		t=self.compiler.compiler_type
		if t in copt:
			for e in self.extensions:
				e.extra_compile_args=copt[t]
		if t in lopt:
			for e in self.extensions:
				e.extra_link_args=lopt[t]
		build_ext.build_extensions(self)

modules=[Extension(
	name="RayTracer_C_Ext",
	sources=["RayTracer_C_Ext.c"]
)]
copt={
	"unix":["-fopenmp","-O3","-std=c11","-funroll-loops","-march=native"],
	"msvc":["/openmp","/O2","/fp:fast"]
}
lopt={
	"unix":["-lgomp"]
}

setup(
	name="RayTracer_C_Ext",
	version="1.0",
	ext_modules=modules,
	cmdclass={"build_ext":build_ext_subclass}
)

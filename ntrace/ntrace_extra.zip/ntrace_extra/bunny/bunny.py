"""
bunny.py - v1.01

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com
"""

import sys,time
from NTrace import *

# Setup the C raytracer and overload the default python render function.
# import RayTracer_C_Ext
# Scene.render=lambda self,prog=0: RayTracer_C_Ext.render(self,prog)

if __name__=="__main__":
	start=time.time()
	path="bunny3d.bmp"
	hpi=math.pi*0.5
	sc=Scene(3,600,600)
	sc.raysperpixel=1<<16
	sc.setcamera((278,273,800),(0,0,0),37.5)
	lightmat=MeshMaterial((1.0,1.0,1.0),25.0)
	wallmat =MeshMaterial((0.9,0.9,0.9))
	rightmat=MeshMaterial((0.2,0.9,0.2))
	leftmat =MeshMaterial((0.9,0.2,0.2))
	matarr=[
		MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0),
		MeshMaterial((0.4,0.4,0.9),0.0,0.0,0.0,1.0,1.0,5.0),
		MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0,1.0,1.5),
		MeshMaterial((0.2,0.2,0.9),0.0,1.0,0.6,0.0,0.0),
		MeshMaterial((0.2,0.9,0.2)),
		MeshMaterial((1.0,0.2,0.2),2.0),
		MeshMaterial((0.9,0.9,0.9)),
	]
	sc.addcube((130,0.2,105),lightmat,Transform((278,548.7,-279.5)))
	sc.addcube((556,559.2),wallmat,Transform((278,0,-279.6),(0,0,hpi)))
	sc.addcube((556,559.2),wallmat,Transform((278,548.8,-279.6),(0,0,-hpi)))
	sc.addcube((556,-548.8),wallmat,Transform((278,274.4,-559.2)))
	sc.addcube((559.2,548.8),leftmat,Transform((0,274.4,-279.6),(0,hpi,0)))
	sc.addcube((559.2,548.8),rightmat,Transform((556,274.4,-279.6),(0,-hpi,0)))
	bun=Mesh("stanford_bunny.obj")
	bun.buildbvh()
	bunmin=bun.bvh.root.bbmin
	scale=350.0
	for i in range(36):
		mat=matarr[i%len(matarr)]
		x=(i%6+0.5)/6.0
		y=(i//6+1.0)/7.0
		pos=[x*556,-bunmin[1]*scale,-y*559]
		angs=[0,-hpi*0.3,0]
		sc.addmesh(bun,mat,Transform(pos,angs,scale))
	sc.addmesh(bun,matarr[1],Transform((160,240,-279.5),scale=1000))
	sc.addmesh(bun,matarr[2],Transform((400,240,-279.5),scale=1000))
	print("rendering {0} objects".format(sc.mesh.faces+sc.mesh.insts))
	sc.render(True,True)
	print("saving image to "+path)
	sc.savebmp(path)
	print("time: {0:.6f}".format(time.time()-start))


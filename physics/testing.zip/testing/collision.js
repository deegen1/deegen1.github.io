/*------------------------------------------------------------------------------


collision.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


GJK
Dynamically find our way through the simplexes of the minkowski difference (A-B)
until we can't find a new vertex or we surround the origin.

Given N points, find the linear combination of weights closest to the origin.

If N<D+1, let D = -closest_point and add a new point.
If N=D+1, and w(i)>0, we're done. Otherwise, remove the lowest weight and retry.

EPA
	A vert id [D]
	B vert id [D]
	weights   [D]
	normal    [D]
	dist

only use mindist for resolver
also use to determine closest points if miss
get rid of vert sorting


*/
/* npx eslint collision.js -c ../../../standards/eslint.js */


import {Random,Data,Vector,Transform} from "../rigidbody/library.js";
import {Phy} from "../rigidbody/physics.js";


//---------------------------------------------------------------------------------
// Collision Detection
// Does not find minimum separating vector.


function CollisionOverlap(avertarr,atrans,bvertarr,btrans,norm) {
	norm=norm.norm();
	let amin=Infinity,amax=-Infinity;
	for (let v of avertarr) {
		let u=atrans.apply(v).mul(norm);
		amin=amin<u?amin:u;
		amax=amax>u?amax:u;
	}
	let bmin=Infinity,bmax=-Infinity;
	for (let v of bvertarr) {
		let u=btrans.apply(v).mul(norm);
		bmin=bmin<u?bmin:u;
		bmax=bmax>u?bmax:u;
	}
	//bmax-=amin;
	//amax-=bmin;
	//return amax>bmax?amax:bmax;
	amin-=bmax;
	bmin-=amax;
	return amin>bmin?amin:bmin;
}


function CollisionDetect1(world,_avertarr,atrans,_bvertarr,btrans) {
	// Randomly pick a separating vector.
	let dim=world.dim;
	let avertarr=[],bvertarr=[];
	for (let v of _avertarr) {avertarr.push(atrans.apply(v));}
	for (let v of _bvertarr) {bvertarr.push(btrans.apply(v));}
	let maxnorm=new Vector(dim);
	if (dim) {maxnorm[0]=1;}
	if (!avertarr.length || !bvertarr.length) {return [false,maxnorm];}
	let maxproj=-Infinity;
	let norm=new Vector(dim);
	let scale=1;
	let rnd=new Random(2);
	for (let test=0;test<1024;test++) {
		// Generate a new vector.
		for (let i=0;i<dim;i++) {
			norm[i]=maxnorm[i]+rnd.gets()*scale;
		}
		let mag=norm.sqr();
		if (mag<1e-10) {continue;}
		norm.imul(1/Math.sqrt(mag));
		// Get the projection of A and B.
		let amin=Infinity,amax=-Infinity;
		for (let v of avertarr) {
			let p=v.mul(norm);
			amin=amin<p?amin:p;
			amax=amax>p?amax:p;
		}
		let bmin=Infinity,bmax=-Infinity;
		for (let v of bvertarr) {
			let p=v.mul(norm);
			bmin=bmin<p?bmin:p;
			bmax=bmax>p?bmax:p;
		}
		// If we have a new best separation, record it.
		amin-=bmax;
		bmin-=amax;
		let proj=amin>bmin?amin:bmin;
		if (maxproj<proj) {
			maxproj=proj;
			let tmp=norm;
			norm=maxnorm;
			maxnorm=tmp;
			if (proj>0) {break;}
		}
		scale*=0.98;
	}
	return [(maxproj<0),maxnorm];
}


function CollisionDetect2(abody,bbody) {
	// GJK
	// Determines if bodies are colliding.
	// Uses constant memory based on dim.
	// Doesn't find minimum separating vector.
	// Inline everything for performance.
	let dim=abody.world.dim;
	let avertarr=abody.vertarr,bvertarr=bbody.vertarr;
	let averts=avertarr.length,bverts=bvertarr.length;
	let atrans=abody.trans,ainv=atrans.inv();
	let btrans=ainv.apply(bbody.trans);
	let dif=new Array((dim+1)*dim);
	let mat=new Array((dim+1)*dim);
	// Pick an initial direction. Any will work, but B.pos-A.pos works best.
	let normsum=0;
	for (let i=0;i<dim;i++) {
		let x=btrans.vec[i];
		dif[i]=x;
		normsum+=x*x;
	}
	if (normsum<1e-10 && dim) {dif[0]=1;}
	let vertarr=new Array((dim+1)*dim);
	let idarr=new Array(dim+1);
	let bvert=new Vector(dim);
	let verts=1,reject=-1,preject=0;
	let test=0,tests=(averts+bverts+1)*(averts+bverts+1);
	for (;test<tests;test++) {
		// Find new supports. Direction is stored in dif[0...dim].
		if (reject<0) {
			let max=-Infinity,min=Infinity;
			let norm=dif;
			let a=0,b=0;
			// Find max(A.verts*norm);
			for (let i=0;i<averts;i++) {
				let v=avertarr[i],p=0;
				for (let j=0;j<dim;j++) {p+=v[j]*norm[j];}
				if (max<p) {max=p;a=i;}
			}
			// bnorm=btrans.mat.trans()*norm
			let bnorm=bvert,bmat=btrans.mat,bvec=btrans.vec;
			for (let i=0;i<dim;i++) {
				let x=0;
				for (let j=0,k=i;j<dim;j++,k+=dim) {x+=bmat[k]*norm[j];}
				bnorm[i]=x;
			}
			// Find min(B.verts*bnorm)
			for (let i=0;i<bverts;i++) {
				let v=bvertarr[i],p=0;
				for (let j=0;j<dim;j++) {p+=v[j]*bnorm[j];}
				if (min>p) {min=p;b=i;}
			}
			// bvert=btrans.apply(bvertarr[b]);
			// min=bvert*norm
			let v=bvertarr[b];min=0;
			for (let i=0;i<dim;i++) {
				let x=bvec[i];
				for (let j=0,r=i*dim;j<dim;j++) {x+=bmat[r+j]*v[j];}
				bvert[i]=x;
				min+=norm[i]*x;
			}
			// If we have a separating vector.
			if (max<min) {verts=0;break;}
			let avert=avertarr[a];
			let d=preject*dim;
			for (let i=0;i<dim;i++) {vertarr[d+i]=avert[i]-bvert[i];}
			idarr[preject]=a*bverts+b;
		}
		// Find the closest point in a set of vertices to another point.
		// Use linear algebra to compute the barycenter coordinates of the set.
		// di = vi - v0
		// dP =  P - v0, put in row 0
		let vidx=dim,cols=0,v0=0;
		for (let i=0;i<verts;i++) {
			if (i===reject) {continue;}
			let r=i*dim;
			if (!cols++) {v0=r;continue;}
			for (let j=0;j<dim;j++) {dif[vidx++]=vertarr[r+j]-vertarr[v0+j];}
		}
		for (let j=0;j<dim;j++) {dif[j]=-vertarr[v0+j];}
		// Create matrix. Note the solution column is on the left for efficiency.
		// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
		// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
		let rows=cols-1,elems=rows*cols;
		for (let i=1;i<cols;i++) {
			let rvec=i*dim;vidx=0;
			for (let j=0;j<=i;j++) {
				let dot=0;
				for (let k=0;k<dim;k++) {
					dot-=dif[rvec+k]*dif[vidx++];
				}
				mat[(i-1)*cols+j]=dot;
				if (j) {mat[(j-1)*cols+i]=dot;}
			}
		}
		// Row reduce the matrix.
		// [ u3 | 0 0 1 ]
		// [ u2 | 0 1 0 ]
		// [ u1 | 1 0 0 ]
		for (let i=0;i<rows;i++) {
			// Find the largest element in column i.
			let row=i*cols,off=rows-i,last=row+off;
			let src=0,dst=last;
			let max=0;
			for (let r=last;r<elems;r+=cols) {
				let x=mat[r],a=x>0?x:-x;
				if (max<a) {max=a;src=r;}
			}
			// Normalize and move picked row.
			max=max>1e-20?1/mat[src]:0;
			while (dst>=row) {
				let a=mat[dst],b=mat[src];
				mat[src--]=a;
				mat[dst--]=b*max;
			}
			// Reduce other rows.
			for (let r=off;r<elems;r+=cols) {
				if (r===last) {continue;}
				dst=r;src=last;
				let mul=mat[dst];
				while (src>row) {
					mat[--dst]-=mul*mat[--src];
				}
			}
		}
		// The first column of mat holds the barycenter coordinates.
		if (verts<=dim) {preject=verts++;} else {preject=reject;}
		reject=-1;
		if (preject>=0) {
			// Find a new direction. Store in dif[0...dim].
			vidx=dim;
			for (let i=1;i<=rows;i++) {
				let u=mat[elems-i*cols];
				for (let j=0;j<dim;j++) {
					dif[j]-=u*dif[vidx++];
				}
			}
		} else {
			let u0=1,min=0;
			for (let i=rows;i>=0;i--) {
				let u=i?mat[elems-i*cols]:u0;
				if (min>u) {min=u;reject=i;}
				u0-=u;
			}
			if (reject<0) {break;}
		}
	}
	// Normalize pre-transform for stability.
	let norm=(new Vector(dif.slice(0,dim))).normalize();
	norm=ainv.mat.trans().mul(norm);
	return [(test<tests && verts>dim),norm];
}


function CollisionDetect3(abody,bbody) {
	// GJK
	// Determines if bodies are colliding.
	// Doesn't use constant memory.
	// Doesn't find minimum separating vector.
	// Inline everything for performance.
	let dim=abody.world.dim;
	let averts=abody.vertarr.length,bverts=bbody.vertarr.length;
	if (!dim) {return [(averts>0 && bverts>0),new Vector(0)];}
	let avertlen=averts*dim,bvertlen=bverts*dim;
	// Pretransform the vertices. Flatten arrays to [x0,y0,z0,x1,y1,z1,...].
	let avertarr=null,bvertarr=null;
	for (let side=0;side<2;side++) {
		let body=[abody,bbody][side];
		let srcarr=body.vertarr;
		let verts=srcarr.length;
		let dstarr=new Array(verts*dim);
		let mat=body.trans.mat,vec=body.trans.vec;
		// mat*v+vec
		for (let s=0,d=0;s<verts;s++) {
			let v=srcarr[s];
			for (let i=0,m=0;i<dim;i++) {
				let x=vec[i];
				for (let j=0;j<dim;j++) {x+=mat[m++]*v[j];}
				dstarr[d++]=x;
			}
		}
		if (side) {bvertarr=dstarr;} else {avertarr=dstarr;}
	}
	let dif=new Array((dim+1)*dim);
	let mat=new Array((dim+1)*dim);
	// Pick an initial direction. Any will work, but B.pos-A.pos works best.
	let normsum=0;
	for (let i=0;i<dim;i++) {
		let x=bbody.trans.vec[i]-abody.trans.vec[i];
		dif[i]=x;
		normsum+=x*x;
	}
	if (normsum<1e-10) {dif[0]=1;}
	let vertarr=new Array((dim+1)*dim);
	let idarr=new Array(dim+1);
	vertarr.fill(0);
	let verts=1,reject=-1,preject=0;
	let test=0,tests=(averts+bverts+1)*(averts+bverts+1);
	for (;test<tests;test++) {
		// Find new supports. Direction is stored in dif[0...dim].
		if (reject<0) {
			let max=-Infinity,min=Infinity;
			let norm=dif;
			let a=0,b=0;
			// Find max(A.verts*norm);
			for (let i=0;i<avertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=avertarr[i+j]*norm[j];}
				if (max<p) {max=p;a=i;}
			}
			// Find min(B.verts*bnorm)
			for (let i=0;i<bvertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=bvertarr[i+j]*norm[j];}
				if (min>p) {min=p;b=i;}
			}
			// If we have a separating vector.
			if (max<min) {test=tests;break;}
			let d=preject*dim;
			for (let i=0;i<dim;i++) {vertarr[d+i]=avertarr[a+i]-bvertarr[b+i];}
			idarr[preject]=a*bvertlen+b;
		}
		// Find the closest point in a set of vertices to another point.
		// Use linear algebra to compute the barycenter coordinates of the set.
		// di = vi - v0
		// dP =  P - v0, put in row 0
		let vidx=dim,cols=0,v0=0;
		for (let i=0;i<verts;i++) {
			if (i===reject) {continue;}
			let r=i*dim;
			if (!cols++) {v0=r;continue;}
			for (let j=0;j<dim;j++) {dif[vidx++]=vertarr[r+j]-vertarr[v0+j];}
		}
		for (let j=0;j<dim;j++) {dif[j]=-vertarr[v0+j];}
		// Create matrix. Note the solution column is on the left for efficiency.
		// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
		// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
		let rows=cols-1,elems=rows*cols;
		for (let i=1;i<cols;i++) {
			let rvec=i*dim;vidx=0;
			for (let j=0;j<=i;j++) {
				let dot=0;
				for (let k=0;k<dim;k++) {
					dot-=dif[rvec+k]*dif[vidx++];
				}
				mat[(i-1)*cols+j]=dot;
				if (j) {mat[(j-1)*cols+i]=dot;}
			}
		}
		// Row reduce the matrix.
		// [ u3 | 0 0 1 ]
		// [ u2 | 0 1 0 ]
		// [ u1 | 1 0 0 ]
		for (let i=0;i<rows;i++) {
			// Find the largest element in column i.
			let row=i*cols,off=rows-i,last=row+off;
			let src=0,dst=last;
			let max=0;
			for (let r=last;r<elems;r+=cols) {
				let x=mat[r],a=x>0?x:-x;
				if (max<a) {max=a;src=r;}
			}
			// Normalize and move picked row.
			max=max>1e-20?1/mat[src]:0;
			while (dst>=row) {
				let a=mat[dst],b=mat[src];
				mat[src--]=a;
				mat[dst--]=b*max;
			}
			// Reduce other rows.
			for (let r=off;r<elems;r+=cols) {
				if (r===last) {continue;}
				dst=r;src=last;
				let mul=mat[dst];
				while (src>row) {
					mat[--dst]-=mul*mat[--src];
				}
			}
		}
		// The first column of mat holds the barycenter coordinates.
		if (verts<=dim) {preject=verts++;} else {preject=reject;}
		reject=-1;
		if (preject>=0) {
			// Find a new direction. Store in dif[0...dim].
			vidx=dim;
			for (let i=1;i<=rows;i++) {
				let u=mat[elems-i*cols];
				for (let j=0;j<dim;j++) {
					dif[j]-=u*dif[vidx++];
				}
			}
		} else {
			let u0=1,min=0;
			for (let i=rows;i>=0;i--) {
				let u=i?mat[elems-i*cols]:u0;
				if (min>u) {min=u;reject=i;}
				u0-=u;
			}
			if (reject<0) {break;}
		}
	}
	let norm=new Vector(dif.slice(0,dim));
	return [(test<tests && verts>dim),norm];
}


function CollisionDetectTest() {
	console.log("starting rigid body collision test");
	let rnd=new Random(1);
	let tests=10000;//1000000;
	let maxdim=10;
	let maxverts=20;
	function randpoint(arr,dim,scale) {
		let u=new Vector(dim);
		let len=arr.length;
		if (len && (rnd.getu32()&3)===0) {
			// Linear combinations can cause edge cases.
			let v=arr[rnd.mod(len)],w=arr[rnd.mod(len)];
			for (let i=0;i<dim;i++) {u[i]=(v[i]+w[i])*0.5;}
		} else {
			for (let i=0;i<dim;i++) {u[i]=rnd.gets()*scale;}
		}
		arr.push(u);
	}
	function randtrans(dim,mscale,vscale) {
		let t=new Transform(dim);
		let mat=t.mat,vec=t.vec;
		let dim2=dim*dim;
		let det=0;
		// Reject unstable matrices.
		do {
			for (let i=0;i<dim2;i++) {mat[i]=rnd.gets()*mscale;}
			det=Math.abs(mat.det());
		} while (dim>0 && (det<1e-3 || det>1e+3));
		for (let i=0;i<dim ;i++) {vec[i]=rnd.gets()*vscale;}
		return t;
	}
	let time=performance.now();
	for (let test=0;test<tests;test++) {
		let dim=rnd.mod(maxdim+1);
		let averts=rnd.mod(maxverts)+1;
		let bverts=rnd.mod(maxverts)+1;
		let avertarr=[],bvertarr=[];
		for (let i=0;i<averts;i++) {randpoint(avertarr,dim,5);}
		for (let i=0;i<bverts;i++) {randpoint(bvertarr,dim,5);}
		let afacearr=[],bfacearr=[];
		let atrans=randtrans(dim,2,10);
		let btrans=randtrans(dim,2,10);
		//if (test!==146076) {continue;}
		let world=new Phy.World(dim);
		let abody=new Phy.Body(world,[avertarr,afacearr],atrans,null);
		let bbody=new Phy.Body(world,[bvertarr,bfacearr],btrans,null);
		let col1=CollisionDetect1(abody,bbody);
		let col2=CollisionDetect3(abody,bbody);
		let over1=CollisionOverlap(abody,bbody,col1[1]);
		let over2=CollisionOverlap(abody,bbody,col2[1]);
		let error="";
		if (!col1[0] && col2[0]) {
			error+="error 1";
		}
		if (col1[0]!==(over1<=0)) {
			error+="error 2";
		}
		if (col2[0]!==(over2<=0)) {
			error+="error 3";
		}
		if ((test&0xfff)===0 || error) {
			console.log(`test: ${test}, dim: ${dim}, averts: ${averts}, bverts: ${bverts}`);
			console.log("col1:",col1[0],over1);
			console.log("col2:",col2[0],over2);
			if (error) {throw error;}
		}
	}
	time=(performance.now()-time)*0.001;
	console.log("time:",time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Collision Resolving
// Find minimum separating vector.


function EPAAlloc(world,len) {
	let epaarr=world.colepaarr;
	if (len>epaarr.length) {
		let dim=world.dim;
		while (len&(len+1)) {len|=len>>>1;}
		while (epaarr.length<=len) {
			epaarr.push({
				vertid:new Int32Array(dim),
				weight:new Float64Array(dim),
				norm:new Float64Array(dim),
				dist:0
			});
		}
		world.colepaarr=epaarr;
	}
	return epaarr;
}


function EPAInit(world) {
	let dim=world.dim,dim1=(dim+1)*dim;
	world.colepaarr=[];
	world.coltmpvertarr=[new Float64Array(0),new Float64Array(0)];
	world.coldif=new Float64Array(dim1);
	world.colmat=new Float64Array(dim1);
	world.colvertarr=new Float64Array(dim1);
	world.colvertid=new Int32Array(dim+1);
	world.colprevid=new Int32Array(dim+1);
	world.colweight=new Float64Array(dim);
	EPAAlloc(world,dim+1);
}


function CollisionResolve2(world,_avertarr,atrans,_bvertarr,btrans) {
	// GJK
	// Determines if bodies are colliding.
	// Doesn't use constant memory.
	// Finds minimum separating vector.
	// Inline everything for performance.
	// EPA
	//      vert IDs [D]
	//      weights  [D]
	//      normal   [D]
	//      dist
	//let world=abody.world;
	//EPAInit(world);
	let dim=world.dim;
	let averts=_avertarr.length,bverts=_bvertarr.length;
	if (!dim) {return [(averts>0 && bverts>0),new Vector(0),0,new Vector(0),new Vector(0)];}
	// Pick an initial direction. Any will work, but B.pos-A.pos works best.
	let dif=world.coldif;
	let normsum=0;
	for (let i=0;i<dim;i++) {
		let x=btrans.vec[i]-atrans.vec[i];
		dif[i]=x;
		normsum+=x*x;
	}
	// Pretransform the vertices. Flatten arrays to [x0,y0,z0,x1,y1,z1,...].
	for (let side=0;side<2;side++) {
		let srcarr=side?_bvertarr:_avertarr;
		let dstarr=world.coltmpvertarr[side];
		let verts=srcarr.length,vertlen=verts*dim;
		if (dstarr.length<vertlen) {
			dstarr=new Float64Array(vertlen*2);
			world.coltmpvertarr[side]=dstarr;
		}
		let mat=(side?btrans:atrans).mat;
		// mat*v+vec
		for (let s=0,d=0;s<verts;s++) {
			let v=srcarr[s];
			for (let i=0,m=0;i<dim;i++) {
				let x=side?dif[i]:0;
				for (let j=0;j<dim;j++) {x+=mat[m++]*v[j];}
				dstarr[d++]=x;
			}
		}
	}
	let avertlen=averts*dim,bvertlen=bverts*dim;
	let avertarr=world.coltmpvertarr[0],bvertarr=world.coltmpvertarr[1];
	if (normsum<1e-10) {dif[0]=1;}
	let mat=world.colmat;
	let vertarr=world.colvertarr;
	let vertid=world.colvertid;
	let previd=world.colprevid;
	let weight=world.colweight;
	previd.fill(-1);
	// Setup EPA memory.
	let epaarr=world.colepaarr;
	let epaalloc=epaarr.length;
	function epacmp(a,b) {
		// If distances are the same, sort by vertices to detect duplicates.
		let d=a.dist-b.dist;
		//if (d<-1e-10 || d>1e-10) {return d<0?-1:1;}
		if (d!==0) {return d<0?-1:1;}
		let sa=a.vertid,sb=b.vertid;
		for (let i=0;i<dim;i++) {
			let av=sa[i],bv=sb[i];
			if (av!==bv) {return av<bv?-1:1;}
		}
		return 0;
	}
	let epalen=-1,epachild=0;
	let epaprev=null;
	// Stop searching for a separating vector at (a.verts+b.verts+1)^2.
	let verts=1,reject=-1;
	let test=0,tests=(averts+bverts+1)*(averts+bverts+1);
	for (test=0;test<tests || epalen>=0;test++) {
		let norm=dif;
		let mask=1<<verts;
		let dist=0;
		if (epalen>=0) {
			// If we've added child EPA faces, sort them.
			if (epachild) {
				for (let child=0;child<verts;child++) {
					let i=epalen++;
					let epa=epaarr[i];
					while (i>0) {
						let j=(i-1)>>>1;
						let p=epaarr[j];
						if (epacmp(p,epa)<0) {break;}
						epaarr[i]=p;
						i=j;
					}
					epaarr[i]=epa;
				}
				epachild=0;
			}
			// Find the next closest simplex.
			let epa=epaarr[0];
			let last=epaarr[--epalen];
			let idx=0;
			while (true) {
				let i0=idx*2+1,i1=i0+1;
				if (i0>=epalen) {break;}
				if (i1>=epalen) {i1=i0;}
				let e0=epaarr[i0],e1=epaarr[i1];
				if (epacmp(e0,e1)>0) {i0=i1;e0=e1;}
				if (epacmp(e0,last)>=0) {break;}
				epaarr[idx]=e0;
				idx=i0;
			}
			epaarr[idx]=last;
			epaarr[epalen]=epa;
			// Prevent backtracking and duplicates.
			if (epaprev!==null && epacmp(epaprev,epa)>=0) {continue;}
			if (epalen+verts+1>epaalloc) {
				epaarr=world.epaalloc(epalen+verts+1);
				epaalloc=epaarr.length;
			}
			// Move the current EPA to the end so it isn't overwritten.
			epaprev=epa;
			epaarr[epalen]=epaarr[epaalloc-1];
			epaarr[epaalloc-1]=epaprev;
			for (let i=0;i<dim;i++) {vertid[i]=epa.vertid[i];}
			norm=epa.norm;
			dist=epa.dist;
			mask--;
		}
		// Find new supports. Direction is stored in dif[0...dim].
		if (reject<0) {
			let max=-Infinity,min=Infinity;
			let a=0,b=0;
			// Find max(A.verts*norm);
			for (let i=0;i<avertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=avertarr[i+j]*norm[j];}
				if (max<p) {max=p;a=i;}
			}
			// Find min(B.verts*bnorm)
			for (let i=0;i<bvertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=bvertarr[i+j]*norm[j];}
				if (min>p) {min=p;b=i;}
			}
			// If we have a separating vector or can't expand the EPA.
			if (max-min-dist<1e-10) {break;}
			let id=a*bvertlen+b,i=verts-1;
			while (i>0 && vertid[i-1]>id) {
				vertid[i]=vertid[i-1];
				i--;
			}
			vertid[i]=id;
		}
		// Calculate the current set of minkowski vertices A.vert(i)-B.vert(j).
		for (let i=0;i<verts;i++) {
			let id=vertid[i];
			if (previd[i]!==id) {
				previd[i]=id;
				let a=~~(id/bvertlen),b=id%bvertlen,d=i*dim;
				for (let j=0;j<dim;j++) {vertarr[d+j]=avertarr[a+j]-bvertarr[b+j];}
			}
		}
		// Find the closest point in a set of vertices to another point.
		// Use linear algebra to compute the barycenter coordinates of the set.
		while (--mask>0) {
			// di = vi - v0
			// dP =  P - v0, put in row 0
			let vidx=dim,cols=0,v0=0;
			for (let i=0;i<verts;i++) {
				if (!(mask&(1<<i))) {continue;}
				let r=i*dim;
				if (!cols++) {v0=r;continue;}
				for (let j=0;j<dim;j++) {dif[vidx++]=vertarr[r+j]-vertarr[v0+j];}
			}
			for (let j=0;j<dim;j++) {dif[j]=-vertarr[v0+j];}
			// Create matrix. Note the solution column is on the left for efficiency.
			// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
			// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
			let rows=cols-1,elems=rows*cols;
			for (let i=1;i<cols;i++) {
				let rvec=i*dim;vidx=0;
				for (let j=0;j<=i;j++) {
					let dot=0;
					for (let k=0;k<dim;k++) {
						dot-=dif[rvec+k]*dif[vidx++];
					}
					mat[(i-1)*cols+j]=dot;
					if (j) {mat[(j-1)*cols+i]=dot;}
				}
			}
			// Row reduce the matrix.
			// [ u3 | 0 0 1 ]
			// [ u2 | 0 1 0 ]
			// [ u1 | 1 0 0 ]
			for (let i=0;i<rows;i++) {
				// Find the largest element in column i.
				let row=i*cols,off=rows-i,last=row+off;
				let src=0,dst=last;
				let max=0;
				for (let r=last;r<elems;r+=cols) {
					let x=mat[r],a=x>0?x:-x;
					if (max<a) {max=a;src=r;}
				}
				// Normalize and move picked row.
				max=max>1e-10?1/mat[src]:0;
				while (dst>=row) {
					let a=mat[dst],b=mat[src];
					mat[src--]=a;
					mat[dst--]=b*max;
				}
				// Reduce other rows.
				for (let r=off;r<elems;r+=cols) {
					if (r===last) {continue;}
					dst=r;src=last;
					let mul=mat[dst];
					while (src>row) {
						mat[--dst]-=mul*mat[--src];
					}
				}
			}
			// The first column of mat holds the barycenter coordinates.
			// Find a new direction. Store in dif[0...dim].
			reject=-1;
			vidx=dim;
			let u0=1,min=0;
			for (let i=1;i<=rows;i++) {
				let u=mat[elems-i*cols];
				for (let j=0;j<dim;j++) {
					dif[j]-=u*dif[vidx++];
				}
				if (min>u) {min=u;reject=i;}
				weight[i]=u;
				u0-=u;
			}
			if (min>u0) {min=u0;reject=0;}
			weight[0]=u0;
			if (epalen>=0) {
				// Check all combinations for the closest point.
				if (reject>=0) {continue;}
				dist=0;
				for (let i=0;i<dim;i++) {
					let x=dif[i];
					dist+=x*x;
				}
				for (let child=0;child<verts;child++) {
					// Record the new EPA face. NaN distances can occur.
					let bit=1<<child;
					let epa=epaarr[epalen+child];
					let edist=(epachild&bit)?epa.dist:Infinity;
					if (edist>dist && !(mask&bit)) {
						epa.dist=dist;
						epachild|=bit;
						let wpos=0;
						let enorm=epa.norm,eweight=epa.weight,evertid=epa.vertid;
						for (let i=0;i<dim;i++) {
							let j=i+(i>=child);
							enorm[i]=-dif[i];
							eweight[i]=((mask>>>j)&1)?weight[wpos++]:0;
							evertid[i]=vertid[j];
						}
					}
				}
			} else if (verts<=dim) {
				verts++;
				reject=-1;
				break;
			} else if (reject>=0) {
				verts--;
				for (let i=reject;i<verts;i++) {vertid[i]=vertid[i+1];}
				break;
			} else {
				// The polygons are colliding so build the EPA.
				epalen=0;
			}
		}
	}
	if (epaprev!==null) {
		// Calculate contact points based on weights.
		let apos=atrans.vec;
		let ap=new Vector(apos),bp=new Vector(apos);
		for (let i=0;i<dim;i++) {
			let w=epaprev.weight[i];
			let id=epaprev.vertid[i];
			let av=~~(id/bvertlen);
			let bv=id%bvertlen;
			for (let j=0;j<dim;j++) {
				ap[j]+=w*avertarr[av+j];
				bp[j]+=w*bvertarr[bv+j];
			}
		}
		// Recalculate norm and magnitude based on contacts.
		let norm=bp.sub(ap);
		let mag=norm.mag();
		norm.imul(1/mag);
		return [true,norm,mag,ap,bp];
	}
	// If we're rejecting.
	let norm=new Vector(dif.slice(0,dim));
	return [false,norm,0,null,null];
}


function epainit2(world) {
	let dim=world.dim,dim1=(dim+1)*dim;
	world.colepaarr=[];
	world.coltmpvertarr=[new Float64Array(0),new Float64Array(0)];
	world.coldif=new Float64Array(dim1);
	world.colmat=new Float64Array(dim1);
	world.colvertarr=new Float64Array(dim1);
	world.colvertid=new Int32Array(dim+1);
	world.colprevid=new Int32Array(dim+1);
	world.colweight=new Float64Array(dim);
	function distcmp(l,r) {
		let ld=l.dist,rd=r.dist;
		if (ld===rd) {return 0;}
		return ld<rd?-1:1;
	}
	function vertcmp(l,r) {
		let lv=l.vertid,rv=r.vertid;
		for (let i=0;i<dim;i++) {
			let a=lv[i],b=rv[i];
			if (a!==b) {return a<b?-1:1;}
		}
		return 0;
	}
	world.coldisttree=new Data.Tree(distcmp,Data.Tree.ADD);
	world.colverttree=new Data.Tree(vertcmp,Data.Tree.DISCARD);
	epaalloc2(world,dim+1);
}


function epaalloc2(world,len) {
	let epaarr=world.colepaarr;
	if (len>epaarr.length) {
		let dim=world.dim;
		while (len&(len+1)) {len|=len>>>1;}
		while (epaarr.length<=len) {
			let epa={
				distnode:new Data.Tree.Node(null),
				vertnode:new Data.Tree.Node(null),
				vertid:new Int32Array(dim),
				weight:new Float64Array(dim),
				norm:new Float64Array(dim),
				dist:0
			};
			epa.distnode.value=epa;
			epa.vertnode.value=epa;
			epaarr.push(epa);
		}
		world.colepaarr=epaarr;
	}
	return epaarr;
}


function CollisionResolve3(world,_avertarr,atrans,_bvertarr,btrans) {
	// GJK
	// Determines if bodies are colliding.
	// Doesn't use constant memory.
	// Finds minimum separating vector.
	// Inline everything for performance.
	// EPA
	//      vert IDs [D]
	//      weights  [D]
	//      normal   [D]
	//      dist
	//let world=abody.world;
	//EPAInit(world);
	let dim=world.dim;
	let averts=_avertarr.length,bverts=_bvertarr.length;
	if (!dim) {return [(averts>0 && bverts>0),new Vector(0),0,new Vector(0),new Vector(0)];}
	// Pick an initial direction. Any will work, but B.pos-A.pos works best.
	let dif=world.coldif;
	let normsum=0;
	for (let i=0;i<dim;i++) {
		let x=btrans.vec[i]-atrans.vec[i];
		dif[i]=x;
		normsum+=x*x;
	}
	// Pretransform the vertices. Flatten arrays to [x0,y0,z0,x1,y1,z1,...].
	for (let side=0;side<2;side++) {
		let srcarr=side?_bvertarr:_avertarr;
		let dstarr=world.coltmpvertarr[side];
		let verts=srcarr.length,vertlen=verts*dim;
		if (dstarr.length<vertlen) {
			dstarr=new Float64Array(vertlen*2);
			world.coltmpvertarr[side]=dstarr;
		}
		let mat=(side?btrans:atrans).mat;
		// mat*v+vec
		for (let s=0,d=0;s<verts;s++) {
			let v=srcarr[s];
			for (let i=0,m=0;i<dim;i++) {
				let x=side?dif[i]:0;
				for (let j=0;j<dim;j++) {x+=mat[m++]*v[j];}
				dstarr[d++]=x;
			}
		}
	}
	let avertlen=averts*dim,bvertlen=bverts*dim;
	let avertarr=world.coltmpvertarr[0],bvertarr=world.coltmpvertarr[1];
	if (normsum<1e-10) {dif[0]=1;}
	let mat=world.colmat;
	let vertarr=world.colvertarr;
	let vertid=world.colvertid;
	let previd=world.colprevid;
	let weight=world.colweight;
	previd.fill(-1);
	// Setup EPA memory.
	epainit2(world);
	let epaarr=world.colepaarr,epamin=null;
	let epaalloc=epaarr.length;
	let epalen=-1,epachild=0;
	let disttree=world.coldisttree;
	let verttree=world.colverttree;
	disttree.clear();
	verttree.clear();
	// Stop searching for a separating vector at (a.verts+b.verts+1)^2.
	let verts=1,reject=-1;
	let test=0,tests=(averts+bverts+1)*(averts+bverts+1);
	for (test=0;test<tests || epalen>=0;test++) {
		let norm=dif;
		let mask=1<<verts;
		let dist=0;
		if (epalen>=0) {
			// If we've added child EPA faces, sort them.
			let stop=epalen+(epachild?verts:0);
			epachild=0;
			for (let i=epalen;i<stop;i++) {
				let epa=epaarr[i];
				if (verttree.addnode(epa.vertnode)!==null) {
					disttree.addnode(epa.distnode);
					epaarr[i]=epaarr[epalen];
					epaarr[epalen++]=epa;
				}
			}
			// Find the next closest simplex.
			let epanode=disttree.first();
			disttree.removenode(epanode);
			epamin=epanode.value;
			if (epalen+verts>epaalloc) {
				epaarr=epaalloc2(world,epalen+verts);
				epaalloc=epaarr.length;
			}
			// Move the current EPA to the end so it isn't overwritten.
			for (let i=0;i<dim;i++) {vertid[i]=epamin.vertid[i];}
			norm=epamin.norm;
			dist=epamin.dist;
			mask--;
		}
		// Find new supports. Direction is stored in dif[0...dim].
		if (reject<0) {
			let max=-Infinity,min=Infinity;
			let a=0,b=0;
			// Find max(A.verts*norm);
			for (let i=0;i<avertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=avertarr[i+j]*norm[j];}
				if (max<p) {max=p;a=i;}
			}
			// Find min(B.verts*bnorm)
			for (let i=0;i<bvertlen;i+=dim) {
				let p=0;
				for (let j=0;j<dim;j++) {p+=bvertarr[i+j]*norm[j];}
				if (min>p) {min=p;b=i;}
			}
			// If we have a separating vector or can't expand the EPA.
			if (max-min-dist<1e-10) {break;}
			let id=a*bvertlen+b,i=verts-1;
			while (i>0 && vertid[i-1]>id) {
				vertid[i]=vertid[i-1];
				i--;
			}
			vertid[i]=id;
		}
		// Calculate the current set of minkowski vertices A.vert(i)-B.vert(j).
		for (let i=0;i<verts;i++) {
			let id=vertid[i];
			if (previd[i]!==id) {
				previd[i]=id;
				let a=~~(id/bvertlen),b=id%bvertlen,d=i*dim;
				for (let j=0;j<dim;j++) {vertarr[d+j]=avertarr[a+j]-bvertarr[b+j];}
			}
		}
		// Find the closest point in a set of vertices to another point.
		// Use linear algebra to compute the barycenter coordinates of the set.
		while (--mask>0) {
			// di = vi - v0
			// dP =  P - v0, put in row 0
			let vidx=dim,cols=0,v0=0;
			for (let i=0;i<verts;i++) {
				if (!(mask&(1<<i))) {continue;}
				let r=i*dim;
				if (!cols++) {v0=r;continue;}
				for (let j=0;j<dim;j++) {dif[vidx++]=vertarr[r+j]-vertarr[v0+j];}
			}
			for (let j=0;j<dim;j++) {dif[j]=-vertarr[v0+j];}
			// Create matrix. Note the solution column is on the left for efficiency.
			// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
			// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
			let rows=cols-1,elems=rows*cols;
			for (let i=1;i<cols;i++) {
				let rvec=i*dim;vidx=0;
				for (let j=0;j<=i;j++) {
					let dot=0;
					for (let k=0;k<dim;k++) {
						dot-=dif[rvec+k]*dif[vidx++];
					}
					mat[(i-1)*cols+j]=dot;
					if (j) {mat[(j-1)*cols+i]=dot;}
				}
			}
			// Row reduce the matrix.
			// [ u3 | 0 0 1 ]
			// [ u2 | 0 1 0 ]
			// [ u1 | 1 0 0 ]
			for (let i=0;i<rows;i++) {
				// Find the largest element in column i.
				let row=i*cols,off=rows-i,last=row+off;
				let src=0,dst=last;
				let max=0;
				for (let r=last;r<elems;r+=cols) {
					let x=mat[r],a=x>0?x:-x;
					if (max<a) {max=a;src=r;}
				}
				// Normalize and move picked row.
				max=max>1e-10?1/mat[src]:0;
				while (dst>=row) {
					let a=mat[dst],b=mat[src];
					mat[src--]=a;
					mat[dst--]=b*max;
				}
				// Reduce other rows.
				for (let r=off;r<elems;r+=cols) {
					if (r===last) {continue;}
					dst=r;src=last;
					let mul=mat[dst];
					while (src>row) {
						mat[--dst]-=mul*mat[--src];
					}
				}
			}
			// The first column of mat holds the barycenter coordinates.
			// Find a new direction. Store in dif[0...dim].
			reject=-1;
			vidx=dim;
			let u0=1,min=0;
			for (let i=1;i<=rows;i++) {
				let u=mat[elems-i*cols];
				for (let j=0;j<dim;j++) {
					dif[j]-=u*dif[vidx++];
				}
				if (min>u) {min=u;reject=i;}
				weight[i]=u;
				u0-=u;
			}
			if (min>u0) {min=u0;reject=0;}
			weight[0]=u0;
			if (epalen>=0) {
				// Check all combinations for the closest point.
				if (reject>=0) {continue;}
				dist=0;
				for (let i=0;i<dim;i++) {
					let x=dif[i];
					dist+=x*x;
				}
				for (let child=0;child<verts;child++) {
					// Record the new EPA face. NaN distances can occur.
					let bit=1<<child;
					let epa=epaarr[epalen+child];
					let edist=(epachild&bit)?epa.dist:Infinity;
					if (edist>dist && !(mask&bit)) {
						epa.dist=dist;
						epachild|=bit;
						let wpos=0;
						let enorm=epa.norm,eweight=epa.weight,evertid=epa.vertid;
						for (let i=0;i<dim;i++) {
							let j=i+(i>=child);
							enorm[i]=-dif[i];
							eweight[i]=((mask>>>j)&1)?weight[wpos++]:0;
							evertid[i]=vertid[j];
						}
					}
				}
			} else if (verts<=dim) {
				verts++;
				reject=-1;
				break;
			} else if (reject>=0) {
				verts--;
				for (let i=reject;i<verts;i++) {vertid[i]=vertid[i+1];}
				break;
			} else {
				// The polygons are colliding so build the EPA.
				epalen=0;
			}
		}
	}
	if (epamin!==null) {
		// Calculate contact points based on weights.
		let apos=atrans.vec;
		let ap=new Vector(apos),bp=new Vector(apos);
		for (let i=0;i<dim;i++) {
			let w=epamin.weight[i];
			let id=epamin.vertid[i];
			let av=~~(id/bvertlen);
			let bv=id%bvertlen;
			for (let j=0;j<dim;j++) {
				ap[j]+=w*avertarr[av+j];
				bp[j]+=w*bvertarr[bv+j];
			}
		}
		// Recalculate norm and magnitude based on contacts.
		let norm=bp.sub(ap);
		let mag=norm.mag();
		norm.imul(1/mag);
		return [true,norm,mag,ap,bp];
	}
	// If we're rejecting.
	let norm=new Vector(dif.slice(0,dim));
	return [false,norm,0,null,null];
}


function CollisionResolveTest() {
	console.log("starting rigid body collision resolving");
	let rnd=new Random(1);
	let tests=100000;
	let maxdim=10;
	let maxverts=20;
	function randpoint(arr,dim,scale) {
		let u=new Vector(dim);
		let len=arr.length;
		if (len && (rnd.getu32()&3)===0) {
			// Linear combinations can cause edge cases.
			let v=arr[rnd.mod(len)],w=arr[rnd.mod(len)];
			for (let i=0;i<dim;i++) {u[i]=(v[i]+w[i])*0.5;}
		} else {
			for (let i=0;i<dim;i++) {u[i]=rnd.gets()*scale;}
		}
		arr.push(u);
	}
	function randtrans(dim,mscale,vscale) {
		let t=new Transform(dim);
		let mat=t.mat,vec=t.vec;
		let dim2=dim*dim;
		let det=0;
		// Reject unstable matrices.
		do {
			for (let i=0;i<dim2;i++) {mat[i]=rnd.gets()*mscale;}
			det=Math.abs(mat.det());
		} while (dim>0 && (det<1e-3 || det>1e+3));
		for (let i=0;i<dim ;i++) {vec[i]=rnd.gets()*vscale;}
		return t;
	}
	let time=performance.now();
	let sumproj1=0;
	let sumproj2=0;
	for (let test=0;test<tests;test++) {
		let dim=rnd.mod(maxdim+1);
		let averts=rnd.mod(maxverts+1);
		let bverts=rnd.mod(maxverts+1);
		let avertarr=[],bvertarr=[];
		for (let i=0;i<averts;i++) {randpoint(avertarr,dim,5);}
		for (let i=0;i<bverts;i++) {randpoint(bvertarr,dim,5);}
		let atrans=randtrans(dim,2,10);
		let btrans=randtrans(dim,2,10);
		//if (test!==32) {continue;}
		let world=new Phy.World(dim);
		let col1=CollisionDetect1(world,avertarr,atrans,bvertarr,btrans);
		//let col2=CollisionResolve2(world,avertarr,atrans,bvertarr,btrans);
		let col2=CollisionResolve3(world,avertarr,atrans,bvertarr,btrans);
		//let col2=world.closestpoint(avertarr,atrans,bvertarr,btrans);
		let over1=CollisionOverlap(avertarr,atrans,bvertarr,btrans,col1[1]);
		let over2=CollisionOverlap(avertarr,atrans,bvertarr,btrans,col2[1]);
		let proj1=over1>0?0:over1;
		let proj2=over2>0?0:over2;
		sumproj1+=proj1;
		sumproj2+=proj2;
		let error="";
		if (proj1>proj2) {
			error+="error 1";
		}
		if (col1[0]!==(over1<=0)) {
			error+="error 2";
		}
		if (col2[0]!==(over2<=0)) {
			error+="error 3";
		}
		// Check if we've actually separated the polygons.
		if (col2[0]) {
			let norm=col2[1],mag=col2[2];
			//let ap=col2[3],bp=col2[4];
			atrans.vec.iadd(norm.mul(mag));
			over2=CollisionOverlap(avertarr,atrans,bvertarr,btrans,norm);
			if (Math.abs(over2)>1e-8) {
				console.log("not separating vector");
				console.log(over2);
				error="error 4";
			}
		}
		if ((test&0xfff)===0 || error) {
			console.log(`test: ${test}, dim: ${dim}, averts: ${averts}, bverts: ${bverts}`);
			console.log("col1:",col1[0],over1,proj1);
			console.log("col2:",col2[0],over2,proj2);
			if (error) {throw error;}
		}
	}
	time=(performance.now()-time)*0.001;
	console.log("time:",time.toFixed(6));
	console.log("proj1:",sumproj1.toFixed(6));
	console.log("proj2:",sumproj2.toFixed(6));
}


function DisplayAnomoly() {
	//let bvertarr=[[-0.1,0.005],[-0.05,0.01],[0.01,0.04],[-0.08,0.03]];
	let bvertarr=[[-0.04702564102564104,-0.017538461538461534],[0.002974358974358965,-0.012538461538461535],[0.06297435897435896,0.017461538461538466],[-0.027025641025641034,0.007461538461538464]];
	let btrans=new Transform({vec:[-0.601883257,0.019107351],ang:[6.272733992]});
	let avertarr=[[-1,-0.01],[1,-0.01],[1,0.01],[-1,0.01]];
	let atrans=new Transform({vec:[0,0.1],ang:[0.1]});
	let world=new Phy.World(2);
	console.log(CollisionResolve3(world,avertarr,atrans,bvertarr,btrans));
}


//---------------------------------------------------------------------------------
// Main Test


function TestMain() {
	//CollisionDetectTest();
	//CollisionResolveTest();
	DisplayAnomoly();
	console.log("done");
}

TestMain();

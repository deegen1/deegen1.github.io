	static collide(a,b) {
		// Collides two atoms. Vector operations are unrolled to use constant memory.
		if (Object.is(a,b)) {return;}
		// Determine if the atoms are overlapping.
		let apos=a.pos,bpos=b.pos;
		let dim=apos.length,i;
		let dist=0.0,dif,norm=a.world.tmpvec;
		for (i=0;i<dim;i++) {
			dif=bpos[i]-apos[i];
			norm[i]=dif;
			dist+=dif*dif;
		}
		let rad=a.rad+b.rad;
		if (dist>=rad*rad) {return;}
		// Bonds can limit the distance between the atoms.
		let b0=a,b1=b;
		if (a.bondlist.count>b.bondlist.count) {b0=b;b1=a;}
		let link=b0.bondlist.head;
		while (link!==null) {
			let bond=link.obj;
			link=link.next;
			if (Object.is(bond.a,b1) || Object.is(bond.b,b1)) {
				rad=rad<bond.dist?rad:bond.dist;
			}
		}
		if (dist>=rad*rad) {return;}
		let amass=a.mass,bmass=b.mass;
		let mass=amass+bmass;
		if ((amass>=Infinity && bmass>=Infinity) || mass<=1e-10 || dim===0) {
			return;
		}
		amass=amass>=Infinity? 1.0: amass/mass;
		bmass=bmass>=Infinity?-1.0:-bmass/mass;
		// If the atoms are too close together, randomize the direction.
		let den=1;
		if (dist>1e-10) {
			dist=Math.sqrt(dist);
			den=1.0/dist;
		} else {
			norm.randomize();
		}
		// Check the relative velocity. We can have situations where two atoms increase
		// eachother's velocity because they've been pushed past eachother.
		let avel=a.vel,bvel=b.vel;
		let veldif=0.0;
		for (i=0;i<dim;i++) {
			norm[i]*=den;
			veldif+=(avel[i]-bvel[i])*norm[i];
		}
		let intr=a.type.intarr[b.type.id];
		let posdif=rad-dist;
		veldif=veldif>0?veldif:0;
		veldif=veldif*intr.vmul+posdif*intr.vpmul;
		posdif*=intr.pmul;
		// If we have a callback, allow it to handle the collision.
		let callback=intr.callback;
		if (callback!==null && !callback(a,b,norm,veldif,posdif)) {return;}
		// Push the atoms apart.
		let aposmul=posdif*bmass,avelmul=veldif*bmass;
		let bposmul=posdif*amass,bvelmul=veldif*amass;
		for (i=0;i<dim;i++) {
			dif=norm[i];
			apos[i]+=dif*aposmul;
			avel[i]+=dif*avelmul;
			bpos[i]+=dif*bposmul;
			bvel[i]+=dif*bvelmul;
		}
	}
	static closestpoint(vertarr,point,minbary=null,difvert=null,mat=null) {
		// Find the closest point in a simplex to another point.
		// We iterate over all 2^n sets of vertices and use linear
		// algebra to compute the barycenter coordinates of each set.
		let dim=point.length,verts=dim;
		if (!minbary) {minbary=new Array(verts);}
		if (!difvert) {difvert=new Array(dim*dim);}
		if (!mat) {mat=new Array(dim*(dim-1));}
		let mindist=Infinity;
		let combos=1<<verts;
		for (let combo=1;combo<combos;combo++) {
			// di = vi - v0
			// dP =  P - v0, put in row 0
			let cols=0,vidx=0,v0;
			for (let i=0;i<verts;i++) {
				if ((combo>>>i)&1) {
					let v=vertarr[i];
					if (!cols++) {v0=v;v=point;}
					for (let j=0;j<dim;j++) {difvert[vidx++]=v[j]-v0[j];}
				}
			}
			// Create matrix. Note the solution column is on the left for efficiency.
			// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
			// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
			let rows=cols-1,elems=rows*cols;
			for (let i=1;i<cols;i++) {
				let rvec=i*dim;vidx=0;
				for (let j=0;j<=i;j++) {
					let dot=0;
					for (let k=0;k<dim;k++) {
						dot+=difvert[rvec+k]*difvert[vidx++];
					}
					mat[(i-1)*cols+j]=dot;
					if (j) {mat[(j-1)*cols+i]=dot;}
				}
			}
			// Row reduce the matrix.
			// [ u3 | 0 0 1 ]
			// [ u2 | 0 1 0 ]
			// [ u1 | 1 0 0 ]
			let u0=1;
			for (let i=0;i<rows;i++) {
				// Find the largest element in column i.
				let row=i*cols,off=cols-i-1,last=row+off;
				let src,max=0;
				for (let r=last;r<elems;r+=cols) {
					let x=mat[r],a=x>0?x:-x;
					if (max<a) {max=a;src=r;}
				}
				if (max<1e-10) {u0=-1;break;}
				// Normalize and move picked row.
				let norm=1/mat[src],dst=last;
				while (dst>=row) {
					let a=mat[dst],b=mat[src];
					mat[src--]=a;
					mat[dst--]=b*norm;
				}
				// Reduce other rows.
				for (let r=off;r<elems;r+=cols) {
					if (r===last) {continue;}
					dst=r;src=last;
					let mul=mat[dst];
					while (src>row) {
						mat[--dst]-=mul*mat[--src];
					}
				}
			}
			if (u0<0) {continue;}
			// The first column holds the barycenter coordinates.
			// Caclulate dP-u1*d1-u2*d2-...
			vidx=dim;
			for (let i=1;i<=rows;i++) {
				let u=mat[elems-i*cols];
				if (u<0) {u0=-1;break;}
				for (let j=0;j<dim;j++) {
					difvert[j]-=u*difvert[vidx++];
				}
				u0-=u;
			}
			if (u0<0) {continue;}
			// Calculate distance = dP*dP.
			let dist=0;
			for (let i=0;i<dim;i++) {
				let d=difvert[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let j=elems;
				for (let i=0;i<verts;i++) {
					let u=0;
					if ((combo>>>i)&1) {
						u=j<elems?mat[j]:u0;
						j-=cols;
					}
					minbary[i]=u;
				}
			}
		}
		return [Math.sqrt(mindist),minbary];
	}


	static calcnormal(vertarr) {
		// Find a vector N where v*N=c for all verts.
		let verts=vertarr.length,dim=vertarr[0].length;
		if (verts!==dim) {throw "verts!=dim";}
		let mat=new Matrix(dim-1,dim-1);
		let norm=new Vector(dim);
		let base=vertarr[0];
		for (let i=0;i<dim;i++) {
			let dst=0;
			for (let r=1;r<dim;r++) {
				let row=vertarr[r];
				for (let c=0;c<dim;c++) {
					if (c===i) {continue;}
					mat[dst++]=row[c]-base[c];
				}
			}
			let det=mat.det();
			norm[i]=(i&1)?-det:det;
		}
		let mag=norm.mag();
		norm.imul(mag>1e-10?1/mag:0);
		return norm;
	}


	/*createshape2(fill,mat,minrad,spacing,vertarr,facearr,transform=null,bonddist=NaN,bondtension=NaN,bondbreak=Infinity) {
		// Fill types: 0 Outline, 1 Uniform, 2 Greedy.
		//
		// Atoms and bonds are placed *before* applying transform.
		// Radii and bond lengths will be rescaled if needed.
		let dim=this.dim;
		if (!(spacing>1e-10 && minrad>1e-10)) {throw `Invalid spacing: ${spacing}, ${minrad}`;}
		let reso=4,resmul=reso/spacing,resrad=minrad*resmul;
		// Find the bounds of our shape.
		let bndmin=(new Vector(dim)).set(Infinity);
		let bndmax=(new Vector(dim)).set(-Infinity);
		let locvert=[];
		for (let v of vertarr) {
			let u=new Vector(v);
			bndmin.imin(u);
			bndmax.imax(u);
			locvert.push(u);
		}
		let locoff=bndmax.add(bndmin).imul(0.5);
		for (let v of locvert) {v.isub(locoff).imul(resmul);}
		bndmin.isub(locoff).isub(spacing).imul(resmul);
		bndmax.isub(locoff).iadd(spacing).imul(resmul);
		let locface=[];
		for (let farr of facearr) {
			if (face.length!==dim) {throw `invalid face: ${face}`;}
			let varr=new Array(dim);
			for (let i=0;i<dim;i++) {varr[i]=locvert[farr[i]];}
			locface.push({varr:varr,norm:calcnormal(varr)});
		}
		//
		let cell0={};
		let cellmask=0;
		let cellmap=(new Array(cellmask+1)).fill(null);
		let coordi=new Array(dim);
		function *itercells() {
		}
		function getcell() {
		}
		function hashcoord(pos) {
			let hash=1;
			for (let i=0;i<dim;i++) {
				let x=Math.round(pos[i]/iter);
				hash=Random.hashu32(hash+x);
				coordi[i]=x;
			}
			return hash;
		}
		for (let face of newface) {
			let varr=face.varr;
			cellmask=0;
			cellmap=(new Array(cellmask+1)).fill(null);
			let hash=hashcoord(varr[0]);
		}
		// Transform and rescale everything.
		locoff.imul(resmul);
		transform=new Transform(transform??{dim:dim});
		let scale=Math.pow(transform.mat.det(),1/dim);
		for (let atom of atomarr) {
			atom.pos=transform.apply(atom.pos);
			atom.rad*=scale;
			atom.updateconstants();
		}
		for (let bond of bondarr) {
			bond.dist=bond.a.pos.dist(bond.b.pos);
			bond.breakdist=bondbreak*scale;
		}
		return atomarr;
	}*/

/*------------------------------------------------------------------------------


simplex.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint simplex.js -c ../../../standards/eslint.js */


import {Random,Vector,Matrix} from "../library.js";


//---------------------------------------------------------------------------------
// Closest Constrained


function FindBarycenter1(verts,point,dim) {
	let bary=new Vector(dim);
	let tmppt=new Vector(dim);
	let minbary=new Vector(dim);
	let mindist=Infinity;
	let rnd=new Random();
	for (let iter=0;iter<256;iter++) {
		let scale=1/(1<<(iter&30));
		for (let pt=0;pt<128;pt++) {
			let den=0;
			for (let i=0;i<dim;i++) {
				// let x=minbary[i]+(rnd.getnorm())*scale;
				let x=minbary[i]+(rnd.getf()*2-1)*scale;
				x=x>0?x:0;
				bary[i]=x;
				den+=x;
			}
			if (den<=1e-20) {
				bary.set(0);
				bary[0]=1;
				den=1;
			}
			tmppt.set(0);
			for (let i=0;i<dim;i++) {
				let u=bary[i]/den;
				bary[i]=u;
				let v=verts[i];
				for (let j=0;j<dim;j++) {
					tmppt[j]+=u*v[j];
				}
			}
			let dist=0;
			for (let i=0;i<dim;i++) {
				let d=tmppt[i]-point[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let tmp=bary;
				bary=minbary;
				minbary=tmp;
			}
		}
		// scale*=0.85;
	}
	return minbary;
}


function FindBarycenter2(verts,point,dim) {
	// let scale=1;
	let bary=new Vector(dim);
	let tmppt=new Vector(dim);
	let minbary=new Vector(dim);
	let mindist=Infinity;
	let iterbary=new Vector(dim);
	let flags=1<<dim;
	for (let iter=0;iter<64;iter++) {
		// let scale=1/(1<<(1*(iter&31)));
		let scale=Math.pow(2,-2*(iter&15));
		iterbary.set(minbary);
		for (let f=1;f<flags;f++) {
			let den=0;
			for (let i=0;i<dim;i++) {
				let u=iterbary[i]+((f>>>i)&1)*scale;
				bary[i]=u;
				den+=u;
			}
			tmppt.set(0);
			den=den>1e-10?1/den:0;
			for (let i=0;i<dim;i++) {
				let u=bary[i]*=den;
				let v=verts[i];
				for (let j=0;j<dim;j++) {
					tmppt[j]+=u*v[j];
				}
			}
			let dist=den>0?0:Infinity;
			for (let i=0;i<dim;i++) {
				let d=tmppt[i]-point[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let tmp=bary;
				bary=minbary;
				minbary=tmp;
			}
		}
		// scale*=0.5;
	}
	// let den=0;
	// for (let i=0;i<dim;i++) {den+=minbary[i];}
	// for (let i=0;i<dim;i++) {minbary[i]/=den;}
	return minbary;
}


function FindBarycenter3(verts,point,dim) {
	let bary=new Vector(dim);
	let tmppt=new Vector(dim);
	let minbary=new Vector(dim);
	let mindist=Infinity;
	let flags=1<<dim;
	for (let iter=0;iter<128;iter++) {
		// Alternate adding and subtracting at different scales.
		let scale=((iter&1)?-1:1)/(1<<(iter&30));
		for (let f=0;f<flags;f++) {
			let den=0;
			for (let i=0;i<dim;i++) {
				let u=minbary[i]+((f>>>i)&1)*scale;
				u=u>0?u:0;
				bary[i]=u;
				den+=u;
			}
			tmppt.set(0);
			den=den>1e-10?1/den:0;
			for (let i=0;i<dim;i++) {
				let u=bary[i]*den;
				let v=verts[i];
				for (let j=0;j<dim;j++) {
					tmppt[j]+=u*v[j];
				}
			}
			let dist=den>0?0:Infinity;
			for (let i=0;i<dim;i++) {
				let d=tmppt[i]-point[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let tmp=bary;
				bary=minbary;
				minbary=tmp;
			}
		}
	}
	let den=0;
	for (let i=0;i<dim;i++) {den+=minbary[i];}
	for (let i=0;i<dim;i++) {minbary[i]/=den;}
	return minbary;
}


function FindBarycenter4(verts,point,dim) {
	let bary=new Vector(dim);
	let tmppt=new Vector(dim);
	let minbary=new Vector(dim);
	let mindist=Infinity;
	let flags=1;
	for (let i=0;i<dim;i++) {flags*=3;}
	for (let iter=0;iter<128;iter++) {
		let scale=1/(1<<(iter%24));
		for (let f=0;f<flags;f++) {
			let den=0,t=f;
			for (let i=0;i<dim;i++) {
				let u=minbary[i]+(1-(t%3))*scale;
				t=t/3|0;
				u=u>0?u:0;
				bary[i]=u;
				den+=u;
			}
			tmppt.set(0);
			den=den>1e-5?1/den:0;
			for (let i=0;i<dim;i++) {
				let u=bary[i]*den;
				let v=verts[i];
				for (let j=0;j<dim;j++) {
					tmppt[j]+=u*v[j];
				}
			}
			let dist=den>0?0:Infinity;
			for (let i=0;i<dim;i++) {
				let d=tmppt[i]-point[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let tmp=bary;
				bary=minbary;
				minbary=tmp;
			}
		}
	}
	let den=0;
	for (let i=0;i<dim;i++) {den+=minbary[i];}
	for (let i=0;i<dim;i++) {minbary[i]/=den;}
	return minbary;
}


function FindBarycenter6(verts,point,dim) {
	// Find direction from current estimation to point.
	// Find point most colinear with this direction.
	// Nudge current estimation towards point.
	let tmppt=new Vector(dim);
	let tmpdir=new Vector(dim);
	let mindist=point.dist2(verts[0]);
	let bary=new Vector(dim);
	bary[0]=1;
	let minbary=new Vector(bary);
	let scale=1;
	for (let iter=0;iter<128;iter++) {
		tmpdir.set(0);
		for (let i=0;i<dim;i++) {
			let u=bary[i],v=verts[i];
			for (let j=0;j<dim;j++) {
				tmpdir[j]+=u*v[j];
			}
		}
		let dist=0;// ,off=0;
		for (let i=0;i<dim;i++) {
			tmppt[i]=tmpdir[i];
			let d=point[i]-tmpdir[i];
			dist+=d*d;
			// off+=d*tmpdir[i];
			tmpdir[i]=d;
		}
		if (mindist>dist) {
			mindist=dist;
			minbary.set(bary);
		}
		let norm=1/(Math.sqrt(dist)+1e-20);
		tmpdir.imul(norm);
		let max=0,min=0;
		for (let i=0;i<dim;i++) {
			let v=verts[i].sub(tmppt);
			let mag=v.mag();
			let w=v.imul(1/(mag+1e-20)).mul(tmpdir);
			min=min<w?min:w;
			max=max>w?max:w;
			bary[i]=w;
		}
		// if (max<1e-20) {break;}
		max=max>-min?max:-min;
		let den=0;// scale=1/(max*(1<<iter));
		for (let i=0;i<dim;i++) {
			let w=minbary[i]+bary[i]*scale;
			w=w>0?w:0;
			bary[i]=w;
			den+=w;
		}
		den=den>1e-20?1/den:NaN;
		for (let i=0;i<dim;i++) {
			bary[i]*=den;
		}
		scale*=0.95;
	}
	return minbary;
}


function FindBarycenter7(verts,point,dim) {
	let tmppt=new Vector(dim);
	let tmpvert=new Array(dim);
	let baryvec=new Array(dim);
	for (let i=0;i<dim;i++) {
		tmpvert[i]=new Vector(dim);
		baryvec[i]=new Vector(dim);
	}
	let bary=new Vector(dim);
	let minbary=new Vector(dim);
	let mindist=Infinity;
	let combos=1<<dim;
	for (let combo=1;combo<combos;combo++) {
		let vecs=0;
		for (let i=0;i<dim;i++) {
			if ((combo>>>i)&1) {
				tmpvert[vecs++].set(verts[i]);
			}
		}
		vecs--;
		let mat=new Matrix(vecs,vecs);
		for (let i=1;i<=vecs;i++) {
			tmpvert[i].isub(tmpvert[0]);
		}
		for (let i=0;i<vecs;i++) {
			for (let j=0;j<=i;j++) {
				let dot=tmpvert[i+1].mul(tmpvert[j+1]);
				mat[i*vecs+j]=dot;
				mat[j*vecs+i]=dot;
			}
		}
		try {mat=mat.inv();}
		catch {console.log("no inv");continue;}
		//          baryvec
		// u1=(inv11*v1+inv12*v2+inv13*v3+...)*(P-v0)
		// u2=(inv21*v1+inv22*v2+inv23*v3+...)*(P-v0)
		for (let i=0;i<vecs;i++) {
			let b=baryvec[i];
			b.set(0);
			for (let j=0;j<vecs;j++) {
				let u=mat[i*vecs+j],v=tmpvert[j+1];
				for (let k=0;k<dim;k++) {b[k]+=u*v[k];}
			}
		}
		// u[i]=baryvec[i]*(P-v0)
		tmppt.set(point).isub(tmpvert[0]);
		let sum=0;
		for (let i=0;i<vecs;i++) {
			let u=baryvec[i].mul(tmppt);
			if (u<0) {sum=Infinity;break;}
			bary[i+1]=u;
			sum+=u;
		}
		if (sum>1) {continue;}
		bary[0]=1-sum;
		tmppt.set(0);
		for (let i=dim-1;i>=0;i--) {
			let u=0,v=verts[i];
			if ((combo>>>i)&1) {u=bary[vecs--];}
			bary[i]=u;
			for (let j=0;j<dim;j++) {
				tmppt[j]+=u*v[j];
			}
		}
		let dist=tmppt.dist2(point);
		if (mindist>dist) {
			mindist=dist;
			minbary.set(bary);
			// console.log(dist);
		}
	}
	return minbary;
}


function FindBarycenter8(vertarr,point) {
	// Find the closest point in a simplex to another point.
	// We iterate over all 2^n sets of vertices and use linear
	// algebra to compute the barycenter coordinates of each set.
	let dim=point.length,verts=dim;
	let difvert=new Array(dim*dim);
	let minbary=new Array(verts);
	let mat=new Array(dim*(dim-1));
	let mindist=Infinity;
	let combos=1<<verts;
	for (let combo=1;combo<combos;combo++) {
		// di = vi - v0
		// dP =  P - v0, put in row 0
		let cols=0,vidx=0,v0=null;
		for (let i=0;i<verts;i++) {
			if ((combo>>>i)&1) {
				let v=vertarr[i];
				if (!cols++) {v0=v;v=point;}
				for (let j=0;j<dim;j++) {difvert[vidx++]=v[j]-v0[j];}
			}
		}
		// Create matrix. Note the solution column is on the left for efficiency.
		// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
		// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
		let rows=cols-1,elems=rows*cols;
		for (let i=1;i<cols;i++) {
			let rvec=i*dim;vidx=0;
			for (let j=0;j<=i;j++) {
				let dot=0;
				for (let k=0;k<dim;k++) {
					dot+=difvert[rvec+k]*difvert[vidx++];
				}
				mat[(i-1)*cols+j]=dot;
				if (j) {mat[(j-1)*cols+i]=dot;}
			}
		}
		// Row reduce the matrix.
		// [ u3 | 0 0 1 ]
		// [ u2 | 0 1 0 ]
		// [ u1 | 1 0 0 ]
		let u0=1;
		for (let i=0;i<rows;i++) {
			// Find the largest element in column i.
			let row=i*cols,off=cols-i-1,last=row+off;
			let src=0,max=0;
			for (let r=last;r<elems;r+=cols) {
				let x=mat[r],a=x>0?x:-x;
				if (max<a) {max=a;src=r;}
			}
			if (max<1e-10) {u0=-1;break;}
			// Normalize and move picked row.
			let norm=1/mat[src],dst=last;
			while (dst>=row) {
				let a=mat[dst],b=mat[src];
				mat[src--]=a;
				mat[dst--]=b*norm;
			}
			// Reduce other rows.
			for (let r=off;r<elems;r+=cols) {
				if (r===last) {continue;}
				dst=r;src=last;
				let mul=mat[dst];
				while (src>row) {
					mat[--dst]-=mul*mat[--src];
				}
			}
		}
		if (u0<0) {continue;}
		// The first column holds the barycenter coordinates.
		// Caclulate dP-u1*d1-u2*d2-...
		vidx=dim;
		for (let i=1;i<=rows;i++) {
			let u=mat[elems-i*cols];
			if (u<0) {u0=-1;break;}
			for (let j=0;j<dim;j++) {
				difvert[j]-=u*difvert[vidx++];
			}
			u0-=u;
		}
		if (u0<0) {continue;}
		// Calculate distance = dP*dP.
		let dist=0;
		for (let i=0;i<dim;i++) {
			let d=difvert[i];
			dist+=d*d;
		}
		if (mindist>dist) {
			mindist=dist;
			let j=elems;
			for (let i=0;i<verts;i++) {
				let u=0;
				if ((combo>>>i)&1) {
					u=j<elems?mat[j]:u0;
					j-=cols;
				}
				minbary[i]=u;
			}
		}
	}
	return minbary;
}


function FindBarycenter9(vertarr,point) {
	// Given the current guess, pick a vertex and project towards
	// or away from it.
	// dir=vert[i]-min
	// proj=(p-min)*dir/dir^2
	// u[j]*=1-proj
	// u[i]+=proj
	let dim=point.length,verts=dim;
	if (verts<=0) {return [];}
	let minbary=new Array(verts);
	let minpos=new Array(dim);
	minbary.fill(0);
	minbary[0]=1;
	for (let i=0;i<dim;i++) {minpos[i]=vertarr[0][i];}
	for (let iter=0;iter<dim*2;iter++) {
		for (let i=0;i<verts;i++) {
			// Calculate projection
			// d=v-min
			// u=(p-min)*d/(d*d)
			let num=0,den=0,v=vertarr[i];
			for (let j=0;j<dim;j++) {
				let x=minpos[j],d=v[j]-x;
				num+=(point[j]-x)*d;
				den+=d*d;
			}
			if (den<1e-20) {continue;}
			let nu=num/den;
			nu=nu<1?nu:1;
			// Scale coefficients.
			let sum=0;
			for (let j=0;j<verts;j++) {
				let u=minbary[j]*(1-nu)+(j===i?nu:0);
				u=u>0?u:0;
				minbary[j]=u;
				sum+=u;
			}
			if (sum<1e-10) {sum=1;minbary[iter%verts]=1;}
			sum=1/sum;
			minpos.fill(0);
			for (let j=0;j<verts;j++) {
				let u=minbary[j]*=sum;
				v=vertarr[j];
				for (let k=0;k<dim;k++) {
					minpos[k]+=u*v[k];
				}
			}
		}
	}
	return minbary;
}


function BarycenterTest() {
	console.log("testing barycenter calculation");
	let tests=1000;
	let dims=6;
	let rnd=new Random();
	let sols=5;
	let distarr=new Array(sols);
	let errsum=new Array(sols);
	errsum.fill(0);
	for (let test=0;test<tests;test++) {
		// Generate points.
		let dim=rnd.mod(dims)+1;
		let vertarr=new Array(dim+1);
		let copyarr=new Array(dim+1);
		for (let i=0;i<=dim;i++) {
			let v=new Vector(dim);
			vertarr[i]=v;
			for (let j=0;j<dim;j++) {
				v[j]=(rnd.getf()-0.5)*Math.pow(2,rnd.getf()*32-16);
			}
			// Duplicate vertices to create edge cases.
			let dup=rnd.mod(2*dim);
			if (dup<i) {v.set(vertarr[dup]);}
			copyarr[i]=new Vector(v);
		}
		let point=vertarr[dim];
		// Find solutions.
		let solarr=[
			FindBarycenter1(vertarr,point,dim),
			FindBarycenter3(vertarr,point,dim),
			FindBarycenter4(vertarr,point,dim),
			FindBarycenter8(vertarr,point),
			FindBarycenter9(vertarr,point)
		];
		// Grade accuracy.
		let mindist=Infinity;
		let tmp=new Vector(dim);
		for (let s=0;s<sols;s++) {
			let bary=solarr[s];
			let dist=0,sum=0;
			for (let i=0;i<dim;i++) {tmp[i]=-point[i];}
			for (let i=0;i<dim;i++) {
				let u=bary[i],v=vertarr[i];
				if (!(u>=0)) {
					console.log(s,u);
					throw "u<0";
				}
				for (let j=0;j<dim;j++) {
					tmp[j]+=u*v[j];
				}
				sum+=u;
			}
			if (isNaN(sum) || Math.abs(sum-1)>1e-10) {
				console.log(s,sum);
				throw "sum!=1";
			}
			for (let i=0;i<dim;i++) {
				dist+=tmp[i]*tmp[i];
			}
			dist=Math.sqrt(dist);
			mindist=mindist<dist?mindist:dist;
			distarr[s]=dist;
		}
		for (let s=0;s<sols;s++) {
			let err=(Math.abs(distarr[s]-mindist)>mindist*0.01)|0;
			errsum[s]+=err;
			//if (s===4 && err) {console.log(mindist,distarr[s]);}
		}
		// Check if the data has been modified.
		for (let i=0;i<=dim;i++) {
			let a=vertarr[i];
			let b=copyarr[i];
			for (let j=0;j<dim;j++) {
				if (a[j]!==b[j]) {
					throw "data modified";
				}
			}
		}
	}
	for (let s=0;s<sols;s++) {
		console.log(`${s+1}: ${errsum[s]/tests}`);
	}
}


//---------------------------------------------------------------------------------
// Closest Unconstrained


function ClosestDist(vertarr,point,bary) {
	let verts=vertarr.length;
	let dim=point.length;
	let tmppt=point.neg();
	for (let i=0;i<verts;i++) {
		let u=bary[i];
		let v=vertarr[i];
		for (let j=0;j<dim;j++) {
			tmppt[j]+=u*v[j];
		}
	}
	let dist=0;
	for (let j=0;j<dim;j++) {
		let x=tmppt[j];
		dist+=x*x;
	}
	return Math.sqrt(dist);
}


function ClosestPoint1(vertarr,point) {
	// Use random perterbations to find the best barycenter.
	let verts=vertarr.length;
	let dim=point.length;
	let tmppt=new Vector(dim);
	let bary=new Vector(verts);
	let minbary=new Vector(verts);
	let mindist=Infinity;
	let rnd=new Random();
	let scale=0;
	for (let v of vertarr) {scale+=v.dist(point);}
	scale=scale/vertarr.length+1;
	for (let iter=0;iter<256;iter++) {
		//let scale=1/(1<<(iter&30));
		for (let pt=0;pt<128;pt++) {
			let norm=0;
			for (let i=0;i<verts;i++) {
				let u=minbary[i]+(rnd.getf()*2-1)*scale;
				bary[i]=u;
				norm+=u;
			}
			if (norm>-1e-10 && norm<1e-10) {continue;}
			tmppt.set(0);
			for (let i=0;i<verts;i++) {
				let u=bary[i]/norm;
				let v=vertarr[i];
				bary[i]=u;
				for (let j=0;j<dim;j++) {
					tmppt[j]+=u*v[j];
				}
			}
			let dist=0;
			for (let i=0;i<dim;i++) {
				let d=tmppt[i]-point[i];
				dist+=d*d;
			}
			if (mindist>dist) {
				mindist=dist;
				let tmp=bary;
				bary=minbary;
				minbary=tmp;
			}
		}
		scale*=0.88;
	}
	return minbary;
}


function ClosestPoint2(vertarr,point) {
	// Find the closest point in a set of vertices to another point.
	// Use linear algebra to compute the barycenter coordinates of each set.
	let verts=vertarr.length;
	let dim=point.length;
	let rows=verts-1,elems=rows*verts;
	let dif=new Array(verts*dim);
	let mat=new Array(elems);
	// di = vi - v0
	// dP =  P - v0, put in row 0
	let vidx=0;
	let v0=vertarr[0];
	for (let i=0;i<verts;i++) {
		let v=i?vertarr[i]:point;
		for (let j=0;j<dim;j++) {dif[vidx++]=v[j]-v0[j];}
	}
	// Create matrix. Note the solution column is on the left for efficiency.
	// [ d1*dP | d1*d1 d1*d2 d1*d3 ... ]
	// [ d2*dP | d2*d1 d2*d2 d2*d3 ... ]
	for (let i=1;i<verts;i++) {
		let rvec=i*dim;vidx=0;
		for (let j=0;j<=i;j++) {
			let dot=0;
			for (let k=0;k<dim;k++) {
				dot-=dif[rvec+k]*dif[vidx++];
			}
			mat[(i-1)*verts+j]=dot;
			if (j) {mat[(j-1)*verts+i]=dot;}
		}
	}
	// Row reduce the matrix.
	// [ u3 | 0 0 1 ]
	// [ u2 | 0 1 0 ]
	// [ u1 | 1 0 0 ]
	for (let i=0;i<rows;i++) {
		// Find the largest element in column i.
		let row=i*verts,off=rows-i,last=row+off;
		let src=0,dst=last;
		let max=0;
		for (let r=last;r<elems;r+=verts) {
			let x=mat[r],a=x>0?x:-x;
			if (max<a) {max=a;src=r;}
		}
		// Normalize and move picked row.
		let norm=max>1e-20?1/mat[src]:0;
		while (dst>=row) {
			let a=mat[dst],b=mat[src];
			mat[src--]=a;
			mat[dst--]=b*norm;
		}
		// Reduce other rows.
		for (let r=off;r<elems;r+=verts) {
			if (r===last) {continue;}
			dst=r;src=last;
			let mul=mat[dst];
			while (src>row) {
				mat[--dst]-=mul*mat[--src];
			}
		}
	}
	// The first column holds the barycenter coordinates.
	let bary=new Array(verts);
	let u0=1;
	for (let i=1;i<verts;i++) {
		let u=mat[elems-i*verts];
		bary[i]=u;
		u0-=u;
	}
	bary[0]=u0;
	return bary;
}


function ClosestTest() {
	console.log("testing closest point");
	let rnd=new Random(1);
	let tests=10000;
	let maxdim=10;
	function randpoint(dim,scale) {
		let v=new Vector(dim);
		for (let i=0;i<dim;i++) {v[i]=rnd.gets()*scale;}
		return v;
	}
	let sumdist1=0;
	let sumdist2=0;
	for (let test=0;test<tests;test++) {
		let dim=rnd.mod(maxdim+1);
		let verts=rnd.mod(dim+2);
		let point=randpoint(dim,10);
		let vertarr=new Array(verts);
		for (let i=0;i<verts;i++) {
			vertarr[i]=randpoint(dim,10);
		}
		let bary1=ClosestPoint1(vertarr,point);
		let bary2=ClosestPoint2(vertarr,point);
		let dist1=ClosestDist(vertarr,point,bary1);
		let dist2=ClosestDist(vertarr,point,bary2);
		if (dist2-dist1>1e-9) {
			console.log("dim  :",dim);
			console.log("verts:",verts);
			console.log("dist1:",dist1);
			console.log("dist2:",dist2);
			throw "error";
		}
		sumdist1+=dist1;
		sumdist2+=dist2;
	}
	console.log("sumdist1:",sumdist1);
	console.log("sumdist2:",sumdist2);
}


//---------------------------------------------------------------------------------
// Given D+1 verts, if a weight is negative, then that vert will be on the
// opposite side of the plane formed by the other verts.


function SimplexSideTest() {
	console.log("testing simplex side");
	let rnd=new Random(1);
	let tests=1000000;
	let maxdim=10;
	function randpoint(dim,scale) {
		let v=new Vector(dim);
		for (let i=0;i<dim;i++) {v[i]=rnd.gets()*scale;}
		return v;
	}
	for (let test=0;test<tests;test++) {
		if ((test&0xffff)===0) {console.log("test:",test);}
		let dim=rnd.mod(maxdim+1);
		let verts=dim+1;
		let point=randpoint(dim,10);
		let vertarr=new Array(verts);
		for (let i=0;i<verts;i++) {
			vertarr[i]=randpoint(dim,10);
		}
		let bary=ClosestPoint2(vertarr,point);
		// The most negative weight should be the least desirable vertex.
		let minw=Infinity;
		let mini=0;
		for (let i=0;i<verts;i++) {
			let w=bary[i];
			if (minw>w) {minw=w;mini=i;}
		}
		//console.log("minw:",minw,dim);
		// If the point is in the set, there's no vertex to remove.
		if (minw>=0) {continue;}
		// Swap the worst vertex to the end and calculate the direction from
		// the D vertices to P.
		let minv=vertarr[mini];
		vertarr[mini]=vertarr[verts-1];
		vertarr[verts-1]=minv;
		let vertnew=vertarr.slice(0,verts-1);
		bary=ClosestPoint2(vertnew,point);
		let norm=new Vector(point);
		for (let i=0;i<verts-1;i++) {
			norm.isub(vertarr[i].mul(bary[i]));
		}
		// Test if P and min(V) are on the opposite side of the plane.
		let baseproj=vertarr[0].mul(norm);
		let pproj=point.mul(norm)-baseproj;
		let vproj=minv.mul(norm)-baseproj;
		if (Math.abs(pproj)<1e-10 || Math.abs(vproj)<1e-10) {continue;}
		//console.log(pproj,vproj);
		if ((pproj<0)===(vproj<0)) {
			console.log("dim  :",dim);
			console.log("verts:",verts);
			console.log("pproj:",pproj);
			console.log("vproj:",vproj);
			throw "error";
		}
	}
}


//---------------------------------------------------------------------------------
// Main Test


function TestMain() {
	//BarycenterTest();
	//ClosestTest();
	SimplexSideTest();
	console.log("done");
}

TestMain();
/*

stack_anim.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


npm install -g require-from-string
npm install -g canvas

ffmpeg -f image2 -framerate 60 -i "./anim/anim_%04d.tga" anim.gif


*/
/* npx eslint stack_anim.js -c ../../../standards/eslint.js */
/* global Vector, Random */


//---------------------------------------------------------------------------------
// Includes


var requirestr=require("require-from-string");
var fileio=require("fs");
(function(){
	// NodeJS doesn't provide a clean way to include JS files written for browsers.
	var files=["../library.js","../physics.js"];
	var objects=["Draw","Random","Vector","PhyWorld","PhyAtom"];
	// Include everything.
	var libsrc="var ImageData=require('canvas').ImageData;\n";
	for (let file of files) {libsrc+=fileio.readFileSync(file)+"\n";}
	libsrc+="\nmodule.exports={"+objects.map((n)=>n+":"+n).join(",")+"};";
	let module=requirestr(libsrc);
	for (let name of objects) {global[name]=module[name];}
})();


//---------------------------------------------------------------------------------
// Main Script


function StackAnim(frames,mode) {
	// Setup the canvas
	let drawh=200;
	let draww=100;
	let vieww=draww/drawh;
	let draw=new Draw(draww,drawh);
	//
	let world=new PhyWorld(2);
	world.maxsteptime=Infinity;
	world.gravity.set([0,0.1]);
	let normtype=world.createatomtype(0.01,1.0,0.98);
	let rnd=new Random();
	let rad=0.006,px=rad,py=1-rad;
	for (let p=0;p<2000;p++) {
		// let pos=new Vector([px+rnd.getf()*rad,py+rnd.getf()*rad]);
		let pos=new Vector([rnd.getf()*vieww,rnd.getf()*1]);
		let atom=world.createatom(pos,rad,normtype);
		// px+=2*rad;
		// if (px>vieww-rad) {px=rad;py-=2*rad;}
		atom.velsum=0;
	}
	world.bndmin=new Vector([0,0]);
	world.bndmax=new Vector([vieww,1]);
	//
	PhyAtom.collideatom=function (a,b) {
		// Collides two atoms. Vector operations are unrolled to use constant memory.
		if (Object.is(a,b)) {return;}
		// Determine if the atoms are overlapping.
		const amass=0.5,bmass=0.5,vmul=0.98*2,vpmul=1,pmul=1;
		let apos=a.pos,bpos=b.pos;
		let dim=apos.length,i;
		let dist=0.0,dif,norm=a.world.tmpvec;
		for (i=0;i<dim;i++) {
			dif=bpos[i]-apos[i];
			norm[i]=dif;
			dist+=dif*dif;
		}
		let rad=a.rad+b.rad;
		if (dist>rad*rad) {return;}
		// If the atoms are too close together, randomize the direction.
		if (dist>1e-10) {
			dist=Math.sqrt(dist);
			dif=1.0/dist;
		} else {
			dist=0;
			dif=1.0;
			a.world.tmpvec.randomize();
		}
		// Check the relative velocity. We can have situations where two atoms increase
		// eachother's velocity because they've been pushed past eachother.
		let avel=a.vel,bvel=b.vel;
		let veldif=0.0;
		for (i=0;i<dim;i++) {
			norm[i]*=dif;
			veldif-=(bvel[i]-avel[i])*norm[i];
		}
		let posdif=rad-dist;
		if (mode===0) {
			veldif=veldif*vmul;
		} else if (mode===1) {
			veldif=veldif>0?veldif:0;
			veldif=veldif*vmul;
		} else if (mode===2) {
			veldif=veldif>0?veldif:0;
			veldif=veldif*vmul+posdif*vpmul;
		}
		posdif*=pmul;
		a.velsum+=Math.abs(veldif*bmass);
		b.velsum+=Math.abs(veldif*amass);
		// Push the atoms apart.
		let avelmul=veldif*bmass,bvelmul=veldif*amass;
		let aposmul=posdif*bmass,bposmul=posdif*amass;
		for (i=0;i<dim;i++) {
			dif=norm[i];
			apos[i]-=dif*aposmul;
			avel[i]-=dif*avelmul;
			bpos[i]+=dif*bposmul;
			bvel[i]+=dif*bvelmul;
		}
	};
	//
	for (let frame=0;frame<frames;frame++) {
		world.update(1/60);
		draw.fill(0,0,0,255);
		// draw.setscale(viewscale,viewscale);
		let link=world.atomlist.head;
		while (link!==null) {
			let atom=link.obj;
			link=link.next;
			let x=atom.pos[0]*drawh,y=atom.pos[1]*drawh,rad=atom.rad*drawh;
			let u=atom.velsum*.25;
			u=u>0?(u<1?u:1):0;
			draw.setcolor(255*u,0,255*(1-u),255);
			draw.filloval(x,y,rad,rad);
			atom.velsum*=0.98;
		}
		/*let data8=draw.img.data8;
		let pixels=data8.length;
		for (let i=0;i<pixels;i+=4) {
			let r=data8[i],g=data8[i+1],b=data8[i+2];
			if (r+g+b<254) {
				data8[i+0]=0;
				data8[i+1]=0;
				data8[i+2]=0;
				data8[i+3]=255;
			}
		}*/
		//
		let path="/media/veracrypt1/Downloads/anim/anim_"+frame.toString().padStart(4,"0")+".tga";
		data8=draw.img.totga();
		fileio.writeFileSync(path,data8);
		console.log(path);
	}
}

StackAnim(600,2);

#!/usr/bin/python3
"""
sudo apt install binaryen
"""

import os,re,sys,shutil,gzip,base64

# Compile
outpath="broadphase.wasm"
comp="clang broadphase_wasm.c --target=wasm32 -O1 -flto -nostdlib -fno-builtin-memset --no-standard-libraries -Wl,--stack-first -Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined -Wl,--lto-O3 --output "+outpath
if os.path.isfile(outpath): os.remove(outpath)
print(comp)
os.system(comp)

# Optimize
optpath="broadphase_opt.wasm"
comp="wasm-opt "+outpath+" -o "+optpath+" -O3"
if os.path.isfile(optpath): os.remove(optpath)
print(comp)
os.system(comp)
outpath=optpath

if os.path.isfile(outpath):
	wasmdata=open(outpath,"rb").read()
	#wasmcomp=gzip.compress(wasmdata)
	out64="broadphase_wasm_64.txt"
	#str64=base64.b64encode(wasmcomp).decode("utf-8")
	str64=base64.b64encode(wasmdata).decode("utf-8")
	l=len(str64)
	str64="\n".join([str64[i:min(i+80,l)] for i in range(0,l,80)])
	with open(out64,"w") as f: f.write(str64)

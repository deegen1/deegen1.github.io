/*------------------------------------------------------------------------------


physics.js - v3.13

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


With enough atoms and bonds, anything can be simulated.
Atoms can overlap if they're bonded.
Two atoms will only collide once a step.


--------------------------------------------------------------------------------
History


1.00
     Initial version. Copied from C engine.
1.21
     Tweaks for performance improvement in javascript.
1.22
     The simulation can now use a variable timestep.
2.00
     Rewrote broadphase to use recursive subdivision instead of cells.
     Broadphase will no longer collide 2 atoms multiple times a step.
2.01
     Broadphase now uses a BVH instead of subdivided regions.
3.00
     Bonds now apply acceleration but modify pos and vel directly for stability.
     Added iterators.
3.01
     Atoms can now go to sleep. The BVH will ignore sleeping nodes.
3.02
     Removed collide flag in favor of callbacks.
     Allowed multiple bonds between 2 atoms. This effectively allows multiple
     iterations per bond per timestep.
3.03
     Electrostatic bonds can form during atom collisions.
     Bonds can break if they're too far apart.
     Added .data fields to atoms, bonds, and atomtypes.
     Added stepcallback() to allow manual tweaks before each timestep.
3.04
     Fixed autobond creating multiple bonds.
3.05
     Added createshape() to dynamically fill shapes.
3.06
     In createshape, used barycentric magnitude to emphasize vertices and
     edges. Fixed bond distance calculations for greedy filling.
3.07
     Changed atom type callback to a global collision callback.
3.08
     Fixed double releasing atoms and bonds.
3.09
     Fixed memory allocation for broadphase BVH.
3.10
     Reordered collcallback() to allow tweaking the AtomInteraction.
3.11
     Push coefficient now scales with dt.
     Damping coefficients are updated per-loop, instead of per-atom.
3.12
     Sped up createshape() 5x by unrolling vector operations.


--------------------------------------------------------------------------------
TODO


Grid
	prev/next
	atomnext
	Randomize order of active atoms
	List all unique atoms in same cells if:
		!other.added and (other.sleeping or other.id>atom.id)
	set flag on other atom to avoid duplicates
	randomize order and collide
	remove flag while processing
	auto adjust size if celldim+-25% or mask has changed

createshape
	Inside/outside test for dim>2.
	Simplex distance calculation for dim>2.
	Instead of checking each cell for overlap with atoms, remove cells every
	time an atom is created.
	Why are there sometimes holes?
	sort:
		outline first, then center outward
		sort=dist>-1e-10?bary.sqr():1/dist
	cell:
		idx
		hash
		sort
		dist
		pos
	After filling a cell, update dist for everything within 2*rad
	remove autobond and createbox

callbacks
	atomdelcallback
	bonddelcallback
	process deletions at start of main loop
	add to release queue

Reduce closestpoint() from 2^N steps to N.
Remove world bounds. Add to timestep in demo.
Add static bonds to article.
New article: friction with springs.
Remove static bonds if another bond is formed afterwards?
Motors: linear, angular, range. Add acceleration?


*/
/* npx eslint physics.js -c ../../standards/eslint.js */


import {Random,Vector,Transform} from "./library.js";


//---------------------------------------------------------------------------------
// Physics - v3.13


class PhyLink {

	constructor(obj) {
		this.prev=null;
		this.next=null;
		this.list=null;
		this.obj=obj??null;
		this.idx=null;
	}


	release() {
		this.remove();
	}


	add(list) {
		if (this.list!==list) {list.add(this);}
	}


	remove(clear) {
		if (this.list!==null) {this.list.remove(this,clear);}
	}

}


class PhyList {

	constructor(ptr=null) {
		this.head=null;
		this.tail=null;
		this.ptr=ptr;
		this.count=0;
	}


	release(clear) {
		let link=this.head;
		while (link!==null) {
			let next=link.next;
			link.prev=null;
			link.next=null;
			link.list=null;
			if (clear) {link.obj=null;}
			link=next;
		}
		this.count=0;
	}


	*iter() {
		let link=null,next=this.head;
		while ((link=next)!==null) {
			next=link.next;
			yield link.obj;
		}
	}


	add(link) {
		this.addafter(link);
	}


	addafter(link,prev=null) {
		// Inserts the link after prev.
		link.remove();
		let next=null;
		if (prev!==null) {
			next=prev.next;
			prev.next=link;
		} else {
			next=this.head;
			this.head=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (next!==null) {
			next.prev=link;
		} else {
			this.tail=link;
		}
		this.count++;
	}


	addbefore(link,next=null) {
		// Inserts the link before next.
		link.remove();
		let prev=null;
		if (next!==null) {
			prev=next.prev;
			next.prev=link;
		} else {
			prev=this.tail;
			this.tail=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (prev!==null) {
			prev.next=link;
		} else {
			this.head=link;
		}
		this.count++;
	}


	remove(link,clear) {
		if (link===null) {
			return;
		}
		let prev=link.prev;
		let next=link.next;
		if (prev!==null) {
			prev.next=next;
		} else {
			this.head=next;
		}
		if (next!==null) {
			next.prev=prev;
		} else {
			this.tail=prev;
		}
		this.count--;
		link.prev=null;
		link.next=null;
		link.list=null;
		if (clear) {link.obj=null;}
	}

}


class PhyAtomInteraction {

	constructor(a,b) {
		this.world=a.world;
		this.worldlink=new PhyLink(this);
		this.world.intrlist.add(this.worldlink);
		this.a=a;
		this.b=b;
		this.pmul=0;
		this.vmul=0;
		this.vpmul=0;
		this.dt=NaN;
		this.push0=0;
		this.statictension=0;
		this.staticdist=0;
		this.updateconstants();
	}


	updateconstants() {
		let a=this.a,b=this.b;
		this.pmul=(a.pmul+b.pmul)*0.5;
		this.vmul=a.vmul+b.vmul;
		this.vpmul=(a.vpmul+b.vpmul)*0.5;
		this.statictension=(a.statictension+b.statictension)*0.5;
		this.staticdist=(a.staticdist+b.staticdist)*0.5;
	}


	calcdt(dt) {
		if (this.dt===dt) {return;}
		this.dt=dt;
		let ipush=1-this.pmul;
		this.push0=ipush>0?1-Math.pow(ipush,dt):1;
	}


	static get(a,b) {
		if (a.type!==undefined) {a=a.type;}
		if (b.type!==undefined) {b=b.type;}
		return a.intarr[b.id];
	}

}


class PhyAtomType {

	constructor(world,id,damp,density,elasticity=1,push=1,statictension=50) {
		this.world=world;
		this.worldlink=new PhyLink(this);
		this.atomlist=new PhyList();
		this.id=id;
		this.intarr=[];
		this.damp=damp;
		this.density=density;
		this.pmul=push;
		this.vmul=elasticity;
		this.vpmul=1.0;
		this.statictension=statictension;
		this.staticdist=1.0;
		this.bound=true;
		this.dt =NaN;
		this.dt0=0;
		this.dt1=0;
		this.dt2=0;
		this.gravity=null;
		this.data={};
	}


	release() {
		let id=this.id;
		let link=this.world.typelist.head;
		while (link!==null) {
			link.obj.intarr[id]=null;
			link=link.next;
		}
		this.atomlist.clear();
		this.worldlink.remove();
	}


	updateconstants(dt) {
		// We want to solve for dt0, dt1, dt2, and dt3 in our integration equations.
		//
		//      pos+=vel*dt2+accel*dt3
		//      vel =vel*dt0+accel*dt1
		//
		// ----------------------------------------
		//
		// It's easiest to ignore acceleration and solve for dt0 first. If we continuously
		// apply damping over time t to vel, we get
		//
		//      vel(t)=vel(0)*(1-damp)^t
		//
		// Applying dt0 every step gets us
		//
		//      vel(s)=vel(0)*dt0^s
		//
		// We define dt=t/steps, hence we want to find dt0 when s=t/dt.
		//
		//      vel(s)=vel(0)*dt0^(t/dt)
		//
		// Solving
		//
		//      vel(0)*dt0^(t/dt)=vel(0)*(1-damp)^t
		//      dt0^(t/dt)=(1-damp)^t
		//      ln(dt0^(t/dt))=ln((1-damp)^t)
		//      (t/dt)*ln(dt0)=t*ln(1-damp)
		//      dt0=e^(dt*ln(1-damp))
		//
		// ----------------------------------------
		//
		// To calculate dt1, integrate the derivative for the velocity
		//
		//      v'(t)=ln(1-damp)*v(t)+accel0
		//      v(0)=vel0
		//
		// We will have
		//
		//      d=1-damp
		//      v(t)=vel0*d^t+accel0*(d^t-1)/ln(d)
		//      v(t)=vel0*dt0+accel0*(dt0-1)/ln(d)
		//      dt1=(dt0-1)/ln(1-damp)
		//
		// ----------------------------------------
		//
		// To calculate dt2 and dt3, integrate the derivate for the position
		//
		//      p'(t)=v(t)
		//      p(0)=pos0
		//
		// We will have
		//
		//      d=1-damp
		//      p'(t)=vel0*d^t+accel0*(d^t-1)/ln(d)
		//      p(t)=pos0+vel0*(d^t-1)/ln(d)+accel0*((d^t-1)/ln(d)-t)/ln(d)
		//      p(t)=pos0+vel0*dt1+accel0*(dt1-t)/ln(d)
		//      dt2=dt1
		//      dt3=(dt1-dt)/ln(1-damp)
		//
		this.dt=dt;
		let damp=this.damp,idamp=1.0-damp;
		let dt0=0,dt1=0,dt2=0;
		if (damp<=1e-10) {
			// Special case damping=0: just integrate.
			dt0=1.0;
			dt1=dt;
			dt2=dt*dt*0.5;
		} else if (idamp<=1e-10) {
			// Special case damping=1: all velocity=0.
			// If dt=0 then time isn't passing, so maintain velocity.
			dt0=(dt>=-1e-20 && dt<=1e-20)?1.0:0.0;
			dt1=0.0;
			dt2=0.0;
		} else {
			// Normal case.
			let lnd=Math.log(idamp);
			dt0=Math.exp(dt*lnd);
			dt1=(dt0-1.0)/lnd;
			dt2=(dt1-dt )/lnd;
		}
		this.dt0=dt0;
		this.dt1=dt1;
		this.dt2=dt2;
	}


	updateinteractions() {
		let intarr=this.intarr;
		for (let i=intarr.length-1;i>=0;i--) {
			intarr[i].updateconstants();
		}
	}


	static initinteraction(a,b) {
		let inter=new PhyAtomInteraction(a,b);
		while (a.intarr.length<=b.id) {a.intarr.push(null);}
		while (b.intarr.length<=a.id) {b.intarr.push(null);}
		a.intarr[b.id]=inter;
		b.intarr[a.id]=inter;
	}

}


class PhyAtom {

	constructor(pos,rad,type) {
		this.worldlink=new PhyLink(this);
		this.world=type.world;
		this.world.atomlist.addbefore(this.worldlink);
		this.deleted=false;
		this.sleeping=false;
		this.updatetime=0;
		pos=new Vector(pos);
		this.pos=pos;
		this.vel=new Vector(pos.length);
		this.rad=rad;
		this.bondlist=new PhyList();
		this.typelink=new PhyLink(this);
		this.type=type;
		type.atomlist.add(this.typelink);
		this.data={};
		this.updateconstants();
	}


	release() {
		if (this.deleted) {return;}
		this.deleted=true;
		let link=null;
		while ((link=this.bondlist.head)!==null) {
			link.obj.release();
		}
		this.typelink.remove();
		this.worldlink.remove();
	}


	bonditer() {return this.bondlist.iter();}


	updateconstants() {
		// Calculate the mass of the atom, where mass=volume*density.
		let dim=this.pos.length;
		let mass=this.type.density;
		if (dim>0) {
			let vol0=mass,rad=this.rad;
			let volmul=rad*rad*6.283185307;
			mass*=2.0*rad;
			for (let i=2;i<=dim;i++) {
				let vol1=vol0*volmul/i;
				vol0=mass;
				mass=vol1;
			}
		}
		this.mass=mass;
	}


	update() {
		// Move the particle and apply damping to the velocity.
		// acc+=gravity
		// pos+=vel*dt1+acc*dt2
		// vel =vel*dt0+acc*dt1
		let world=this.world;
		let bndmin=world.bndmin;
		let bndmax=world.bndmax;
		let pe=this.pos,ve=this.vel;
		let dim=pe.length,type=this.type;
		let bound=type.bound;
		let ge=type.gravity;
		ge=(ge===null?this.world.gravity:ge);
		let dt0=type.dt0,dt1=type.dt1,dt2=type.dt2;
		let rad=this.rad,energy=0;
		for (let i=0;i<dim;i++) {
			let vel=ve[i],acc=ge[i];
			let pos=vel*dt1+acc*dt2+pe[i];
			vel=vel*dt0+acc*dt1;
			let b=bound?bndmin[i]+rad:-Infinity;
			if (pos<b) {pos=b;vel=vel<0?-vel:vel;}
			b=bound?bndmax[i]-rad:Infinity;
			if (pos>b) {pos=b;vel=vel>0?-vel:vel;}
			pe[i]=pos;
			ve[i]=vel;
			energy+=vel*vel;
		}
		this.sleeping=energy<1e-10;
		this.updatetime=0;
	}


	static collide(a,b) {
		// Collides two atoms. Vector operations are unrolled to use constant memory.
		if (a===b || a.deleted || b.deleted) {return;}
		// Determine if the atoms are overlapping.
		let apos=a.pos,bpos=b.pos;
		let dim=apos.length;
		let dist=0.0,norm=a.world.tmpvec;
		for (let i=0;i<dim;i++) {
			let dif=bpos[i]-apos[i];
			norm[i]=dif;
			dist+=dif*dif;
		}
		let rad=a.rad+b.rad;
		if (dist>=rad*rad) {return;}
		// Bonds can limit the distance between the atoms.
		let b0=a,b1=b;
		if (a.bondlist.count>b.bondlist.count) {b0=b;b1=a;}
		let link=b0.bondlist.head;
		let bonded=null;
		while (link!==null) {
			let bond=link.obj;
			link=link.next;
			if (bond.a===b1 || bond.b===b1) {
				rad=rad<bond.dist?rad:bond.dist;
				bonded=bond;
			}
		}
		if (dist>=rad*rad) {return;}
		let amass=a.mass,bmass=b.mass;
		let mass=amass+bmass;
		if ((amass>=Infinity && bmass>=Infinity) || mass<=1e-10 || dim===0) {
			return;
		}
		amass=amass>=Infinity? 1.0: amass/mass;
		bmass=bmass>=Infinity?-1.0:-bmass/mass;
		// If the atoms are too close together, randomize the direction.
		let den=1;
		if (dist>1e-10) {
			dist=Math.sqrt(dist);
			den=1.0/dist;
		} else {
			norm.randomize();
		}
		// Check the relative velocity. We can have situations where two atoms increase
		// eachother's velocity because they've been pushed past eachother.
		let avel=a.vel,bvel=b.vel;
		let veldif=0.0;
		for (let i=0;i<dim;i++) {
			norm[i]*=den;
			veldif+=(avel[i]-bvel[i])*norm[i];
		}
		let posdif=rad-dist;
		// If we have a callback, allow it to handle the collision.
		let intr=a.type.intarr[b.type.id];
		let callback=a.world.collcallback;
		if (callback!==null && !callback(intr,a,b,norm,veldif,posdif,bonded)) {return;}
		posdif*=intr.push0;
		veldif=veldif>0?veldif:0;
		veldif=veldif*intr.vmul+posdif*intr.vpmul;
		// Create an electrostatic bond between the atoms.
		if (bonded===null && intr.statictension>0) {
			let bond=a.world.createbond(a,b,rad,intr.statictension);
			bond.breakdist=rad+(a.rad<b.rad?a.rad:b.rad)*intr.staticdist;
		}
		// Push the atoms apart.
		let aposmul=posdif*bmass,avelmul=veldif*bmass;
		let bposmul=posdif*amass,bvelmul=veldif*amass;
		for (let i=0;i<dim;i++) {
			let dif=norm[i];
			apos[i]+=dif*aposmul;
			avel[i]+=dif*avelmul;
			bpos[i]+=dif*bposmul;
			bvel[i]+=dif*bvelmul;
		}
	}

}


class PhyBond {

	constructor(world,a,b,dist,tension) {
		this.world=world;
		this.worldlink=new PhyLink(this);
		this.world.bondlist.add(this.worldlink);
		this.deleted=false;
		this.a=a;
		this.b=b;
		this.dist=dist;
		this.breakdist=Infinity;
		this.tension=tension;
		this.alink=new PhyLink(this);
		this.blink=new PhyLink(this);
		this.a.bondlist.add(this.alink);
		this.b.bondlist.add(this.blink);
		this.data={};
	}


	release () {
		if (this.deleted) {return;}
		this.deleted=true;
		this.alink.remove();
		this.blink.remove();
		this.worldlink.remove();
	}


	update() {
		// Pull two atoms toward eachother based on the distance and bond strength.
		// Vector operations are unrolled to use constant memory.
		let a=this.a,b=this.b;
		if (this.deleted || (a.sleeping && b.sleeping)) {return;}
		let amass=a.mass,bmass=b.mass;
		let mass=amass+bmass;
		if ((amass>=Infinity && bmass>=Infinity) || mass<=1e-10) {
			return;
		}
		amass=amass>=Infinity? 1.0: amass/mass;
		bmass=bmass>=Infinity?-1.0:-bmass/mass;
		// Get the distance and direction between the atoms.
		let apos=a.pos,bpos=b.pos;
		let dim=apos.length;
		let norm=a.world.tmpvec;
		let dist=0.0;
		for (let i=0;i<dim;i++) {
			let dif=bpos[i]-apos[i];
			norm[i]=dif;
			dist+=dif*dif;
		}
		// If the atoms are too close together, randomize the direction.
		let tension=this.tension;
		if (dist>1e-10) {
			dist=Math.sqrt(dist);
			tension/=dist;
		} else {
			norm.randomize();
		}
		if (dist>this.breakdist) {
			this.release();
			return;
		}
		// Apply equal and opposite acceleration. Updating pos and vel in this
		// function, instead of waiting for atom.update(), increases stability.
		let at=a.type,bt=b.type;
		let acc=(this.dist-dist)*tension;
		let aacc=acc*bmass,aposmul=aacc*at.dt2,avelmul=aacc*at.dt1;
		let bacc=acc*amass,bposmul=bacc*bt.dt2,bvelmul=bacc*bt.dt1;
		let avel=a.vel,bvel=b.vel;
		for (let i=0;i<dim;i++) {
			let dif=norm[i];
			apos[i]+=dif*aposmul;
			avel[i]+=dif*avelmul;
			bpos[i]+=dif*bposmul;
			bvel[i]+=dif*bvelmul;
		}
	}

}


//---------------------------------------------------------------------------------
// Cell based broadphase. Collisions not unique.


class PhyCell {

	constructor() {
		this.dist=0;
		this.atom=null;
		this.hash=0;
		this.next=null;
		// this.prev=null;
		// this.atomnext=null;
	}

}


class PhyBroadphase {

	constructor(world) {
		this.world=world;
		this.slack=1.05;
		this.cellarr=[];
		this.celldim=0.05;
		this.cellmap=[];
		this.mapused=0;
		this.hash0=0;
	}


	release() {
		this.cellarr=[];
		this.cellmap=[];
	}


	getcell(point) {
		if (this.mapused===0) {return null;}
		let dim=this.world.dim,celldim=this.celldim;
		let hash=this.hash0,x;
		for (let d=0;d<dim;d++) {
			x=Math.floor(point[d]/celldim);
			hash=Random.hashu32(hash+x);
		}
		return this.cellmap[hash&(this.mapused-1)];
	}


	testcell(newcell,oldcell,point,d,off) {
		// Tests if the fast distance computation matches the actual distance.
		let world=this.world;
		let dim=world.dim,i;
		let coord=newcell.coord;
		if (coord===undefined) {
			coord=new Array(dim);
			newcell.coord=coord;
		}
		let hash=this.hash0;
		let celldim=this.celldim;
		if (oldcell!==null) {
			for (i=0;i<dim;i++) {coord[i]=oldcell.coord[i];}
			coord[d]+=off;
			for (i=0;i<=d;i++) {hash=Random.hashu32(hash+coord[i]);}
		} else {
			for (i=0;i<dim;i++) {coord[i]=Math.floor(point[i]/celldim);}
		}
		if (newcell.hash!==hash) {
			console.log("hash mismatch");
			throw "error";
		}
		let rad=newcell.atom.rad*this.slack;
		let dist=-rad*rad;
		for (i=0;i<dim;i++) {
			let x0=coord[i]*celldim;
			let x1=x0+celldim;
			let x=point[i];
			if (x<x0) {
				x-=x0;
				dist+=x*x;
			} else if (x>x1) {
				x-=x1;
				dist+=x*x;
			}
		}
		if (Math.abs(newcell.dist-dist)>1e-10) {
			console.log("dist drift");
			throw "error";
		}
	}


	build() {
		// Find all cells that an atom overlaps and add that atom to a linked list in the
		// cell.
		//
		// To find the cells that overlap a atom, first create a cell at the center of the
		// atom. Then expand along the X axis until we reach the edge. For each of these
		// cells, expand along the Y axis until we reach the edge. Continue for each
		// dimension.
		//
		//                                                                  +--+
		//                                                                  |  |
		//                                                               +--+--+--+
		//                                                               |  |  |  |
		//      +--+        +--+--+--+        +--+--+--+--+--+        +--+--+--+--+--+
		//      |  |   ->   |  |  |  |   ->   |  |  |  |  |  |   ->   |  |  |  |  |  |
		//      +--+        +--+--+--+        +--+--+--+--+--+        +--+--+--+--+--+
		//                                                               |  |  |  |
		//                                                               +--+--+--+
		//                                                                  |  |
		//                                                                  +--+
		//
		//    Start at      Expand along      Continue until we        Expand along Y
		//    center.       X axis.           reach the edge.          axis.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcount=world.atomlist.count;
		this.mapused=0;
		if (atomcount===0) {
			return;
		}
		// Randomize the order of the atoms.
		let cellmap=this.cellmap;
		while (atomcount>cellmap.length) {
			cellmap=cellmap.concat(new Array(cellmap.length+1));
		}
		let rnd=world.rnd;
		let atomlink=world.atomlist.head;
		let celldim=0.0;
		let atom;
		for (let i=0;i<atomcount;i++) {
			atom=atomlink.obj;
			atomlink=atomlink.next;
			celldim+=atom.rad;
			let j=rnd.getu32()%(i+1);
			cellmap[i]=cellmap[j];
			cellmap[j]=atom;
		}
		// Use a heuristic to calculate celldim.
		let slack=this.slack;
		celldim*=2.5*slack/atomcount;
		let hash0=rnd.getu32();
		this.celldim=celldim;
		this.hash0=hash0;
		let invdim=1.0/celldim;
		let celldim2=2.0*celldim*celldim;
		let cellend=0;
		let cellarr=this.cellarr;
		let cellalloc=cellarr.length;
		let hashu32=Random.hashu32;
		let floor=Math.floor;
		for (let i=0;i<atomcount;i++) {
			atom=cellmap[i];
			let rad=atom.rad*slack;
			// Make sure we have enough cells.
			let radcells=floor(rad*2*invdim+2.1);
			let combo=radcells;
			for (let d=1;d<dim;d++) {combo*=radcells;}
			while (cellend+combo>cellalloc) {
				cellarr=cellarr.concat(new Array(cellalloc+1));
				for (let j=0;j<=cellalloc;j++) {cellarr[cellalloc+j]=new PhyCell();}
				cellalloc=cellarr.length;
			}
			let pos=atom.pos;
			// Get the starting cell.
			let cellstart=cellend;
			let cell=cellarr[cellend++];
			cell.atom=atom;
			cell.dist=-rad*rad;
			cell.hash=hash0;
			for (let d=0;d<dim;d++) {
				// Precalculate constants for the cell-atom distance calculation.
				// floor(x) is needed so negative numbers round to -infinity.
				let cen    =floor(pos[d]*invdim);
				let cendif =cen*celldim-pos[d];
				let neginit=cendif*cendif;
				let incinit=(celldim+2*cendif)*celldim;
				let posinit=incinit+neginit;
				for (let c=cellend-1;c>=cellstart;c--) {
					// Using the starting cell's distance to pos, calculate the distance to the cells
					// above and below. The starting cell is at cen[d] = floor(pos[d]/celldim).
					cell=cellarr[c];
					let hashcen=cell.hash+cen;
					cell.hash=hashu32(hashcen);
					// Check the cells below the center.
					let hash=hashcen;
					let dist=cell.dist+neginit;
					let distinc=-incinit;
					while (dist<0) {
						let newcell=cellarr[cellend++];
						newcell.atom=atom;
						newcell.dist=dist;
						newcell.hash=hashu32(--hash);
						distinc+=celldim2;
						dist+=distinc;
					}
					// Check the cells above the center.
					hash=hashcen;
					dist=cell.dist+posinit;
					distinc=incinit;
					while (dist<0) {
						let newcell=cellarr[cellend++];
						newcell.atom=atom;
						newcell.dist=dist;
						newcell.hash=hashu32(++hash);
						distinc+=celldim2;
						dist+=distinc;
					}
				}
			}
		}
		// Hash cell coordinates and add to the map.
		let cellmask=cellend;
		cellmask|=cellmask>>>16;
		cellmask|=cellmask>>>8;
		cellmask|=cellmask>>>4;
		cellmask|=cellmask>>>2;
		cellmask|=cellmask>>>1;
		let mapused=cellmask+1;
		if (mapused>cellmap.length) {
			cellmap=new Array(mapused);
		}
		for (let i=0;i<mapused;i++) {
			cellmap[i]=null;
		}
		for (let i=0;i<cellend;i++) {
			let cell=cellarr[i];
			let hash=cell.hash&cellmask;
			cell.next=cellmap[hash];
			cellmap[hash]=cell;
		}
		this.cellarr=cellarr;
		this.cellmap=cellmap;
		this.mapused=mapused;
	}


	collide() {
		// Look at each grid cell. Check for collisions among atoms within that cell.
		let mapused=this.mapused;
		let cellmap=this.cellmap;
		let al,bl,a,collide=PhyAtom.collide;
		for (let c=0;c<mapused;c++) {
			al=cellmap[c];
			while (al!==null) {
				a=al.atom;
				al=al.next;
				bl=al;
				while (bl!==null) {
					collide(a,bl.atom);
					bl=bl.next;
				}
			}
		}
	}

}


class PhyWorld {

	constructor(dim) {
		this.dim=dim;
		this.maxsteptime=1/180;
		this.rnd=new Random();
		this.gravity=new Vector(dim);
		this.gravity[dim-1]=0.2;
		this.bndmin=(new Vector(dim)).set(-Infinity);
		this.bndmax=(new Vector(dim)).set( Infinity);
		this.typelist=new PhyList();
		this.intrlist=new PhyList();
		this.atomlist=new PhyList();
		this.bondlist=new PhyList();
		this.atomarr=[];
		this.bondarr=[];
		this.activecnt=0;
		this.activeregions=[];
		this.tmpvec=new Vector(dim);
		this.broad=new PhyBroadphase(this);
		this.stepcallback=null;
		this.collcallback=null;
		this.data={};
	}


	release() {
		this.atomlist.release();
		this.typelist.release();
		this.intrlist.release();
		this.bondlist.release();
		this.broad.release();
	}


	atomiter() {return this.atomlist.iter();}
	bonditer() {return this.bondlist.iter();}


	createatomtype(damp,density,elasticity=1,push=1,statictension=50) {
		// Assume types are sorted from smallest to largest.
		// Find if there's any missing ID or add to the end.
		let link=this.typelist.head;
		let id=0;
		while (link!==null) {
			let nextid=link.obj.id;
			if (id<nextid) {break;}
			id=nextid+1;
			link=link.next;
		}
		let type=new PhyAtomType(this,id,damp,density,elasticity,push,statictension);
		this.typelist.addbefore(type.worldlink,link);
		link=this.typelist.head;
		while (link!==null) {
			PhyAtomType.initinteraction(link.obj,type);
			link=link.next;
		}
		return type;
	}


	createatom(pos,rad,type) {
		return new PhyAtom(pos,rad,type);
	}


	findbonds(a,b) {
		// Return any bonds that exists between A and B.
		if (a.bondlist.count>b.bondlist.count) {
			let tmp=a;
			a=b;
			b=tmp;
		}
		let ret=[];
		let link=a.bondlist.head;
		while (link!==null) {
			let bond=link.obj;
			if (Object.is(bond.a,b) || Object.is(bond.b,b)) {
				ret+=[bond];
			}
			link=link.next;
		}
		return ret;
	}


	createbond(a,b,dist,tension) {
		// Create a bond. If dist<0, use the current distance between the atoms.
		if (dist<0.0) {dist=a.pos.dist(b.pos);}
		let bond=new PhyBond(this,a,b,dist,tension);
		return bond;
	}


	autobond(atomarr,tension) {
		// Balance distance, mass, # of bonds, direction.
		let count=atomarr.length;
		if (count===0 || isNaN(tension)) {return;}
		let infoarr=new Array(count);
		for (let i=0;i<count;i++) {
			let info={
				atom:atomarr[i]
			};
			infoarr[i]=info;
		}
		for (let i=0;i<count;i++) {
			let mainatom=infoarr[i].atom;
			let rad=mainatom.rad*4.1;
			for (let j=0;j<i;j++) {
				let atom=infoarr[j].atom;
				if (Object.is(atom,mainatom)) {continue;}
				let dist=atom.pos.dist(mainatom.pos);
				if (dist<rad) {
					this.createbond(atom,mainatom,-1.0,tension);
				}
			}
		}
	}


	createbox(cen,side,rad,dist,type,tension=NaN) {
		// O O O O
		//  O O O
		// O O O O
		let pos=new Vector(cen);
		let atomcombos=1;
		let dim=this.dim;
		if (side.length===undefined) {side=(new Array(dim)).fill(side);}
		for (let i=0;i<dim;i++) {atomcombos*=side[i];}
		let atomarr=new Array(atomcombos);
		for (let atomcombo=0;atomcombo<atomcombos;atomcombo++) {
			// Find the coordinates of the atom.
			let atomtmp=atomcombo;
			for (let i=0;i<dim;i++) {
				let s=side[i],x=atomtmp%s;
				atomtmp=Math.floor(atomtmp/s);
				pos[i]=cen[i]+(x*2-s+1)*dist;
			}
			atomarr[atomcombo]=this.createatom(pos,rad,type);
		}
		this.autobond(atomarr,tension);
		return atomarr;
	}


	createshape(fill,mat,minrad,spacing,vertarr,facearr,transform=null,bonddist=NaN,bondtension=NaN,bondbreak=Infinity) {
		// Fill types: 0 Outline, 1 Uniform, 2 Greedy.
		//
		// Atoms and bonds are placed *before* applying transform.
		// Radii and bond lengths will be rescaled if needed.
		// Unrolled ops are 5x as fast.
		let dim=this.dim;
		if (dim!==2) {throw `Only implemented for 2 dimensions: ${dim}`;}
		if (!(spacing>1e-10 && minrad>1e-10)) {throw `Invalid spacing: ${spacing}, ${minrad}`;}
		let iter=spacing*0.25;
		let subspace=spacing*0.5;
		// Find the bounds of our shape.
		let bndmin=(new Vector(dim)).set(Infinity);
		let bndmax=(new Vector(dim)).set(-Infinity);
		for (let vert of vertarr) {
			bndmin.imin(vert);
			bndmax.imax(vert);
		}
		bndmin.isub(spacing);
		bndmax.iadd(spacing);
		let newface=[];
		for (let face of facearr) {
			if (face.length!==dim) {throw `invalid face: ${face}`;}
			let vert=new Array(dim);
			for (let i=0;i<dim;i++) {vert[i]=new Vector(vertarr[face[i]]);}
			newface.push(vert);
		}
		// Loop through each cell.
		let cellarr=[];
		let cellpos=new Vector(bndmin);
		let minpos=new Vector(dim),minbary=new Vector(dim);
		let dif=new Vector(dim);
		while (true) {
			// Get the distance to the nearest edge and determine if we're inside.
			let mindist=Infinity;
			let parity=0;
			for (let face of newface) {
				// dif=b-a, u=(pos-a)*dif/dif^2
				let a=face[0],b=face[1];
				let u=0,den=0,dist=0;
				for (let i=0;i<dim;i++) {
					let x=a[i],d=b[i]-x;
					dif[i]=d;
					den+=d*d;
					u+=(cellpos[i]-x)*d;
				}
				u=u>0?u:0;
				u=u<den?u/den:1;
				let eps=1e-10;
				let cy=cellpos[1]-a[1];
				if ((cy>=eps && cy<=dif[1]-eps) || (cy<=-eps && cy>=dif[1]+eps)) {
					let x=a[0]+cy*dif[0]/dif[1];
					parity^=x<cellpos[0]?1:0;
				}
				// dif=dif*u+a, dist=(dif-cellpos)^2
				for (let i=0;i<dim;i++) {
					let d=dif[i];
					dif[i]=d=d*u+a[i];
					d-=cellpos[i];
					dist+=d*d;
				}
				if (mindist>dist) {
					mindist=dist;
					let tmp=minpos;
					minpos=dif;
					dif=tmp;
					minbary[0]=u;
					minbary[1]=1-u;
				}
			}
			// If we're outside, clamp to the edge. Sort edges based on
			// barycenter to give vertices and edges better definition.
			mindist=Math.sqrt(mindist)*(parity && fill?-1:1);
			if (mindist<spacing) {
				if (mindist<0) {minpos.set(cellpos);}
				else {mindist=Math.max(1-minbary.sqr(),0);}
				cellarr.push({dist:mindist,pos:minpos.copy()});
			}
			// Advance to next cell. Skip gaps if we're far from a face.
			let skip=(fill===2 && mindist<0?-mindist:mindist)-spacing*2-iter;
			if (skip>0) {cellpos[0]+=(skip/iter|0)*iter;}
			let i=0;
			for (;i<dim;i++) {
				cellpos[i]+=iter;
				if (cellpos[i]<bndmax[i]) {break;}
				cellpos[i]=bndmin[i];
			}
			if (i>=dim) {break;}
		}
		// Prep bonds.
		if (!(bondtension>0 && bondbreak>0 && bonddist>0)) {bonddist=NaN;}
		bonddist-=minrad*2;
		let bondarr=[];
		// Fill from the center outward.
		cellarr.sort((l,r)=>l.dist-r.dist);
		let cells=cellarr.length,atoms=0;
		let mincheck=-1;
		let atomarr=[];
		for (let c=0;c<cells;c++) {
			let cell=cellarr[c];
			cellpos=cell.pos;
			let celldist=cell.dist<0?cell.dist:0;
			let cellrad=fill===2 && celldist<0?spacing-celldist:minrad;
			// Find the largest radius we can fill.
			let atom=null;
			if (mincheck<0 && celldist>=0) {mincheck=atoms;fill=0;}
			let i=mincheck>0?mincheck:0,i0=i;
			for (;i<atoms;i++) {
				atom=atomarr[i];
				let rad=0,a=atom.pos;
				for (let j=0;j<dim;j++) {
					let d=cellpos[j]-a[j];
					rad+=d*d;
				}
				rad=Math.sqrt(rad);
				let cutoff=fill===2?subspace+atom.rad:spacing;
				if (rad<minrad || rad<cutoff) {break;}
				cellrad=cellrad<rad?cellrad:rad;
			}
			if (i>=atoms) {
				atom=this.createatom(cellpos,cellrad,mat);
				atom.data._filldist=celldist;
				// Bond before transforming.
				if (bonddist>0) {
					let bondmin=cellrad+bonddist;
					for (let b of atomarr) {
						let dist=b.pos.dist(cellpos);
						if (dist<bondmin+b.rad) {
							bondarr.push(this.createbond(atom,b,dist,bondtension));
						}
					}
				}
				atomarr.push(atom);
				atoms++;
			}
			// Move the rejection atom nearer to the front.
			i0+=(i-i0)>>1;
			atomarr[i ]=atomarr[i0];
			atomarr[i0]=atom;
		}
		// Transform and rescale everything.
		transform=new Transform(transform??{dim:dim});
		let scale=Math.pow(transform.mat.det(),1/dim);
		for (let atom of atomarr) {
			atom.pos=transform.apply(atom.pos);
			atom.rad*=scale;
			atom.updateconstants();
		}
		for (let bond of bondarr) {
			bond.dist=bond.a.pos.dist(bond.b.pos);
			bond.breakdist=bondbreak*scale;
		}
		return atomarr;
	}


	clearactive() {
		this.activeregions=[];
	}


	addactive(cen,dev) {
		// cen[i]+-dev[i]
		let dim=this.dim;
		cen=(new Vector(dim)).set(cen);
		dev=(new Vector(dim)).set(dev);
		let vol=1;
		for (let i=0;i<dim;i++) {
			vol*=dev[i];
		}
		vol=vol>0?vol:Infinity;
		this.activeregions.push({cen:cen,dev:dev,vol:vol});
	}


	update(time) {
		// Process the simulation in multiple steps if time is too large.
		if (time<1e-9 || isNaN(time)) {return;}
		let dt=this.maxsteptime;
		let steps=time<=dt?1:Math.ceil(time/dt);
		if (steps<Infinity) {dt=time/steps;}
		let rnd=this.rnd;
		for (let step=0;step<steps;step++) {
			if (this.stepcallback!==null) {this.stepcallback(dt);}
			// Update types and interactions.
			let typelink=this.typelist.head;
			while (typelink!==null) {
				typelink.obj.updateconstants(dt);
				typelink=typelink.next;
			}
			let intrlink=this.intrlist.head;
			while (intrlink!==null) {
				intrlink.obj.calcdt(dt);
				intrlink=intrlink.next;
			}
			// Integrate atoms.
			let atomcnt=this.atomlist.count;
			let atomarr=this.atomarr;
			if (atomarr.length<atomcnt) {
				atomarr=new Array(atomcnt*2);
				this.atomarr=atomarr;
			}
			let atomlink=this.atomlist.head;
			let activecnt=0;
			let oldesttime=0;
			let oldestatom=null;
			while (atomlink!==null) {
				let atom=atomlink.obj;
				let uptime=atom.updatetime+dt;
				atom.updatetime=uptime;
				if (oldesttime<uptime) {
					oldesttime=uptime;
					oldestatom=atom;
				}
				atomarr[activecnt++]=atom;
				atomlink=atomlink.next;
			}
			if (this.activeregions.length>0 && activecnt>0) {
				activecnt=0;
				let activesort=[];
				for (let reg of this.activeregions) {
					activesort.push(reg);
					let i=activesort.length;
					while (i>0 && reg.vol>activesort[i-1].vol) {
						activesort[i]=activesort[i-1];
						i--;
					}
					activesort[i]=reg;
				}
				let dim=this.dim;
				for (let i=0;i<activesort.length+1;i++) {
					let reg=activesort[i?i-1:0];
					let cen=reg.cen,dev=reg.dev;
					if (!i) {cen=oldestatom.pos;}
					for (let j=activecnt;j<atomcnt;j++) {
						let atom=atomarr[j];
						let pos=atom.pos,rad=atom.rad;
						let d=0;
						for (;d<dim;d++) {
							let x=pos[d]-cen[d];
							x=(x<0?-x:x)-rad;
							if (x>=dev[d]) {break;}
						}
						if (d===dim) {
							atomarr[j]=atomarr[activecnt];
							atomarr[activecnt++]=atom;
						}
					}
				}
			}
			this.activecnt=activecnt;
			for (let i=0;i<activecnt;i++) {
				atomarr[i].update();
			}
			for (let i=activecnt;i<atomcnt;i++) {
				atomarr[i].sleeping=true;
			}
			// Integrate bonds after atoms or vel will be counted twice.
			// Randomize the evaluation order to reduce oscillations.
			let bondcnt=this.bondlist.count;
			let bondarr=this.bondarr;
			if (bondarr.length<bondcnt) {
				bondarr=new Array(bondcnt*2);
				this.bondarr=bondarr;
			}
			let bondlink=this.bondlist.head;
			for (let i=0;i<bondcnt;i++) {
				let j=rnd.getu32()%(i+1);
				bondarr[i]=bondarr[j];
				bondarr[j]=bondlink.obj;
				bondlink=bondlink.next;
			}
			for (let i=0;i<bondcnt;i++) {
				bondarr[i].update();
			}
			// Collide atoms.
			this.broad.build();
			this.broad.collide();
		}
	}

}


const Phy={
	Intr:PhyAtomInteraction,
	AtomType:PhyAtomType,
	Atom:PhyAtom,
	Bond:PhyBond,
	Broadphase:PhyBroadphase,
	World:PhyWorld
};
export {Phy};

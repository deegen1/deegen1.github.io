/*------------------------------------------------------------------------------


collision2d.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint collision2d.js -c ../../../standards/eslint.js */


import {Draw,Random,Vector,Transform,Input} from "../rigidbody/library.js";
import {Phy} from "../rigidbody/physics.js";


//---------------------------------------------------------------------------------
// Helper Functions


function PseudoAngle(dx,dy) {
	// Counter-clockwise
	let ang=dx/(Math.abs(dx)+Math.abs(dy));
	return dy<0?(3+ang):(1-ang);
}


//function PseudoAngle(dx,dy) {
//	// Clockwise
//	let ang=dx/(Math.abs(dx)+Math.abs(dy));
//	return dy>0?(3+ang):(1-ang);
//}


//---------------------------------------------------------------------------------
// Hulls


function HullWrap1(vertarr) {
	// Given a set points, find the fewest points needed for the convex hull.
	// Order clockwise.
	// Find the left-most, bottom-most vertex.
	const dim=2;
	let verts=vertarr.length;
	if (!verts) {return [];}
	let minv=vertarr[0];
	let mini=0;
	for (let i=1;i<verts;i++) {
		let u=vertarr[i];
		for (let d=dim-1;d>=0;d--) {
			let vx=minv[d],ux=u[d];
			if (vx!==ux) {
				if (vx>ux) {minv=u;mini=i;}
				break;
			}
		}
	}
	vertarr[mini]=vertarr[0];
	vertarr[0]=minv;
	// Wrap around to find the hull.
	let hverts=1;
	while (hverts<verts) {
		mini=hverts;
		minv=vertarr[mini];
		let v0=vertarr[mini-1];
		for (let i=0;i<verts;i++) {
			let u=vertarr[i];
			let dx0=minv[0]-v0[0],dy0=minv[1]-v0[1];
			let dx1=u[0]-v0[0],dy1=u[1]-v0[1];
			if (dx0*dy1-dy0*dx1<0) {
				minv=u;
				mini=i;
			}
		}
		if (mini===0) {break;}
		vertarr[mini]=vertarr[hverts];
		vertarr[hverts++]=minv;
	}
	return vertarr.slice(0,hverts);
}


function HullWrap2(vertarr) {
	// Given a set points, find the fewest points needed for the convex hull.
	// Order counter-clockwise.
	let verts=vertarr.length;
	if (!verts) {return [];}
	// Find the bottom-most, left-most vertex.
	const eps=1e-8;
	let minx=Infinity,miny=Infinity;
	let mini=0;
	for (let i=0;i<verts;i++) {
		let v=vertarr[i],x=v[0],y=v[1];
		if (miny>y || (miny===y && minx>x)) {
			mini=i;
			miny=y;
			minx=x;
		}
	}
	// Wrap around to find the hull.
	let vidx=0;
	let minang=-eps;
	do {
		let v=vertarr[mini],x0=v[0],y0=v[1];
		vertarr[mini]=vertarr[vidx];
		vertarr[vidx++]=v;
		// Get the angle to the starting point.
		mini=0;
		let dx=minx-x0,dy=miny-y0;
		let maxlen=Math.abs(dx)-dy;
		let maxang=(maxlen>eps?3+dx/maxlen:4)-eps;
		for (let i=vidx;i<verts;i++) {
			v=vertarr[i];dx=v[0]-x0;dy=v[1]-y0;
			let len=Math.abs(dx)+Math.abs(dy),ang=dx/len;
			ang=dy<0?(3+ang):(1-ang);
			let dif=maxang-ang;
			if (!(len>2*eps && minang<ang)) {
				vertarr[i--]=vertarr[--verts];
			} else if (dif>eps || (dif>-eps && maxlen<len)) {
				mini=i;
				maxang=maxang<ang?maxang:ang;
				maxlen=len;
			}
		}
		minang=maxang;
	} while (mini>0);
	return vertarr.slice(0,vidx);
}


function HullWrap3(vertarr) {
	// Given a set points, find the convex hull and sort counter-clockwise.
	let verts=vertarr.length;
	if (!verts) {return [];}
	// Start with the bottom-most, left-most vertex.
	let minx=Infinity,miny=Infinity;
	let mini=0;
	for (let i=0;i<verts;i++) {
		let v=vertarr[i],x=v[0],y=v[1];
		if (miny>y || (miny===y && minx>x)) {
			mini=i;
			miny=y;
			minx=x;
		}
	}
	// Wrap around to find the hull. Use the dot product's sign to ensure
	// consistent direction.
	let vidx=0;
	let dx=1,dy=0;
	do {
		let u=vertarr[mini],x0=u[0],y0=u[1];
		vertarr[mini]=vertarr[vidx];
		vertarr[vidx++]=u;
		// Point back to the start.
		mini=0;
		let dx0=minx-x0,dy0=miny-y0;
		let minmag=dx0*dx0+dy0*dy0;
		let mindot=(dx*dx0+dy*dy0)>0?1:0;
		for (let i=vidx;i<verts;i++) {
			let v=vertarr[i];
			let dx1=v[0]-x0,dy1=v[1]-y0;
			let mag=dx1*dx1+dy1*dy1;
			let crs=dx0*dy1-dy0*dx1;
			let dot=(dx*dx1+dy*dy1)>0?1:0;
			if (!(mag>1e-12)) {
				vertarr[i--]=vertarr[--verts];
			} else if (mindot<dot || (mindot===dot && (crs<0 || (crs===0 && minmag<mag)))) {
				minmag=mag;
				mindot=dot;
				dx0=dx1;
				dy0=dy1;
				mini=i;
			}
		}
		dx=dx0;
		dy=dy0;
	} while (mini>0);
	return vertarr.slice(0,vidx);
}


function HullWrapTest() {
	console.log("testing hull wrapping");
	let rnd=new Random(1);
	let tests=10000000;
	let hullsum=0,vertsum=0;
	for (let test=0;test<tests;test++) {
		// Make a random hull.
		//let verts=rnd.mod(20);
		let verts=(1/(rnd.getf()*rnd.getf()+0.001))|0;
		let vertarr=[];
		if (!(test&0xffff)) {console.log(test,verts);}
		let xmul=rnd.getnorm()*2,ymul=rnd.getnorm()*2;
		let type=rnd.mod(5);
		if (type<3) {
			// Random
			for (let i=0;i<verts;i++) {
				type=rnd.mod(101);
				let x=rnd.getnorm()*xmul,y=rnd.getnorm()*ymul;
				if (type>50 && i>0) {
					// Perturb a point.
					let den=rnd.mod(34)+10;
					den=den<30?1/(1<<den):0;
					x*=den;
					y*=den;
					let v0=vertarr[rnd.mod(i)],x0=v0[0],y0=v0[1];
					let v1=vertarr[rnd.mod(i)],x1=v1[0],y1=v1[1];
					if (type<75) {
						// Linear combination of 2 points.
						let u=rnd.getf()*3-1;
						x+=x0+(x1-x0)*u;
						y+=y0+(y1-y0)*u;
					} else {
						// Make a corner of 2 points.
						x+=x0;
						y+=y1;
					}
				}
				vertarr.push(new Vector([x,y]));
			}
		} else if (type===3) {
			// Square
			for (let i=0;i<verts;i++) {
				let t=i&3;
				let x=(t<2?t*2-1:rnd.gets())*xmul;
				let y=(t>1?t*2-5:rnd.gets())*ymul;
				vertarr.push(new Vector([x,y]));
			}
		} else {
			// Circle
			for (let i=0;i<verts;i++) {
				let ang=(i/verts)*Math.PI*2;
				let x=Math.cos(ang)*xmul;
				let y=Math.sin(ang)*ymul;
				vertarr.push(new Vector([x,y]));
			}
		}
		//if (test!==149759) {continue;}
		let origarr=[];
		for (let v of vertarr) {origarr.push(new Vector(v));}
		//let hullarr=HullWrap1(vertarr);
		//let hullarr=HullWrap2(vertarr); // verts: 23212070 64934733
		let hullarr=HullWrap3(vertarr); // verts: 82600941 249760459
		hullsum+=hullarr.length;
		vertsum+=origarr.length;
		// Check if we have points not in the original set.
		for (let v of hullarr) {
			let found=false;
			let x=v[0],y=v[1];
			for (let u of origarr) {
				if (x===u[0] && y===u[1]) {
					found=true;
					break;
				}
			}
			if (!found) {
				console.log("unable to find point");
				console.log("test :",test);
				console.log("vert :",hullarr);
				console.log("orig :",origarr);
				console.log("point:",v);
				throw "error";
			}
		}
		// Check projections against the original.
		for (let i=0;i<101;i++) {
			let ang=Math.PI*(i/100);
			let cs=Math.cos(ang),sn=Math.sin(ang);
			let omin=Infinity,omax=-Infinity;
			let ominv=null,omaxv=null;
			for (let v of origarr) {
				let u=cs*v[0]+sn*v[1];
				if (omin>u) {omin=u;ominv=v;}
				if (omax<u) {omax=u;omaxv=v;}
			}
			let hmin=Infinity,hmax=-Infinity;
			let hminv=null,hmaxv=null;
			for (let v of hullarr) {
				let u=cs*v[0]+sn*v[1];
				if (hmin>u) {hmin=u;hminv=v;}
				if (hmax<u) {hmax=u;hmaxv=v;}
			}
			if (Math.abs(omin-hmin)>1e-6 || Math.abs(omax-hmax)>1e-6) {
				console.log("projections mismatch");
				console.log("test:",test);
				console.log("min :",omin,hmin,omin-hmin,ominv,hminv);
				console.log("max :",omax,hmax,omax-hmax,omaxv,hmaxv);
				console.log("orig:",origarr);
				console.log("hull:",hullarr);
				throw "error";
			}
		}
		// Counter-clockwise ordering.
		let len=hullarr.length;
		let prevang=0;
		for (let i=0;i<len;i++) {
			let v0=hullarr[i],x0=v0[0],y0=v0[1];
			let v1=hullarr[(i+1)%len],x1=v1[0],y1=v1[1];
			let ang=PseudoAngle(x1-x0,y1-y0);
			if (prevang-1e-8>ang) {
				console.log("angles out of order:",prevang,ang,i);
				console.log("test:",test);
				console.log("orig:",origarr);
				console.log("hull:",hullarr);
				throw "error";
			}
			prevang=ang;
		}
	}
	console.log("verts:",hullsum,vertsum);
}


//---------------------------------------------------------------------------------
// Collision Detection
// Does not find minimum separating vector.


function CollisionOverlap(avertarr,amat,apos,bvertarr,bmat,bpos,norm) {
	let mag=norm.mag();
	if (!(mag>1e-10)) {return Infinity;}
	let normx=norm[0]/mag;
	let normy=norm[1]/mag;
	// (x*matxx+y*matxy+matx)*normx+(x*matyx+y*matyy+maty)*normy
	// mdot=mat.trans()*norm
	// proj=v.dot(mdot)+pos.dot(norm)
	// A projection.
	let xmul=amat[0]*normx+amat[2]*normy;
	let ymul=amat[1]*normx+amat[3]*normy;
	let amin=Infinity,amax=-Infinity;
	for (let v of avertarr) {
		let u=v[0]*xmul+v[1]*ymul;
		amin=amin<u?amin:u;
		amax=amax>u?amax:u;
	}
	// B projection.
	xmul=bmat[0]*normx+bmat[2]*normy;
	ymul=bmat[1]*normx+bmat[3]*normy;
	let bmin=Infinity,bmax=-Infinity;
	for (let v of bvertarr) {
		let u=v[0]*xmul+v[1]*ymul;
		bmin=bmin<u?bmin:u;
		bmax=bmax>u?bmax:u;
	}
	// Calculate overlap.
	let off=(bpos[0]-apos[0])*normx+(bpos[1]-apos[1])*normy;
	amin-=bmax+off;
	bmin-=amax-off;
	return amin>bmin?amin:bmin;
}


function CollisionDetect1(avertarr,amat,apos,bvertarr,bmat,bpos) {
	// Find the closest points on the edge of the convex hulls of A and B.
	let averts=avertarr.length;
	let bverts=bvertarr.length;
	let aminpos=new Vector(2);
	let bminpos=new Vector(2);
	if (!averts || !bverts) {return [false,aminpos,bminpos];}
	// Apply transforms and find a point on the hulls.
	for (let side=0;side<2;side++) {
		let vertarr=side?bvertarr:avertarr;
		let verts=vertarr.length;
		if (!verts) {continue;}
		let mat=side?bmat:amat;
		let pos=side?bpos:apos;
		let matxx=mat[0],matxy=mat[1],matx=pos[0];
		let matyx=mat[2],matyy=mat[3],maty=pos[1];
		let newarr=new Array();
		for (let v of vertarr) {
			let x0=v[0],y0=v[1];
			let x=x0*matxx+y0*matxy+matx;
			let y=x0*matyx+y0*matyy+maty;
			newarr.push(new Vector([x,y]));
		}
		if (side) {
			bvertarr=newarr;
		} else {
			avertarr=newarr;
		}
	}
	let rnd=new Random(1);
	let mindist=Infinity;
	let overlap=true;
	for (let test=0;test<256;test++) {
		// Pick a random line and random point.
		// Use the line to project the vertices.
		let side=test&1;
		let vertarr=side?bvertarr:avertarr;
		let verts=vertarr.length;
		let i0=rnd.mod(verts),v0=vertarr[i0],x0=v0[0],y0=v0[1];
		let i1=rnd.mod(verts),v1=vertarr[i1],x1=v1[0],y1=v1[1];
		let dx=x1-x0,dy=y1-y0,den=dx*dx+dy*dy;
		let u=rnd.getf()*2;
		if (u>1) {
			// Occasionally try to get close to a previous point.
			let pos=side?aminpos:bminpos;
			u=(pos[0]-x0)*dx+(pos[1]-y0)*dy;
			u=u>0?(u<den?u/den:1):0;
		}
		let px=x0+dx*u,py=y0+dy*u;
		if (den<1e-10) {
			dx=1;
			dy=0;
		} else {
			den=Math.sqrt(den);
			dx/=den;
			dy/=den;
		}
		// Find extremes of A.
		let aminu=Infinity,amaxu=-Infinity;
		let aminv=null,amaxv=null;
		for (let v of avertarr) {
			u=v[0]*dy-v[1]*dx;
			if (aminu>u) {aminu=u;aminv=v;}
			if (amaxu<u) {amaxu=u;amaxv=v;}
		}
		// Find extremes of B.
		let bminu=Infinity,bmaxu=-Infinity;
		let bminv=null,bmaxv=null;
		for (let v of bvertarr) {
			u=v[0]*dy-v[1]*dx;
			if (bminu>u) {bminu=u;bminv=v;}
			if (bmaxu<u) {bmaxu=u;bmaxv=v;}
		}
		// Pick opposite sides for a separating vector: [A.min,B.max] or [A.max,B.min].
		let adif=aminu-bmaxu;
		let bdif=bminu-amaxu;
		if (adif>=0 || bdif>=0) {overlap=false;}
		if (adif>bdif) {
			bminu=bmaxu;
			bminv=bmaxv;
		} else {
			aminu=amaxu;
			aminv=amaxv;
		}
		// If [px,py] is on the edge, replace the edge.
		let off=px*dy-py*dx,pt=[px,py];
		if (!side && Math.abs(aminu-off)<1e-6) {aminv=pt;}
		if ( side && Math.abs(bminu-off)<1e-6) {bminv=pt;}
		// Check if the new points are closer.
		dx=aminv[0]-bminv[0];
		dy=aminv[1]-bminv[1];
		let dist=dx*dx+dy*dy;
		if (mindist>dist) {
			mindist=dist;
			aminpos.set(aminv);
			bminpos.set(bminv);
			//console.log(test,mindist);
		}
	}
	return [overlap,aminpos,bminpos];
}


function SolveMinkowski1(a,b) {
	let avert=a.vertarr,bvert=b.vertarr;
	let averts=avert.length,bverts=bvert.length;
	if (!averts || !bverts) {return [false,null,null];}
	// Load transforms.
	let amat=a.mat,apos=a.pos;
	let amatxx=amat[0],amatxy=amat[1],amatx=apos[0];
	let amatyx=amat[2],amatyy=amat[3],amaty=apos[1];
	let adet=amatxx*amatyy-amatxy*amatyx;
	let bmat=b.mat,bpos=b.pos;
	let bmatxx=bmat[0],bmatxy=bmat[1],bmatx=bpos[0];
	let bmatyx=bmat[2],bmatyy=bmat[3],bmaty=bpos[1];
	let bdet=bmatxx*bmatyy-bmatxy*bmatyx;
	// Find start of A.
	let aidx=0,ainc=(adet>0?averts-1:1),acnt=averts;
	let ax0=0,ay0=Infinity;
	let ax1=0,ay1=0;
	let v=avert[0],x=v[0],y=v[1];
	let nx1=x*amatxx+y*amatxy;
	let ny1=x*amatyx+y*amatyy;
	for (let i=0,j=0;i<averts;i++) {
		j+=(j<ainc?averts:0)-ainc;
		v=avert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*amatxx+y*amatxy;
		ny1=x*amatyx+y*amatyy;
		if (ny0<ay0 || (ny0===ay0 && nx0<ax0)) {
			aidx=j;
			ax0=nx0;ax1=nx1;
			ay0=ny0;ay1=ny1;
		}
	}
	let aang=PseudoAngle(ax1-ax0,ay1-ay0);
	// Find start of B.
	let bidx=0,binc=(bdet>0?bverts-1:1),bcnt=bverts;
	let bx0=0,by0=-Infinity;
	let bx1=0,by1=0;
	v=bvert[0];x=v[0];y=v[1];
	nx1=x*bmatxx+y*bmatxy;
	ny1=x*bmatyx+y*bmatyy;
	for (let i=0,j=0;i<bverts;i++) {
		j+=(j<binc?bverts:0)-binc;
		v=bvert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*bmatxx+y*bmatxy;
		ny1=x*bmatyx+y*bmatyy;
		if (ny0>by0 || (ny0===by0 && nx0>bx0)) {
			bidx=j;
			bx0=nx0;bx1=nx1;
			by0=ny0;by1=ny1;
		}
	}
	let bang=PseudoAngle(bx0-bx1,by0-by1);
	// Build the Minkowski difference.
	let overlap=averts+bverts>3;
	let mindist=Infinity;
	let minax=0,minay=0;
	let minbx=0,minby=0;
	let offx=amatx-bmatx,offy=amaty-bmaty;
	while (acnt>0 || bcnt>0) {
		// Between A and B, pick the left-most side next.
		let ax=ax0,ay=ay0;
		let bx=bx0,by=by0;
		//let dx=adx,dy=ady;
		let side=0;
		if (acnt && (!bcnt || aang<bang)) {
			acnt--;
			aidx+=(aidx<ainc?averts:0)-ainc;
			v=avert[aidx];x=v[0];y=v[1];
			ax0=ax1;ax1=x*amatxx+y*amatxy;
			ay0=ay1;ay1=x*amatyx+y*amatyy;
			aang=PseudoAngle(ax1-ax0,ay1-ay0);
		} else {
			bcnt--;
			bidx+=(bidx<binc?bverts:0)-binc;
			v=bvert[bidx];x=v[0];y=v[1];
			bx0=bx1;bx1=x*bmatxx+y*bmatxy;
			by0=by1;by1=x*bmatyx+y*bmatyy;
			bang=PseudoAngle(bx0-bx1,by0-by1);
			side=1;
		}
		let dx=ax-ax0+bx0-bx;
		let dy=ay-ay0+by0-by;
		let px=ax-bx+offx,py=ay-by+offy;
		if (px*dy>py*dx) {overlap=false;}
		// Find the closest point on the manifold segment to (0,0).
		let d=dx*dx+dy*dy;
		let u=px*dx+py*dy;
		u=u>0?(u<d?u/d:1):0;
		dx*=u;px-=dx;
		dy*=u;py-=dy;
		let dist=px*px+py*py;
		if (mindist>dist) {
			mindist=dist;
			if (side) {bx+=dx;by+=dy;}
			else      {ax-=dx;ay-=dy;}
			minax=ax;minay=ay;
			minbx=bx;minby=by;
		}
	}
	let ap=new Vector([minax+amatx,minay+amaty]);
	let bp=new Vector([minbx+bmatx,minby+bmaty]);
	return [overlap,ap,bp];
}


function SolveMinkowski2(a,b) {
	let avert=a.vertarr,bvert=b.vertarr;
	let averts=avert.length,bverts=bvert.length;
	if (!averts || !bverts) {return [false,null,null];}
	// Load transforms.
	let amat=a.mat,apos=a.pos;
	let amatxx=amat[0],amatxy=amat[1],amatx=apos[0];
	let amatyx=amat[2],amatyy=amat[3],amaty=apos[1];
	let adet=amatxx*amatyy-amatxy*amatyx;
	let bmat=b.mat,bpos=b.pos;
	let bmatxx=bmat[0],bmatxy=bmat[1],bmatx=bpos[0];
	let bmatyx=bmat[2],bmatyy=bmat[3],bmaty=bpos[1];
	let bdet=bmatxx*bmatyy-bmatxy*bmatyx;
	// Find start of A.
	let aidx=0,ainc=(adet>0?averts-1:1),acnt=averts;
	let ax0=0,ay0=Infinity;
	let ax1=0,ay1=0;
	let v=avert[0],x=v[0],y=v[1];
	let nx1=x*amatxx+y*amatxy;
	let ny1=x*amatyx+y*amatyy;
	for (let i=0,j=0;i<averts;i++) {
		j+=(j<ainc?averts:0)-ainc;
		v=avert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*amatxx+y*amatxy;
		ny1=x*amatyx+y*amatyy;
		if (ny0<ay0 || (ny0===ay0 && nx0<ax0)) {
			aidx=j;
			ax0=nx0;ax1=nx1;
			ay0=ny0;ay1=ny1;
		}
	}
	// Find start of B.
	let bidx=0,binc=(bdet>0?bverts-1:1),bcnt=bverts;
	let bx0=0,by0=-Infinity;
	let bx1=0,by1=0;
	v=bvert[0];x=v[0];y=v[1];
	nx1=x*bmatxx+y*bmatxy;
	ny1=x*bmatyx+y*bmatyy;
	for (let i=0,j=0;i<bverts;i++) {
		j+=(j<binc?bverts:0)-binc;
		v=bvert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*bmatxx+y*bmatxy;
		ny1=x*bmatyx+y*bmatyy;
		if (ny0>by0 || (ny0===by0 && nx0>bx0)) {
			bidx=j;
			bx0=nx0;bx1=nx1;
			by0=ny0;by1=ny1;
		}
	}
	// Build the Minkowski difference.
	let overlap=averts+bverts>3;
	let mindist=Infinity;
	let minax=0,minay=0;
	let minbx=0,minby=0;
	let offx=amatx-bmatx,offy=amaty-bmaty;
	let dx=1,dy=0;
	while (acnt>0 || bcnt>0) {
		// Between A and B, pick the left-most side next.
		let ax=ax0,ay=ay0,adx=ax1-ax0,ady=ay1-ay0;
		let bx=bx0,by=by0,bdx=bx0-bx1,bdy=by0-by1;
		let side=adx*bdy<ady*bdx?1:0;
		let asign=acnt?(dx*adx+dy*ady>0?1:0):-1;
		let bsign=bcnt?(dx*bdx+dy*bdy>0?1:0):-1;
		if (asign!==bsign) {side=bsign>asign?1:0;}
		if (!side) {
			acnt--;
			aidx+=(aidx<ainc?averts:0)-ainc;
			v=avert[aidx];x=v[0];y=v[1];
			ax0=ax1;ax1=x*amatxx+y*amatxy;
			ay0=ay1;ay1=x*amatyx+y*amatyy;
			dx=adx;dy=ady;
		} else {
			bcnt--;
			bidx+=(bidx<binc?bverts:0)-binc;
			v=bvert[bidx];x=v[0];y=v[1];
			bx0=bx1;bx1=x*bmatxx+y*bmatxy;
			by0=by1;by1=x*bmatyx+y*bmatyy;
			dx=bdx;dy=bdy;
		}
		let px=bx-ax-offx,py=by-ay-offy;
		if (px*dy>py*dx) {overlap=false;}
		// Find the closest point on the manifold segment to (0,0).
		let d=dx*dx+dy*dy;
		let u=px*dx+py*dy;
		u=u>0?(u<d?u/d:1):0;
		let ux=dx*u;px-=ux;
		let uy=dy*u;py-=uy;
		let dist=px*px+py*py;
		if (mindist>dist) {
			mindist=dist;
			if (side) {bx-=ux;by-=uy;}
			else      {ax+=ux;ay+=uy;}
			minax=ax;minay=ay;
			minbx=bx;minby=by;
		}
	}
	let ap=new Vector([minax+amatx,minay+amaty]);
	let bp=new Vector([minbx+bmatx,minby+bmaty]);
	return [overlap,ap,bp];
}


function SolveMinkowski3(a,b) {
	let avert=a.vertarr,bvert=b.vertarr;
	let averts=avert.length,bverts=bvert.length;
	if (!averts || !bverts) {return [false,null,null];}
	// Load transforms.
	let amat=a.mat,apos=a.pos;
	let amatxx=amat[0],amatxy=amat[1],amatx=apos[0];
	let amatyx=amat[2],amatyy=amat[3],amaty=apos[1];
	let adet=amatxx*amatyy-amatxy*amatyx;
	let bmat=b.mat,bpos=b.pos;
	let bmatxx=bmat[0],bmatxy=bmat[1],bmatx=bpos[0];
	let bmatyx=bmat[2],bmatyy=bmat[3],bmaty=bpos[1];
	let bdet=bmatxx*bmatyy-bmatxy*bmatyx;
	// Find start of A.
	let ainc=(adet>0?averts-1:1),aidx=ainc,acnt=averts;
	let v=avert[0],x=v[0],y=v[1];
	let ax0=x*amatxx+y*amatxy;
	let ay0=x*amatyx+y*amatyy;
	v=avert[aidx];x=v[0];y=v[1];
	let ax1=x*amatxx+y*amatxy;
	let ay1=x*amatyx+y*amatyy;
	let dx=ax1-ax0,dy=ay1-ay0;
	// Find start of B.
	let bidx=0,binc=(bdet>0?bverts-1:1),bcnt=bverts;
	let bx0=0,by0=-Infinity;
	let bx1=0,by1=0;
	v=bvert[0];x=v[0];y=v[1];
	let nx1=x*bmatxx+y*bmatxy;
	let ny1=x*bmatyx+y*bmatyy;
	let maxdot=-Infinity;
	for (let i=0,j=0;i<bverts;i++) {
		j+=(j<binc?bverts:0)-binc;
		v=bvert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*bmatxx+y*bmatxy;
		ny1=x*bmatyx+y*bmatyy;
		let bdx=nx1-nx0,bdy=ny1-ny0;
		let dot=dx*bdx+dy*bdy;
		dot=(dot<0?-dot:dot)*dot/(bdx*bdx+bdy*bdy);
		if (maxdot<dot) {
			maxdot=dot;
			bidx=j;
			bx0=nx0;bx1=nx1;
			by0=ny0;by1=ny1;
		}
	}
	// Build the Minkowski difference.
	let overlap=averts+bverts>3;
	let mindist=Infinity;
	let minax=0,minay=0;
	let minbx=0,minby=0;
	let offx=amatx-bmatx,offy=amaty-bmaty;
	//let dx=1,dy=0;
	while (acnt>0 || bcnt>0) {
		// Between A and B, pick the left-most side next.
		let ax=ax0,ay=ay0,adx=ax1-ax0,ady=ay1-ay0;
		let bx=bx0,by=by0,bdx=bx0-bx1,bdy=by0-by1;
		let side=adx*bdy<ady*bdx?1:0;
		let asign=acnt?(dx*adx+dy*ady>0?1:0):-1;
		let bsign=bcnt?(dx*bdx+dy*bdy>0?1:0):-1;
		if (asign!==bsign) {side=bsign>asign?1:0;}
		if (!side) {
			acnt--;
			aidx+=(aidx<ainc?averts:0)-ainc;
			v=avert[aidx];x=v[0];y=v[1];
			ax0=ax1;ax1=x*amatxx+y*amatxy;
			ay0=ay1;ay1=x*amatyx+y*amatyy;
			dx=adx;dy=ady;
		} else {
			bcnt--;
			bidx+=(bidx<binc?bverts:0)-binc;
			v=bvert[bidx];x=v[0];y=v[1];
			bx0=bx1;bx1=x*bmatxx+y*bmatxy;
			by0=by1;by1=x*bmatyx+y*bmatyy;
			dx=bdx;dy=bdy;
		}
		let px=bx-ax-offx,py=by-ay-offy;
		if (px*dy>py*dx) {overlap=false;}
		// Find the closest point on the manifold segment to (0,0).
		let d=dx*dx+dy*dy;
		let u=px*dx+py*dy;
		u=u>0?(u<d?u/d:1):0;
		let ux=dx*u;px-=ux;
		let uy=dy*u;py-=uy;
		let dist=px*px+py*py;
		if (mindist>dist) {
			mindist=dist;
			if (side) {bx-=ux;by-=uy;}
			else      {ax+=ux;ay+=uy;}
			minax=ax;minay=ay;
			minbx=bx;minby=by;
		}
	}
	let ap=new Vector([minax+amatx,minay+amaty]);
	let bp=new Vector([minbx+bmatx,minby+bmaty]);
	return [overlap,ap,bp];
}


function CollisionResolveTest() {
	console.log("testing collision resolving");
	let rnd=new Random(1);
	let tests=1000000;
	for (let test=0;test<tests;test++) {
		//console.log("test:",test);
		if (!(test&0xfff)) {console.log("test:",test);}
		let world=new Phy.World(2);
		let abody=null,bbody=null;
		let avertarr=null,bvertarr=null;
		for (let side=0;side<2;side++) {
			// Make a random hull.
			//let verts=rnd.mod(20);
			let verts=Math.round(1/(rnd.getf()*rnd.getf()+0.01));
			let vertarr=[];
			let xmul=rnd.getnorm()*2,ymul=rnd.getnorm()*2;
			let type=rnd.mod(5);
			if (type<3) {
				// Random
				for (let i=0;i<verts;i++) {
					type=rnd.mod(101);
					let x=rnd.getnorm()*xmul,y=rnd.getnorm()*ymul;
					if (type>50 && i>0) {
						// Perturb a point.
						let den=rnd.mod(34)+10;
						den=den<30?1/(1<<den):0;
						x*=den;
						y*=den;
						let v0=vertarr[rnd.mod(i)],x0=v0[0],y0=v0[1];
						let v1=vertarr[rnd.mod(i)],x1=v1[0],y1=v1[1];
						if (type<75) {
							// Linear combination of 2 points.
							let u=rnd.getf()*3-1;
							x+=x0+(x1-x0)*u;
							y+=y0+(y1-y0)*u;
						} else {
							// Make a corner of 2 points.
							x+=x0;
							y+=y1;
						}
					}
					vertarr.push(new Vector([x,y]));
				}
			} else if (type===3) {
				// Square
				for (let i=0;i<verts;i++) {
					let t=i&3;
					let x=(t<2?t*2-1:rnd.gets())*xmul;
					let y=(t>1?t*2-5:rnd.gets())*ymul;
					vertarr.push(new Vector([x,y]));
				}
			} else {
				// Circle
				for (let i=0;i<verts;i++) {
					let ang=(i/verts)*Math.PI*2;
					let x=Math.cos(ang)*xmul;
					let y=Math.sin(ang)*ymul;
					vertarr.push(new Vector([x,y]));
				}
			}
			let body=world.createbody(vertarr,[0,0],[0]);
			// Random transform.
			type=rnd.getu32();
			let mat=body.mat;
			if (type&2) {
				for (let i=0;i<4;i++) {mat[i]=rnd.getnorm();}
			} else if (type===1) {
				mat.rotate(rnd.getf()*(Math.PI*2));
			}
			// Apply same center-of-mass shifting to vertarr.
			let pos=body.pos;
			for (let v of vertarr) {v.isub(pos);}
			for (let i=0;i<2;i++) {pos[i]=rnd.getnorm()*4;}
			//vertarr=body.vertarr;
			if (side) {
				bvertarr=vertarr;
				bbody=body;
			} else {
				avertarr=vertarr;
				abody=body;
			}
		}
		//if (test!==759718) {continue;}
		let amat=abody.mat,apos=abody.pos;
		let bmat=bbody.mat,bpos=bbody.pos;
		let col1=CollisionDetect1(avertarr,amat,apos,bvertarr,bmat,bpos);
		//let col2=SolveMinkowski1(abody,bbody);
		//let col2=SolveMinkowski2(abody,bbody);
		//let col2=SolveMinkowski3(abody,bbody);
		let col2=Phy.Body.checkoverlap(abody,bbody);
		//let col2=world.closestpoint(abody.vertarr,amat,apos,bbody.vertarr,bmat,bpos);
		//if (!col2[0]) {continue;}
		let over1=col1[0],apos1=col1[1],bpos1=col1[2],dif1=bpos1.sub(apos1);
		let over2=col2[0],apos2=col2[1],bpos2=col2[2],dif2=bpos2.sub(apos2);
		let proj1=CollisionOverlap(avertarr,amat,apos,bvertarr,bmat,bpos,dif1);
		let proj2=CollisionOverlap(avertarr,amat,apos,bvertarr,bmat,bpos,dif2);
		let error=false;
		//if ((proj1<0)!==over1) {
		//	console.log("not separating vector 1",proj1);
		//	error=true;
		//}
		if ((proj2<0)!==over2) {
			console.log("not separating vector 2",proj2);
			error=true;
		}
		// If we have a separating vector, judge by distance instead of projection.
		if (proj1>=0) {proj1=dif1.sqr();}
		if (proj2>=0) {proj2=dif2.sqr();}
		let pmin=proj1,pmax=Infinity;
		if (proj1>=0) {pmin=0;pmax=proj1;}
		if (proj2-pmin<-1e-4 || proj2-pmax>1e-4) {
			console.log("approximation better");
			error=true;
		}
		if (error) {
			console.log(test,proj1,proj2);
			console.log("dif:",proj1-proj2);
			console.log(avertarr,abody.vertarr);
			console.log(bvertarr,bbody.vertarr);
			console.log(apos,bpos);
			console.log("pos 1:",apos1,bpos1);
			console.log("pos 2:",apos2,bpos2);
			throw "error";
		}
	}
}


//---------------------------------------------------------------------------------
// Drawing


function DrawCollisionDetect(a,b,draw) {
	let col=CollisionDetect1(a.vertarr,a.mat,a.pos,b.vertarr,b.mat,b.pos);
	let overlap=col[0],ap=col[1],bp=col[2];
	if (overlap) {draw.setcolor(255,0,0);}
	else {draw.setcolor(0,0,255);}
	draw.drawline(ap[0],ap[1],bp[0],bp[1]);
}


function DrawMinkowski(a,b,draw) {
	draw.setcolor(255,0,0);
	const cenx=draw.img.width/2,ceny=draw.img.height/2;
	let avert=a.vertarr,bvert=b.vertarr;
	let averts=avert.length,bverts=bvert.length;
	if (!averts || !bverts) {return [false,null,null];}
	// Load transforms.
	let amat=a.mat,apos=a.pos;
	let amatxx=amat[0],amatxy=amat[1],amatx=apos[0];
	let amatyx=amat[2],amatyy=amat[3],amaty=apos[1];
	let adet=amatxx*amatyy-amatxy*amatyx;
	let bmat=b.mat,bpos=b.pos;
	let bmatxx=bmat[0],bmatxy=bmat[1],bmatx=bpos[0];
	let bmatyx=bmat[2],bmatyy=bmat[3],bmaty=bpos[1];
	let bdet=bmatxx*bmatyy-bmatxy*bmatyx;
	// Find start of A.
	let aidx=0,ainc=(adet>0?averts-1:1),acnt=averts;
	let ax0=0,ay0=Infinity;
	let ax1=0,ay1=0;
	let v=avert[0],x=v[0],y=v[1];
	let nx1=x*amatxx+y*amatxy;
	let ny1=x*amatyx+y*amatyy;
	for (let i=0,j=0;i<averts;i++) {
		j+=(j<ainc?averts:0)-ainc;
		v=avert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*amatxx+y*amatxy;
		ny1=x*amatyx+y*amatyy;
		if (ny0<ay0 || (ny0===ay0 && nx0<ax0)) {
			aidx=j;
			ax0=nx0;ax1=nx1;
			ay0=ny0;ay1=ny1;
		}
	}
	// Find start of B.
	let bidx=0,binc=(bdet>0?bverts-1:1),bcnt=bverts;
	let bx0=0,by0=-Infinity;
	let bx1=0,by1=0;
	v=bvert[0];x=v[0];y=v[1];
	nx1=x*bmatxx+y*bmatxy;
	ny1=x*bmatyx+y*bmatyy;
	for (let i=0,j=0;i<bverts;i++) {
		j+=(j<binc?bverts:0)-binc;
		v=bvert[j];x=v[0];y=v[1];
		let nx0=nx1,ny0=ny1;
		nx1=x*bmatxx+y*bmatxy;
		ny1=x*bmatyx+y*bmatyy;
		if (ny0>by0 || (ny0===by0 && nx0>bx0)) {
			bidx=j;
			bx0=nx0;bx1=nx1;
			by0=ny0;by1=ny1;
		}
	}
	// Build the Minkowski difference.
	let loop=0;
	let overlap=averts+bverts>3;
	let mindist=Infinity;
	let minax=0,minay=0;
	let minbx=0,minby=0;
	let offx=amatx-bmatx,offy=amaty-bmaty;
	let dx=1,dy=0;
	while (acnt>0 || bcnt>0) {
		// Between A and B, pick the left-most side next.
		let ax=ax0,ay=ay0,adx=ax1-ax0,ady=ay1-ay0;
		let bx=bx0,by=by0,bdx=bx0-bx1,bdy=by0-by1;
		let side=adx*bdy<ady*bdx?1:0;
		let asign=acnt?(dx*adx+dy*ady>0?1:0):-1;
		let bsign=bcnt?(dx*bdx+dy*bdy>0?1:0):-1;
		if (asign!==bsign) {side=bsign>asign?1:0;}
		if (!side) {
			acnt--;
			aidx+=(aidx<ainc?averts:0)-ainc;
			v=avert[aidx];x=v[0];y=v[1];
			ax0=ax1;ax1=x*amatxx+y*amatxy;
			ay0=ay1;ay1=x*amatyx+y*amatyy;
			dx=adx;dy=ady;
		} else {
			bcnt--;
			bidx+=(bidx<binc?bverts:0)-binc;
			v=bvert[bidx];x=v[0];y=v[1];
			bx0=bx1;bx1=x*bmatxx+y*bmatxy;
			by0=by1;by1=x*bmatyx+y*bmatyy;
			dx=bdx;dy=bdy;
		}
		let px=bx-ax-offx,py=by-ay-offy;
		if (px*dy>py*dx) {overlap=false;}
		let px1=bx0-ax0-offx,py1=by0-ay0-offy;
		draw.filltext(px+cenx,py+ceny,loop.toString());loop++;
		draw.drawline(px+cenx,py+ceny,px1+cenx,py1+ceny);
		// Find the closest point on the manifold segment to (0,0).
		let d=dx*dx+dy*dy;
		let u=px*dx+py*dy;
		u=u>0?(u<d?u/d:1):0;
		let ux=dx*u;px-=ux;
		let uy=dy*u;py-=uy;
		let dist=px*px+py*py;
		if (mindist>dist) {
			mindist=dist;
			if (side) {bx-=ux;by-=uy;}
			else      {ax+=ux;ay+=uy;}
			minax=ax;minay=ay;
			minbx=bx;minby=by;
		}
	}
	let ap=new Vector([minax+amatx,minay+amaty]);
	let bp=new Vector([minbx+bmatx,minby+bmaty]);
	if (overlap) {draw.setcolor(255,0,0);}
	else {draw.setcolor(0,0,255);}
	draw.filloval(cenx,ceny,5,5);
	draw.drawline(ap[0],ap[1],bp[0],bp[1]);
	return [overlap,ap,bp];
}


function RandBody(world,verts,rnd) {
	let vert=[];
	for (let i=0;i<verts;i++) {vert.push([rnd.gets()*50,rnd.gets()*50]);}
	let body=world.createbody(vert,[500,500],0);
	for (let i=0;i<4;i++) {body.mat[i]=rnd.gets()*2;}
	return body;
}


function Collision2DDisplay() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let rnd=new Random();
	//rnd.acc=378868995;rnd.inc=2955291637;
	//rnd.acc=4057325140;rnd.inc=2877804663;
	//rnd.acc=4151271293;rnd.inc=3198637479;
	//rnd.acc=305596773;rnd.inc=3579456361;
	console.log(rnd.acc,rnd.inc);
	let draw=new Draw(canv);
	let input=new Input(canv);
	let world=new Phy.World(2);
	let abody=RandBody(world,5,rnd);
	let bbody=RandBody(world,4,rnd);
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		draw.setcolor(255,255,255);
		let mouse=input.getmousepos();
		bbody.pos.set(mouse);
		for (let body of world.bodyiter()) {
			let trans=new Transform({mat:body.mat,vec:body.pos});
			let vertarr=body.vertarr,verts=vertarr.length;
			let v1=trans.apply(vertarr[verts-1]);
			for (let i=0;i<verts;i++) {
				let v0=v1;v1=trans.apply(vertarr[i]);
				draw.drawline(v0[0],v0[1],v1[0],v1[1]);
				draw.filltext(v0[0],v0[1],i.toString());
			}
		}
		//DrawCollisionDetect(abody,bbody,draw);
		DrawMinkowski(abody,bbody,draw);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


//---------------------------------------------------------------------------------
// Main


function main() {
	//HullWrapTest();
	//CollisionResolveTest();
	Collision2DDisplay();
	console.log("done");
}
main();
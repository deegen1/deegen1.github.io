/*------------------------------------------------------------------------------


collision2d.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint collision2d.js -c ../../../standards/eslint.js */


import {Draw,Random,Vector,Transform,Input} from "../library.js";


function DrawMinkowski(a,b) {
}


function Collision2DDisplay() {
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=1000;
	canv.height=1000;
	canv.style.width=canv.width+"px";
	canv.style.height=canv.height+"px";
	let draw=new Draw(canv);
	let input=new Input(canv);
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		let [mx,my]=input.getmousepos();
		draw.setcolor(255,255,0);
		draw.fillrect(mx,my,100,50);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}
Collision2DDisplay();
//---------------------------------------------------------------------------------
// WASM Rendering Module
//
//
// SVG paths and atoms will be queued instead drawn with JS. Queued data will then
// be drawn with wasmrender(). This module is optional.
//
//
// Memory layout
// 	 0        :  mem size
//    4        :  temp start
// 	 8        :  alpha offset
// 	12        :  width
// 	16        :  height
// 	20        :  image data
// 	20+pix*4  :  draw queue
// 	...       :  temp data
//
//
// Path data (type=0)
// 	 0  :  type
// 	 4  :  rgba
// 	 8  :  matxx
// 	12  :  matxy
// 	16  :  matx
// 	20  :  matyx
// 	24  :  matyy
// 	28  :  maty
// 	32  :  path length
// 	36  :  path data
//
//
// Atom data (type=1)
// 	 0  :  type
// 	 4  :  rgba
// 	 8  :  x
// 	12  :  y
// 	16  :  rad

/*
constructor() {
	this.wasmloaded=false;
	// Comment this out to avoid WASM.
	DemoWASMInit(this);
}
update(time) {
	if (this.wasmloaded) {this.wasmrenderstart();}
	...
	if (this.wasmloaded) {this.wasmrender();}
}
*/

async function DemoWASMInit(state) {
	// Attempt to load the WebAssembly program.
	// fill_wasm.c -> compile -> gzip -> base64
	console.log("loading wasm");
	let wasmstr=`
		H4sIAGJiHWgC/6VYSWwb1xl+s4gczpAWqc2U6Dj/e9kUJ3Zkitq8SdRiO2kRH4ocCsShZVFKTNHana2O
		pSBBG6C77QKNGyAkHSNdkh5yiAPokKCn9pZTeyqa3nqrUaBFUQR1v//NcEhGjlMgEoZvmf/97/+/92/z
		xOz6eUMIYQzGzghxxrgozpibm+jgEcbmGWcz+BNnIvWOcUmcsbhnjlrW/NLz8RfAZGXt3NLGueGcMFun
		FjBl8JTLU2vz6+denheW5caELURbJGo4dpuxYhhGm2UII/JQZFPkt7Zs78sawT+GF/2XkYqcnz+/vPaS
		KVKFAjMvzM2Wy4W5jeW1dWF5xbPPhjLFwhGL43rPzm88Nz+7cnZ2fV7YDtisz28MZoXnMJuFc+WyaHO4
		WVkuvySiTnFt9oXZjeXzwgmUWCrOr4mIVygwlwKzsURvoXBuqXhubX5uo7BwYWlu49zyUmFj9mx53hDx
		QqG4vlx4bnapWJ63DBfD2Y3ZAvhYZqJQeLa8fHa27POxMPb18sc21mou/rDNff9gzBKGF/ERuWWY9qZx
		yZzI/2TL7jdF/ge6KSsjb55MiPxVPZRm/udbthJ5e9We4C6Zw6B9a8uWwiOQbjBhSVkkFvPWhfyLq8qw
		J8h8f/LVra2t5CVpkwCZtVGShjWBvj1iCRL50VK9NxD2+sMehb102EuGPSfsTSwqcD+RYFFYHkHW8YTQ
		+7CYoIBomGQKz/sz8NvMv+HrFcu/rjvKDBRXbQEQKlJWFhQrsdYlYi7R1YyKMmr82v4GFIwmzWAsbc+c
		IGsmgT0DnIjfbX0eZRFM8GDRTPJ5OgzUhI8SZA9gmWT6721tfXJb1PHZMTWwc6p/5xTtnErvnErunHJ2
		Tu2E1wngbegXQOxoiAMtfZMwgBNoDXCWYNNv2tIyJ/ifB2KXKQwTPJmY2ihCFsUoSnYyyq8pHy+TKOX3
		YG3caCUzkw64dmlYhTLIfFwf73/us/ddTG7al8xXwCeymP9ULMkxEvvMpDzOjZAnsLfoN9Pq6AysWdRZ
		Y5NjTNC1LRUd35b38SC+Le/n1tmWD3Brb8sH6cS2fIism5LIvCklc4CGxygHaUvqEEMxLIfoEFRWgzJL
		h9heRvPWcRz2Id6G36VLbDWj6FFJZj1yZIpi0qMhSLitXLq/RvdRVg9itQqpinTIpYdq9CDx+IGKjEGN
		UWiApbuxNK21oLFTbJfQuhTapmrg4AE6gS7kPEzOmJWmwxQbs5JoUmOWg8Yb04cOk8wy/zx7DQ1rOZL+
		9oN6EPeF6IQCyZKeafdfH8KZ+Dr4FAngYpZkDty8aRH8zbOjxFqHna3DRGOYMNi5PJILelnQdgZtAi0o
		KOljFvfRilO7P3b9sQsOqdYdnNZhvHXofnH/FJHezwnaeNC6aHn/w+w5/Pfv8RFrAEP4Tz+g3DweWBns
		3KV4NeDrTNRwzHFKNU/0V+XD2CBVJbcq90G1zlbyTvKaJx6pykeBh6fJ9wcvbo3LA6Hssgvm0Usp2Q0T
		6SFPdsBUe6ijqvbS3hr1UndV3Uv31iryHrr3mnyM9l6TA+bFcD3tpQPUVd/z0/GaOkhdFbWL+H9/jR6t
		1OgRPF5F9THXRI3uJf/tvho9jDf9eFIV1ck7ddUqqoFrEej1hUIDm3vmeIY71z25p/7mtmwskZlGt3Fe
		MtnottMA7alRoqISBGEe40GXP8BvyLMIL+mEkfTJJO3CooR0+Yz30kHa9bXU29OiXuNIMrTH14/b6zLj
		Qc5Ms5yZZjnJvZOA9IWT+TqydmCb7i87iu76UXTzUagv4tnxFXICSHf6O12/PfHXl18fLzY7061NDUEY
		hIY58We/Mmi1c1Aa5jIg7vdQBiS5F6Gsz2iQDozB6Qapl4PaIK/oR9PDsW2QVzlokkFsW0QmyuoQ5+lQ
		h8yVPZUwGmINPmINyAOEph8OhCYNH0LjwI3QJOFJaITsiAsP6SfLOSjHjHJ0VKchOGV6Fo68e3Z1Rqf4
		O2goo03ROEu7WfAspVniLMdmB00sjMbYIdogH0EH1RRnmOzj4JwNufYx+oJBRqJ8Pn/bWP3Ix/6z5Ynr
		atc1WMOJKR6fpuN+u55RfddkJ0LUKJ4h5DSVavaoOFKd2i27m5wQMSRCo3x8/Qx9nz4UBsTTZ6Ny3Hcg
		yLCWECMV0+enotx3iwyKB2txsCLGmU3GOH0Ns96Ccn4WypLLTdRHYZA6uXGwypWOnxDaYcfUcVYnBaeq
		eqZ/9scH/+YdSB3TRjfMFWQH9VxXaV6JJIn/3UUVzcBwG8H/hnKr4cK5BBM6VUrXqL2CLaIZyXtBVExV
		uQ0XzmWgVWpBZXkzDz1uUzLOmqQwwVMql1EIv9g4C+o5GTU3MWqvcgy+3vDljjcboiMQOBXFuQJLet4M
		iD7LzwGznl+DOZddWy96qCxi0tWGfLMhce8NLITQLrZH6s2AUWZODgKM36OQEroYpWxZRikDisEMAlM3
		hMEzl4F1xyFp740bOPQk9955B249QkNsbDT8PoRvxOKmbjGjnFZBnSZBKVp6f5K++zqXk0Nsy0MeCgu4
		Asof9kYluLZMAq3WLKxzbJKbbsrwuyEGOJBm8nb9T5epQ8z5eWaW9QvOEQADsodhiNNwUC4/gNQG6jBj
		Df4+dEqXsCMQxIRVBqRqigLP4sEkTdLUUyqSQW/624gPI3ByBmJyRJslwk9G5ZqZ+r5fJ5tmsqyWqf7K
		4O+AYXgltW3kN9fxpbD139deXJV57Hr71c+jqwwJ2auqPhyngESN5Z3n5SGurcvq8HtyGr56lEa0nJP0
		xrsKOuY35ZGmTNjoupZfcWfpyJM4nBwdfjJhozHPq6M4EDLLzQvd5myak1mcZHM9kaXcSa53jpC5KCPM
		c5EYw5uyj47elL1NtNj2Ik2+qwb7zZMcZL+JzRE4CUbJ8RMVpe441AvnrVUV7D4eZgodd/lNZ5iYikpk
		dN3rwFx6mh3RgalwZFZxEhmVLPp1McxHOuyOiDIVOCtbd7wIFuRdQ+RJyrjevx/xwLuuOuoWjCoHMYDY
		V+9i1gj2Uco9kblZVWlKX1NerUbphktI/pJJLUgBLo1Kt6l7d6eRdmONxRIfRkA/UmLtxHtyCqr0VaEf
		JOATbW9C4wY1AHunijwNcBiedKXWUJCBCFcsIDRVK1yfmlCIz4gQKE6iQeTlUceYNYrGo44a7a5QrMq5
		NkK5EiThQNVRRbxpR+CMg6KK3zjoag0F4s1KxypVPhKXkR9FYU5aHwwmoGU7dwYqyA3aYKdo+luQZ1J7
		e/trNMVxRM7w+iF2rCGcc1MkkDOcwfDkWJkgUijBQWAGn9ctIcNjMlDwd2PekH400NWAfbdoYHE0mNkR
		DfiCw/KjQUss6ILhwWfqtDM6JDS7be5JTdcO63QrqABZcXjmEX5OZiirLF2gLKpIXrD7CO2PoRmtjC/M
		UHtjcDwkCec427jXQ5OowBwiN+ekfXfrxvHaGfw44UJYCbRE0UT2TXxVIdnI9lZBdB7exQ9ySZwMfQ2g
		BhEbuKA7FtQjyv4IKfUi2RicwK7xsD6pNSrQeJU8FJjO9NM//t0/+5/+y3gF/lqn/PsnSJHXp99ZOer+
		KboyUWFA6ia28kmt8cJDEbIZfnbeys81fYIu8BWN9xvWGNmnbQOh7BhCrB936dCitOFcowxS03KndbkT
		LFf4/A8Wji+WwYXGS6uUh1VMlGkM3cjamr4moeyTGiQXJ80aNUItf7EiS/MliYXMQNmS5DTmAU9P45nk
		OwsuiwMUrY/gLha6x+2LlLyT9m316VZok1W+QWiBNhZSfhFaH8FYEwSxVghiTQgCsRYELYgeZzXF/w1k
		BCzuAKRFER9IOwBS36fRBMeACTiQrsO9f7RZ7ivupnERm/FdDSeDfaaj3MvbdTv/uPIL1ddq9X3NMT2F
		rSxKPZGB03aBTZzcK+Hi8cpbd11s5fnwxBNIQBxFXdTXWx9fhk6Rq1N+xcQz489kZIKtXyf4bvT8BN/D
		CX63f0XF4dG9KnchICfL/M3OZgxTSH5A8SvMa9xnqyJXtt9u6Pahci7/UEW/zxSnTvMXxy+bxOPKD8/J
		DA7G0gydKz9SToPaaaHOM8ysjGBlLC2K6izJNJigSZH4gLy6MEgxVylyGU7UhtcdJXZ8S9/4ERrLwklp
		zfizzl9zVbUHa2ManGe40KfY1Wcy+oMpoj93oqczozhuSGvyJ0eiwDFGr/s4XOd/60T04tMJAx9Amwzz
		FEW336bIT1V0u/qhpt0av8wrpq76r/2p0xmul6+oqB5RNJi8GsycOq2nhDjDZhr9VWCmnWSxM/YGttrt
		22p3KRj3Ntxg9yJ1lqmn5B/ymgfr9erma3FjcZAl57IvICPo+F18FqU49qcofTK4Vu0oyQ5K8mSSuvzr
		bCgvOJGQeDcpvAhGScP7g2EalwzGzGB0hL6iL3H49m+mmy7G9fVpeBfduLG3mu6lyQqv663wut4Kr+ut
		8LreCq/rrfC63gqv660vu0+273Rdb/v6idHYytpy8cLc/Nq6EUd3bn59fb64/+xLRvypsxeWNi7QXHl2
		6dnUwdyBgQMD+w9e0JMHDxz8H/Hof9abGgAA
	`;
	let gzipbytes=Uint8Array.from(atob(wasmstr),(c)=>c.codePointAt(0));
	let gzipstream=new Blob([gzipbytes]).stream();
	let decstream=gzipstream.pipeThrough(new DecompressionStream("gzip"));
	let decblob=await new Response(decstream).blob();
	let wasmbytes=new Uint8Array(await decblob.arrayBuffer());
	// Compile module.
	let module=new WebAssembly.Module(wasmbytes);
	if (!module) {
		console.log("could not load module");
		return;
	}
	console.log("compiled module");
	// Set up instance specific functions.
	function wasmprinti64(h,l) {
		console.log("Debug: "+((BigInt(h>>>0)<<32n)+BigInt(l>>>0)));
	}
	function wasmprintf64(x) {
		console.log("Debug: "+x);
	}
	function wasmresize(bytes) {
		// state.wasmresize(bytes);
		console.log("resize:",bytes);
		let wasm=state.wasm;
		let heaplen=wasm.heaplen;
		let wasmmem=wasm.instance.exports.memory;
		if (bytes<=wasmmem.buffer.byteLength) {
			if (wasm.memu32!==null) {return;}
			bytes=wasmmem.buffer.byteLength;
		}
		let newlen=1;
		while (newlen<bytes) {newlen+=newlen;}
		let pagebytes=65536;
		let pages=Math.ceil((newlen-wasmmem.buffer.byteLength)/pagebytes);
		wasmmem.grow(pages);
		let wasmbuf=wasmmem.buffer;
		wasm.memu32=new Uint32Array(wasmbuf,heaplen);
		wasm.memf32=new Float32Array(wasmbuf,heaplen);
		wasm.memu32[0]=wasmbuf.byteLength;
		// If the WASM memory was invalidated, reset the image buffer.
		let img=wasm.img;
		if (img!==null) {
			if (!Object.is(wasm.img.data32,wasm.imgdata)) {
				throw "image has been changed";
			}
			let imgw=img.width||1;
			let imgh=img.height||1;
			let pixels=imgw*imgh;
			let off=wasm.memu32.byteOffset+wasm.metalen;
			wasm.imgdata=new Uint32Array(wasmbuf,off,pixels);
			img.data8  =new Uint8Array(wasmbuf,off,pixels*4);
			img.datac8 =new Uint8ClampedArray(wasmbuf,off,pixels*4);
			img.data32 =wasm.imgdata;
			img.imgdata=new ImageData(img.datac8,imgw,imgh);
		}
	}
	function wasmfillfast(r,g,b,a) {
		let wasm=state.wasm;
		let draw=state.draw;
		if (!Object.is(draw.img,wasm.img)) {
			Draw.prototype.fill=wasm.fillorig;
			let ret=draw.fill(r,g,b,a);
			Draw.prototype.fill=wasm.fillfast;
			return ret;
		}
		wasm.imgdata[0]=draw.rgbatoint(r,g,b,a);
		wasm.wasmfill();
	}
	function wasmpolyfast(poly,trans) {
		// Copy the path and image to webassembly memory for faster rendering.
		let wasm=state.wasm;
		let draw=state.draw;
		if (!Object.is(draw.img,wasm.img)) {
			Draw.prototype.fillpoly=wasm.polyorig;
			let ret=draw.fillpoly(poly,trans);
			Draw.prototype.fillpoly=wasm.polyfast;
			return ret;
		}
		if (poly===undefined) {poly=draw.defpoly;}
		trans=trans===undefined?draw.deftrans:draw.tmptrans.set(trans);
		let iw=draw.img.width,ih=draw.img.height;
		let alpha=draw.rgba[3]/255.0;
		if (poly.vertidx<3 || iw<1 || ih<1 || alpha<1e-5) {return;}
		// Screenspace transformation.
		let vmulx=draw.viewmulx,voffx=draw.viewoffx;
		let vmuly=draw.viewmuly,voffy=draw.viewoffy;
		let matxx=trans.data[0]*vmulx,matxy=trans.data[1]*vmulx,matx=(trans.data[2]-voffx)*vmulx;
		let matyx=trans.data[3]*vmuly,matyy=trans.data[4]*vmuly,maty=(trans.data[5]-voffy)*vmuly;
		// Perform a quick AABB-OBB overlap test.
		// Define the transformed bounding box.
		let aabb=poly.aabb;
		let bndx=aabb.minx*matxx+aabb.miny*matxy+matx;
		let bndy=aabb.minx*matyx+aabb.miny*matyy+maty;
		let bnddx0=aabb.dx*matxx,bnddy0=aabb.dx*matyx;
		let bnddx1=aabb.dy*matxy,bnddy1=aabb.dy*matyy;
		// Test if the image AABB has a separating axis.
		let minx=bndx-iw,maxx=bndx;
		if (bnddx0<0) {minx+=bnddx0;} else {maxx+=bnddx0;}
		if (bnddx1<0) {minx+=bnddx1;} else {maxx+=bnddx1;}
		if (maxx<=0 || 0<=minx) {return;}
		let miny=bndy-ih,maxy=bndy;
		if (bnddy0<0) {miny+=bnddy0;} else {maxy+=bnddy0;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Test if the poly OBB has a separating axis.
		let cross=bnddx0*bnddy1-bnddy0*bnddx1;
		minx=bndy*bnddx0-bndx*bnddy0;
		maxx=minx;bnddx0*=ih;bnddy0*=iw;
		if (cross <0) {minx+=cross ;} else {maxx+=cross ;}
		if (bnddx0<0) {maxx-=bnddx0;} else {minx-=bnddx0;}
		if (bnddy0<0) {minx+=bnddy0;} else {maxx+=bnddy0;}
		if (maxx<=0 || 0<=minx) {return;}
		miny=bndy*bnddx1-bndx*bnddy1;
		maxy=miny;bnddx1*=ih;bnddy1*=iw;
		if (cross <0) {maxy-=cross ;} else {miny-=cross ;}
		if (bnddx1<0) {maxy-=bnddx1;} else {miny-=bnddx1;}
		if (bnddy1<0) {miny+=bnddy1;} else {maxy+=bnddy1;}
		if (maxy<=0 || 0<=miny) {return;}
		// Copy to webassembly.
		let vidx=poly.vertidx,varr=poly.vertarr;
		let memu32=wasm.memu32;
		let idx=wasm.memidx;
		let pathlen=9+3*vidx;
		if (idx+pathlen>memu32.length) {
			wasmresize(idx+pathlen);
			memu32=wasm.memu32;
		}
		let memf32=wasm.memf32;
		// console.log(memu32.byteOffset+idx*4);
		// type [0-4]
		memu32[idx++]=0;
		// color [4-8]
		memu32[idx++]=draw.rgba32[0];
		// transform [8-32]
		memf32[idx++]=matxx;
		memf32[idx++]=matxy;
		memf32[idx++]=matx;
		memf32[idx++]=matyx;
		memf32[idx++]=matyy;
		memf32[idx++]=maty;
		// path [32-...]
		memu32[idx++]=vidx;
		for (let i=0;i<vidx;i++) {
			let v=varr[i];
			memu32[idx++]=v.type;
			memf32[idx++]=v.x;
			memf32[idx++]=v.y;
		}
		wasm.memidx=idx;
	}
	function wasmatomfast(atom) {
		let draw=state.draw,img=draw.img;
		// Check if it's on the screen.
		let dw=img.width,dh=img.height,scale=dh;
		let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
		let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
		let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
		let rad=atom.rad*scale+0.5;
		if (dx*dx+dy*dy>=rad*rad) {return;}
		// Copy to webassembly.
		let wasm=state.wasm;
		let memu32=wasm.memu32;
		let idx=wasm.memidx;
		if (idx+5>memu32.length) {
			wasmresize(idx+5);
			memu32=wasm.memu32;
		}
		let memf32=wasm.memf32;
		let data=atom.userdata;
		// console.log(memu32.byteOffset+idx*4);
		memu32[idx++]=1;
		memu32[idx++]=draw.rgbatoint(data.r,data.g,data.b,255);
		memf32[idx++]=x;
		memf32[idx++]=y;
		memf32[idx++]=rad;
		wasm.memidx=idx;
	}
	PhyScene.prototype.wasmrenderstart=function() {
		// Overload: drawatom, fill, and fillpoly.
		let wasm=this.wasm;
		let draw=this.draw;
		let img=draw.img;
		let imgw=img.width,imgh=img.height;
		wasm.memidx=Math.floor(wasm.metalen/4)+imgw*imgh;
		if (wasm.memidx*4>wasm.memu32.length) {
			wasmresize(wasm.memu32.byteOffset+wasm.memidx*4);
		}
		let wasmbuf=wasm.instance.exports.memory.buffer;
		let memu32=wasm.memu32;
		if (!Object.is(wasm.imgdata,img.data32)) {
			let old=wasm.img;
			if (old!==null) {
				let copy=new Draw.Image(old);
				old.data8=copy.data8;
				old.datac8=copy.datac8;
				old.data32=copy.data32;
				old.imgdata=copy.imgdata;
			}
			let off=memu32.byteOffset+wasm.metalen;
			let pixels=imgw*imgh;
			wasm.img=img;
			wasm.imgdata=new Uint32Array(wasmbuf,off,pixels);
			wasm.imgdata.set(img.data32);
			img.data8  =new Uint8Array(wasmbuf,off,pixels*4);
			img.datac8 =new Uint8ClampedArray(wasmbuf,off,pixels*4);
			img.data32 =wasm.imgdata;
			img.imgdata=new ImageData(img.datac8,imgw,imgh);
			memu32[2]=draw.rgbashift[3];
			memu32[3]=imgw;
			memu32[4]=imgh;
		}
		memu32[0]=wasmbuf.byteLength;
		memu32[1]=wasm.memidx;
		// console.log("start idx:",wasm.memu32.byteOffset+wasm.memidx*4);
		wasm.fillorig=Draw.prototype.fill;
		wasm.polyorig=Draw.prototype.fillpoly;
		wasm.atomorig=PhyScene.prototype.drawatom;
		Draw.prototype.fill=wasm.fillfast;
		Draw.prototype.fillpoly=wasm.polyfast;
		PhyScene.prototype.drawatom=wasm.atomfast;
	};
	PhyScene.prototype.wasmrender=function() {
		// Restore: drawatom, fill, and fillpoly.
		let wasm=this.wasm;
		Draw.prototype.fill=wasm.fillorig;
		Draw.prototype.fillpoly=wasm.polyorig;
		PhyScene.prototype.drawatom=wasm.atomorig;
		// Set start of temp memory.
		// console.log("stop idx:",wasm.memu32.byteOffset+wasm.memidx*4);
		wasm.memu32[1]=wasm.memu32.byteOffset+wasm.memidx*4;
		wasm.memidx=0;
		wasm.render();
		// throw "render";
	};
	// Create the WASM instance.
	let imports={env:{wasmprinti64,wasmprintf64,wasmresize}};
	let inst=new WebAssembly.Instance(module,imports);
	if (!inst) {
		console.log("could not create wasm instance");
		return;
	}
	let wasm={
		instance:inst,
		exports :inst.exports,
		heaplen :inst.exports.getheapbase(),
		metalen :20,
		wasmfill:inst.exports.wasmfill,
		render  :inst.exports.wasmrender,
		fillorig:null,
		polyorig:null,
		atomorig:null,
		fillfast:wasmfillfast,
		polyfast:wasmpolyfast,
		atomfast:wasmatomfast,
		img     :null,
		imgdata :null,
		memu32  :null,
		memf32  :null,
		memidx  :0
	};
	state.wasm=wasm;
	wasmresize(wasm.heaplen+wasm.metalen);
	state.wasmloaded=true;
}


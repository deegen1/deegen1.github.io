/*------------------------------------------------------------------------------


hull.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


cross product


*/
/* npx eslint hull.js -c ../../../standards/eslint.js */


import {Draw,Random,Vector,Transform,Input} from "../library.js";


function CalcHull(vertarr) {
	let verts=vertarr.length;
	if (!verts) {return [];}
	let dim=vertarr[0];
}
/*------------------------------------------------------------------------------


testing.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint testing.js -c ../../../standards/eslint.js */
/* global Random, Draw */

function DrawAtom1(atom,draw,distmap,fakemap) {
	// If two atoms overlap, prefer the one that's closer.
	// Overlap is judged by the center of the pixel (.5,.5).
	// let draw=this.draw;
	let img=draw.img;
	let imgdata32=img.data32;
	// let distmap=this.distmap;
	// Check if it's on the screen.
	let dw=img.width,dh=img.height,scale=dh;
	let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
	let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
	let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
	let rad=atom.rad*scale+0.5,rad2=rad*rad;
	if (dx*dx+dy*dy>=rad2) {return;}
	let rad21=rad>1?(rad-1)*(rad-1):0;
	// Fill in the circle at (x,y) with radius 'rad'.
	let data=atom.userdata;
	let miny=Math.floor(y-rad+0.5),maxy=Math.ceil(y+rad-0.5);
	miny=miny> 0?miny: 0;
	maxy=maxy<dh?maxy:dh;
	// PhyAssert(miny<maxy);
	draw.setcolor(data.r,data.g,data.b,255);
	let colrgba=draw.rgba32[0];
	let coll=(colrgba&0x00ff00ff)>>>0;
	let colh=(colrgba&0xff00ff00)>>>0;
	let colh2=colh>>>8;
	for (;miny<maxy;miny++) {
		// Find the boundaries of the row we're on. Clip to center of pixel.
		dy=miny-y+0.5;
		let d2=dy*dy;
		dx=Math.sqrt(rad2-d2)-0.5;
		let minx=Math.floor(x-dx),maxx=Math.ceil(x+dx);
		minx=minx> 0?minx: 0;
		maxx=maxx<dw?maxx:dw;
		dx=minx-x+0.5;
		d2+=dx*dx;
		minx+=dw*miny;
		maxx+=dw*miny;
		// Normal version. Time FF: 2.582620, time CR: 2.692565
		for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let m2=distmap[minx];
			let u=(m2-d2)*0.5,u1=u+0.5,u2=u-0.5;
			// sqrt(m2)-sqrt(d2)>-1
			if (u1>0 || m2>u1*u1) {
				fakemap[minx]=d2<m2?d2:m2;
				// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
				if (d2<=rad21 && u2>0 && d2<u2*u2) {
					imgdata32[minx]=colrgba;
				} else {
					// Blend if we're on the edge or bordering another atom.
					let dst=imgdata32[minx];
					let dist=Math.sqrt(d2);
					let bord=Math.sqrt(m2)-dist;
					let edge=rad-dist;
					let a=(256-(bord<1?(bord+1)*128:256)*(edge<1?edge:1))|0;
					imgdata32[minx]=
						(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
						((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
				}
			}
			d2+=2*dx+1;
			dx++;
		}
		// Sqrt version. Time FF: 2.740580, time CR: 2.834620
		/*for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let md=distmap[minx];
			// md+1>sqrt(d2)
			if (d2<(md+1)*(md+1)) {
				let dist=Math.sqrt(d2);
				let edge=rad-dist;
				let bord=md-dist+1;
				fakemap[minx]=dist<md?dist:md;
				// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
				if (edge>=1 && bord>=2) {
					imgdata32[minx]=colrgba;
				} else {
					// Blend if we're on the edge or bordering another atom.
					let dst=imgdata32[minx];
					let u=1-(bord<2?bord*0.5:1)*(edge<1?edge:1);
					let a=(u*256)|0;
					imgdata32[minx]=(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
					                ((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
				}
			}
			d2+=2*dx+1;
			dx++;
		}*/
		// No conditionals version. Time FF: 3.998880, time CR: 3.543120
		/*for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let md=distmap[minx];
			let dist=Math.sqrt(d2);
			let edge=rad-dist;
			let bord=md-dist+1;
			bord=bord>0?(bord<2?bord:2):bord;
			fakemap[minx]=dist<md?dist:md;
			// Blend if we're on the edge or bordering another atom.
			let dst=imgdata32[minx];
			let u=1-bord*0.5*(edge<1?edge:1);
			let a=(u*256)|0;
			imgdata32[minx]=(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
			                ((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
			d2+=2*dx+1;
			dx++;
		}*/
		// PhyAssert(maxx>=dw*miny+dw || d2>=rad2,[d2,rad2]);
	}
}


function TestAtomFill() {
	console.log("starting atom fill test");
	let rnd=new Random(0);
	let dw=999,dh=1000,pixels=dw*dh;
	let maxrad=50;
	let scale=1.0/dh;
	let draw=new Draw(dw,dh);
	let distmap=new Float32Array(pixels);
	let fakemap=new Float32Array(pixels);
	for (let i=0;i<pixels;i++) {distmap[i]=rnd.getf()*maxrad;}
	// Normal version uses squared distances
	for (let i=0;i<pixels;i++) {distmap[i]*=distmap[i];}
	let minx=-maxrad*scale,maxx=(dw+maxrad)*scale;
	let miny=-maxrad*scale,maxy=(dh+maxrad)*scale;
	let time=performance.now();
	for (let test=0;test<100000;test++) {
		let atom={
			pos:[rnd.getf()*(maxx-minx)+minx,rnd.getf()*(maxy-miny)+miny],
			rad:rnd.getf()*maxrad*scale,
			userdata:{r:rnd.getf()*256,g:rnd.getf()*256,b:rnd.getf()*256}
		};
		DrawAtom1(atom,draw,distmap,fakemap);
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


function TestMain() {
	console.log("testing");
	//TestAtomFill();
	console.log("done");
}

TestMain();
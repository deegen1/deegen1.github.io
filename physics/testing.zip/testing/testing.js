/*------------------------------------------------------------------------------


testing.js - v1.01

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


Dist = Random
DrawAtom1: FF: 4.266580, CR: 4.218610
DrawAtom2: FF: 4.130800, CR: 4.116455
DrawAtom3: FF: 4.041860, CR: 3.998840

Dist = Inf
DrawAtom1: FF: 2.144820, CR: 1.703985
DrawAtom2: FF: 2.136980, CR: 1.718145
DrawAtom3: FF: 1.588100, CR: 1.695400


*/
/* npx eslint testing.js -c ../../../standards/eslint.js */


import {Phy} from "../physics.js";
import {Random,Vector,Matrix,Transform,Input,Draw} from "../library.js";


function PhyAssert(cond,msg) {
	if (!cond) {
		console.log(msg);
		throw "error";
	}
}


//---------------------------------------------------------------------------------
// Drawing


class DrawAtom {

	// drawatom
	//      FF Array: 2.998120
	//      FF F32  : 2.788260
	//      FF F64  : 3.024740
	//      CR Array: 2.962315
	//      CR F32  : 2.866525
	//      CR F64  : 2.955715
	//
	// Clear array.fill()
	//      FF Array: 11.079600
	//      FF F32  : 5.715860
	//      FF F64  : 6.396300
	//      CR Array: 9.694990
	//      CR F32  : 3.114185
	//      CR F64  : 3.227760
	//
	// Clear fill+=1
	//      FF Array: 8.221300
	//      FF F32  : 3.881260
	//      FF F64  : 5.134740
	//      CR Array: 5.100005
	//      CR F32  : 6.084015
	//      CR F64  : 6.206215
	//
	// Clear fill+=8
	//      FF Array: 5.958520
	//      FF F32  : 3.255480
	//      FF F64  : 3.316220
	//      CR Array: 3.291560
	//      CR F32  : 4.528440
	//      CR F64  : 4.648790
	//
	// Fastest: Float32Array, Fill+8

	constructor(dw,dh) {
		let pixels=dw*dh;
		this.scale=1;
		this.draw=new Draw(dw,dh);
		this.distmap=(new Float32Array(pixels)).fill(0);
		this.fakemap=(new Float32Array(pixels)).fill(0);
	}


	filldist() {
		// array.fill()
		// this.distmap.fill(Infinity);
		// fill+=1
		// let distmap=this.distmap,img=this.draw.img;
		// let pixels=img.width*img.height;
		// for (let i=0;i<pixels;i++) {distmap[i]=Infinity;}
		// fill+=8
		let distmap=this.distmap,img=this.draw.img;
		let i=img.width*img.height;
		while (i>7) {
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
		}
		while (i>0) {
			distmap[--i]=Infinity;
		}
	}


	drawatom1(atom) {
		// If two atoms overlap, prefer the one that's closer.
		// Overlap is judged by the center of the pixel (.5,.5).
		let draw=this.draw,img=draw.img;
		// Check if it's on the screen.
		let dw=img.width,dh=img.height,scale=this.scale;
		let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
		let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
		let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
		let rad=atom.rad*scale+0.5,rad2=rad*rad;
		if (dx*dx+dy*dy>=rad2) {return;}
		let rad21=rad>1?(rad-1)*(rad-1):0;
		// Fill in the circle at (x,y) with radius 'rad'.
		let colrgba=draw.rgbatoint(atom.data.rgb);
		let coll=(colrgba&0x00ff00ff)>>>0;
		let colh=(colrgba&0xff00ff00)>>>0;
		let colh2=colh>>>8;
		let miny=Math.floor(y-rad+0.5),maxy=Math.ceil(y+rad-0.5);
		miny=miny> 0?miny: 0;
		maxy=maxy<dh?maxy:dh;
		// PhyAssert(miny<maxy);
		let imgdata=img.data32;
		let distmap=this.distmap;
		let fakemap=this.fakemap;
		for (;miny<maxy;miny++) {
			// Find the boundaries of the row we're on. Clip to center of pixel.
			dy=miny-y+0.5;
			let d2=dy*dy;
			dx=Math.sqrt(rad2-d2)-0.5;
			let minx=Math.floor(x-dx),maxx=Math.ceil(x+dx);
			minx=minx> 0?minx: 0;
			maxx=maxx<dw?maxx:dw;
			dx=minx-x+0.5;
			d2+=dx*dx;
			minx+=dw*miny;
			maxx+=dw*miny;
			for (;minx<maxx;minx++) {
				// Check if we can overwrite another atom's pixel, or if we need to blend them.
				// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
				let m2=distmap[minx];
				let u=(m2-d2)*0.5,u1=u+0.5,u2=u-0.5;
				// sqrt(m2)-sqrt(d2)>-1
				if (u1>0 || m2>u1*u1) {
					// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
					if (d2<=rad21 && u2>0 && d2<u2*u2) {
						// Only write the distance if we're inside the border.
						fakemap[minx]=d2;
						imgdata[minx]=colrgba;
					} else {
						// Blend if we're on the edge or bordering another atom.
						let dst=imgdata[minx];
						let dist=Math.sqrt(d2);
						let bord=Math.sqrt(m2)-dist;
						let edge=rad-dist;
						let a=(256-(bord<1?(bord+1)*128:256)*(edge<1?edge:1))|0;
						imgdata[minx]=
							(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
							((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
					}
				}
				d2+=2*dx+1;
				dx++;
			}
			// PhyAssert(maxx>=dw*miny+dw || d2>=rad2,[d2,rad2]);
		}
	}


	drawatom2(atom) {
		// If two atoms overlap, prefer the one that's closer.
		// Overlap is judged by the center of the pixel (.5,.5).
		let draw=this.draw,img=draw.img;
		// Check if it's on the screen.
		let imgw=img.width,imgh=img.height,scale=this.scale;
		let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
		let dx=(x>1?(x<imgw?x:imgw):1)-0.5-x;
		let dy=(y>1?(y<imgh?y:imgh):1)-0.5-y;
		let rad=atom.rad*scale+0.5,rad2=rad*rad;
		if (dx*dx+dy*dy>=rad2) {return;}
		let rad21=rad>1?(rad-1)*(rad-1):0;
		// Fill in the circle at (x,y) with radius 'rad'.
		let colrgba=draw.rgbatoint(atom.data.rgb);
		let coll=(colrgba&0x00ff00ff)>>>0;
		let colh=(colrgba&0xff00ff00)>>>0;
		let colh2=colh>>>8,tmp=0;
		const rnd0=0.5+1e-6,rnd1=0.5-1e-6;
		tmp=y-rad+rnd0;let miny=tmp>0?~~tmp:0;
		tmp=y+rad+rnd1;let maxy=tmp<imgh?~~tmp:imgh;
		//PhyAssert(miny<maxy);
		let imgdata=img.data32;
		let distmap=this.distmap;
		let fakemap=this.fakemap;
		for (;miny<maxy;miny++) {
			// Find the boundaries of the row we're on. Clip to center of pixel.
			dy=miny-y+0.5;
			let d2=dy*dy;
			//PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			dx=Math.sqrt(rad2-d2);
			tmp=x-dx+rnd0;let minx=tmp>0?~~tmp:0;
			tmp=x+dx+rnd1;let maxx=tmp<imgw?~~tmp:imgw;
			dx=minx-x+0.5;
			d2+=dx*dx;
			dx+=dx+1;
			minx+=miny*imgw;
			maxx+=miny*imgw;
			for (;minx<maxx;minx++) {
				// Check if we can overwrite another atom's pixel, or if we need to blend them.
				//PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
				let m2=distmap[minx];
				let u2=(m2-d2+1)*0.5;
				// sqrt(m2)-sqrt(d2)>-1
				if (u2>0 || m2>u2*u2) {
					// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
					u2-=1;
					if (d2<=rad21 && u2>0 && d2<u2*u2) {
						// Only write the distance if we're inside the border.
						fakemap[minx]=d2;
						imgdata[minx]=colrgba;
					} else {
						// Blend if we're on the edge or bordering another atom.
						let dst=imgdata[minx];
						let dist=Math.sqrt(d2);
						let over=Math.sqrt(m2)-dist;
						let edge=rad-dist;
						let a=~~(256-(over<1?(over+1)*128:256)*(edge<1?edge:1));
						imgdata[minx]=
							(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
							((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
					}
				}
				d2+=dx;
				dx+=2;
			}
			//PhyAssert(maxx>=miny*imgw+imgw || d2>=rad2,[d2,rad2]);
		}
	}


	drawatom3(atom) {
		// If two atoms overlap, prefer the one that's closer.
		// Overlap is judged by the center of the pixel (.5,.5).
		let draw=this.draw,img=draw.img;
		// Check if it's on the screen.
		let dw=img.width,dh=img.height,scale=this.scale;
		let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
		let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
		let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
		let rad=atom.rad*scale+0.5,rad2=rad*rad;
		if (dx*dx+dy*dy>=rad2) {return;}
		// Fill in the circle at (x,y) with radius 'rad'.
		let colrgba=draw.rgbatoint(atom.data.rgb);
		let coll=(colrgba&0x00ff00ff)>>>0;
		let colh=(colrgba&0xff00ff00)>>>0;
		let colh2=colh>>>8;
		const rnd0=0.5+1e-6,rnd1=0.5-1e-6;
		let miny=y-rad+rnd0;miny=miny> 0?~~miny: 0;
		let maxy=y+rad+rnd1;maxy=maxy<dh?~~maxy:dh;
		// PhyAssert(miny<maxy);
		let imgdata=img.data32;
		let distmap=this.distmap;
		let fakemap=this.fakemap;
		for (;miny<maxy;miny++) {
			// Find the boundaries of the row we're on. Clip to center of pixel.
			dy=miny-y+0.5;
			let d2=dy*dy;
			//PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			dx=Math.sqrt(rad2-d2);
			let minx=x-dx+rnd0;minx=minx> 0?~~minx: 0;
			let maxx=x+dx+rnd1;maxx=maxx<dw?~~maxx:dw;
			dx=minx-x+0.5;
			d2+=dx*dx;
			dx+=dx+1;
			minx+=dw*miny;
			maxx+=dw*miny;
			for (;minx<maxx;minx++) {
				// Check if we can overwrite another atom's pixel, or if we need to blend them.
				//PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
				let md=distmap[minx]+1;
				// md+1>sqrt(d2)
				if (d2<md*md) {
					let dist=Math.sqrt(d2);
					let edge=rad-dist;
					let over=md-dist;
					// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
					if (edge>=1 && over>=2) {
						fakemap[minx]=dist;
						imgdata[minx]=colrgba;
					} else {
						// Blend if we're on the edge or bordering another atom.
						let dst=imgdata[minx];
						let a=~~(256-(over<2?over*128:256)*(edge<1?edge:1));
						imgdata[minx]=(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
						              ((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
					}
				}
				d2+=dx;
				dx+=2;
			}
			// PhyAssert(maxx>=dw*miny+dw || d2>=rad2,[d2,rad2]);
		}
	}

}


function DistFillTest() {
	console.log("starting atom fill test");
	let rnd=new Random(0);
	let dw=999,dh=1000,pixels=dw*dh;
	let da=new DrawAtom(dw,dh);
	for (let i=0;i<pixels;i++) {da.distmap[i]=rnd.getf();}
	let time=performance.now();
	for (let test=0;test<10000;test++) {
		da.filldist();
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


function AtomDrawTest() {
	console.log("starting atom draw test");
	let rnd=new Random(0);
	let maxdim=1000;
	let maxrad=50;
	let tests=200000;
	let da=new DrawAtom(maxdim,maxdim);
	// Normal version uses squared distances
	let distmap=da.distmap,pixels=maxdim*maxdim;
	for (let i=0;i<pixels;i++) {distmap[i]=Math.pow(rnd.getf()*maxrad,2);}
	let time=performance.now();
	let atom={
		pos:[0,0],
		rad:1,
		data:{
			rgb:[rnd.getf()*256|0,rnd.getf()*256|0,rnd.getf()*256|0,255]
		}
	};
	let img=da.draw.img;
	for (let test=0;test<tests;test++) {
		let imgw=rnd.mod(maxdim+1);
		let imgh=rnd.mod(maxdim+1);
		img.width =imgw;
		img.height=imgh;
		atom.pos[0]=rnd.getf()*(imgw+maxrad*2)-maxrad;
		atom.pos[1]=rnd.getf()*(imgh+maxrad*2)-maxrad;
		atom.rad=rnd.getf()*maxrad;
		atom.data.rgb[0]=rnd.getu32()&255;
		//da.drawatom1(atom);
		da.drawatom2(atom);
		//da.drawatom3(atom);
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


function AtomDrawInfTest() {
	console.log("starting atom draw test");
	let rnd=new Random(0);
	let maxdim=1000;
	let maxrad=50;
	let tests=200000;
	let da=new DrawAtom(maxdim,maxdim);
	// Normal version uses squared distances
	da.distmap.fill(Infinity);
	let time=performance.now();
	let atom={
		pos:[0,0],
		rad:1,
		data:{
			rgb:[rnd.getf()*256|0,rnd.getf()*256|0,rnd.getf()*256|0,255]
		}
	};
	let img=da.draw.img;
	for (let test=0;test<tests;test++) {
		let imgw=rnd.mod(maxdim+1);
		let imgh=rnd.mod(maxdim+1);
		img.width =imgw;
		img.height=imgh;
		atom.pos[0]=rnd.getf()*(imgw+maxrad*2)-maxrad;
		atom.pos[1]=rnd.getf()*(imgh+maxrad*2)-maxrad;
		atom.rad=rnd.getf()*maxrad;
		atom.data.rgb[0]=rnd.getu32()&255;
		//da.drawatom1(atom);
		//da.drawatom2(atom);
		da.drawatom3(atom);
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


function AtomDrawDemo() {
	let dstw=1000,dsth=1000;
	let canv=document.createElement("canvas");
	document.body.appendChild(canv);
	canv.style.background="#000000";
	canv.style.position="absolute";
	canv.style.top="0px";
	canv.style.left="0px";
	canv.width=dstw;
	canv.height=dsth;
	canv.style.width=dstw+"px";
	canv.style.height=dsth+"px";
	let da=new DrawAtom(dstw,dsth);
	da.fakemap=da.distmap;
	let draw=da.draw;
	draw.screencanvas(canv);
	let input=new Input(canv);
	let rnd=new Random(1);
	let atomarr=[];
	for (let i=0;i<500;i++) {
		atomarr.push({
			pos:[rnd.getf()*dstw,rnd.getf()*dsth],
			rad:rnd.getf()*50,
			data:{
				rgb:[rnd.getf()*256|0,rnd.getf()*256|0,rnd.getf()*256|0,255]
			}
		});
	}
	function update() {
		requestAnimationFrame(update);
		input.update();
		draw.fill(0,0,0,255);
		draw.setcolor(40,40,80,255);
		let dim=50;
		for (let y=0;y<dsth;y+=dim) {
			for (let x=0;x<dstw;x+=dim) {
				if ((x+y)%(2*dim)) {
					draw.fillrect(x,y,dim,dim);
				}
			}
		}
		atomarr[atomarr.length-1].pos=input.getmousepos();
		let time=performance.now();
		da.filldist();
		for (let atom of atomarr) {
			da.drawatom2(atom);
		}
		time=(performance.now()-time)*0.001;
		draw.setcolor(255,255,255,255);
		draw.filltext(5,5,"Time: "+time.toFixed(6),20);
		draw.screenflip();
	}
	requestAnimationFrame(update);
}


//---------------------------------------------------------------------------------
// Broadphase


function BroadphaseBoundFilter() {
	let arr=[
		[-Infinity,-Infinity],
		[-Infinity,1],
		[-Infinity,Infinity],
		[1,1],
		[1,Infinity],
		[Infinity,Infinity]
	];
	for (let bnd of arr) {
		let [min,max]=bnd;
		let val=max>min?max-min:0;
		val=val>=0?val:Infinity;
		console.log(max+" - "+min+" = "+val);
	}
}


function BroadphaseCheckTree(broad,used,trail) {
	let dim=broad.world.dim*2;
	const aabb=3;
	let nodesize=aabb+dim;
	let volume=0;
	let atomcnt=broad.atomcnt;
	if (!atomcnt) {return volume;}
	let memi=broad.memi32;
	let memf=broad.memf32;
	const root=0;
	let leafstart=nodesize*(atomcnt-1);
	let leafend=leafstart+nodesize*atomcnt;
	let leaflast=leafend-nodesize;
	let trailidx=1,trailstop=atomcnt*2-1;
	if (trailstop>trail.length) {trailstop=trail.length;}
	for (let i=0;i<atomcnt;i++) {used[i]=0;}
	trail[0]=root;
	if (root<0 || root>leaflast || memi[root+1]!==-1) {
		console.log("invalid root:",root,memi[root+1]);
		throw "error";
	}
	for (let t=0;t<trailstop;t++) {
		if (t>=trailidx) {
			console.log("end of trail:",t,trailidx);
			throw "error";
		}
		let n=trail[t],p=memi[n+1];
		// Check bounding box against parent
		let vol=1;
		for (let i=0;i<dim;i+=2) {
			let nbnd=n+aabb+i,pbnd=(p>=0?p:0)+aabb+i;
			let nl=memf[nbnd],nr=memf[nbnd+1];
			let pl=memf[pbnd],pr=memf[pbnd+1];
			if (!(pl<=nl && nr<=pr) || !(nl<=nr)) {
				console.log("child box not in parent",n,p);
				throw "error";
			}
			vol*=nr-nl;
		}
		// Check children
		let l=n+nodesize; // memi[n+1];
		let r=memi[n+2];
		let flags=memi[n+0];
		if (!(flags&1)) {
			if (vol<Infinity) {volume+=vol;}
			if (l<0 || l>leaflast || l!==(l|0) || memi[l+1]!==n) {
				console.log("left child misaligned:",n,l,r);
				throw "error";
			}
			if (r<0 || r>leaflast || r!==(r|0) || memi[r+1]!==n || r===l) {
				console.log("right child misaligned:",n,l,r);
				throw "error";
			}
			if ((flags&2)!==(memi[l]&memi[r]&2)) {
				console.log("children not sleeping:",flags&2,memi[l]&2,memi[r]&2);
				throw "error";
			}
			if (trailidx+2>trailstop) {
				console.log("trail length:",trailidx,trailstop);
				throw "error";
			}
			trail[trailidx++]=l;
			trail[trailidx++]=r;
		} else {
			let atom=r;
			if (atom!==(atom|0) || atom<0 || atom>=atomcnt || used[atom]) {
				console.log("invalid atom:",n,atom,atomcnt);
				throw "error";
			}
			used[atom]=1;
		}
	}
	return volume;
}


function BroadphaseStressTest() {
	// Make sure every overlap is detected and collisions occur exactly once.
	//
	// Stats with current broadphase:
	//
	//      duplicate: 0
	//      match    : 28392171
	//      phantom  : 2818698
	//      miss     : 0
	//      AABB hits: 88477517
	//
	console.log("testing broadphase");
	let maxatoms=1000;
	let maxdim=5;
	let maxhits=maxatoms*maxatoms;
	let atomarr=new Array(maxatoms);
	let hitcount=new Array(maxhits);
	let used=new Uint32Array(maxatoms);
	let trail=new Uint32Array(maxatoms*2);
	let tests=100;
	// Replace atom and broadphase collide() for stat tracking.
	let atomcol=Phy.Atom.collide;
	Phy.Atom.collide=function(a,b) {
		let aid=a.id,bid=b.id;
		if (aid>bid) {aid=bid;bid=a.id;}
		hitcount[aid*maxatoms+bid]+=2;
	};
	let broadcol=Phy.Broadphase.prototype.collide;
	let newsrc=broadcol.toString();
	newsrc=newsrc.replace("// Down - check for overlap.","Phy.Broadphase.aabbhits++;");
	newsrc=newsrc.replace(/.*\{/,"");
	newsrc=newsrc.replace(/\}\s*$/,"");
	Phy.Broadphase.prototype.collide=new Function(newsrc);
	let rnd=new Random(2);
	function exprand() {return (rnd.getf()*2-1)*Math.pow(2,rnd.getf()*32-20);}
	let hitsum=[0,0,0,0,0];
	let dimhit=(new Array(maxdim+1)).fill(0);
	let dimvol=(new Array(maxdim+1)).fill(0);
	for (let test=0;test<tests;test++) {
		let dim=rnd.modu32(maxdim+1);
		let world=new Phy.World(dim);
		let type=world.createatomtype(0,1,0);
		for (let atoms=0;atoms<maxatoms;) {
			console.log("test:",test,dim,atoms);
			let atomadd=rnd.modu32(64);
			for (let a=0;a<atomadd && atoms<maxatoms;a++) {
				// Generate random positions and radius's.
				let pos=new Vector(dim);
				for (let i=0;i<dim;i++) {pos[i]=exprand();}
				let atom=world.createatom(pos,Math.abs(exprand()),type);
				atom.sleeping=(rnd.getu32()&1)?true:false;
				atom.id=atoms;
				atomarr[atoms++]=atom;
			}
			for (let i=0;i<maxhits;i++) {hitcount[i]=0;}
			for (let i=1;i<atoms;i++) {
				let atom=atomarr[i];
				let apos=atom.pos;
				let arad=atom.rad;
				let asleep=atom.sleeping;
				for (let j=0;j<i;j++) {
					atom=atomarr[j];
					if (!asleep || !atom.sleeping) {
						let bpos=atom.pos;
						let rad=atom.rad+arad;
						let dist=0;
						for (let d=0;d<dim;d++) {
							let x=apos[d]-bpos[d];
							dist+=x*x;
						}
						if (dist<rad*rad) {
							hitcount[j*maxatoms+i]=1;
						}
					}
				}
			}
			// Rebuild multiple times to catch any memory shuffling errors.
			let memi=world.broad.memi32;
			if (memi!==null && memi!==undefined) {
				let len=memi.length;
				for (let i=0;i<len;i++) {memi[i]=rnd.getu32();}
			}
			world.broad.build();
			BroadphaseCheckTree(world.broad,used,trail);
			Phy.Broadphase.aabbhits=0;
			world.broad.collide();
		}
		dimhit[dim]+=Phy.Broadphase.aabbhits;
		dimvol[dim]+=BroadphaseCheckTree(world.broad,used,trail);
		for (let i=0;i<maxhits;i++) {
			let cnt=hitcount[i];
			hitsum[cnt<4?cnt:4]++;
		}
	}
	console.log("duplicate:",hitsum[4]);
	console.log("match    :",hitsum[3]);
	console.log("phantom  :",hitsum[2]);
	console.log("miss     :",hitsum[1]);
	console.log("AABB hits:",Phy.Broadphase.aabbhits);
	for (let i=0;i<=maxdim;i++) {
		let vol=dimvol[i],hit=dimhit[i];
		console.log(i+": vol "+vol.toFixed(0)+", hit "+hit);
	}
	Phy.Atom.collide=atomcol;
	Phy.Broadphase.prototype.collide=broadcol;
}


function BroadphaseSpeedTest() {
	// Firefox
	//
	//      1: 0.195308, 29058380
	//      2: 0.112012, 62560
	//      3: 0.140488, 1070
	//      4: 0.165446, 60
	//
	// Chrome
	//
	//      1: 0.168849, 29058380
	//      2: 0.113747, 62560
	//      3: 0.138402, 1070
	//      4: 0.165947, 60
	//
	console.log("testing broadphase");
	let collisions=0;
	let origcol=Phy.Atom.collide;
	Phy.Atom.collide=function() {collisions++;};
	let rnd=new Random(2);
	let atoms=200000,tests=10;
	for (let dim=1;dim<5;dim++) {
		let world=new Phy.World(dim);
		let type=world.createatomtype(0,1,0);
		let radmul=(1<<dim)/atoms;
		for (let a=0;a<atoms;a++) {
			// Generate random positions and radius's.
			let pos=new Vector(dim);
			for (let i=0;i<dim;i++) {pos[i]=rnd.getf();}
			let rad=radmul/(rnd.getf()+.01);
			let atom=world.createatom(pos,rad,type);
			atom.sleeping=rnd.getu32()&1;
		}
		for (let warmup=0;warmup<2;warmup++) {
			world.broad.build();
			world.broad.collide();
		}
		collisions=0;
		let time=performance.now();
		for (let test=0;test<tests;test++) {
			world.broad.build();
			world.broad.collide();
		}
		time=(performance.now()-time)/(1000*tests);
		console.log(dim.toString()+": "+time.toFixed(6)+", "+collisions);
	}
	Phy.Atom.collide=origcol;
}


//---------------------------------------------------------------------------------
// Narrowphase


function NarrowphaseSpeedTest() {
	// Firefox
	//
	//      0: 0.043260
	//      1: 0.045020
	//      2: 0.045680
	//      3: 0.106000
	//      4: 0.115460
	//      5: 0.146480
	//
	let tests=300000;
	let trials=10;
	let atoms=tests*2;
	let rnd=new Random(3);
	let atomarr=new Array(atoms);
	let posarr=new Array(atoms);
	for (let dim=0;dim<6;dim++) {
		let world=new Phy.World(dim);
		let types=5;
		let typearr=new Array(types);
		for (let i=0;i<types;i++) {
			typearr[i]=world.createatomtype(rnd.getf(),rnd.getf(),rnd.getf());
		}
		typearr[0].intarr[1].collide=false;
		let lastpos=null,lastrad=0,pos0=new Vector(dim);
		for (let i=0;i<atoms;i++) {
			if (!(i&1)) {lastpos=pos0;lastrad=10;}
			let rad=rnd.getf();
			let space=rnd.getf()*2*(rad+lastrad);
			if (((i>>1)&255)===0) {space=0;}
			let pos=Vector.random(dim).imul(space).iadd(lastpos);
			posarr[i]=new Vector(pos);
			atomarr[i]=world.createatom(pos,rad,typearr[rnd.modu32(types)]);
			lastpos=pos;
			lastrad=rad;
		}
		let collide=Phy.Atom.collide;
		let time=performance.now();
		for (let trial=0;trial<trials;trial++) {
			for (let i=0;i<atoms;i+=2) {
				let a=atomarr[i],b=atomarr[i+1];
				a.pos.set(posarr[i  ]);a.vel.set(0);
				b.pos.set(posarr[i+1]);b.vel.set(0);
				collide(a,b);
			}
		}
		time=(performance.now()-time)/(trials*1000);
		console.log(dim+": "+time.toFixed(6));
	}
}


//---------------------------------------------------------------------------------
// Bonds


function BondStepTest() {
	// Simulate integrating bond forces.
	//
	// pos        + vel    : error increases a lot as steps increase
	// pos*dt     + vel*dt : error increases slightly as steps increase
	// pos*dt^2   + vel*dt : error decreases as steps increase
	// pos*dt^2/2 + vel*dt : error decreases as steps increase
	for (let steps=1;steps<21;steps++) {
		let dt=1/steps;
		let tension=0.1;
		let pos=1,vel=0;
		for (let s=0;s<steps;s++) {
			// update atom
			pos+=vel*dt;
			// update bond
			let dif=pos-0;
			dif*=tension;
			pos-=dif*dt*dt*0.5;
			vel-=dif*dt;
		}
		let pos0=1-tension*0.5;
		let vel0=0-tension;
		let err=Math.abs(pos-pos0)+Math.abs(vel-vel0);
		console.log(steps+" err: "+err.toFixed(6),pos,vel);
	}
	/*for (let steps=1;steps<21;steps++) {
		let dt=1/steps;
		let tension=0.1;
		let pos=1,vel=0,acc=0;
		for (let s=0;s<steps;s++) {
			// update atom
			pos+=vel*dt+acc*dt*dt*0.5;
			vel+=acc*dt;
			acc=0;
			// update bond
			let dif=pos-0;
			dif*=tension;
			acc-=dif;
		}
		let pos0=1-tension*0.5;
		let vel0=0-tension;
		let err=Math.abs(pos-pos0)+Math.abs(vel-vel0);
		console.log(steps+" err: "+err.toFixed(6),pos,vel);
	}*/
}


//---------------------------------------------------------------------------------
// Dynamics


function ThreeBallProblem() {
	// Try and aggregate forces so collision order doesn't matter.
	// Result: this trivially fails. If an atom is moving to the right and collides
	// with a stack of atoms with the same coordinate, the force in the system is
	// multiplies.
	//
	// Measure forces before and after.
	//
	//  O      O
	// O      OO
	//  O      O
	//
	let posarr=[[0,0],[1,-1],[1,1],[1,0],[1,0]];
	let atomarr=[];
	for (let pos of posarr) {
		atomarr.push({
			mass:1,
			rad:1,
			pos:new Vector(pos),
			vel:new Vector(2),
			posacc:new Vector(2),
			velacc:new Vector(2),
			posden:0,
			velden:0
		});
	}
	atomarr[0].vel[0]=1;
	let force0=0;
	for (let a of atomarr) {force0+=a.mass*a.vel.mag();}
	for (let a0=1;a0<atomarr.length;a0++) {
		for (let a1=0;a1<a0;a1++) {
			// if (a0 && a1) {continue;}
			let a=atomarr[a0];
			let b=atomarr[a1];
			let apos=a.pos,bpos=b.pos;
			let dim=apos.length,i=0;
			let dist=0.0,dif=0,norm=new Vector(dim);
			for (i=0;i<dim;i++) {
				dif=bpos[i]-apos[i];
				norm[i]=dif;
				dist+=dif*dif;
			}
			let rad=a.rad+b.rad;
			let amass=a.mass,bmass=b.mass;
			let mass=amass+bmass;
			// if ((amass>=Infinity && bmass>=Infinity) || mass<=1e-10 || dim===0) {
			// 	return;
			// }
			amass=amass>=Infinity? 1.0: amass/mass;
			bmass=bmass>=Infinity?-1.0:-bmass/mass;
			// If the atoms are too close together, randomize the direction.
			let den=1;
			if (dist>1e-10) {
				dist=Math.sqrt(dist);
				den=1.0/dist;
			} else {
				norm.randomize();
			}
			// Check the relative velocity. We can have situations where two atoms increase
			// eachother's velocity because they've been pushed past eachother.
			let avel=a.vel,bvel=b.vel;
			let veldif=0.0;
			for (i=0;i<dim;i++) {
				norm[i]*=den;
				veldif+=(avel[i]-bvel[i])*norm[i];
			}
			const vmul=2,vpmul=0,pmul=1;
			let posdif=rad-dist;
			veldif=veldif>0?veldif:0;
			veldif=veldif*vmul+posdif*vpmul;
			posdif*=pmul;
			// If we have a callback, allow it to handle the collision.
			// let callback=intr.callback;
			// if (callback!==null && !callback(a,b,norm,veldif,posdif)) {return;}
			// Push the atoms apart.
			let apmul=posdif*bmass,apden=apmul>0?apmul:-apmul;apmul*=apden;a.posden+=apden;
			let avmul=veldif*bmass,avden=avmul>0?avmul:-avmul;avmul*=avden;a.velden+=avden;
			let bpmul=posdif*amass,bpden=bpmul>0?bpmul:-bpmul;bpmul*=bpden;b.posden+=bpden;
			let bvmul=veldif*amass,bvden=bvmul>0?bvmul:-bvmul;bvmul*=bvden;b.velden+=bvden;
			apos=a.posacc;avel=a.velacc;
			bpos=b.posacc;bvel=b.velacc;
			for (i=0;i<dim;i++) {
				dif=norm[i];
				apos[i]+=dif*apmul;
				avel[i]+=dif*avmul;
				bpos[i]+=dif*bpmul;
				bvel[i]+=dif*bvmul;
			}
			/*let aposmul=posdif*bmass,avelmul=veldif*bmass;
			let bposmul=posdif*amass,bvelmul=veldif*amass;
			for (i=0;i<dim;i++) {
				dif=norm[i];
				apos[i]+=dif*aposmul;
				avel[i]+=dif*avelmul;
				bpos[i]+=dif*bposmul;
				bvel[i]+=dif*bvelmul;
			}*/
		}
	}
	let force1=0;
	for (let a of atomarr) {
		let pnorm=a.posden>1e-10?1/a.posden:0;
		let vnorm=a.velden>1e-10?1/a.velden:0;
		console.log(a.posden,a.velden);
		a.posden=0;
		a.velden=0;
		a.pos.iadd(a.posacc.imul(pnorm));
		a.posacc.set(0);
		a.vel.iadd(a.velacc.imul(vnorm));
		a.velacc.set(0);
		console.log(a.vel.tostring());
		force1+=a.mass*a.vel.mag();
	}
	console.log("force 0: "+force0.toFixed(6));
	console.log("force 1: "+force1.toFixed(6));
}


function FrictionTest() {
	let world=new Phy.World(2);
	let mat=world.createatomtype(1.0,1.0,0.5,1);
	let intr=mat.intarr[0];
	intr.vpmul=0;
	intr.friction=1;
	let a=world.createatom([0,-1],2,mat);
	a.vel.set([1,1]);
	let b=world.createatom([0,0],2,mat);
	Phy.Atom.collide(a,b);
	console.log(a.vel.toString());
	console.log(b.vel.toString());
}


//---------------------------------------------------------------------------------
// Normal Vectors


function CalcNormal1(vertarr) {
	// Find a vector N where v*N=c for all verts.
	let verts=vertarr.length,dim=vertarr[0].length;
	if (verts!==dim) {throw "verts!=dim";}
	let mat=new Matrix(dim-1,dim-1);
	let norm=new Vector(dim);
	let base=vertarr[0];
	for (let i=0;i<dim;i++) {
		let dst=0;
		for (let r=1;r<dim;r++) {
			let row=vertarr[r];
			for (let c=0;c<dim;c++) {
				if (c===i) {continue;}
				mat[dst++]=row[c]-base[c];
			}
		}
		let det=mat.det();
		norm[i]=(i&1)?-det:det;
	}
	let mag=norm.mag();
	norm.imul(mag>1e-10?1/mag:0);
	return norm;
}


function CalcNormal2(vertarr) {
	// Find a vector N where v*N=c for all verts.
	let dim=vertarr.length,dim1=dim-1;
	let mat=new Matrix(dim1,dim1);
	let norm=new Vector(dim);
	let base=vertarr[0];
	let dst=0;
	for (let r=1;r<dim;r++) {
		let row=vertarr[r];
		for (let c=1;c<dim;c++) {
			mat[dst++]=row[c]-base[c];
		}
	}
	norm[0]=mat.det();
	for (let i=1;i<dim;i++) {
		let c=i-1,x=base[c];dst=c-dim1;
		for (let r=1;r<dim;r++) {
			mat[dst]=vertarr[r][c]-x;
			dst+=dim1;
		}
		let det=mat.det();
		norm[i]=(i&1)?-det:det;
	}
	let mag=norm.mag();
	norm.imul(mag>1e-10?1/mag:0);
	return norm;
}


function CalcNormal3(vertarr) {
	// guess=(1,0,0,0)
	// g-=n*(n*g)
	// if g.mag()>1e-10: return g
	let dim=vertarr.length;
	let norm=new Vector(dim);
	let vertdif=new Array(dim-1);
	for (let i=0;i<dim-1;i++) {
		let v=vertarr[i+1].sub(vertarr[0]);
		for (let j=0;j<i;j++) {
			let w=vertdif[j];
			let u=w.mul(v);
			v.isub(w.mul(u));
		}
		let mag=v.mag();
		mag=mag>1e-10?1/mag:0;
		vertdif[i]=v.imul(mag);
	}
	let gnorm=new Vector(dim);
	gnorm[0]=1;
	let gmag=1e-10;
	for (let i=0;i<dim;i++) {
		norm.set(0);
		norm[i]=1;
		for (let j=0;j<dim-1;j++) {
			let v=vertdif[j];
			let u=v.mul(norm);
			norm.isub(v.mul(u));
		}
		let mag=norm.mag();
		if (gmag<mag) {
			gmag=mag;
			let tmp=norm;
			norm=gnorm;
			gnorm=tmp;
		}
	}
	gnorm.normalize();
	return gnorm;
}


function NormalVecTest() {
	console.log("testing normal calculation");
	let tests=10000;
	let dims=6;
	let rnd=new Random();
	let dotmax=0;
	let dotavg=0;
	for (let test=0;test<tests;test++) {
		// Generate points.
		let dim=rnd.modu32(dims)+1;
		let vertarr=new Array(dim);
		let copyarr=new Array(dim);
		let mindist=Infinity;
		for (let i=0;i<dim;i++) {
			let v=new Vector(dim);
			vertarr[i]=v;
			for (let j=0;j<dim;j++) {
				v[j]=(rnd.getf()-0.5)*Math.pow(2,rnd.getf()*32-16);
			}
			// Duplicate vertices to create edge cases.
			//let dup=rnd.modu32(2*dim);
			//if (dup<i) {v.set(vertarr[dup]);}
			copyarr[i]=new Vector(v);
			for (let j=0;j<i;j++) {
				mindist=Math.min(mindist,v.dist(vertarr[j]));
			}
		}
		if (mindist<1e-5) {test--;continue;}
		let norm=CalcNormal1(vertarr);
		let mag=norm.mag();
		if (Math.abs(mag-1)>1e-10) {// && Math.abs(mag)>1e-10) {
			console.log("mag not 0 or 1:",mag);
			throw "error";
		}
		for (let i=1;i<dim;i++) {
			let vec=vertarr[i].sub(vertarr[0]);
			let dot=vec.mul(norm);
			let dif=Math.abs(dot);
			if (dif>1e-3 || isNaN(dot)) {
				console.log("dot not 0:",dot,test);
				throw "error";
			}
			dotmax=Math.max(dotmax,dif);
			dotavg+=dif;
		}
		// Check if the data has been modified.
		for (let i=0;i<dim;i++) {
			let a=vertarr[i];
			let b=copyarr[i];
			for (let j=0;j<dim;j++) {
				if (a[j]!==b[j]) {
					throw "data modified";
				}
			}
		}
	}
	dotavg/=tests;
	console.log("dot max:",dotmax.toFixed(6));
	console.log("dot avg:",dotavg.toFixed(6));
}


//---------------------------------------------------------------------------------
// Main Test


function TestMain() {
	console.log("testing");
	//DistFillTest();
	AtomDrawTest();
	//AtomDrawInfTest();
	//AtomDrawDemo();
	//BroadphaseBoundFilter();
	//BroadphaseStressTest();
	//BroadphaseSpeedTest();
	//NarrowphaseSpeedTest();
	//BondStepTest();
	//ThreeBallProblem();
	//FrictionTest();
	//NormalVecTest();
	console.log("done");
}

TestMain();

/*------------------------------------------------------------------------------


testing.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


--------------------------------------------------------------------------------
TODO


*/
/* npx eslint testing.js -c ../../../standards/eslint.js */
/* global Random, Draw, PhyAtom, PhyWorld, PhyBroadphase, Vector */


function PhyAssert(cond,msg) {
	if (!cond) {
		console.log(msg);
		throw "error";
	}
}


//---------------------------------------------------------------------------------
// Drawing


function DrawAtom1(atom,draw,distmap,fakemap) {
	// If two atoms overlap, prefer the one that's closer.
	// Overlap is judged by the center of the pixel (.5,.5).
	// let draw=this.draw;
	let img=draw.img;
	// Check if it's on the screen.
	let dw=img.width,dh=img.height,scale=dh;
	let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
	let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
	let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
	let rad=atom.rad*scale+0.5,rad2=rad*rad;
	if (dx*dx+dy*dy>=rad2) {return;}
	let rad21=rad>1?(rad-1)*(rad-1):0;
	// Fill in the circle at (x,y) with radius 'rad'.
	let data=atom.data;
	draw.setcolor(data.r,data.g,data.b,255);
	let colrgba=draw.rgba32[0];
	let coll=(colrgba&0x00ff00ff)>>>0;
	let colh=(colrgba&0xff00ff00)>>>0;
	let colh2=colh>>>8;
	let miny=Math.floor(y-rad+0.5),maxy=Math.ceil(y+rad-0.5);
	miny=miny> 0?miny: 0;
	maxy=maxy<dh?maxy:dh;
	// PhyAssert(miny<maxy);
	let imgdata32=img.data32;
	// let distmap=this.distmap;
	for (;miny<maxy;miny++) {
		// Find the boundaries of the row we're on. Clip to center of pixel.
		dy=miny-y+0.5;
		let d2=dy*dy;
		dx=Math.sqrt(rad2-d2)-0.5;
		let minx=Math.floor(x-dx),maxx=Math.ceil(x+dx);
		minx=minx> 0?minx: 0;
		maxx=maxx<dw?maxx:dw;
		dx=minx-x+0.5;
		d2+=dx*dx;
		minx+=dw*miny;
		maxx+=dw*miny;
		// Normal version. Time FF: 2.582620, time CR: 2.692565
		for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let m2=distmap[minx];
			let u=(m2-d2)*0.5,u1=u+0.5,u2=u-0.5;
			// sqrt(m2)-sqrt(d2)>-1
			if (u1>0 || m2>u1*u1) {
				fakemap[minx]=d2<m2?d2:m2;
				// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
				if (d2<=rad21 && u2>0 && d2<u2*u2) {
					imgdata32[minx]=colrgba;
				} else {
					// Blend if we're on the edge or bordering another atom.
					let dst=imgdata32[minx];
					let dist=Math.sqrt(d2);
					let bord=Math.sqrt(m2)-dist;
					let edge=rad-dist;
					let a=(256-(bord<1?(bord+1)*128:256)*(edge<1?edge:1))|0;
					imgdata32[minx]=
						(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
						((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
				}
			}
			d2+=2*dx+1;
			dx++;
		}
		// Sqrt version. Time FF: 2.740580, time CR: 2.834620
		/*for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let md=distmap[minx];
			// md+1>sqrt(d2)
			if (d2<(md+1)*(md+1)) {
				let dist=Math.sqrt(d2);
				let edge=rad-dist;
				let bord=md-dist+1;
				fakemap[minx]=dist<md?dist:md;
				// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
				if (edge>=1 && bord>=2) {
					imgdata32[minx]=colrgba;
				} else {
					// Blend if we're on the edge or bordering another atom.
					let dst=imgdata32[minx];
					let u=1-(bord<2?bord*0.5:1)*(edge<1?edge:1);
					let a=(u*256)|0;
					imgdata32[minx]=(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
					                ((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
				}
			}
			d2+=2*dx+1;
			dx++;
		}*/
		// No conditionals version. Time FF: 3.998880, time CR: 3.543120
		/*for (;minx<maxx;minx++) {
			// Check if we can overwrite another atom's pixel, or if we need to blend them.
			// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
			let md=distmap[minx];
			let dist=Math.sqrt(d2);
			let edge=rad-dist;
			let bord=md-dist+1;
			bord=bord>0?(bord<2?bord:2):bord;
			fakemap[minx]=dist<md?dist:md;
			// Blend if we're on the edge or bordering another atom.
			let dst=imgdata32[minx];
			let u=1-bord*0.5*(edge<1?edge:1);
			let a=(u*256)|0;
			imgdata32[minx]=(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
			                ((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
			d2+=2*dx+1;
			dx++;
		}*/
		// PhyAssert(maxx>=dw*miny+dw || d2>=rad2,[d2,rad2]);
	}
}


class DA2 {
	//
	// drawatom
	//      FF Array: 2.998120
	//      FF F32  : 2.788260
	//      FF F64  : 3.024740
	//      CR Array: 2.962315
	//      CR F32  : 2.866525
	//      CR F64  : 2.955715
	//
	// Clear array.fill()
	//      FF Array: 11.079600
	//      FF F32  : 5.715860
	//      FF F64  : 6.396300
	//      CR Array: 9.694990
	//      CR F32  : 3.114185
	//      CR F64  : 3.227760
	//
	// Clear fill+=1
	//      FF Array: 8.221300
	//      FF F32  : 3.881260
	//      FF F64  : 5.134740
	//      CR Array: 5.100005
	//      CR F32  : 6.084015
	//      CR F64  : 6.206215
	//
	// Clear fill+=8
	//      FF Array: 5.958520
	//      FF F32  : 3.255480
	//      FF F64  : 3.316220
	//      CR Array: 3.291560
	//      CR F32  : 4.528440
	//      CR F64  : 4.648790
	//
	// Fastest: Float32Array, Fill+8
	//

	constructor(dw,dh) {
		let pixels=dw*dh;
		this.draw=new Draw(dw,dh);
		this.distmap=(new Float32Array(pixels)).fill(0);
		this.fakemap=(new Float32Array(pixels)).fill(0);
	}


	filldist() {
		// array.fill()
		//this.distmap.fill(Infinity);
		// fill+=1
		//let distmap=this.distmap,img=this.draw.img;
		//let pixels=img.width*img.height;
		//for (let i=0;i<pixels;i++) {distmap[i]=Infinity;}
		// fill+=8
		let distmap=this.distmap,img=this.draw.img;
		let i=img.width*img.height;
		while (i>7) {
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
			distmap[--i]=Infinity;
		}
		while (i>0) {
			distmap[--i]=Infinity;
		}
	}


	drawatom(atom) {
		// If two atoms overlap, prefer the one that's closer.
		// Overlap is judged by the center of the pixel (.5,.5).
		let draw=this.draw,img=draw.img;
		// Check if it's on the screen.
		let dw=img.width,dh=img.height,scale=dh;
		let x=atom.pos[0]*scale,y=atom.pos[1]*scale;
		let dx=(x>1?(x<dw?x:dw):1)-0.5-x;
		let dy=(y>1?(y<dh?y:dh):1)-0.5-y;
		let rad=atom.rad*scale+0.5,rad2=rad*rad;
		if (dx*dx+dy*dy>=rad2) {return;}
		let rad21=rad>1?(rad-1)*(rad-1):0;
		// Fill in the circle at (x,y) with radius 'rad'.
		draw.setcolor(atom.data.rgb);
		let colrgba=draw.rgba32[0];
		let coll=(colrgba&0x00ff00ff)>>>0;
		let colh=(colrgba&0xff00ff00)>>>0;
		let colh2=colh>>>8;
		let miny=Math.floor(y-rad+0.5),maxy=Math.ceil(y+rad-0.5);
		miny=miny> 0?miny: 0;
		maxy=maxy<dh?maxy:dh;
		// PhyAssert(miny<maxy);
		let imgdata32=img.data32;
		let distmap=this.distmap;
		let fakemap=this.fakemap;
		for (;miny<maxy;miny++) {
			// Find the boundaries of the row we're on. Clip to center of pixel.
			dy=miny-y+0.5;
			let d2=dy*dy;
			dx=Math.sqrt(rad2-d2)-0.5;
			let minx=Math.floor(x-dx),maxx=Math.ceil(x+dx);
			minx=minx> 0?minx: 0;
			maxx=maxx<dw?maxx:dw;
			dx=minx-x+0.5;
			d2+=dx*dx;
			minx+=dw*miny;
			maxx+=dw*miny;
			// Normal version. Time FF: 2.582620, time CR: 2.692565
			for (;minx<maxx;minx++) {
				// Check if we can overwrite another atom's pixel, or if we need to blend them.
				// PhyAssert(d2>=0 && d2<=rad2,[d2,rad2]);
				let m2=distmap[minx];
				let u=(m2-d2)*0.5,u1=u+0.5,u2=u-0.5;
				// sqrt(m2)-sqrt(d2)>-1
				if (u1>0 || m2>u1*u1) {
					// rad-dist>1 and sqrt(m2)-sqrt(d2)>1
					if (d2<=rad21 && u2>0 && d2<u2*u2) {
						// Only write the distance if we're inside the border.
						fakemap[minx]=d2;
						imgdata32[minx]=colrgba;
					} else {
						// Blend if we're on the edge or bordering another atom.
						let dst=imgdata32[minx];
						let dist=Math.sqrt(d2);
						let bord=Math.sqrt(m2)-dist;
						let edge=rad-dist;
						let a=(256-(bord<1?(bord+1)*128:256)*(edge<1?edge:1))|0;
						imgdata32[minx]=
							(((Math.imul((dst&0x00ff00ff)-coll,a)>>>8)+coll)&0x00ff00ff)+
							((Math.imul(((dst&0xff00ff00)>>>8)-colh2,a)+colh)&0xff00ff00);
					}
				}
				d2+=2*dx+1;
				dx++;
			}
			// PhyAssert(maxx>=dw*miny+dw || d2>=rad2,[d2,rad2]);
		}
	}

}


function AtomDrawTest() {
	console.log("starting atom draw test");
	let rnd=new Random(0);
	let dw=999,dh=1000,pixels=dw*dh;
	let maxrad=50;
	let scale=1.0/dh;
	let da=new DA2(dw,dh);
	// Normal version uses squared distances
	for (let i=0;i<pixels;i++) {da.distmap[i]=Math.pow(rnd.getf()*maxrad,2);}
	let minx=-maxrad*scale,maxx=(dw+maxrad)*scale;
	let miny=-maxrad*scale,maxy=(dh+maxrad)*scale;
	let time=performance.now();
	for (let test=0;test<100000;test++) {
		let atom={
			pos:[rnd.getf()*(maxx-minx)+minx,rnd.getf()*(maxy-miny)+miny],
			rad:rnd.getf()*maxrad*scale,
			data:{
				rgb:[rnd.getf()*256|0,rnd.getf()*256|0,rnd.getf()*256|0,255]
			}
		};
		da.drawatom(atom);
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


function AtomFillTest() {
	console.log("starting atom fill test");
	let rnd=new Random(0);
	let dw=999,dh=1000,pixels=dw*dh;
	let da=new DA2(dw,dh);
	for (let i=0;i<pixels;i++) {da.distmap[i]=rnd.getf();}
	let time=performance.now();
	for (let test=0;test<10000;test++) {
		da.filldist();
	}
	time=(performance.now()-time)/1000;
	console.log("time: "+time.toFixed(6));
}


//---------------------------------------------------------------------------------
// Broadphase


function BroadphaseBoundFilter() {
	let arr=[
		[-Infinity,-Infinity],
		[-Infinity,1],
		[-Infinity,Infinity],
		[1,1],
		[1,Infinity],
		[Infinity,Infinity]
	];
	for (let bnd of arr) {
		let [min,max]=bnd;
		let val=max>min?max-min:0;
		val=val>=0?val:Infinity;
		console.log(max+" - "+min+" = "+val);
	}
}


function BroadphaseCheckTree(broad,used,trail) {
	let dim=broad.world.dim*2;
	const aabb=3;
	let nodesize=aabb+dim;
	let volume=0;
	let atomcnt=broad.atomcnt;
	if (!atomcnt) {return volume;}
	let memi=broad.memi32;
	let memf=broad.memf32;
	const root=0;
	let leafstart=nodesize*(atomcnt-1);
	let leafend=leafstart+nodesize*atomcnt;
	let leaflast=leafend-nodesize;
	let trailidx=1,trailstop=atomcnt*2-1;
	if (trailstop>trail.length) {trailstop=trail.length;}
	for (let i=0;i<atomcnt;i++) {used[i]=0;}
	trail[0]=root;
	if (root<0 || root>leaflast || memi[root+1]!==-1) {
		console.log("invalid root:",root,memi[root+1]);
		throw "error";
	}
	for (let t=0;t<trailstop;t++) {
		if (t>=trailidx) {
			console.log("end of trail:",t,trailidx);
			throw "error";
		}
		let n=trail[t],p=memi[n+1];
		// Check bounding box against parent
		let vol=1;
		for (let i=0;i<dim;i+=2) {
			let nbnd=n+aabb+i,pbnd=(p>=0?p:0)+aabb+i;
			let nl=memf[nbnd],nr=memf[nbnd+1];
			let pl=memf[pbnd],pr=memf[pbnd+1];
			if (!(pl<=nl && nr<=pr) || !(nl<=nr)) {
				console.log("child box not in parent",n,p);
				throw "error";
			}
			vol*=nr-nl;
		}
		// Check children
		let l=n+nodesize; //memi[n+1];
		let r=memi[n+2];
		let flags=memi[n+0];
		if (!(flags&1)) {
			if (vol<Infinity) {volume+=vol;}
			if (l<0 || l>leaflast || l!==(l|0) || memi[l+1]!==n) {
				console.log("left child misaligned:",n,l,r);
				throw "error";
			}
			if (r<0 || r>leaflast || r!==(r|0) || memi[r+1]!==n || r===l) {
				console.log("right child misaligned:",n,l,r);
				throw "error";
			}
			if ((flags&2)!==(memi[l]&memi[r]&2)) {
				console.log("children not sleeping:",flags&2,memi[l]&2,memi[r]&2);
				throw "error";
			}
			if (trailidx+2>trailstop) {
				console.log("trail length:",trailidx,trailstop);
				throw "error";
			}
			trail[trailidx++]=l;
			trail[trailidx++]=r;
		} else {
			let atom=r;
			if (atom!==(atom|0) || atom<0 || atom>=atomcnt || used[atom]) {
				console.log("invalid atom:",n,atom,atomcnt);
				throw "error";
			}
			used[atom]=1;
		}
	}
	return volume;
}


function BroadphaseStressTest() {
	// Make sure every overlap is detected and collisions occur exactly once.
	//
	// Stats with current broadphase:
	//
	//      duplicate: 0
	//      match    : 28392171
	//      phantom  : 2818698
	//      miss     : 0
	//      AABB hits: 88477517
	//
	console.log("testing broadphase");
	let maxatoms=1000;
	let maxdim=5;
	let maxhits=maxatoms*maxatoms;
	let atomarr=new Array(maxatoms);
	let hitcount=new Array(maxhits);
	let used=new Uint32Array(maxatoms);
	let trail=new Uint32Array(maxatoms*2);
	let tests=100;
	// Replace atom and broadphase collide() for stat tracking.
	let atomcol=PhyAtom.collide;
	PhyAtom.collide=function(a,b) {
		let aid=a.id,bid=b.id;
		if (aid>bid) {aid=bid;bid=a.id;}
		hitcount[aid*maxatoms+bid]+=2;
	};
	let broadcol=PhyBroadphase.prototype.collide;
	let newsrc=broadcol.toString();
	newsrc=newsrc.replace("// Down - check for overlap.","PhyBroadphase.aabbhits++;");
	newsrc=newsrc.replace(/.*\{/,"");
	newsrc=newsrc.replace(/\}\s*$/,"");
	PhyBroadphase.prototype.collide=new Function(newsrc);
	let rnd=new Random(2);
	function exprand() {return (rnd.getf()*2-1)*Math.pow(2,rnd.getf()*32-20);}
	let hitsum=[0,0,0,0,0];
	let dimhit=(new Array(maxdim+1)).fill(0);
	let dimvol=(new Array(maxdim+1)).fill(0);
	for (let test=0;test<tests;test++) {
		let dim=rnd.modu32(maxdim+1);
		let world=new PhyWorld(dim);
		let type=world.createatomtype(0,1,0);
		for (let atoms=0;atoms<maxatoms;) {
			console.log("test:",test,dim,atoms);
			let atomadd=rnd.modu32(64);
			for (let a=0;a<atomadd && atoms<maxatoms;a++) {
				// Generate random positions and radius's.
				let pos=new Vector(dim);
				for (let i=0;i<dim;i++) {pos[i]=exprand();}
				let atom=world.createatom(pos,Math.abs(exprand()),type);
				atom.sleeping=(rnd.getu32()&1)?true:false;
				atom.id=atoms;
				atomarr[atoms++]=atom;
			}
			for (let i=0;i<maxhits;i++) {hitcount[i]=0;}
			for (let i=1;i<atoms;i++) {
				let atom=atomarr[i];
				let apos=atom.pos;
				let arad=atom.rad;
				let asleep=atom.sleeping;
				for (let j=0;j<i;j++) {
					atom=atomarr[j];
					if (!asleep || !atom.sleeping) {
						let bpos=atom.pos;
						let rad=atom.rad+arad;
						let dist=0;
						for (let d=0;d<dim;d++) {
							let x=apos[d]-bpos[d];
							dist+=x*x;
						}
						if (dist<rad*rad) {
							hitcount[j*maxatoms+i]=1;
						}
					}
				}
			}
			// Rebuild multiple times to catch any memory shuffling errors.
			let memi=world.broad.memi32;
			if (memi!==null && memi!==undefined) {
				let len=memi.length;
				for (let i=0;i<len;i++) {memi[i]=rnd.getu32();}
			}
			world.broad.build();
			BroadphaseCheckTree(world.broad,used,trail);
			PhyBroadphase.aabbhits=0;
			world.broad.collide();
		}
		dimhit[dim]+=PhyBroadphase.aabbhits;
		dimvol[dim]+=BroadphaseCheckTree(world.broad,used,trail);
		for (let i=0;i<maxhits;i++) {
			let cnt=hitcount[i];
			hitsum[cnt<4?cnt:4]++;
		}
	}
	console.log("duplicate:",hitsum[4]);
	console.log("match    :",hitsum[3]);
	console.log("phantom  :",hitsum[2]);
	console.log("miss     :",hitsum[1]);
	console.log("AABB hits:",PhyBroadphase.aabbhits);
	for (let i=0;i<=maxdim;i++) {
		let vol=dimvol[i],hit=dimhit[i];
		console.log(i+": vol "+vol.toFixed(0)+", hit "+hit);
	}
	PhyAtom.collide=atomcol;
	PhyBroadphase.prototype.collide=broadcol;
}


function BroadphaseSpeedTest() {
	// Firefox
	//
	//      1: 0.195308, 29058380
	//      2: 0.112012, 62560
	//      3: 0.140488, 1070
	//      4: 0.165446, 60
	//
	// Chrome
	//
	//      1: 0.168849, 29058380
	//      2: 0.113747, 62560
	//      3: 0.138402, 1070
	//      4: 0.165947, 60
	//
	console.log("testing broadphase");
	let collisions=0;
	let origcol=PhyAtom.collide;
	PhyAtom.collide=function() {collisions++;};
	let rnd=new Random(2);
	let atoms=200000,tests=10;
	for (let dim=1;dim<5;dim++) {
		let world=new PhyWorld(dim);
		let type=world.createatomtype(0,1,0);
		let radmul=(1<<dim)/atoms;
		for (let a=0;a<atoms;a++) {
			// Generate random positions and radius's.
			let pos=new Vector(dim);
			for (let i=0;i<dim;i++) {pos[i]=rnd.getf();}
			let rad=radmul/(rnd.getf()+.01);
			let atom=world.createatom(pos,rad,type);
			atom.sleeping=rnd.getu32()&1;
		}
		for (let warmup=0;warmup<2;warmup++) {
			world.broad.build();
			world.broad.collide();
		}
		collisions=0;
		let time=performance.now();
		for (let test=0;test<tests;test++) {
			world.broad.build();
			world.broad.collide();
		}
		time=(performance.now()-time)/(1000*tests);
		console.log(dim.toString()+": "+time.toFixed(6)+", "+collisions);
	}
	PhyAtom.collide=origcol;
}


//---------------------------------------------------------------------------------
// Narrowphase


function NarrowphaseSpeedTest() {
	// Firefox
	//
	//      0: 0.043260
	//      1: 0.045020
	//      2: 0.045680
	//      3: 0.106000
	//      4: 0.115460
	//      5: 0.146480
	//
	let tests=300000;
	let trials=10;
	let atoms=tests*2;
	let rnd=new Random(3);
	let atomarr=new Array(atoms);
	let posarr=new Array(atoms);
	for (let dim=0;dim<6;dim++) {
		let world=new PhyWorld(dim);
		let types=5;
		let typearr=new Array(types);
		for (let i=0;i<types;i++) {
			typearr[i]=world.createatomtype(rnd.getf(),rnd.getf(),rnd.getf());
		}
		typearr[0].intarr[1].collide=false;
		let lastpos,lastrad,pos0=new Vector(dim);
		for (let i=0;i<atoms;i++) {
			if (!(i&1)) {lastpos=pos0;lastrad=10;}
			let rad=rnd.getf();
			let space=rnd.getf()*2*(rad+lastrad);
			if (((i>>1)&255)===0) {space=0;}
			let pos=Vector.random(dim).imul(space).iadd(lastpos);
			posarr[i]=new Vector(pos);
			atomarr[i]=world.createatom(pos,rad,typearr[rnd.modu32(types)]);
			lastpos=pos;
			lastrad=rad;
		}
		let collide=PhyAtom.collide;
		let time=performance.now();
		for (let trial=0;trial<trials;trial++) {
			for (let i=0;i<atoms;i+=2) {
				let a=atomarr[i],b=atomarr[i+1];
				a.pos.set(posarr[i  ]);a.vel.set(0);
				b.pos.set(posarr[i+1]);b.vel.set(0);
				collide(a,b);
			}
		}
		time=(performance.now()-time)/(trials*1000);
		console.log(dim+": "+time.toFixed(6));
	}
}


//---------------------------------------------------------------------------------
// Bonds


function BondStepTest() {
	// Simulate integrating bond forces.
	//
	// pos        + vel    : error increases a lot as steps increase
	// pos*dt     + vel*dt : error increases slightly as steps increase
	// pos*dt^2   + vel*dt : error decreases as steps increase
	// pos*dt^2/2 + vel*dt : error decreases as steps increase
	for (let steps=1;steps<21;steps++) {
		let dt=1/steps;
		let tension=0.1;
		let pos=1,vel=0;
		for (let s=0;s<steps;s++) {
			// update atom
			pos+=vel*dt;
			// update bond
			let dif=pos-0;
			dif*=tension;
			pos-=dif*dt*dt*0.5;
			vel-=dif*dt;
		}
		let pos0=1-tension*0.5;
		let vel0=0-tension;
		let err=Math.abs(pos-pos0)+Math.abs(vel-vel0);
		console.log(steps+" err: "+err.toFixed(6),pos,vel);
	}
	/*for (let steps=1;steps<21;steps++) {
		let dt=1/steps;
		let tension=0.1;
		let pos=1,vel=0,acc=0;
		for (let s=0;s<steps;s++) {
			// update atom
			pos+=vel*dt+acc*dt*dt*0.5;
			vel+=acc*dt;
			acc=0;
			// update bond
			let dif=pos-0;
			dif*=tension;
			acc-=dif;
		}
		let pos0=1-tension*0.5;
		let vel0=0-tension;
		let err=Math.abs(pos-pos0)+Math.abs(vel-vel0);
		console.log(steps+" err: "+err.toFixed(6),pos,vel);
	}*/
}


//---------------------------------------------------------------------------------
// Dynamics


function ThreeBallProblem() {
	// Try and aggregate forces so collision order doesn't matter.
	// Result: this trivially fails. If an atom is moving to the right and collides
	// with a stack of atoms with the same coordinate, the force in the system is
	// multiplies.
	//
	// Measure forces before and after.
	//
	//  O      O
	// O      OO
	//  O      O
	//
	let posarr=[[0,0],[1,-1],[1,1],[1,0],[1,0]];
	let atomarr=[];
	for (let pos of posarr) {
		atomarr.push({
			mass:1,
			rad:1,
			pos:new Vector(pos),
			vel:new Vector(2),
			posacc:new Vector(2),
			velacc:new Vector(2),
			posden:0,
			velden:0
		});
	}
	atomarr[0].vel[0]=1;
	let force0=0;
	for (let a of atomarr) {force0+=a.mass*a.vel.mag();}
	for (let a0=1;a0<atomarr.length;a0++) {
		for (let a1=0;a1<a0;a1++) {
			//if (a0 && a1) {continue;}
			let a=atomarr[a0];
			let b=atomarr[a1];
			let apos=a.pos,bpos=b.pos;
			let dim=apos.length,i;
			let dist=0.0,dif,norm=new Vector(dim);
			for (i=0;i<dim;i++) {
				dif=bpos[i]-apos[i];
				norm[i]=dif;
				dist+=dif*dif;
			}
			let rad=a.rad+b.rad;
			let amass=a.mass,bmass=b.mass;
			let mass=amass+bmass;
			//if ((amass>=Infinity && bmass>=Infinity) || mass<=1e-10 || dim===0) {
			//	return;
			//}
			amass=amass>=Infinity? 1.0: amass/mass;
			bmass=bmass>=Infinity?-1.0:-bmass/mass;
			// If the atoms are too close together, randomize the direction.
			let den=1;
			if (dist>1e-10) {
				dist=Math.sqrt(dist);
				den=1.0/dist;
			} else {
				norm.randomize();
			}
			// Check the relative velocity. We can have situations where two atoms increase
			// eachother's velocity because they've been pushed past eachother.
			let avel=a.vel,bvel=b.vel;
			let veldif=0.0;
			for (i=0;i<dim;i++) {
				norm[i]*=den;
				veldif+=(avel[i]-bvel[i])*norm[i];
			}
			const vmul=2,vpmul=0,pmul=1;
			let posdif=rad-dist;
			veldif=veldif>0?veldif:0;
			veldif=veldif*vmul+posdif*vpmul;
			posdif*=pmul;
			// If we have a callback, allow it to handle the collision.
			//let callback=intr.callback;
			//if (callback!==null && !callback(a,b,norm,veldif,posdif)) {return;}
			// Push the atoms apart.
			let apmul=posdif*bmass,apden=apmul>0?apmul:-apmul;apmul*=apden;a.posden+=apden;
			let avmul=veldif*bmass,avden=avmul>0?avmul:-avmul;avmul*=avden;a.velden+=avden;
			let bpmul=posdif*amass,bpden=bpmul>0?bpmul:-bpmul;bpmul*=bpden;b.posden+=bpden;
			let bvmul=veldif*amass,bvden=bvmul>0?bvmul:-bvmul;bvmul*=bvden;b.velden+=bvden;
			apos=a.posacc;avel=a.velacc;
			bpos=b.posacc;bvel=b.velacc;
			for (i=0;i<dim;i++) {
				dif=norm[i];
				apos[i]+=dif*apmul;
				avel[i]+=dif*avmul;
				bpos[i]+=dif*bpmul;
				bvel[i]+=dif*bvmul;
			}
			/*let aposmul=posdif*bmass,avelmul=veldif*bmass;
			let bposmul=posdif*amass,bvelmul=veldif*amass;
			for (i=0;i<dim;i++) {
				dif=norm[i];
				apos[i]+=dif*aposmul;
				avel[i]+=dif*avelmul;
				bpos[i]+=dif*bposmul;
				bvel[i]+=dif*bvelmul;
			}*/
		}
	}
	let force1=0;
	for (let a of atomarr) {
		let pnorm=a.posden>1e-10?1/a.posden:0;
		let vnorm=a.velden>1e-10?1/a.velden:0;
		console.log(a.posden,a.velden);
		a.posden=0;
		a.velden=0;
		a.pos.iadd(a.posacc.imul(pnorm));
		a.posacc.set(0);
		a.vel.iadd(a.velacc.imul(vnorm));
		a.velacc.set(0);
		console.log(a.vel.tostring());
		force1+=a.mass*a.vel.mag();
	}
	console.log("force 0: "+force0.toFixed(6));
	console.log("force 1: "+force1.toFixed(6));
}


function FrictionTest() {
	let world=new PhyWorld(2);
	let mat=world.createatomtype(1.0,1.0,0.5,1);
	let intr=mat.intarr[0];
	intr.vpmul=0;
	intr.friction=1;
	let a=world.createatom([0,-1],2,mat);
	a.vel.set([1,1]);
	let b=world.createatom([0,0],2,mat);
	PhyAtom.collide(a,b);
	console.log(a.vel.toString());
	console.log(b.vel.toString());
}


//---------------------------------------------------------------------------------
// Main Test


function TestMain() {
	console.log("testing");
	//AtomDrawTest();
	//AtomFillTest();
	//BroadphaseBoundFilter();
	BroadphaseStressTest();
	//BroadphaseSpeedTest();
	//NarrowphaseSpeedTest();
	//BondStepTest();
	//ThreeBallProblem();
	//FrictionTest();
	console.log("done");
}

TestMain();
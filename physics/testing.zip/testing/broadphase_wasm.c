/*------------------------------------------------------------------------------


broadphase_wasm.c - v1.01

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Webassembly acceleration for physics broadphase step.
The stack and heap share memory. --stack-first keeps the stack at 0.
Some variables are marked as volatile to force the compiler to reread them.

Testing of wasmbuild_normal() showed JS was actually faster, but the morton code
version makes heavy use of 64-bit operations that are in favor of WASM.

Environment variables:


     1    dim
     1    atomcnt
          memi32 data
     0/1  align
     N    arr
     N    tmp
     N*2  morton arr
     N*2  morton tmp
     256  radix


--------------------------------------------------------------------------------
Compiling


apt-get install clang lld

clang broadphase_wasm.c --target=wasm32 -O3 -nostdlib -fno-builtin-memset \
-Wl,--stack-first -Wl,--export-all -Wl,--no-entry -Wl,--allow-undefined \
--output broadphase.wasm


--------------------------------------------------------------------------------
TODO


*/

#if defined(__llvm__)
	#pragma clang diagnostic warning "-Weverything"
	#pragma clang diagnostic ignored "-Wmissing-prototypes"
	#pragma clang diagnostic ignored "-Wnull-pointer-arithmetic"
	#pragma clang diagnostic ignored "-Wcast-qual"
	#pragma clang diagnostic ignored "-Wdeclaration-after-statement"
	// #pragma clang diagnostic ignored "-Wpadded"
	#pragma clang diagnostic ignored "-Wcast-align"
	#pragma clang diagnostic ignored "-Wreserved-identifier"
	#pragma clang diagnostic ignored "-Wfloat-equal"
	#pragma clang diagnostic ignored "-Wunused-macros"
	#pragma clang diagnostic ignored "-Wdouble-promotion"
#endif

#include <stdint.h>

typedef  uint8_t u8;
typedef uint16_t u16;
typedef  int16_t i16;
typedef uint32_t u32;
typedef  int32_t i32;
typedef uint64_t u64;
typedef  int64_t i64;
typedef    float f32;
typedef   double f64;


//---------------------------------------------------------------------------------
// Helper functions


extern const uint8_t __heap_base;
__attribute__((used)) int getheapbase(void) {
	return (int)&__heap_base;
}


// https://github.com/emscripten-core/emscripten
// #define fmin  __builtin_wasm_min_f64
// #define fmax  __builtin_wasm_max_f64
// #define fmin  __builtin_wasm_min_f32
// #define fmax  __builtin_wasm_max_f32
// #define ffloor __builtin_floor
// #define fceil  __builtin_ceil
// #define fsqrt __builtin_sqrt
// #define fabs  __builtin_fabs
// #define isnan __builtin_isnan
#define clz64 __builtin_clzll


//---------------------------------------------------------------------------------
// Median splitting, unrolled addresses

/*
__attribute__((used))
void wasmbuild(i32 base) {
	// Manually handle all word alignment.
	// Split this off to a separate function so clang doesn't optimize everything out.
	// Load our environment data.
	i32 dim    =*((i32*)(base+4));
	i32 atomcnt=*((i32*)(base+8));
	i32 nodesize=12+8*dim;
	i32 leafstart=base+nodesize*(atomcnt-1);
	i32 leafend=base+nodesize*(atomcnt*2-1);
	i32 sortstop=leafend+atomcnt*4;
	*((i32*)(base+4))=leafend;
	*((i32*)(base+8))=sortstop;
	i32 leafidx=leafstart;
	for (i32 i=leafend;i<sortstop;i+=4) {*((i32*)i)=leafidx;leafidx+=nodesize;}
	const f32 inf=1.0f/0.0f;
	i32 treeidx=base+nodesize;
	for (i32 work=base;work<leafstart;work+=nodesize) {
		// Pop the top working range off the stack.
		i32 worklo=*((i32*)(work+4));
		i32 workhi=*((i32*)(work+8));
		i32 workmid=worklo+(((workhi-worklo)>>3)<<2);
		// Optional. Handle tails.
		if (workhi-worklo==8) {
			*((i32*)(work+4))=*((i32*)(worklo  ));
			*((i32*)(work+8))=*((i32*)(worklo+4));
			continue;
		}
		// Find the axis with the greatest range.
		i32 sortaxis=-1;
		f32 sortmax=-inf;
		for (i32 axis=12;axis<nodesize;axis+=8) {
			f32 min=inf,max=-inf,x;
			for (i32 i=worklo;i<workhi;i+=4) {
				i32 node=(*((i32*)i))+axis;
				x=*((f32*)(node  ));
				min=min<x?min:x;
				//x=*((f32*)(node+4));
				max=max>x?max:x;
			}
			max-=min;
			max=max>=0?max:inf;
			if (sortmax<max) {
				sortmax=max;
				sortaxis=axis;
			}
		}
		// Heapsort the largest axis. We only need to sort half.
		i32 sortend=sortaxis>=0?workhi-4:worklo;
		i32 sortheap=workmid;
		i32 nodeoff=4-worklo;
		while (sortend>=workmid) {
			i32 node,child,nidx;
			if (sortheap>worklo) {
				// Build the heap.
				sortheap-=4;
				node=sortheap;
				nidx=*((i32*)sortheap);
			} else {
				// Pop the greatest element to the end of the array.
				node=sortheap;
				nidx=*((i32*)sortend);
				*((i32*)sortend)=*((i32*)sortheap);
				sortend-=4;
			}
			f32 nval=*((f32*)(nidx+sortaxis));
			// Heap sort the top element down.
			// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
			while ((child=(node<<1)+nodeoff)<=sortend) {
				i32 cidx=*((i32*)child);
				f32 cval=*((f32*)(cidx+sortaxis));
				if (child<sortend) {
					i32 ridx=*((i32*)(child+4));
					f32 rval=*((f32*)(ridx+sortaxis));
					if (cval<rval) {
						cidx=ridx;
						cval=rval;
						child+=4;
					}
				}
				if (nval>=cval) {break;}
				*((i32*)node)=cidx;
				node=child;
			}
			*((i32*)node)=nidx;
		}
		// Split the sorted nodes in half. If we only have 1 node on a side, stop
		// dividing. Otherwise, add the range to the working stack.
		i32 leaf;
		if (worklo+4==workmid) {
			leaf=*((i32*)worklo);
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			*((i32*)(leaf+4))=worklo;
			*((i32*)(leaf+8))=workmid;
		}
		*((i32*)(work+4))=leaf;
		if (workhi-4==workmid) {
			leaf=*((i32*)workmid);
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			*((i32*)(leaf+4))=workmid;
			*((i32*)(leaf+8))=workhi;
		}
		*((i32*)(work+8))=leaf;
	}
	// Set parents and bounding boxes.
	for (i32 n=leafstart;n>base;) {
		i32 nend=n;
		n-=nodesize;
		i32 p=(n-base)>>2;
		i32 l=*((i32*)(n+4));
		*((i32*)(l  ))=p;
		*((i32*)(n+4))=(l-base)>>2;
		l+=12;
		i32 r=*((i32*)(n+8));
		*((i32*)(r  ))=p;
		*((i32*)(n+8))=(r-base)>>2;
		r+=12;
		i32 i=n+12;
		f32 x,y;
		while (i<nend) {
			x=*((f32*)l);y=*((f32*)r);*((f32*)i)=x<y?x:y;l+=4;r+=4;i+=4;
			x=*((f32*)l);y=*((f32*)r);*((f32*)i)=x>y?x:y;l+=4;r+=4;i+=4;
		}
	}
}
*/

//---------------------------------------------------------------------------------
// Median splitting


__attribute__((used))
void wasmbuild(i32 base) {
	// Split this off to a separate function so clang doesn't optimize everything out.
	// Load our environment data.
	i32* const memi=(i32*)base;
	f32* const memf=(f32*)base;
	i32 dim    =memi[1];
	i32 atomcnt=memi[2];
	i32 nodesize=3+2*dim;
	i32 leafstart=nodesize*(atomcnt-1);
	i32 leafend=nodesize*(atomcnt*2-1);
	memi[1]=leafend;
	memi[2]=leafend+atomcnt;
	const f32 inf=1.0f/0.0f;
	i32 treeidx=nodesize;
	for (i32 work=0;work<leafstart;work+=nodesize) {
		// Pop the top working range off the stack.
		i32 worklo=memi[work+1];
		i32 workhi=memi[work+2];
		i32 workmid=worklo+((workhi-worklo)>>1);
		// Optional. Handle tails.
		if (workhi-worklo==2) {
			memi[work+1]=memi[worklo  ];
			memi[work+2]=memi[worklo+1];
			continue;
		}
		// Find the axis with the greatest range.
		i32 sortaxis=-1;
		f32 sortmax=-inf;
		for (i32 axis=3;axis<nodesize;axis+=2) {
			f32 min=inf,max=-inf,x;
			f32* mems=memf+axis;
			for (i32 i=worklo;i<workhi;i++) {
				i32 node=memi[i];
				x=mems[node  ];
				min=min<x?min:x;
				// x=mems[node+1];
				max=max>x?max:x;
			}
			max-=min;
			max=max>=0?max:inf;
			if (sortmax<max) {
				sortmax=max;
				sortaxis=axis;
			}
		}
		// Heapsort the largest axis. We only need to sort half.
		i32 sortend=sortaxis>=0?workhi-1:worklo;
		i32 sortheap=workmid;
		i32 nodeoff=1-worklo;
		f32* mems=memf+sortaxis;
		while (sortend>=workmid) {
			i32 node,child,nidx;
			if (sortheap>worklo) {
				// Build the heap.
				node=--sortheap;
				nidx=memi[node];
			} else {
				// Pop the greatest element to the end of the array.
				node=sortheap;
				nidx=memi[sortend];
				memi[sortend--]=memi[sortheap];
			}
			f32 nval=mems[nidx];
			// Heap sort the top element down.
			// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
			while ((child=(node<<1)+nodeoff)<=sortend) {
				i32 cidx=memi[child];
				f32 cval=mems[cidx];
				if (child<sortend) {
					i32 ridx=memi[child+1];
					f32 rval=mems[ridx];
					if (cval<rval) {
						cidx=ridx;
						cval=rval;
						child++;
					}
				}
				if (nval>=cval) {break;}
				memi[node]=cidx;
				node=child;
			}
			memi[node]=nidx;
		}
		// Split the sorted nodes in half. If we only have 1 node on a side, stop
		// dividing. Otherwise, add the range to the working stack.
		i32 leaf;
		if (worklo+1==workmid) {
			leaf=memi[worklo];
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			memi[leaf+1]=worklo;
			memi[leaf+2]=workmid;
		}
		memi[work+1]=leaf;
		if (workhi-1==workmid) {
			leaf=memi[workmid];
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			memi[leaf+1]=workmid;
			memi[leaf+2]=workhi;
		}
		memi[work+2]=leaf;
	}
	// Set parents and bounding boxes.
	for (i32 n=leafstart-nodesize;n>=0;n-=nodesize) {
		i32 l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
		memi[l]=n;l+=3;
		memi[r]=n;r+=3;
		f32 x,y;
		for (i32 i=n+3;i<ndim;i+=2) {
			x=memf[l++];y=memf[r++];
			memf[i  ]=x<y?x:y;
			x=memf[l++];y=memf[r++];
			memf[i+1]=x>y?x:y;
		}
	}
}


//---------------------------------------------------------------------------------
// Morton code splitting


/*
__attribute__((used))
void wasmbuild(i32 base) {
	// Split this off to a separate function so clang doesn't optimize everything out.
	// Load our environment data.
	i32* const memi=(i32*)base;
	f32* const memf=(f32*)base;
	i32 dim    =memi[1];
	i32 atomcnt=memi[2];
	i32 nodesize=3+2*dim;
	i32 leafstart=nodesize*(atomcnt-1);
	i32 leafend=nodesize*(atomcnt*2-1);
	// Sorting buffers.
	i32* sortarr=memi+leafend;
	sortarr=(i32*)((((u32)sortarr)+7)&0xfffffff8);
	i32* sorttmp=sortarr+atomcnt;
	u64* codearr=(u64*)(sorttmp+atomcnt);
	u64* codetmp=codearr+atomcnt;
	u32* radix=(u32*)(codetmp+atomcnt);
	// Scale coordinates to an integer range and interleave them to form morton codes.
	#define INF (1.0/0.0)
	u32 bits=dim==2?32:21;
	f64 mask=(f64)((1ULL<<bits)-1);
	f64 scale=dim==2?65536:1024;
	f64 half=(mask+1)*0.5;
	for (i32 i=0;i<atomcnt;i++) {
		i32 node=leafstart+i*nodesize;
		sortarr[i]=node;
		u64 z=0;
		for (i32 j=3;j<nodesize;j+=2) {
			f64 x=((f64)memf[node+j])*scale+half;
			x=x>-INF?x:0;
			x=x< INF?x:mask;
			// If x is outside our range, fall back to regular sorting.
			if (x<0 || x>mask) {return;}
			u64 y=(u64)x;
			if (dim==2) {
				// Spread by 2
				y=(y|(y<<16))&0x0000ffff0000ffffULL;
				y=(y|(y<< 8))&0x00ff00ff00ff00ffULL;
				y=(y|(y<< 4))&0x0f0f0f0f0f0f0f0fULL;
				y=(y|(y<< 2))&0x3333333333333333ULL;
				y=(y|(y<< 1))&0x5555555555555555ULL;
			} else {
				// Spread by 3
				y=(y|(y<<32))&0x003f00000000ffffULL;
				y=(y|(y<<16))&0x003f0000ff0000ffULL;
				y=(y|(y<< 8))&0x300f00f00f00f00fULL;
				y=(y|(y<< 4))&0x30c30c30c30c30c3ULL;
				y=(y|(y<< 2))&0x9249249249249249ULL;
			}
			z+=z+y;
		}
		codearr[i]=z;
	}
	// Radix sort the codes.
	for (u32 shift=0;shift<64;shift+=8) {
		for (u32 i=0;i<256;i++) {radix[i]=0;}
		for (i32 i=0;i<atomcnt;i++) {
			radix[(u8)(codearr[i]>>shift)]++;
		}
		u32 sum=(u32)atomcnt;
		for (i32 i=255;i>=0;i--) {
			sum-=radix[i];
			radix[i]=sum;
		}
		for (i32 i=0;i<atomcnt;i++) {
			u64 code=codearr[i];
			u32 j=radix[(u8)(code>>shift)]++;
			codetmp[j]=code;
			sorttmp[j]=sortarr[i];
		}
		void* tmp;
		tmp=sortarr;sortarr=sorttmp;sorttmp=tmp;
		tmp=codearr;codearr=codetmp;codetmp=tmp;
	}
	memi[1]=0;
	memi[2]=atomcnt;
	i32 treeidx=nodesize;
	for (i32 work=0;work<leafstart;work+=nodesize) {
		// Pop the top working range off the stack.
		i32 worklo=memi[work+1];
		i32 workhi=memi[work+2];
		i32 sortdiv=worklo+((workhi-worklo)>>1);
		u64 first=codearr[worklo];
		i32 prefix=clz64(first^codearr[workhi-1]);
		if (prefix<64) {
			i32 lo=worklo,hi=workhi;
			while (lo<hi) {
				i32 mid=lo+((hi-lo)>>1);
				i32 split=clz64(first^codearr[mid]);
				if (split>prefix) {lo=mid+1;} else {hi=mid;}
			}
			sortdiv=lo;
		}
		// Split the sorted nodes in half. If we only have 1 node on a side, stop
		// dividing. Otherwise, add the range to the working stack.
		i32 leaf;
		if (worklo+1==sortdiv) {
			leaf=sortarr[worklo];
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			memi[leaf+1]=worklo;
			memi[leaf+2]=sortdiv;
		}
		memi[work+1]=leaf;
		if (workhi-1==sortdiv) {
			leaf=sortarr[sortdiv];
		} else {
			leaf=treeidx;
			treeidx+=nodesize;
			memi[leaf+1]=sortdiv;
			memi[leaf+2]=workhi;
		}
		memi[work+2]=leaf;
	}
	// Set parents and bounding boxes.
	for (i32 n=leafstart-nodesize;n>=0;n-=nodesize) {
		i32 l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
		memi[l]=n;l+=3;
		memi[r]=n;r+=3;
		f32 x,y;
		for (i32 i=n+3;i<ndim;i+=2) {
			x=memf[l++];y=memf[r++];
			memf[i  ]=x<y?x:y;
			x=memf[l++];y=memf[r++];
			memf[i+1]=x>y?x:y;
		}
	}
	memi[0]=-1;
}
*/

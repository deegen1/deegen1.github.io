/*------------------------------------------------------------------------------


broadphase_rb.js - v1.00

Copyright 2026 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
TODO


FF
phy1 collide: 
phy1 basic  : 
phy2 collide: 
phy2 basic  : 
phy1 collide: 3: 30672349, 0.038538, 0.418526
phy1 basic  : 3:  9223537, 0.037486, 0.189514
phy2 collide: 3:  9223537, 0.032916, 0.180518
phy2 basic  : 3:  9223537, 0.035044, 0.236192

CR
phy1 collide: 2: 52479345, 0.034013, 0.468600
phy1 basic  : 2: 20026966, 0.040827, 0.344549
phy2 collide: 2: 20026966, 0.024589, 0.322988
phy2 basic  : 2: 20026966, 0.025388, 0.428845
phy1 collide: 3: 28045462, 0.040479, 0.337548
phy1 basic  : 3:  9223537, 0.049450, 0.194619
phy2 collide: 3:  9223537, 0.035425, 0.161226
phy2 basic  : 3:  9223537, 0.043568, 0.233337


*/
/* npx eslint broadphase_rb.js -c ../../../../standards/eslint.js */


import {Random,Vector,Matrix} from "../library.js";


//---------------------------------------------------------------------------------
// Linked List


class ListLink {

	constructor(obj) {
		this.prev=null;
		this.next=null;
		this.list=null;
		this.obj=obj??null;
		this.idx=null;
	}


	release() {
		this.remove();
	}


	add(list) {
		if (this.list!==list) {list.add(this);}
	}


	remove(clear) {
		if (this.list!==null) {this.list.remove(this,clear);}
	}

}


class LinkedList {

	constructor(ptr=null) {
		this.head=null;
		this.tail=null;
		this.ptr=ptr;
		this.count=0;
	}


	release(clear) {
		let link=this.head;
		while (link!==null) {
			let next=link.next;
			link.prev=null;
			link.next=null;
			link.list=null;
			if (clear) {link.obj=null;}
			link=next;
		}
		this.count=0;
	}


	*iter() {
		let link=null,next=this.head;
		while ((link=next)!==null) {
			next=link.next;
			yield link.obj;
		}
	}


	add(link) {
		this.addafter(link);
	}


	addafter(link,prev=null) {
		// Inserts the link after prev.
		link.remove();
		let next=null;
		if (prev!==null) {
			next=prev.next;
			prev.next=link;
		} else {
			next=this.head;
			this.head=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (next!==null) {
			next.prev=link;
		} else {
			this.tail=link;
		}
		this.count++;
	}


	addbefore(link,next=null) {
		// Inserts the link before next.
		link.remove();
		let prev=null;
		if (next!==null) {
			prev=next.prev;
			next.prev=link;
		} else {
			prev=this.tail;
			this.tail=link;
		}
		link.prev=prev;
		link.next=next;
		link.list=this;
		if (prev!==null) {
			prev.next=link;
		} else {
			this.head=link;
		}
		this.count++;
	}


	remove(link,clear) {
		if (link===null) {
			return;
		}
		let prev=link.prev;
		let next=link.next;
		if (prev!==null) {
			prev.next=next;
		} else {
			this.head=next;
		}
		if (next!==null) {
			next.prev=prev;
		} else {
			this.tail=prev;
		}
		this.count--;
		link.prev=null;
		link.next=null;
		link.list=null;
		if (clear) {link.obj=null;}
	}

}


//---------------------------------------------------------------------------------
// Physics Placeholder


class PhyBody {

	constructor(world,varr,mat,pos) {
		this.world=world;
		this.worldlink=new ListLink(this);
		this.world.bodylist.addbefore(this.worldlink);
		this.sleeping=false;
		this.vertarr=varr;
		this.mat=mat;
		this.pos=pos;
		this.hitcount=0;
	}


	static overlap(a,b) {
		// Manually check for AABB overlap.
		// Reject NaNs, Inf, and empty bodies.
		if (Object.is(a,b)) {return false;}
		let dim=a.world.dim;
		let amat=a.mat,apos=a.pos,avert=a.vertarr;
		let bmat=b.mat,bpos=b.pos,bvert=b.vertarr;
		if (!avert.length || !bvert.length) {return false;}
		if (!dim) {return true;}
		let anew=[],bnew=[];
		for (let v of avert) {anew.push(amat.mul(v).iadd(apos));}
		for (let v of bvert) {bnew.push(bmat.mul(v).iadd(bpos));}
		for (let d=0;d<dim;d++) {
			let amin=Infinity,amax=-Infinity;
			for (let v of anew) {
				let x=v[d];
				amin=amin<x?amin:x;
				amax=amax>x?amax:x;
			}
			if (!(amin>-Infinity && amin<Infinity && amax>-Infinity && amax<Infinity)) {return false;}
			let bmin=Infinity,bmax=-Infinity;
			for (let v of bnew) {
				let x=v[d];
				bmin=bmin<x?bmin:x;
				bmax=bmax>x?bmax:x;
			}
			if (!(bmin>-Infinity && bmin<Infinity && bmax>-Infinity && bmax<Infinity)) {return false;}
			if (bmax<amin || amax<bmin) {return false;}
		}
		return true;
	}


	static collide(a,b) {
		a.hitcount++;
		b.hitcount++;
	}

}


class PhyWorld {

	constructor(dim) {
		this.dim=dim;
		this.rnd=new Random();
		this.bodylist=new LinkedList();
	}

}


//---------------------------------------------------------------------------------
// BVH with center splitting and flattening.
// Current standard.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      (2N-1)S  tree
	//      N        sorting
	//      (2D+1)N  leaf bounds
	//      N        rand tree
	//
	// Node structure:
	//
	//      0 flags
	//      1 parent
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If flags&1: body_id=right
	// If flags&2: sleeping
	//
	// Center splitting.
	// Flat construction.


	constructor(world) {
		this.world=world;
		this.slack=0.0;// SET 0.05 //
		this.bodycnt=0;
		this.bodyarr=null;
		this.memi32=[];
		this.memf32=null;
		this.testcount=0;// REMOVE //
	}


	release() {
		this.bodyarr=null;
		this.bodycnt=0;
		this.memi32=[];
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the bodies.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the bodies by whether they're above or below the center of this range.
		let world=this.world;
		let dim=world.dim;
		let bodycnt=world.bodylist.count;
		if (!bodycnt) {
			this.bodycnt=0;
			return;
		}
		// Allocate working arrays.
		let dim2=2*dim,nodesize=3+dim2;
		let sortstart=nodesize*(bodycnt*2-1);
		let leafstart=sortstart+bodycnt;
		let treesize=leafstart+bodycnt*nodesize;
		let memi=this.memi32;
		if (memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.bodyarr=new Array(bodycnt*2);
		}
		let memf=this.memf32;
		// Store bodies and their bounds. body_id*2+sleeping.
		let slack=(1+this.slack)*0.5;
		let bodyarr=this.bodyarr;
		let bodylink=world.bodylist.head;
		bodycnt=0;
		while (bodylink) {
			let body=bodylink.obj;
			bodylink=bodylink.next;
			// Reject empty bodies.
			let varr=body.vertarr;
			let vlen=varr.length;
			if (!vlen) {continue;}
			let leafidx=leafstart+(1+dim2)*bodycnt;
			memi[leafidx++]=(bodycnt<<1)|(body.sleeping?1:0);
			memi[sortstart+bodycnt]=leafidx;
			bodyarr[bodycnt++]=body;
			// Find the bounding box of the transformed body.
			let pos=body.pos,mat=body.mat;
			for (let d=0;d<dim;d++) {
				let min=Infinity,max=-Infinity;
				let midx=d*dim;
				for (let i=0;i<vlen;i++) {
					let v=varr[i],x=0;
					for (let j=0;j<dim;j++) {x+=mat[midx+j]*v[j];}
					min=min<x?min:x;
					max=max>x?max:x;
				}
				let dev=(max-min)*slack;
				let cen=(max+min)*0.5+pos[d];
				min=cen-dev;
				max=cen+dev;
				// Reject bodies with degenerate coordinates.
				if (!(min<Infinity && max>-Infinity)) {
					bodycnt--;
					break;
				}
				memf[leafidx++]=min;
				memf[leafidx++]=max;
			}
		}
		this.bodycnt=bodycnt;
		if (!bodycnt) {return;}
		memi[1]=-1;
		memi[2]=sortstart+bodycnt;
		let workstop=nodesize*(bodycnt*2-1);
		let worklo=sortstart;
		for (let work=0;work<workstop;work+=nodesize) {
			// Pop the top working range off the stack.
			let workhi=memi[work+2],workcnt=workhi-worklo;
			if (workcnt===1) {worklo++;continue;}
			// Find the axis with the greatest range.
			let sortaxis=-1;
			let sortmin=-Infinity,sortval=-Infinity;
			for (let axis=0;axis<dim2;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				// Handle min=max=inf.
				let val=max>min?max-min:0;
				val=val>=0?val:Infinity;
				if (sortval<val) {
					sortval=val;
					sortmin=min;
					sortaxis=axis;
				}
			}
			// Divide the nodes depending on if they're above or below the center.
			sortmin+=sortval*0.5;
			sortval=sortmin<Infinity?sortmin:3.40282347e+38;
			let sortdiv=worklo;
			for (let i=dim2?worklo:workhi;i<workhi;i++) {
				let node=memi[i];
				if (memf[node+sortaxis]<=sortval) {
					memi[i]=memi[sortdiv];
					memi[sortdiv++]=node;
				}
			}
			if (sortdiv<=worklo || sortdiv>=workhi) {sortdiv=worklo+(workcnt>>>1);}
			// Queue the divided nodes for additional processing.
			// Left follows immediately, right needs to be padded.
			let l=work+nodesize;
			let r=work+(sortdiv-worklo)*nodesize*2;
			memi[l+2]=sortdiv;
			memi[r+2]=workhi;
			memi[work+2]=r;
		}
		// Set parents and bounding boxes.
		for (let n=workstop-nodesize;n>=0;n-=nodesize) {
			let l=n+nodesize,r=memi[n+2],ndim=n+nodesize;
			if (r>=sortstart) {
				// Leaf
				l=memi[r-1];r=l;
				let a=memi[l-1];
				memi[n+2]=a>>>1; // body_idx
				memi[n  ]=((a&1)<<1)|1; // sleeping|is_leaf
			} else {
				// Parent
				memi[n  ]=memi[l]&memi[r]&2; // sleeping|is_parent
				memi[l+1]=n;l+=3;
				memi[r+1]=n;r+=3;
			}
			for (let i=n+3;i<ndim;i+=2) {
				let x=memf[l++],y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Check for collisions among leaves. Randomly reorder the tree to randomize
		// collision order.
		let bodycnt=this.bodycnt;
		if (bodycnt<=1) {return;}
		this.bodycnt=0;
		let nodesize=3+this.world.dim*2;
		let memi=this.memi32;
		let memf=this.memf32;
		let bodyarr=this.bodyarr;
		let collide=PhyBody.collide;
		// Skip traversal by setting node.parent to node.next.
		let randstart=nodesize*(bodycnt*2-1);
		let randend=randstart;
		let rnd=this.world.rnd;
		memi[1]=randstart<<2;
		for (let n=nodesize;n<randstart;n+=nodesize) {
			let flag=memi[n];
			// if root: next=end
			// if node=parent.right: next=parent.next
			// if node=parent.left : next=parent.right
			let next=memi[n+1];
			if (n===next+nodesize) {
				next=memi[next+2];
			} else {
				next=memi[next+1]>>>2;
			}
			if (flag&1) {
				let cnt=(++randend)-randstart;
				let j=randstart+rnd.mod(cnt);
				memi[randend-1]=memi[j];
				memi[j]=(n<<2)|flag;
			}
			memi[n+1]=(next<<2)|flag;
		}
		// Process leaves left to right.
		let testcount=0;// REMOVE //
		for (let n=randstart;n<randend;n++) {
			let node=memi[n],sleep=node&2;
			node>>>=2;
			let body=bodyarr[memi[node+2]];
			let nbnd=node+3,ndim=node+nodesize;
			node=memi[node+1]>>>2;
			while (node<randstart) {
				let next=memi[node+1];
				if (!(sleep&next)) {
					// Down - check for overlap.
					testcount++;// REMOVE //
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (!(next&1)) {node+=nodesize;continue;}
						else {collide(body,bodyarr[memi[node+2]]);}
					}
				}
				node=next>>>2;
			}
		}
		this.testcount+=testcount;// REMOVE //
	}


	collide_basic() {
		// Look at all leaf nodes and check for collision with all leaves to their right.
		let bodycnt=this.bodycnt;
		let nodesize=3+this.world.dim*2;
		let memi=this.memi32;
		let memf=this.memf32;
		let bodyarr=this.bodyarr;
		let collide=PhyBody.collide;
		let randstart=nodesize*(bodycnt*2-1);
		let randend=randstart;
		let rnd=this.world.rnd;
		for (let n=0;n<randstart;n+=nodesize) {
			// If this is a leaf.
			let flag=memi[n];
			if (flag&1) {
				let cnt=(++randend)-randstart;
				let j=randstart+rnd.mod(cnt);
				memi[randend-1]=memi[j];
				memi[j]=(n<<2)|flag;
			}
		}
		let testcount=0;// REMOVE //
		for (let n=randstart;n<randend;n++) {
			// See if the right child is a body.
			let node=memi[n],sleep=node&2;
			node>>>=2;
			let body=bodyarr[memi[node+2]];
			let prev=node,nbnd=node+3,ndim=node+nodesize;
			node=memi[node+1];
			while (node>=0) {
				let leaf=memi[node+2];
				let next=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let flag=memi[node];
					if (!(flag&sleep)) {
						testcount++;// REMOVE //
						let u=nbnd,v=node+3;
						while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
						if (u===ndim) {
							if (!(flag&1)) {next=node+nodesize;}
							else {collide(body,bodyarr[leaf]);}
						}
					}
				} else if (prev!==leaf) {
					// Up - go right or up again.
					next=leaf;
				}
				prev=node;
				node=next;
			}
		}
		this.testcount+=testcount;// REMOVE //
	}

}


//---------------------------------------------------------------------------------
// Testing


function BroadphaseCheckTree(broad,used,trail) {
	let dim=broad.world.dim*2;
	const aabb=3;
	let nodesize=aabb+dim;
	let volume=0;
	let bodycnt=broad.bodycnt;
	if (!bodycnt) {return volume;}
	let memi=broad.memi32;
	let memf=broad.memf32;
	const root=0;
	let leafstart=nodesize*(bodycnt-1);
	let leafend=leafstart+nodesize*bodycnt;
	let leaflast=leafend-nodesize;
	let trailidx=1,trailstop=bodycnt*2-1;
	if (trailstop>trail.length) {trailstop=trail.length;}
	for (let i=0;i<bodycnt;i++) {used[i]=0;}
	trail[0]=root;
	if (root<0 || root>leaflast || memi[root+1]!==-1) {
		console.log("invalid root:",root,memi[root+1]);
		throw "error";
	}
	for (let t=0;t<trailstop;t++) {
		if (t>=trailidx) {
			console.log("end of trail:",t,trailidx);
			throw "error";
		}
		let n=trail[t],p=memi[n+1];
		// Check bounding box against parent
		let vol=1;
		for (let i=0;i<dim;i+=2) {
			let nbnd=n+aabb+i,pbnd=(p>=0?p:0)+aabb+i;
			let nl=memf[nbnd],nr=memf[nbnd+1];
			let pl=memf[pbnd],pr=memf[pbnd+1];
			if (!(pl<=nl && nr<=pr) || !(nl<=nr)) {
				console.log("child box not in parent",n,p);
				throw "error";
			}
			vol*=nr-nl;
		}
		// Check children
		let l=n+nodesize;
		// let l=memi[n+1];
		let r=memi[n+2];
		let flags=memi[n+0];
		if (!(flags&1)) {
			if (vol<Infinity) {volume+=vol;}
			if (l<0 || l>leaflast || l!==(l|0) || memi[l+1]!==n) {
				console.log("left child misaligned:",n,l,r);
				throw "error";
			}
			if (r<0 || r>leaflast || r!==(r|0) || memi[r+1]!==n || r===l) {
				console.log("right child misaligned:",n,l,r);
				throw "error";
			}
			if ((flags&2)!==(memi[l]&memi[r]&2)) {
				console.log("children not sleeping:",flags&2,memi[l]&2,memi[r]&2);
				throw "error";
			}
			if (trailidx+2>trailstop) {
				console.log("trail length:",trailidx,trailstop);
				throw "error";
			}
			trail[trailidx++]=l;
			trail[trailidx++]=r;
		} else {
			let atom=r;
			if (atom!==(atom|0) || atom<0 || atom>=bodycnt || used[atom]) {
				console.log("invalid atom:",n,atom,bodycnt);
				throw "error";
			}
			used[atom]=1;
		}
	}
	return volume;
}


function StressTest() {
	console.log("testing rigidbody broadphase");
	let maxdim=5;
	let maxbodies=500;
	let used=new Uint32Array(maxbodies);
	let trail=new Uint32Array(maxbodies*2);
	let rnd=new Random(0);
	function randcoord(min=-8,max=0) {
		let type=rnd.getu32()&0xfff;
		if (type<1) {return NaN;}
		if (type<2) {return Infinity;}
		if (type<3) {return -Infinity;}
		return rnd.gets()*Math.pow(2,rnd.getf()*(max-min)+min);
	}
	for (let test=0;test<100;test++) {
		let dim=rnd.mod(maxdim+1);
		console.log(test,dim);
		let world=new PhyWorld(dim);
		let broad=new PhyBroadphase(world);
		for (let bodies=0;bodies<maxbodies;bodies++) {
			// Random transform.
			let mat=new Matrix(dim,dim);
			let pos=new Vector(dim);
			for (let d=0,i=0;d<dim;d++) {
				let scale=randcoord();
				for (let c=0;c<dim;c++) {
					mat[i++]=rnd.gets()*scale;
				}
				pos[d]=randcoord(0,0);
			}
			// Random verts.
			let verts=rnd.mod(10);
			let varr=new Array(verts);
			for (let i=0;i<verts;i++) {
				let v=new Vector(dim);
				for (let j=0;j<dim;j++) {v[j]=rnd.gets();}
				varr[i]=v;
			}
			let body=new PhyBody(world,varr,mat,pos);
			// Count overlaps with previous bodies.
			let hitcount=0;
			for (let b of world.bodylist.iter()) {
				hitcount+=PhyBody.overlap(b,body)?1:0;
			}
			// Rebuild multiple times to catch any memory shuffling errors.
			let memi=broad.memi32;
			let len=memi?memi.length:0;
			for (let i=0;i<len;i++) {memi[i]=rnd.getu32();}
			broad.build();
			BroadphaseCheckTree(broad,used,trail);
			broad.collide();
			//broad.collide_basic();
			// Compare
			if (body.hitcount!==hitcount) {
				console.log(body.hitcount,hitcount);
				console.log(body);
				throw "hitcount";
			}
		}
	}
}


function SpeedTest() {
	console.log("testing rigidbody broadphase speed");
	let maxbodies=40000;
	let rnd=new Random(0);
	function randcoord(min=-8,max=0) {
		return rnd.gets()*Math.pow(2,rnd.getf()*(max-min)+min);
	}
	let dim=2;
	let tests=10;
	let buildtime=0,coltime=0;
	let testcount=0;
	for (let test=0;test<10;test++) {
		let world=new PhyWorld(dim);
		let broad=new PhyBroadphase(world);
		for (let bodies=0;bodies<maxbodies;bodies++) {
			// Random transform.
			let mat=new Matrix(dim,dim);
			let pos=new Vector(dim);
			for (let d=0,i=0;d<dim;d++) {
				let scale=randcoord();
				for (let c=0;c<dim;c++) {
					mat[i++]=rnd.gets()*scale;
				}
				pos[d]=randcoord(0,0);
			}
			// Random verts.
			let verts=rnd.mod(10)+1;
			let varr=new Array(verts);
			for (let i=0;i<verts;i++) {
				let v=new Vector(dim);
				for (let j=0;j<dim;j++) {v[j]=rnd.gets();}
				varr[i]=v;
			}
			new PhyBody(world,varr,mat,pos);
		}
		let t0=performance.now();
		broad.build();
		let t1=performance.now();
		broad.collide();
		//broad.collide_basic();
		let t2=performance.now();
		testcount+=broad.testcount;
		buildtime+=t1-t0;
		coltime+=t2-t1;
	}
	buildtime/=tests*1000;
	coltime/=tests*1000;
	testcount/=tests;
	console.log(`${dim}: ${testcount.toFixed(0)}, ${buildtime.toFixed(6)}, ${coltime.toFixed(6)}`);
}


function main() {
	StressTest();
	//SpeedTest();
}
main();

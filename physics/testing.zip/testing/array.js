const ATOM_WORLD_IDX=0,BOND_WORLD_IDX=1,BOND_A_IDX=2,BOND_B_IDX=3;


class PhyArray {

	constructor(field) {
		this.field=field;
		this.count=0;
		this.arr=new Array();
	}


	release() {
		let arr=this.arr;
		while (this.count) {arr[0].release();}
	}


	*iter() {
		let i=this.count;
		let arr=this.arr;
		while (i-->0) {yield arr[i];}
	}


	add(obj) {
		let field=this.field;
		let i=obj[field];
		if (i>=0) {throw "already in list";}
		let cnt=this.count++;
		let arr=this.arr;
		obj[field]=cnt;
		if (cnt>=arr.length) {
			arr.push(obj);
		} else {
			arr[cnt]=obj;
		}
	}


	remove(obj) {
		let field=this.field;
		let i=obj[field];
		if (!(i>=0)) {return;}
		let cnt=--this.count;
		let arr=this.arr;
		if (i>cnt || !Object.is(arr[i],obj)) {
			throw "wrong list";
		}
		let nxt=arr[cnt];
		nxt[field]=i;
		obj[field]=-1;
		arr[i  ]=nxt;
		arr[cnt]=null;
	}

}


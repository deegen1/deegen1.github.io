/*------------------------------------------------------------------------------


broadphase.js - v1.00

Copyright 2025 Alec Dee - MIT license - SPDX: MIT
2dee.net - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Old versions of the broadphase collision detection.


*/


//---------------------------------------------------------------------------------
// Cell based broadphase. Collisions not unique.


class PhyCell {

	constructor() {
		this.dist=0;
		this.atom=null;
		this.hash=0;
		this.next=null;
	}

}


class PhyBroadphase {

	constructor(world) {
		this.world=world;
		this.slack=1.05;
		this.cellarr=[];
		this.celldim=0.05;
		this.cellmap=[];
		this.mapused=0;
		this.hash0=0;
	}


	release() {
		this.cellarr=[];
		this.cellmap=[];
	}


	getcell(point) {
		if (this.mapused===0) {return null;}
		let dim=this.world.dim,celldim=this.celldim;
		let hash=this.hash0,x;
		for (let d=0;d<dim;d++) {
			x=Math.floor(point[d]/celldim);
			hash=Random.hashu32(hash+x);
		}
		return this.cellmap[hash&(this.mapused-1)];
	}


	testcell(newcell,oldcell,point,d,off) {
		// Tests if the fast distance computation matches the actual distance.
		let world=this.world;
		let dim=world.dim,i;
		let coord=newcell.coord;
		if (coord===undefined) {
			coord=new Array(dim);
			newcell.coord=coord;
		}
		let hash=this.hash0;
		let celldim=this.celldim;
		if (oldcell!==null) {
			for (i=0;i<dim;i++) {coord[i]=oldcell.coord[i];}
			coord[d]+=off;
			for (i=0;i<=d;i++) {hash=Random.hashu32(hash+coord[i]);}
		} else {
			for (i=0;i<dim;i++) {coord[i]=Math.floor(point[i]/celldim);}
		}
		if (newcell.hash!==hash) {
			console.log("hash mismatch");
			throw "error";
		}
		let rad=newcell.atom.rad*this.slack;
		let dist=-rad*rad;
		for (i=0;i<dim;i++) {
			let x0=coord[i]*celldim;
			let x1=x0+celldim;
			let x=point[i];
			if (x<x0) {
				x-=x0;
				dist+=x*x;
			} else if (x>x1) {
				x-=x1;
				dist+=x*x;
			}
		}
		if (Math.abs(newcell.dist-dist)>1e-10) {
			console.log("dist drift");
			throw "error";
		}
	}


	build() {
		// Find all cells that an atom overlaps and add that atom to a linked list in the
		// cell.
		//
		// To find the cells that overlap a atom, first create a cell at the center of the
		// atom. Then expand along the X axis until we reach the edge. For each of these
		// cells, expand along the Y axis until we reach the edge. Continue for each
		// dimension.
		//
		//                                                                  +--+
		//                                                                  |  |
		//                                                               +--+--+--+
		//                                                               |  |  |  |
		//      +--+        +--+--+--+        +--+--+--+--+--+        +--+--+--+--+--+
		//      |  |   ->   |  |  |  |   ->   |  |  |  |  |  |   ->   |  |  |  |  |  |
		//      +--+        +--+--+--+        +--+--+--+--+--+        +--+--+--+--+--+
		//                                                               |  |  |  |
		//                                                               +--+--+--+
		//                                                                  |  |
		//                                                                  +--+
		//
		//    Start at      Expand along      Continue until we        Expand along Y
		//    center.       X axis.           reach the edge.          axis.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcount=world.atomlist.count;
		this.mapused=0;
		if (atomcount===0) {
			return;
		}
		// Randomize the order of the atoms.
		let cellmap=this.cellmap;
		while (atomcount>cellmap.length) {
			cellmap=cellmap.concat(new Array(cellmap.length+1));
		}
		let rnd=world.rnd;
		let atomlink=world.atomlist.head;
		let celldim=0.0;
		let atom;
		for (let i=0;i<atomcount;i++) {
			atom=atomlink.obj;
			atomlink=atomlink.next;
			celldim+=atom.rad;
			let j=rnd.getu32()%(i+1);
			cellmap[i]=cellmap[j];
			cellmap[j]=atom;
		}
		// Use a heuristic to calculate celldim.
		let slack=this.slack;
		celldim*=2.5*slack/atomcount;
		let hash0=rnd.getu32();
		this.celldim=celldim;
		this.hash0=hash0;
		let invdim=1.0/celldim;
		let celldim2=2.0*celldim*celldim;
		let cellend=0;
		let cellarr=this.cellarr;
		let cellalloc=cellarr.length;
		let hashu32=Random.hashu32;
		let floor=Math.floor;
		for (let i=0;i<atomcount;i++) {
			atom=cellmap[i];
			let rad=atom.rad*slack;
			// Make sure we have enough cells.
			let radcells=floor(rad*2*invdim+2.1);
			let combo=radcells;
			for (let d=1;d<dim;d++) {combo*=radcells;}
			while (cellend+combo>cellalloc) {
				cellarr=cellarr.concat(new Array(cellalloc+1));
				for (let j=0;j<=cellalloc;j++) {cellarr[cellalloc+j]=new PhyCell();}
				cellalloc=cellarr.length;
			}
			let pos=atom.pos;
			// Get the starting cell.
			let cellstart=cellend;
			let cell=cellarr[cellend++];
			cell.atom=atom;
			cell.dist=-rad*rad;
			cell.hash=hash0;
			for (let d=0;d<dim;d++) {
				// Precalculate constants for the cell-atom distance calculation.
				// floor(x) is needed so negative numbers round to -infinity.
				let cen    =floor(pos[d]*invdim);
				let cendif =cen*celldim-pos[d];
				let neginit=cendif*cendif;
				let incinit=(celldim+2*cendif)*celldim;
				let posinit=incinit+neginit;
				for (let c=cellend-1;c>=cellstart;c--) {
					// Using the starting cell's distance to pos, calculate the distance to the cells
					// above and below. The starting cell is at cen[d] = floor(pos[d]/celldim).
					cell=cellarr[c];
					let hashcen=cell.hash+cen;
					cell.hash=hashu32(hashcen);
					// Check the cells below the center.
					let hash=hashcen;
					let dist=cell.dist+neginit;
					let distinc=-incinit;
					while (dist<0) {
						let newcell=cellarr[cellend++];
						newcell.atom=atom;
						newcell.dist=dist;
						newcell.hash=hashu32(--hash);
						distinc+=celldim2;
						dist+=distinc;
					}
					// Check the cells above the center.
					hash=hashcen;
					dist=cell.dist+posinit;
					distinc=incinit;
					while (dist<0) {
						let newcell=cellarr[cellend++];
						newcell.atom=atom;
						newcell.dist=dist;
						newcell.hash=hashu32(++hash);
						distinc+=celldim2;
						dist+=distinc;
					}
				}
			}
		}
		// Hash cell coordinates and add to the map.
		let cellmask=cellend;
		cellmask|=cellmask>>>16;
		cellmask|=cellmask>>>8;
		cellmask|=cellmask>>>4;
		cellmask|=cellmask>>>2;
		cellmask|=cellmask>>>1;
		let mapused=cellmask+1;
		if (mapused>cellmap.length) {
			cellmap=new Array(mapused);
		}
		for (let i=0;i<mapused;i++) {
			cellmap[i]=null;
		}
		for (let i=0;i<cellend;i++) {
			let cell=cellarr[i];
			let hash=cell.hash&cellmask;
			cell.next=cellmap[hash];
			cellmap[hash]=cell;
		}
		this.cellarr=cellarr;
		this.cellmap=cellmap;
		this.mapused=mapused;
	}


	collide() {
		// Look at each grid cell. Check for collisions among atoms within that cell.
		let mapused=this.mapused;
		let cellmap=this.cellmap;
		let al,bl,a,collide=PhyAtom.collide;
		for (let c=0;c<mapused;c++) {
			al=cellmap[c];
			while (al!==null) {
				a=al.atom;
				al=al.next;
				bl=al;
				while (bl!==null) {
					collide(a,bl.atom);
					bl=bl.next;
				}
			}
		}
	}

}


//---------------------------------------------------------------------------------
// Try to split atoms into zones.
// An atom can be in multiple zones.


function BroadphaseCheckZones(broad) {
	// Check if all arrays, zones, and atoms are valid.
	let atomarr=broad.atomarr;
	let atomcnt=broad.atomcnt;
	if ((atomarr?atomarr.length:0)<atomcnt) {
		console.log("atom length:",atomarr.length,atomcnt);
		throw "error";
	}
	// Empty zones.
	let zonecnt=broad.zonecnt;
	if (!zonecnt || !atomcnt) {
		if ((zonecnt===0)!==(atomcnt===0)) {
			console.log("non-emtpy zone:",zonecnt,atomcnt);
			throw "error";
		}
		return;
	}
	// Memory management.
	let memarr=broad.memarr;
	let memlen=memarr[0].length;
	for (let i=0;i<memarr.length;i++) {
		let arr=memarr[i];
		if (!(arr instanceof Int32Array)) {
			console.log("not int32[]:",i);
			throw "error";
		}
		if (arr.length!==memlen) {
			console.log("array lengths uneven:",arr.length,memlen);
			throw "error";
		}
		for (let j=0;j<i;j++) {
			let dup=memarr[j];
			if (Object.is(dup,arr)) {
				console.log("duplicate arrays:",i,j);
				throw "error";
			}
			if (Object.is(dup.buffer,arr.buffer)) {
				let off0=arr.byteOffset,len0=arr.length*4;
				let off1=dup.byteOffset,len1=dup.length*4;
				if (off0+len0>off1 && off1+len1>off0) {
					console.log("overlapping buffers:",i,j,off0,len0,off1,len1);
					throw "error";
				}
			}
		}
	}
	if (zonecnt>memlen || atomcnt>memlen) {
		console.log("zone count:",zonecnt,atomcnt,memlen);
		throw "error";
	}
	// Zone-atom pairs should be unique.
	let azmap=new Uint32Array(zonecnt*atomcnt);
	azmap.fill(0);
	// Zone checks.
	let zoneend=memarr[0];
	let zoneatoms=memarr[1];
	let zonemax=zoneend[zonecnt-1];
	if (zonemax>memlen) {
		console.log("zone end:",zonemax,memlen);
		throw "error";
	}
	for (let z=0;z<zonecnt;z++) {
		let prev=z?zoneend[z-1]:0;
		let end=zoneend[z];
		if (prev>=end) {
			console.log("zone order:",prev,end);
			throw "error";
		}
		// Atoms should be unique within a zone.
		for (let i=prev;i<end;i++) {
			let a=zoneatoms[i];
			if (a<0 || a>=atomcnt) {
				console.log("invalid atom:",a);
				throw "error";
			}
			let key=z*atomcnt+a;
			if (azmap[key]&1) {
				console.log("zone-atom pair not unique:",z,a);
				throw "error";
			}
			azmap[key]|=1;
		}
	}
	// Atom checks.
	let atomend=memarr[2];
	let atomzones=memarr[3];
	if (atomend[atomcnt-1]!==zonemax) {
		console.log("zone-atom counts unequal:",atomend[atomcnt-1],zonemax);
		throw "error";
	}
	for (let a=0;a<atomcnt;a++) {
		let prev=a?atomend[a-1]:0;
		let end=atomend[a];
		if (prev>=end) {
			console.log("atom order:",prev,end);
			throw "error";
		}
		// Zones should be unique within an atom.
		for (let i=prev;i<end;i++) {
			let z=atomzones[i];
			if (z<0 || z>=zonecnt) {
				console.log("invalid zone:",z);
				throw "error";
			}
			let key=z*atomcnt+a;
			if (azmap[key]&2) {
				console.log("atom-zone pair not unique:",z,a);
				throw "error";
			}
			azmap[key]|=2;
		}
	}
	// Zone-atom pairs should be reciprocal.
	let stop=zonecnt*atomcnt;
	for (let i=0;i<stop;i++) {
		let val=azmap[i];
		if (val!==0 && val!==3) {
			let z=Math.floor(i/atomcnt);
			let a=i%atomcnt;
			console.log("zone-atom pairing not reciprocal:",val,z,a);
			throw "error";
		}
	}
}


class PhyBroadphase {

	constructor(world) {
		this.world=world;
		this.slack=1.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.zonecnt=0;
		this.memlen=0;
		this.memarr=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memarr=null;
		this.memlen=0;
		this.zonecnt=0;
	}


	resize(newlen) {
		let memlen=this.memlen;
		if (newlen<=memlen) {return memlen;}
		let dim=this.world.dim,arrs=5+(dim>0?dim:1);
		while (newlen&(newlen+1)) {newlen|=newlen>>>1;}
		newlen++;
		let memarr=this.memarr;
		let buf=(new Int32Array(newlen*arrs)).buffer;
		if (!memarr) {
			memarr=new Array(arrs);
			for (let i=0;i<arrs;i++) {memarr[i]=new Int32Array(buf,0,0);}
			this.memarr=memarr;
		}
		for (let i=0;i<arrs;i++) {
			let sub=new Int32Array(buf,i*newlen*4,newlen);
			sub.set(memarr[i]);
			memarr[i]=sub;
		}
		this.memlen=newlen;
		return newlen;
	}


	build() {
		// Recursively find an axis to best split a group of atoms. If we can't find a
		// good split, assign those atoms to a zone and stop. Then, check all atoms within
		// a zone for collisions.
		//
		// We sort atom bounds once for each axis, with min=atom_id*2+0 max=atom_id*2+1.
		// We can easily determine how many atoms will be on the left, right, or both
		// sides of a split by counting how many even or odd ID's we've read.
		//
		// memarr layout:
		//     arr[0  ]=zoneend
		//     arr[1  ]=zoneatoms
		//     arr[2  ]=atomend   / workend
		//     arr[3  ]=atomzones / coordarr / atomflag
		//     arr[4  ]=tmp       / collided
		//     arr[5+0]=x
		//     arr[5+1]=y
		//     arr[5+2]=z
		//     ...
		//
		// WASM: dim, atomcnt, zonecnt, memlen, atomarr [rad,x,y,...], memarr
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		this.zonecnt=0;
		if (atomcnt===0) {return;}
		let atomcnt2=atomcnt*2;
		// Randomize the order of the atoms.
		let atomarr=this.atomarr;
		if (atomarr===null || atomarr.length<atomcnt) {
			atomarr=new Array(atomcnt2);
			this.atomarr=atomarr;
		}
		let rnd=world.rnd;
		let atomlink=world.atomlist.head;
		for (let i=0;i<atomcnt;i++) {
			let j=rnd.getu32()%(i+1);
			atomarr[i]=atomarr[j];
			atomarr[j]=atomlink.obj;
			atomlink=atomlink.next;
		}
		// Allocate working arrays.
		let memlen=this.resize(atomcnt2);
		let memarr=this.memarr;
		let membuf=memarr[0].buffer;
		let memoff=memarr[0].byteOffset;
		// Store atom bounds. All X's first, then Y's, etc. [x-rad,x+rad]
		let slack=this.slack;
		let bndarr=new Float32Array(membuf,memoff+memlen*4*5);
		for (let i=0;i<atomcnt;i++) {
			let atom=atomarr[i],j=i<<1;
			let pos=atom.pos,rad=Math.abs(atom.rad*slack);
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				if (isNaN(x0) || isNaN(x1)) {x0=x1=-Infinity;}
				bndarr[j  ]=x0;
				bndarr[j+1]=x1;
				j+=memlen;
			}
		}
		// Sort bounds along each axis. Realign axis arrays with bndarr.
		let axistmp=new Int32Array(membuf,memoff+memlen*4*3,memlen);
		let axisarr=new Int32Array(membuf,memoff+memlen*4*4,memlen);
		for (let axis=0;axis<dim;axis++) {
			// Arrange bounds so all minimums are in the front. So if B.max=A.min, A.min
			// will be sorted first. This is needed to properly split edge cases later.
			for (let i=0,j=0;i<atomcnt;i++) {
				axisarr[i]=j++;
				axisarr[i+atomcnt]=j++;
			}
			// Merge sort. This must be stable.
			for (let half=1;half<atomcnt2;half+=half) {
				let hstop=atomcnt2-half;
				for (let i=0;i<atomcnt2;) {
					let i0=i ,i1=i <hstop?i +half:atomcnt2;
					let j0=i1,j1=i1<hstop?i1+half:atomcnt2;
					if (i0<i1 && j0<j1) {
						let io=axisarr[i0],jo=axisarr[j0];
						let iv=bndarr[io],jv=bndarr[jo];
						while (true) {
							if (iv<=jv) {
								axistmp[i++]=io;
								if (++i0>=i1) {break;}
								io=axisarr[i0];
								iv=bndarr[io];
							} else {
								axistmp[i++]=jo;
								if (++j0>=j1) {break;}
								jo=axisarr[j0];
								jv=bndarr[jo];
							}
						}
					}
					while (i0<i1) {axistmp[i++]=axisarr[i0++];}
					while (j0<j1) {axistmp[i++]=axisarr[j0++];}
				}
				let tmp=axisarr;
				axisarr=axistmp;
				axistmp=tmp;
			}
			memarr[5+axis]=axisarr;
			axisarr=new Int32Array(membuf,bndarr.byteOffset,memlen);
			bndarr=new Float32Array(membuf,bndarr.byteOffset+memlen*4);
		}
		memarr[4]=axisarr;
		memarr[3]=axistmp;
		// Special case for 0 dimensions.
		if (dim<=0) {
			axisarr=memarr[5];
			for (let i=0,j=0;i<atomcnt;i++) {
				axisarr[i]=j++;
				axisarr[i+atomcnt]=j++;
			}
		}
		let workend=memarr[2];
		workend[0]=0;
		workend[1]=atomcnt2;
		let workidx=2;
		let zonecnt=0,zoneidx=0;
		while (workidx>0) {
			// Pop the top working range off the stack.
			let workhi=workend[--workidx];
			let worklo=workend[--workidx];
			let workcnt=workhi-worklo;
			// Over-allocate ahead of time.
			let alloc=(zoneidx>workhi?zoneidx:workhi)+workcnt*2;
			if (memlen<alloc) {
				memlen=this.resize(alloc);
				workend=memarr[2];
			}
			// Split the atoms in a way that minimizes max(lcnt,rcnt).
			let minlcnt=0,minrcnt=workcnt>28?(workcnt*.72)|0:(workcnt-8);
			let minidx=0,minaxis=-1;
			for (let axis=0;axis<dim;axis++) {
				axisarr=memarr[5+axis];
				let lcnt=0,rcnt=workcnt;
				for (let i=worklo;lcnt<minrcnt;i++) {
					if (axisarr[i]&1) {
						rcnt-=2;
						// we already know lcnt<minrcnt
						if (minrcnt>rcnt) {
							minrcnt=rcnt;
							minlcnt=lcnt;
							minidx=i;
							minaxis=axis;
						}
					} else {
						lcnt+=2;
					}
				}
			}
			// If no split passed our threshold, add it to the list of settled zones.
			// Use the same axis each time, so A appears before B in all zones.
			if (minaxis<0) {
				axisarr=memarr[5];
				let zoneend=memarr[0];
				let zoneatoms=memarr[1];
				let stop=zoneidx+(workcnt>>>1);
				zoneend[zonecnt++]=stop;
				for (let i=worklo;zoneidx<stop;i++) {
					let x=axisarr[i];
					if (!(x&1)) {zoneatoms[zoneidx++]=x>>>1;}
				}
				continue;
			}
			// Flag each atom for the left half (0), right half (2), or both (1).
			let atomflag=memarr[3];
			axisarr=memarr[5+minaxis];
			for (let i=worklo;i<=minidx;i++) {
				let x=axisarr[i];
				atomflag[x>>>1]=1-(x&1);
			}
			for (let i=workhi-1;i>minidx;i--) {
				let x=axisarr[i];
				atomflag[x>>>1]=2-(x&1);
			}
			// For each axis, copy the left half to [lo,lo+lcnt) and the right half to
			// [hi,hi+rcnt) while maintaining sorted order.
			workend[workidx++]=worklo;
			workend[workidx++]=worklo+minlcnt;
			workend[workidx++]=workhi;
			workend[workidx++]=workhi+minrcnt;
			for (let axis=0;axis<dim;axis++) {
				axisarr=memarr[5+axis];
				let lidx=worklo,ridx=workhi;
				for (let i=worklo;i<workhi;i++) {
					let x=axisarr[i];
					let f=atomflag[x>>>1];
					if (f<=1) {axisarr[lidx++]=x;}
					if (f>=1) {axisarr[ridx++]=x;}
				}
				// PhyAssert(lidx===worklo+minlcnt && ridx===workhi+minrcnt);
			}
		}
		// Records all zones an atom is in.
		this.zonecnt=zonecnt;
		let zoneend  =memarr[0];
		let zoneatoms=memarr[1];
		let atomend  =memarr[2];
		let atomzones=memarr[3];
		let sum=zoneidx;
		for (let i=0;i<atomcnt;i++) {atomend[i]=0;}
		for (let i=0;i<sum;i++) {atomend[zoneatoms[i]]++;}
		for (let i=atomcnt-1;i>=0;i--) {
			sum-=atomend[i];
			atomend[i]=sum;
		}
		let idx=0;
		for (let z=0;z<zonecnt;z++) {
			let stop=zoneend[z];
			while (idx<stop) {
				let a=zoneatoms[idx++];
				atomzones[atomend[a]++]=z;
			}
		}
	}


	collide() {
		// Look at all zones an atom is in and check for collisions in each zone.
		// Avoid duplicate collisions.
		let atomcnt=this.atomcnt;
		if (atomcnt<=0) {return;}
		let memarr=this.memarr;
		let collided=memarr[4];
		for (let i=0;i<atomcnt;i++) {collided[i]=-1;}
		let collide=PhyAtom.collide;
		let atomarr=this.atomarr;
		let zoneend  =memarr[0];
		let zoneatoms=memarr[1];
		let atomend  =memarr[2];
		let atomzones=memarr[3];
		let idx=0;
		for (let aid=0;aid<atomcnt;aid++) {
			let aend=atomend[aid];
			let a=atomarr[aid];
			while (idx<aend) {
				let zone=atomzones[idx++];
				let zend=zoneend[zone],bid;
				while ((bid=zoneatoms[--zend])!==aid) {
					if (collided[bid]!==aid) {
						collided[bid]=aid;
						let b=atomarr[bid];
						collide(a,b);
					}
				}
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with mean coordinate splitting and flat construction.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      (2N-1)S  tree
	//      N        sorting
	//      (2D+1)N  leaf bounds
	//      N        rand tree
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=~left.
	//
	// Mean coordinate splitting.
	// Flat construction.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min). Average
		// all points along that axis and split the points above or below the average.
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let dim2=2*dim,nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*3)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let sortstart=nodesize*(atomcnt*2-1);
		let leafstart=sortstart+atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[leafidx++]=i;
			memi[sortstart+i]=leafidx;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		memi[1]=sortstart+atomcnt;
		let worklo=sortstart;
		for (let work=0;work<sortstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let workhi=memi[work+1],workcnt=workhi-worklo;
			if (workcnt===1) {worklo++;continue;}
			// Find the axis with the greatest range.
			let sortaxis=-1;
			let sortavg=-Infinity,sortval=-Infinity;
			for (let axis=0;axis<dim2;axis+=2) {
				let min=Infinity,max=-Infinity,sum=0;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
					sum+=x;
				}
				// Handle min=max=inf.
				let val=max>min?max-min:0;
				val=val>=0?val:Infinity;
				if (sortval<val) {
					sortval=val;
					sortavg=sum;
					sortaxis=axis;
				}
			}
			// Divide the nodes depending on if they're above or below the average.
			sortavg=sortavg<Infinity?sortavg/workcnt:3.40282348e+38;
			let sortdiv=sortaxis>=0?worklo:workhi;
			for (let hi=workhi;sortdiv<hi;) {
				let node=memi[sortdiv];
				if (memf[node+sortaxis]>sortavg) {
					memi[sortdiv]=memi[--hi];
					memi[hi]=node;
				} else {
					sortdiv++;
				}
			}
			if (sortdiv<=worklo || sortdiv>=workhi) {
				sortdiv=worklo+(workcnt>>>1);
			}
			// Queue the divided nodes for additional processing.
			// Left follows immediately, right needs to be padded.
			let l=work+nodesize;
			let r=work+(sortdiv-worklo)*nodesize*2;
			memi[l+1]=sortdiv;
			memi[r+1]=workhi;
			memi[work+1]=l;
			memi[work+2]=r;
		}
		// Set parents and bounding boxes. Leaf = ~atom_id.
		for (let n=sortstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			if (l>=sortstart) {
				l=memi[l-1];r=l;
				memi[n+2]=~memi[l-1];
			} else {
				memi[l]=n;l+=3;
				memi[r]=n;r+=3;
			}
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Check for collisions among leaves. Randomly reorder the tree to randomize
		// collision order.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomly flip the left and right children and repack them.
		// Also find the next node to skip AABB's we've already checked.
		let randstart=treeend;
		let randend=randstart+treeend;
		let rnd=this.world.rnd;
		let swap=0;
		memi[randstart  ]=0;
		memi[randstart+1]=randend;
		memi[randstart+2]=treeend;
		for (let n=randstart;n<randend;n+=nodesize) {
			let orig=memi[n  ];
			let next=memi[n+1];
			// Copy original right child and AABB.
			let u=n+3,v=orig+3,stop=n+nodesize;
			while (u<stop) {memi[u++]=memi[v++];}
			let r=memi[orig+2];
			if (r<0) {
				// Make next negative to let us know if it's a leaf.
				memi[n+1]=~next;
				memi[n+2]=~r;
				continue;
			}
			let l=memi[orig+1];
			// Randomly swap the children.
			if (swap<=1) {swap=rnd.getu32()|0x80000000;}
			if (swap&1) {let tmp=l;l=r;r=tmp;}
			swap>>>=1;
			let cnt=memi[n+2]-nodesize;
			let lcnt=(l<r?0:cnt)+r-l,rcnt=cnt-lcnt;
			let lidx=n+nodesize,ridx=lidx+lcnt;
			memi[lidx  ]=l;
			memi[lidx+1]=ridx;
			memi[lidx+2]=lcnt;
			memi[ridx  ]=r;
			memi[ridx+1]=next;
			memi[ridx+2]=rcnt;
		}
		// Process leaves left to right.
		for (let n=randstart;n<randend;n+=nodesize) {
			let node=~memi[n+1];
			if (node<0) {continue;}
			let atom=atomarr[memi[n+2]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node<randend) {
				let next=memi[node+1];
				// Down - check for overlap.
				let u=nbnd,v=node+3;
				while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
				if (u===ndim) {
					if (next>=0) {next=node+nodesize;}
					else {collide(atom,atomarr[memi[node+2]]);}
				}
				node=next<0?~next:next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with biased collide().


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      (2N-1)S  tree
	//      N        sorting
	//      (2D+1)N  leaf bounds
	//      N        rand tree
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=~left.
	//
	// Mean coordinate splitting.
	// Flat construction.
	// collide() is biased to flowing.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let dim2=2*dim,nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*3)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let sortstart=nodesize*(atomcnt*2-1);
		let leafstart=sortstart+atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[leafidx++]=i;
			memi[sortstart+i]=leafidx;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		memi[1]=sortstart+atomcnt;
		let worklo=sortstart;
		for (let work=0;work<sortstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let workhi=memi[work+1],workcnt=workhi-worklo;
			if (workcnt===1) {worklo++;continue;}
			// Find the axis with the greatest range.
			let sortaxis=-1;
			let sortavg=-Infinity,sortval=-Infinity;
			for (let axis=0;axis<dim2;axis+=2) {
				let min=Infinity,max=-Infinity,sum=0;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
					sum+=x;
				}
				// Handle min=max=inf.
				let val=max>min?max-min:0;
				val=val>=0?val:Infinity;
				if (sortval<val) {
					sortval=val;
					sortavg=sum;
					sortaxis=axis;
				}
			}
			// Divide the nodes depending on if they're above or below the average.
			let sortdiv=worklo;
			if (sortaxis>=0) {
				sortavg=sortavg>-Infinity?sortavg/workcnt:-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i];
					let x=memf[node+sortaxis];
					if (x<sortavg || x<=-Infinity) {
						memi[i]=memi[sortdiv];
						memi[sortdiv++]=node;
					}
				}
			}
			if (sortdiv<=worklo || sortdiv>=workhi) {
				sortdiv=worklo+(workcnt>>>1);
			}
			// Queue the divided nodes for additional processing.
			// Left follows immediately, right needs to be padded.
			let l=work+nodesize;
			let r=work+(sortdiv-worklo)*nodesize*2;
			memi[l+1]=sortdiv;
			memi[r+1]=workhi;
			memi[work+1]=l;
			memi[work+2]=r;
		}
		// Set parents and bounding boxes. Leaf = ~atom_id.
		for (let n=sortstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			if (l>=sortstart) {
				l=memi[l-1];r=l;
				memi[n+2]=~memi[l-1];
			} else {
				memi[l]=n;l+=3;
				memi[r]=n;r+=3;
			}
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		memi[1]=treeend;
		for (let n=nodesize,i=0;n<treeend;n+=nodesize) {
			let p=memi[n];
			let next=p===n-nodesize?memi[p+2]:memi[p+1];
			if (memi[n+2]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
				next=~next;
			}
			memi[n+1]=next;
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],node=~memi[n+1];
			let atom=atomarr[~memi[n+2]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node<treeend) {
				let next=memi[node+1];
				// Down - check for overlap.
				let u=nbnd,v=node+3;
				while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
				if (u===ndim) {
					if (next<0) {
						collide(atom,atomarr[~memi[node+2]]);
					} else {
						next=node+nodesize;
					}
				}
				node=next<0?~next:next;
			}
		}
		this.atomcnt=0;
	}

}


//---------------------------------------------------------------------------------
// BVH mean splitting with no flattening.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// Mean coordinate splitting.
	// No flattening.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortaxis=-1;
			let sortavg=-Infinity,sortval=-Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let min=Infinity,max=-Infinity,sum=0;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
					sum+=x;
				}
				// Handle min=max=inf.
				let val=max>min?max-min:0;
				val=val>=0?val:Infinity;
				if (sortval<val) {
					sortval=val;
					sortavg=sum;
					sortaxis=axis;
				}
			}
			// Divide the nodes depending on if they're above or below the average.
			let sortdiv=worklo;
			if (sortaxis>=0) {
				sortavg=sortavg>-Infinity?sortavg/(workhi-worklo):-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i];
					let x=memf[node+sortaxis];
					if (x<sortavg || x<=-Infinity) {
						memi[i]=memi[sortdiv];
						memi[sortdiv++]=node;
					}
				}
			}
			if (sortdiv<=worklo || sortdiv>=workhi) {
				sortdiv=(worklo+workhi)>>>1;
			}
			// Queue the divided nodes for additional processing.
			// If we only have 1 node on a side, stop dividing.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with median splitting.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// Median splitting.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortaxis=-1,sortmax=-Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				max-=min;
				max=max>=0?max:Infinity;
				if (sortmax<max) {
					sortmax=max;
					sortaxis=axis;
				}
			}
			// Heapsort the largest axis. We only need to sort half.
			let sortend=sortaxis>=0?workhi-1:worklo;
			let sortdiv=worklo+((workhi-worklo)>>>1);
			let sortheap=sortdiv;
			let nodeoff=1-worklo;
			// while (sortend>worklo) {
			while (sortend>=sortdiv) {
				let node,child,nidx;
				if (sortheap>worklo) {
					// Build the heap.
					node=--sortheap;
					nidx=memi[node];
				} else {
					// Pop the greatest element to the end of the array.
					node=sortheap;
					nidx=memi[sortend];
					memi[sortend--]=memi[sortheap];
				}
				let nval=memf[nidx+sortaxis];
				// Heap sort the top element down.
				// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
				while ((child=(node<<1)+nodeoff)<=sortend) {
					let cidx=memi[child];
					let cval=memf[cidx+sortaxis];
					if (child<sortend) {
						let ridx=memi[child+1];
						let rval=memf[ridx+sortaxis];
						if (cval<rval) {
							cidx=ridx;
							cval=rval;
							child++;
						}
					}
					if (nval>=cval) {break;}
					memi[node]=cidx;
					node=child;
				}
				memi[node]=nidx;
			}
			// Split the sorted nodes in half. If we only have 1 node on a side, stop
			// dividing. Otherwise, add the range to the working stack.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with center splitting and flattening.
// Current standard.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      (2N-1)S  tree
	//      N        sorting
	//      (2D+1)N  leaf bounds
	//      N        rand tree
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If right<0, atom_id=~right.
	//
	// Center splitting.
	// Flat construction.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=[];
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=[];
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by whether they're above or below the center of this range.
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let dim2=2*dim,nodesize=3+dim2;
		let sortstart=nodesize*(atomcnt*2-1);
		let treesize=sortstart*2;
		let memi=this.memi32;
		if (memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		// Store atoms and their bounds. atom_id*2+sleeping.
		let leafstart=sortstart+atomcnt;
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomarr=this.atomarr;
		let atomlink=world.atomlist.head;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[leafidx++]=(i<<1)|(atom.sleeping?1:0);
			memi[sortstart+i]=leafidx;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[1]=-1;
		memi[2]=sortstart+atomcnt;
		let worklo=sortstart;
		for (let work=0;work<sortstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let workhi=memi[work+2],workcnt=workhi-worklo;
			if (workcnt===1) {worklo++;continue;}
			// Find the axis with the greatest range.
			let sortaxis=-1;
			let sortmin=-Infinity,sortval=-Infinity;
			for (let axis=0;axis<dim2;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				// Handle min=max=inf.
				let val=max>min?max-min:0;
				val=val>=0?val:Infinity;
				if (sortval<val) {
					sortval=val;
					sortmin=min;
					sortaxis=axis;
				}
			}
			// Divide the nodes depending on if they're above or below the center.
			sortmin+=sortval*0.5;
			sortval=sortmin<Infinity?sortmin:3.40282347e+38;
			let sortdiv=worklo;
			for (let i=dim2?worklo:workhi;i<workhi;i++) {
				let node=memi[i];
				if (memf[node+sortaxis]<=sortval) {
					memi[i]=memi[sortdiv];
					memi[sortdiv++]=node;
				}
			}
			if (sortdiv<=worklo || sortdiv>=workhi) {sortdiv=worklo+(workcnt>>>1);}
			// Queue the divided nodes for additional processing.
			// Left follows immediately, right needs to be padded.
			let l=work+nodesize;
			let r=work+(sortdiv-worklo)*nodesize*2;
			memi[l+2]=sortdiv;
			memi[r+2]=workhi;
			memi[work+2]=r;
		}
		// Set parents and bounding boxes.
		for (let n=sortstart-nodesize;n>=0;n-=nodesize) {
			let l=n+nodesize,r=memi[n+2],ndim=n+nodesize;
			if (r>=sortstart) {
				l=memi[r-1];r=l;
				let a=memi[l-1];
				memi[n+2]=a>>>1;
				memi[n  ]=((a&1)<<1)|1;
			} else {
				memi[n  ]=memi[l]&memi[r]&2;
				memi[l+1]=n;l+=3;
				memi[r+1]=n;r+=3;
			}
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Check for collisions among leaves. Randomly reorder the tree to randomize
		// collision order.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomly flip the left and right children and repack them.
		// Also find the next node to skip AABB's we've already checked.
		let randstart=treeend;
		let randend=randstart+treeend;
		let rnd=this.world.rnd;
		let swap=0;
		memi[randstart  ]=0;
		memi[randstart+1]=randend;
		memi[randstart+2]=treeend;
		for (let n=randstart;n<randend;n+=nodesize) {
			let orig=memi[n  ];
			let next=memi[n+1];
			let cnt =memi[n+2]-nodesize;
			// Copy original right child and AABB.
			let u=n+2,v=orig+2,stop=n+nodesize;
			while (u<stop) {memi[u++]=memi[v++];}
			// Set the flags on .next.
			let f=memi[orig];
			memi[n+1]=(next<<2)|f;
			if (f&1) {continue;}
			// Randomly swap the children.
			let r=memi[orig+2];
			let l=orig+nodesize;
			if (swap<=1) {swap=rnd.getu32()|0x80000000;}
			if (swap&1) {let tmp=l;l=r;r=tmp;}
			swap>>>=1;
			let lcnt=(l<r?0:cnt)+r-l,rcnt=cnt-lcnt;
			let lidx=n+nodesize,ridx=lidx+lcnt;
			memi[lidx  ]=l;
			memi[lidx+1]=ridx;
			memi[lidx+2]=lcnt;
			memi[ridx  ]=r;
			memi[ridx+1]=next;
			memi[ridx+2]=rcnt;
		}
		// Process leaves left to right.
		for (let n=randstart;n<randend;n+=nodesize) {
			let node=memi[n+1];
			if (!(node&1)) {continue;}
			let sleeping=node&2;
			let atom=atomarr[memi[n+2]];
			let nbnd=n+3,ndim=n+nodesize;
			node>>>=2;
			while (node<randend) {
				let next=memi[node+1];
				if (!(sleeping&next)) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (!(next&1)) {node+=nodesize;continue;}
						else {collide(atom,atomarr[memi[node+2]]);}
					}
				}
				node=next>>>2;
			}
		}
	}


	collide_basic() {
		// Look at all leaf nodes and check for collision with all leaves to their right.
		let atomcnt=this.atomcnt;
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		for (let n=0;n<treeend;n+=nodesize) {
			// See if the right child is an atom.
			let sleep=memi[n];
			if (!(sleep&1)) {continue;}
			sleep&=2;
			let atom=atomarr[memi[n+2]];
			let prev=n,node=memi[n+1];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let leaf=memi[node+2];
				let next=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let flag=memi[node];
					if (!(flag&sleep)) {
						let u=nbnd,v=node+3;
						while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
						if (u===ndim) {
							if (!(flag&1)) {next=node+nodesize;}
							else {collide(atom,atomarr[leaf]);}
						}
					}
				} else if (prev!==leaf) {
					// Up - go right or up again.
					next=leaf;
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with center splitting.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// Center splitting.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortdiv=worklo;
			if (nodesize>3) {
				let sortaxis=-1;
				let sortmin=-Infinity,sortval=-Infinity;
				for (let axis=3;axis<nodesize;axis+=2) {
					let min=Infinity,max=-Infinity;
					for (let i=worklo;i<workhi;i++) {
						let node=memi[i]+axis;
						let x=memf[node];
						min=min<x?min:x;
						//x=memf[node+1];
						max=max>x?max:x;
					}
					let val=max-min;
					val=val>=0?val:Infinity;
					if (sortval<val) {
						sortval=val;
						sortmin=min;
						sortaxis=axis;
					}
				}
				if (sortmin<=-Infinity) {
					sortval=-Infinity;
				} else if (sortval<Infinity) {
					sortval=sortval*0.5+sortmin;
				}
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i];
					let x=memf[node+sortaxis];
					if (x<sortval || x<=-Infinity) {
						memi[i]=memi[sortdiv];
						memi[sortdiv++]=node;
					}
				}
			}
			if (sortdiv===worklo || sortdiv===workhi) {
				sortdiv=(worklo+workhi)>>>1;
			}
			// Queue the divided nodes for additional processing.
			// If we only have 1 node on a side, stop dividing.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with count based splitting


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N*2    x sort
	//      N*2    y sort
	//             ...
	//      N*2    x tmp
	//      N*2    y tmp
	//             ...
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.


	constructor(world) {
		this.world=world;
		this.slack=1.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// We sort atom bounds once for each axis, with min=atom_id*2+0 max=atom_id*2+1.
		// We can easily determine how many atoms will be on the left, right, or both
		// sides of a division by counting how many even or odd ID's we've read.
		let world=this.world;
		let dim0=world.dim,dim=dim0>0?dim0:1;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let atomcnt2=atomcnt*2;
		let nodesize=3+2*dim;
		let treesize=atomcnt2*(nodesize+dim*2)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortlow  =leafstart+nodesize*atomcnt;
		let sorthigh =sortlow+atomcnt2*dim;
		// Store atoms and their bounds.
		let slack=this.slack;
		let leafidx=leafstart;
		let pos0=[0];
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			let pos=dim0>0?atom.pos:pos0,rad=Math.abs(atom.rad*slack);
			memi[leafidx+1]=~i;
			leafidx+=3;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				if (isNaN(x0) || isNaN(x1)) {x0=x1=-Infinity;}
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		// Sort bounds along each axis. Realign axis arrays with bndarr.
		for (let axis=0;axis<dim;axis++) {
			let axisarr=new Int32Array(memi.buffer,(sortlow +atomcnt2*axis)*4,atomcnt2);
			let axistmp=new Int32Array(memi.buffer,(sorthigh+atomcnt2*axis)*4,atomcnt2);
			// Arrange bounds so all minimums are in the front. So if B.max=A.min, A.min
			// will be sorted first. This is needed to properly split edge cases later.
			leafidx=leafstart+2*axis+3;
			for (let i=0;i<atomcnt;i++) {
				axisarr[i]=leafidx;
				axisarr[i+atomcnt]=leafidx+1;
				leafidx+=nodesize;
			}
			// Merge sort. This must be stable.
			for (let half=1;half<atomcnt2;half+=half) {
				let hstop=atomcnt2-half;
				for (let i=0;i<atomcnt2;) {
					let i0=i ,i1=i <hstop?i +half:atomcnt2;
					let j0=i1,j1=i1<hstop?i1+half:atomcnt2;
					if (i0<i1 && j0<j1) {
						let io=axisarr[i0],jo=axisarr[j0];
						let iv=memf[io],jv=memf[jo];
						while (true) {
							if (iv<=jv) {
								axistmp[i++]=io;
								if (++i0>=i1) {break;}
								io=axisarr[i0];
								iv=memf[io];
							} else {
								axistmp[i++]=jo;
								if (++j0>=j1) {break;}
								jo=axisarr[j0];
								jv=memf[jo];
							}
						}
					}
					while (i0<i1) {axistmp[i++]=axisarr[i0++];}
					while (j0<j1) {axistmp[i++]=axisarr[j0++];}
				}
				let tmp=axisarr;
				axisarr=axistmp;
				axistmp=tmp;
			}
			for (let i=0;i<atomcnt2;i++) {
				let j=axisarr[i];
				let n=((j/nodesize)|0)*nodesize;
				axisarr[i]=n*2+1-((j-n)&1);
			}
			if (!axis) {
				memi[1]=axisarr.byteOffset>>>2;
				memi[2]=memi[1]+atomcnt2;
			}
		}
		let treeidx=nodesize;
		let sortdif=sorthigh-sortlow;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			let workcnt=workhi-worklo;
			let tmplo=worklo+(worklo<sorthigh?sortdif:-sortdif);
			// Split the atoms in a way that minimizes max(lcnt,rcnt).
			let divmin=workcnt-2,dividx=worklo,divlo=worklo;
			for (let axis=0;axis<dim;axis++) {
				let axislo=worklo+axis*atomcnt2;
				let lcnt=0,rcnt=workcnt;
				for (let i=axislo;lcnt<divmin;i++) {
					if (memi[i]&1) {
						rcnt-=2;
						// we already know lcnt<minrcnt
						if (divmin>rcnt) {
							divmin=rcnt;
							dividx=i;
						}
					} else {
						lcnt+=2;
					}
				}
				if (dividx>=axislo) {divlo=axislo;}
			}
			let divhi=divlo+workcnt;
			// Flag each atom for the left half or right half. Use the parent field to store
			// the flag.
			for (let i=divlo;i<=dividx;i++) {
				let x=memi[i];
				memi[x>>>1]=0;
			}
			let rcnt=0;
			for (let i=dividx+1;i<divhi;i++) {
				let x=memi[i];
				memi[x>>>1]=1;
				rcnt+=x&1;
			}
			// If we have a degenerate case, force one side to be a leaf.
			rcnt+=rcnt;
			if (rcnt===workcnt) {rcnt-=2;memi[memi[divlo  ]>>>1]=0;}
			else if (rcnt===0 ) {rcnt+=2;memi[memi[divhi-1]>>>1]=1;}
			let lcnt=workcnt-rcnt;
			// For each axis, copy the left half to [lo,lo+lcnt) and the right half to
			// [hi,hi+rcnt) while staying sorted. Sort first so we can divide later.
			for (let axis=0;axis<dim;axis++) {
				let off=atomcnt2*axis;
				let axislo=worklo+off,axishi=axislo+workcnt;
				let lidx=tmplo+off,ridx=lidx+lcnt;
				for (let i=axislo;i<axishi;i++) {
					let x=memi[i],j;
					if (memi[x>>>1]) {j=ridx++;} else {j=lidx++;}
					memi[j]=x;
				}
			}
			// If we only have 1 node on a side, stop dividing. Otherwise, mark the ranges
			// of the first axis.
			let leaf;
			if (lcnt===2) {
				leaf=memi[tmplo]>>>1;
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=tmplo;
				memi[leaf+2]=tmplo+lcnt;
			}
			memi[work+1]=leaf;
			if (rcnt===2) {
				leaf=memi[tmplo+workcnt-1]>>>1;
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=tmplo+lcnt;
				memi[leaf+2]=tmplo+workcnt;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2];
			memi[l]=n;
			memi[r]=n;
			let nbnd=n+3,lbnd=l+3,rbnd=r+3;
			let x,y;
			for (let i=0;i<dim;i++) {
				x=memf[lbnd++];y=memf[rbnd++];
				memf[nbnd++]=x<y?x:y;
				x=memf[lbnd++];y=memf[rbnd++];
				memf[nbnd++]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leafs to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let dim=this.world.dim*2;
		let nodesize=3+(dim>0?dim:2);
		let leafidx=nodesize*(atomcnt-1);
		let leafend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leafs.
		let rnd=this.world.rnd;
		let order=new Uint32Array(memi.buffer,leafend*4,atomcnt);
		for (let i=0;i<atomcnt;i++) {
			let j=rnd.getu32()%(i+1);
			order[i]=order[j];
			order[j]=leafidx+i*nodesize;
		}
		for (let i=0;i<atomcnt;i++) {
			let n=order[i],nbnd=n+3,ndim=nbnd+dim;
			let atom=atomarr[~memi[n+1]];
			let prev=n,next,node=memi[n],down=false;
			while (node>=0) {
				if (down) {
					// Down - check for overlap.
					let b0=nbnd,b1=node+3;
					while (b0<ndim && memf[b0]<=memf[b1+1] && memf[b1]<=memf[b0+1]) {b0+=2;b1+=2;}
					if (b0!==ndim) {
						next=prev;
					} else {
						next=memi[node+1];
						if (next<0) {
							collide(atom,atomarr[~next]);
							next=prev;
						}
					}
					down=next!==prev;
				} else {
					// Up - go right or up.
					next=memi[node+2];
					if (prev!==next) {down=true;}
					else {next=memi[node];}
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with median splitting in WASM.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// Median splitting.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
		try {this.wasmload();} catch(e) {console.log(e);}
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		if (this.wasmbuild()) {return;}
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortaxis=-1,sortmax=-Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				max-=min;
				max=max>=0?max:Infinity;
				if (sortmax<max) {
					sortmax=max;
					sortaxis=axis;
				}
			}
			// Heapsort the largest axis. We only need to sort half.
			let sortend=sortaxis>=0?workhi-1:worklo;
			let sortdiv=worklo+((workhi-worklo)>>>1);
			let sortheap=sortdiv;
			let nodeoff=1-worklo;
			// while (sortend>worklo) {
			while (sortend>=sortdiv) {
				let node,child,nidx;
				if (sortheap>worklo) {
					// Build the heap.
					node=--sortheap;
					nidx=memi[node];
				} else {
					// Pop the greatest element to the end of the array.
					node=sortheap;
					nidx=memi[sortend];
					memi[sortend--]=memi[sortheap];
				}
				let nval=memf[nidx+sortaxis];
				// Heap sort the top element down.
				// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
				while ((child=(node<<1)+nodeoff)<=sortend) {
					let cidx=memi[child];
					let cval=memf[cidx+sortaxis];
					if (child<sortend) {
						let ridx=memi[child+1];
						let rval=memf[ridx+sortaxis];
						if (cval<rval) {
							cidx=ridx;
							cval=rval;
							child++;
						}
					}
					if (nval>=cval) {break;}
					memi[node]=cidx;
					node=child;
				}
				memi[node]=nidx;
			}
			// Split the sorted nodes in half. If we only have 1 node on a side, stop
			// dividing. Otherwise, add the range to the working stack.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}


	wasmload() {
		let con=this.constructor;
		if (!con.wasmloaded) {
			// Attempt to load the WebAssembly program.
			con.wasmloaded=1;
			let wasmstr=`
				AGFzbQEAAAABDANgAABgAAF/YAF/AAMEAwABAgQFAXABAQEFAwEAAQYnBn8AQYCABAt/AEGAgAQLfwBB
				gIAEC38AQYCABAt/AEEAC38AQQELB60BCwZtZW1vcnkCABFfX3dhc21fY2FsbF9jdG9ycwAAC2dldGhl
				YXBiYXNlAAEJd2FzbWJ1aWxkAAILX19oZWFwX2Jhc2UDABlfX2luZGlyZWN0X2Z1bmN0aW9uX3RhYmxl
				AQAMX19kc29faGFuZGxlAwEKX19kYXRhX2VuZAMCDV9fZ2xvYmFsX2Jhc2UDAw1fX21lbW9yeV9iYXNl
				AwQMX190YWJsZV9iYXNlAwUKvggDAwABCwYAQYCABAuwCAIYfwR9IAAgACgCBCIPQQF0IhNBA2oiCyAA
				KAIIIgFBAXRBAWtsIgI2AgQgACABIAJqNgIIIAsgAUEBa2wiCUEASgRAIAshCANAAkACfwJAIA5BAnQg
				AGoiAUEIaiIUKAIAIg0gAUEEaiIQKAIAIgRrIgZBAkcEQCAGQQF1IhUgBGohCiAPQQBKDQFBfyEHIA1B
				AWshESAEDAILIBAgACAEQQJ0aiIBKAIANgIAIAFBBGooAgAhAQwCCyAAIARBAnRqIQVBAyEDQwAAgP8h
				G0F/IQcDQEMAAID/IRkgBCANSARAIAAgA0ECdGohDEMAAIB/IRogBSEBIAYhAgNAIBkgDCABKAIAQQJ0
				aioCACIcIBkgHF4bIRkgGiAcIBogHF0bIRogAUEEaiEBIAJBAWsiAg0ACyAZIBqTIRkLIBlDAACAfyAZ
				QwAAAABgGyIZIBsgGSAbXiIBGyEbIAMgByABGyEHIANBAmoiAyALSA0ACyANQQFrIhEgBCAHQQBOGwsi
				AyAKTgRAQQEgBGshFiAAIAdBAnRqIQcgCiEGA0ACQCAEIAZIBEAgACAGQQFrIgZBAnRqKAIAIQwMAQsg
				ACADQQJ0aiIBKAIAIQwgASAAIAZBAnRqKAIANgIAIANBAWshAwsgByAMQQJ0aioCACEaIAYhAgNAAkAg
				AkEBdCAWaiIBIANKDQAgByAAIAFBAnRqKAIAIgVBAnRqKgIAIRkgASADSARAIAcgACABQQFqIhdBAnRq
				KAIAIhhBAnRqKgIAIhsgGSAZIBtdIhIbIRkgGCAFIBIbIQUgFyABIBIbIQELIBkgGl8NACAAIAJBAnRq
				IAU2AgAgASECDAELCyAAIAJBAnRqIAw2AgAgAyAKTg0ACwsCQCAVQQFGBEAgACAEQQJ0aigCACEBDAEL
				IAhBAnQgAGoiAUEIaiAKNgIAIAFBBGogBDYCACAIIgEgC2ohCAsgECABNgIAIAogEUYEQCAAIApBAnRq
				KAIAIQEMAQsgCEECdCAAaiIBQQhqIA02AgAgAUEEaiAKNgIAIAgiASALaiEICyAUIAE2AgAgCyAOaiIO
				IAlIDQALCyAJIAtrIgFBAE4EQCAAQQxqIQogAEEQaiEEQXQgD0EDdGshByAAIAkgE2tBAnRqIQgDQCAJ
				IQYgASIJQQJ0IABqIgFBCGooAgAhAiAAIAFBBGooAgBBAnQiBWogCTYCACAAIAJBAnQiAWogCTYCACAG
				IAlBA2oiA0oEQCABIApqIQEgBCAFaiECIAghBQNAIAUgAkEEayoCACIZIAEqAgAiGiAZIBpdGzgCACAF
				QQRqIAIqAgAiGSABQQRqKgIAIhogGSAaXhs4AgAgAUEIaiEBIAVBCGohBSACQQhqIQIgA0ECaiIDIAZI
				DQALCyAHIAhqIQggCSALayIBQQBODQALCwsAOAlwcm9kdWNlcnMBDHByb2Nlc3NlZC1ieQEMVWJ1bnR1
				IGNsYW5nETE0LjAuMC0xdWJ1bnR1MS4x
			`;
			let wasmbytes=Uint8Array.from(atob(wasmstr),c=>c.charCodeAt(0));
			con.wasmmodule=new WebAssembly.Module(wasmbytes);
			if (!con.wasmmodule) {
				console.log("could not compile module");
				return;
			}
			console.log("compiled module");
		}
		if (!con.wasmmodule) {return;}
		// Create the WASM instance.
		let inst=new WebAssembly.Instance(con.wasmmodule);
		if (!inst) {
			console.log("could not create wasm instance");
			return;
		}
		this.wasm={
			instance :inst,
			exports  :inst.exports,
			heaplen  :inst.exports.getheapbase(),
			wasmbuild:inst.exports.wasmbuild
		};
	}


	wasmbuild() {
		let wasm=this.wasm;
		if (!wasm) {return false;}
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return true;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			let heaplen=wasm.heaplen;
			let wasmmem=wasm.instance.exports.memory;
			let buflen=wasmmem.buffer.byteLength;
			let pagebytes=65536;
			let bytes=heaplen+treesize*2*4;
			let pages=Math.ceil((bytes-buflen)/pagebytes);
			wasmmem.grow(pages);
			let wasmbuf=wasmmem.buffer;
			memi=new Int32Array(wasmbuf,heaplen);
			this.memi32=memi;
			this.memf32=new Float32Array(wasmbuf,heaplen);
		}
		let atomarr=this.atomarr;
		if (atomarr===null || atomarr.length<atomcnt) {
			atomarr=new Array(atomcnt*2);
			this.atomarr=atomarr;
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt>1) {
			memi[1]=dim;
			memi[2]=atomcnt;
			wasm.wasmbuild(memi.byteOffset);
		}
		return true;
	}

}


//---------------------------------------------------------------------------------
// BVH with morton code splitting in WASM.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// Median splitting.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
		try {this.wasmload();} catch(e) {console.log(e);}
	}


	release() {
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		//
		// During each step, find the axis with the largest range (x_max-x_min).
		// Sort the atoms by their minimum bounds on that axis and split the range in half.
		// Continue subdividing each half.
		//
		if (this.wasmbuild()) {return;}
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortaxis=-1,sortmax=-Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				max-=min;
				max=max>=0?max:Infinity;
				if (sortmax<max) {
					sortmax=max;
					sortaxis=axis;
				}
			}
			// Heapsort the largest axis. We only need to sort half.
			let sortend=sortaxis>=0?workhi-1:worklo;
			let sortdiv=worklo+((workhi-worklo)>>>1);
			let sortheap=sortdiv;
			let nodeoff=1-worklo;
			// while (sortend>worklo) {
			while (sortend>=sortdiv) {
				let node,child,nidx;
				if (sortheap>worklo) {
					// Build the heap.
					node=--sortheap;
					nidx=memi[node];
				} else {
					// Pop the greatest element to the end of the array.
					node=sortheap;
					nidx=memi[sortend];
					memi[sortend--]=memi[sortheap];
				}
				let nval=memf[nidx+sortaxis];
				// Heap sort the top element down.
				// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
				while ((child=(node<<1)+nodeoff)<=sortend) {
					let cidx=memi[child];
					let cval=memf[cidx+sortaxis];
					if (child<sortend) {
						let ridx=memi[child+1];
						let rval=memf[ridx+sortaxis];
						if (cval<rval) {
							cidx=ridx;
							cval=rval;
							child++;
						}
					}
					if (nval>=cval) {break;}
					memi[node]=cidx;
					node=child;
				}
				memi[node]=nidx;
			}
			// Split the sorted nodes in half. If we only have 1 node on a side, stop
			// dividing. Otherwise, add the range to the working stack.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}


	wasmload() {
		let con=this.constructor;
		if (!con.wasmloaded) {
			// Attempt to load the WebAssembly program.
			con.wasmloaded=1;
			let wasmstr=`
				AGFzbQEAAAABDANgAABgAAF/YAF/AAMEAwABAgQFAXABAQEFAwEAAQYnBn8AQYCABAt/AEGAgAQLfwBB
				gIAEC38AQYCABAt/AEEAC38AQQELB60BCwZtZW1vcnkCABFfX3dhc21fY2FsbF9jdG9ycwAAC2dldGhl
				YXBiYXNlAAEJd2FzbWJ1aWxkAAILX19oZWFwX2Jhc2UDABlfX2luZGlyZWN0X2Z1bmN0aW9uX3RhYmxl
				AQAMX19kc29faGFuZGxlAwEKX19kYXRhX2VuZAMCDV9fZ2xvYmFsX2Jhc2UDAw1fX21lbW9yeV9iYXNl
				AwQMX190YWJsZV9iYXNlAwUKggwDAwABCwYAQYCABAv0CwQSfwJ+BHwCfSAAKAIEIg5BAXQiEUEDaiIJ
				IAAoAggiBEEBa2whCCAAIARBAXRBAWsgCWxBAnRqQQdqQXhxIgcgBEECdCIBaiIKIAFqIQUCQCAEQQBK
				BEBEAADg////70FEAAAAAP//P0EgDkECRiIBGyIWRAAAAAAAAPA/oEQAAAAAAADgP6IhF0GAgARBgAgg
				ARu3IRggDkEDdEEMaiELIAhBAnQgAGpBDGohAyAOQQBMIQ0DQCAHIAZBAnRqIAYgCWwgCGo2AgACQCAN
				BEBCACEUDAELQQMhAkIAIRQgAyEBA0AgASoCALsgGKIgF6AiFUQAAAAAAAAAACAVRAAAAAAAAPD/ZBsi
				FSAWIBVEAAAAAAAA8H9jGyIVRAAAAAAAAAAAYw0EIBUgFmQNBCAOQQJHAn4gFUQAAAAAAADwQ2MgFUQA
				AAAAAAAAAGZxBEAgFbEMAQtCAAshEyABQQhqIQEEfiATQiCGIBOEQv//g4CAgMAfg0KBgAR+Qv+BgPiP
				gMAfg0KBAn5Cj+CD+ICewIcwg0IRfkLD4bCYjIbD4TCDQgV+Qsmkksmkksmkkn+DBSATQhCGIBOEQv//
				g4Dw/z+DIhNCCIYgE4RC/4H8h/CfwP8AgyITQgSGIBOEQo+evPjw4cOHD4MiE0IChiAThEKz5syZs+bM
				mTODIhNCAYYgE4RC1arVqtWq1arVAIMLIBRCAYZ8IRQgAkECaiICIAlIDQALCyAFIAZBA3RqIBQ3AwAg
				AyALaiEDIAZBAWoiBiAERw0ACwsgBSAEQQN0IgJqIgEgAmohC0IAIRQgBEEATCENA0AgASEMIAUhASAK
				IQYgByEKIBQhE0EAIQIDQCACIAtqQQA2AgAgAkEEaiICQYAIRw0ACyABIQIgBCEDIA1FBEADQCALIAIp
				AwAgE4inQf8BcUECdGoiBSAFKAIAQQFqNgIAIAJBCGohAiADQQFrIgMNAAsLQfwHIQIgBCEDA0AgAiAL
				aiIFIAMgBSgCAGsiAzYCACACQQRrIgJBfEcNAAsgASECIAohAyAEIQUgDUUEQANAIAsgAikDACIUIBOI
				p0H/AXFBAnRqIgcgBygCACIHQQFqNgIAIAwgB0EDdGogFDcDACAGIAdBAnRqIAMoAgA2AgAgAkEIaiEC
				IANBBGohAyAFQQFrIgUNAAsLIBNCCHwhFCAGIQcgDCEFIBNCOFQNAAsgACAENgIIIABBADYCBCAIQQBK
				BEBBACEKIAkhAwNAAkACQAJAIAUgCkECdCAAaiIBQQhqIhIoAgAiBkEBayIPQQN0aikDACAFIAFBBGoi
				CygCACIEQQN0aikDACIThXmnIg1BP0sEQCAGIARrQQF1IARqIQEMAQsgBCIBIAZODQEgBiECA0AgAiAC
				IAFrQQF1IAFqIhAgBSAQQQN0aikDACAThXmnIA1LIgwbIgIgEEEBaiABIAwbIgFKDQALCyAEQQFqIAFH
				DQAgAyECIAcgBEECdGooAgAhAwwBCyADQQJ0IABqIgJBCGogATYCACACQQRqIAQ2AgAgAyAJaiECCyAL
				IAM2AgACfyABIA9GBEAgByAPQQJ0aigCACEBIAIMAQsgAkECdCAAaiIDQQhqIAY2AgAgA0EEaiABNgIA
				IAIiASAJagshAyASIAE2AgAgCSAKaiIKIAhIDQALCyAIIAlrIgFBAE4EQCAAQQxqIQwgAEEQaiEEQXQg
				DkEDdGshCiAAIAggEWtBAnRqIQYDQCAIIQUgASIIQQJ0IABqIgJBCGooAgAhASAAIAJBBGooAgBBAnQi
				AmogCDYCACAAIAFBAnQiAWogCDYCACAFIAhBA2oiB0oEQCABIAxqIQEgAiAEaiECIAYhAwNAIAMgAkEE
				ayoCACIZIAEqAgAiGiAZIBpdGzgCACADQQRqIAIqAgAiGSABQQRqKgIAIhogGSAaXhs4AgAgAUEIaiEB
				IANBCGohAyACQQhqIQIgB0ECaiIHIAVIDQALCyAGIApqIQYgCCAJayIBQQBODQALCyAAQX82AgALCwA4
				CXByb2R1Y2VycwEMcHJvY2Vzc2VkLWJ5AQxVYnVudHUgY2xhbmcRMTQuMC4wLTF1YnVudHUxLjE=
			`;
			let wasmbytes=Uint8Array.from(atob(wasmstr),c=>c.charCodeAt(0));
			con.wasmmodule=new WebAssembly.Module(wasmbytes);
			if (!con.wasmmodule) {console.log("could not compile module");}
		}
		if (!con.wasmmodule) {return;}
		// Create the WASM instance.
		let inst=new WebAssembly.Instance(con.wasmmodule);
		if (!inst) {
			console.log("could not create wasm instance");
			return;
		}
		this.wasm={
			instance :inst,
			exports  :inst.exports,
			heaplen  :inst.exports.getheapbase(),
			wasmbuild:inst.exports.wasmbuild,
			retry    :0
		};
	}


	wasmbuild() {
		let wasm=this.wasm;
		if (!wasm || wasm.retry-->0) {return false;}
		wasm.retry=100;
		let world=this.world;
		let dim=world.dim;
		if (dim!==2 && dim!==3) {return false;}
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return true;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+6)-nodesize+258;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			let heaplen=wasm.heaplen;
			let wasmmem=wasm.instance.exports.memory;
			let buflen=wasmmem.buffer.byteLength;
			let pagebytes=65536;
			let bytes=heaplen+treesize*2*4;
			let pages=Math.ceil((bytes-buflen)/pagebytes);
			wasmmem.grow(pages);
			let wasmbuf=wasmmem.buffer;
			memi=new Int32Array(wasmbuf,heaplen);
			this.memi32=memi;
			this.memf32=new Float32Array(wasmbuf,heaplen);
		}
		let atomarr=this.atomarr;
		if (atomarr===null || atomarr.length<atomcnt) {
			atomarr=new Array(atomcnt*2);
			this.atomarr=atomarr;
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		if (atomcnt<=1) {
			memi[0]=-1;
			return true;
		}
		memi[1]=dim;
		memi[2]=atomcnt;
		wasm.wasmbuild(memi.byteOffset);
		if (memi[0]!==-1) {return false;}
		wasm.retry=0;
		return true;
	}

}


//---------------------------------------------------------------------------------
// BVH with simple SAH splitting.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// SAH fast.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
		this.saharr=null;
		this.sahaabb=null;
	}


	release() {
		this.saharr=null;
		this.sahaabb=null;
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	sahcalc(worklo,workhi,sortaxis,sahmin) {
		// returns [lcnt,sah]
		// Heapsort the axis.
		let sortheap=worklo+((workhi-worklo)>>>1);
		if (sortaxis<=0) {return [sortheap,0];}
		let memi=this.memi32;
		let memf=this.memf32;
		let sortend=workhi-1;
		let nodeoff=1-worklo;
		while (sortend>worklo) {
			let node,child,nidx;
			if (sortheap>worklo) {
				// Build the heap.
				node=--sortheap;
				nidx=memi[node];
			} else {
				// Pop the greatest element to the end of the array.
				node=sortheap;
				nidx=memi[sortend];
				memi[sortend--]=memi[sortheap];
			}
			let nval=memf[nidx+sortaxis];
			// Heap sort the top element down.
			// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
			while ((child=(node<<1)+nodeoff)<=sortend) {
				let cidx=memi[child];
				let cval=memf[cidx+sortaxis];
				if (child<sortend) {
					let ridx=memi[child+1];
					let rval=memf[ridx+sortaxis];
					if (cval<rval) {
						cidx=ridx;
						cval=rval;
						child++;
					}
				}
				if (nval>=cval) {break;}
				memi[node]=cidx;
				node=child;
			}
			memi[node]=nidx;
		}
		// Calculate the right-hand area.
		let dim=this.world.dim,dim2=dim*2;
		let saharr=this.saharr;
		let aabb=this.sahaabb;
		let area=-1;
		for (let i=0;i<dim2;i+=2) {
			aabb[i  ]= Infinity;
			aabb[i+1]=-Infinity;
		}
		for (let w=workhi-1;w>=worklo;w--) {
			let n=memi[w]+3;
			for (let i=0;i<dim2;i+=2) {
				let x=memf[n+i];
				if (aabb[i  ]>x) {aabb[i  ]=x;area=-1;}
				x=memf[n+i+1];
				if (aabb[i+1]<x) {aabb[i+1]=x;area=-1;}
			}
			// If we need to recalc the area.
			if (area<0) {
				if (dim2===2) {
					area=aabb[1]-aabb[0];
				} else {
					area=0;
					let mul=1;
					for (let i=0;i<dim2;i+=2) {
						for (let j=0;j<dim2;j+=2) {
							if (j!==i) {mul*=aabb[j+1]-aabb[j];}
						}
					}
					area+=mul;
				}
			}
			saharr[w-worklo]=area;
		}
		// Calculate the SAH.
		let sahdiv=worklo+1;
		aabb=this.sahaabb;
		area=-1;
		for (let i=0;i<dim2;i+=2) {
			aabb[i  ]= Infinity;
			aabb[i+1]=-Infinity;
		}
		for (let w=worklo;w<workhi-1;w++) {
			let n=memi[w]+3;
			for (let i=0;i<dim2;i+=2) {
				let x=memf[n+i];
				if (aabb[i  ]>x) {aabb[i  ]=x;area=-1;}
				x=memf[n+i+1];
				if (aabb[i+1]<x) {aabb[i+1]=x;area=-1;}
			}
			// If we need to recalc the area.
			if (area<0) {
				if (dim2===2) {
					area=aabb[1]-aabb[0];
				} else {
					area=0;
					let mul=1;
					for (let i=0;i<dim2;i+=2) {
						for (let j=0;j<dim2;j+=2) {
							if (j!==i) {mul*=aabb[j+1]-aabb[j];}
						}
					}
					area+=mul;
				}
			}
			let lcnt=w-worklo+1,rcnt=workhi-w-1;
			let sah=area*lcnt;
			if (sah>sahmin) {break;}
			sah+=saharr[lcnt]*rcnt;
			if (sahmin>sah) {
				sahmin=sah;
				sahdiv=w+1;
			}
		}
		return [sahdiv,sahmin];
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
			this.saharr=new Float64Array(atomcnt*2);
			this.sahaabb=new Float64Array(dim*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sortaxis=-1,sortmax=-Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let min=Infinity,max=-Infinity;
				for (let i=worklo;i<workhi;i++) {
					let node=memi[i]+axis;
					let x=memf[node];
					min=min<x?min:x;
					max=max>x?max:x;
				}
				max-=min;
				max=max>=0?max:Infinity;
				if (sortmax<max) {
					sortmax=max;
					sortaxis=axis;
				}
			}
			let sortdiv=this.sahcalc(worklo,workhi,sortaxis,Infinity)[0];
			// Split the sorted nodes in half. If we only have 1 node on a side, stop
			// dividing. Otherwise, add the range to the working stack.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}

}


//---------------------------------------------------------------------------------
// BVH with full SAH splitting.


class PhyBroadphase {

	// BVH tree structure, S = 3+2*dim:
	//
	//      N*S-S  parent nodes
	//      N*S    leaf nodes
	//      N      sorting
	//
	// Node structure:
	//
	//      0 parent
	//      1 left
	//      2 right
	//      3 x min
	//      4 x max
	//      5 y min
	//        ...
	//
	// If left<0, atom_id=-1-left.
	// SAH full.


	constructor(world) {
		this.world=world;
		this.slack=0.05;
		this.atomcnt=0;
		this.atomarr=null;
		this.memi32=null;
		this.memf32=null;
		this.saharr=null;
		this.sahaabb=null;
	}


	release() {
		this.saharr=null;
		this.sahaabb=null;
		this.atomarr=null;
		this.atomcnt=0;
		this.memi32=null;
		this.memf32=null;
	}


	sahcalc(worklo,workhi,sortaxis,sahmin) {
		// returns [lcnt,sah]
		// Heapsort the axis.
		let sortheap=worklo+((workhi-worklo)>>>1);
		if (sortaxis<=0) {return [sortheap,0];}
		let memi=this.memi32;
		let memf=this.memf32;
		let sortend=workhi-1;
		let nodeoff=1-worklo;
		while (sortend>worklo) {
			let node,child,nidx;
			if (sortheap>worklo) {
				// Build the heap.
				node=--sortheap;
				nidx=memi[node];
			} else {
				// Pop the greatest element to the end of the array.
				node=sortheap;
				nidx=memi[sortend];
				memi[sortend--]=memi[sortheap];
			}
			let nval=memf[nidx+sortaxis];
			// Heap sort the top element down.
			// 2*(node-worklo)+worklo+1 = 2*node-worklo+1
			while ((child=(node<<1)+nodeoff)<=sortend) {
				let cidx=memi[child];
				let cval=memf[cidx+sortaxis];
				if (child<sortend) {
					let ridx=memi[child+1];
					let rval=memf[ridx+sortaxis];
					if (cval<rval) {
						cidx=ridx;
						cval=rval;
						child++;
					}
				}
				if (nval>=cval) {break;}
				memi[node]=cidx;
				node=child;
			}
			memi[node]=nidx;
		}
		// Calculate the right-hand area.
		let dim=this.world.dim,dim2=dim*2;
		let saharr=this.saharr;
		let aabb=this.sahaabb;
		let area=-1;
		for (let i=0;i<dim2;i+=2) {
			aabb[i  ]= Infinity;
			aabb[i+1]=-Infinity;
		}
		for (let w=workhi-1;w>=worklo;w--) {
			let n=memi[w]+3;
			for (let i=0;i<dim2;i+=2) {
				let x=memf[n+i];
				if (aabb[i  ]>x) {aabb[i  ]=x;area=-1;}
				x=memf[n+i+1];
				if (aabb[i+1]<x) {aabb[i+1]=x;area=-1;}
			}
			// If we need to recalc the area.
			if (area<0) {
				if (dim2===2) {
					area=aabb[1]-aabb[0];
				} else {
					area=0;
					let mul=1;
					for (let i=0;i<dim2;i+=2) {
						for (let j=0;j<dim2;j+=2) {
							if (j!==i) {mul*=aabb[j+1]-aabb[j];}
						}
					}
					area+=mul;
				}
			}
			saharr[w-worklo]=area;
		}
		// Calculate the SAH.
		let sahdiv=worklo+1;
		aabb=this.sahaabb;
		area=-1;
		for (let i=0;i<dim2;i+=2) {
			aabb[i  ]= Infinity;
			aabb[i+1]=-Infinity;
		}
		for (let w=worklo;w<workhi-1;w++) {
			let n=memi[w]+3;
			for (let i=0;i<dim2;i+=2) {
				let x=memf[n+i];
				if (aabb[i  ]>x) {aabb[i  ]=x;area=-1;}
				x=memf[n+i+1];
				if (aabb[i+1]<x) {aabb[i+1]=x;area=-1;}
			}
			// If we need to recalc the area.
			if (area<0) {
				if (dim2===2) {
					area=aabb[1]-aabb[0];
				} else {
					area=0;
					let mul=1;
					for (let i=0;i<dim2;i+=2) {
						for (let j=0;j<dim2;j+=2) {
							if (j!==i) {mul*=aabb[j+1]-aabb[j];}
						}
					}
					area+=mul;
				}
			}
			let lcnt=w-worklo+1,rcnt=workhi-w-1;
			let sah=area*lcnt;
			if (sah>sahmin) {break;}
			sah+=saharr[lcnt]*rcnt;
			if (sahmin>sah) {
				sahmin=sah;
				sahdiv=w+1;
			}
		}
		return [sahdiv,sahmin];
	}


	build() {
		// Build a bounding volume hierarchy for the atoms.
		let world=this.world;
		let dim=world.dim;
		let atomcnt=world.atomlist.count;
		this.atomcnt=atomcnt;
		if (atomcnt===0) {return;}
		// Allocate working arrays.
		let nodesize=3+2*dim;
		let treesize=atomcnt*(nodesize*2+1)-nodesize;
		let memi=this.memi32;
		if (memi===null || memi.length<treesize) {
			memi=new Int32Array(treesize*2);
			this.memi32=memi;
			this.memf32=new Float32Array(memi.buffer);
			this.atomarr=new Array(atomcnt*2);
			this.saharr=new Float64Array(atomcnt*2);
			this.sahaabb=new Float64Array(dim*2);
		}
		let memf=this.memf32;
		let leafstart=nodesize*(atomcnt-1);
		let sortstart=leafstart+nodesize*atomcnt;
		// Store atoms and their bounds.
		let slack=1+this.slack;
		let leafidx=leafstart;
		let atomlink=world.atomlist.head;
		let atomarr=this.atomarr;
		for (let i=0;i<atomcnt;i++) {
			let atom=atomlink.obj;
			atomlink=atomlink.next;
			atomarr[i]=atom;
			memi[sortstart+i]=leafidx;
			memi[leafidx+1]=~i;
			leafidx+=3;
			let pos=atom.pos,rad=atom.rad*slack;
			rad=rad>0?rad:-rad;
			for (let axis=0;axis<dim;axis++) {
				let x=pos[axis],x0=x-rad,x1=x+rad;
				x0=x0>-Infinity?x0:-Infinity;
				x1=x1>=x0?x1:x0;
				memf[leafidx++]=x0;
				memf[leafidx++]=x1;
			}
		}
		memi[0]=-1;
		if (atomcnt<=1) {return;}
		memi[1]=sortstart;
		memi[2]=sortstart+atomcnt;
		let treeidx=nodesize;
		for (let work=0;work<leafstart;work+=nodesize) {
			// Pop the top working range off the stack.
			let worklo=memi[work+1];
			let workhi=memi[work+2];
			// Find the axis with the greatest range.
			let sahaxis=-1;
			let sahmin=Infinity;
			for (let axis=3;axis<nodesize;axis+=2) {
				let sah=this.sahcalc(worklo,workhi,axis,sahmin)[1];
				if (sahmin>sah) {
					sahmin=sah;
					sahaxis=axis;
				}
			}
			let sortdiv=this.sahcalc(worklo,workhi,sahaxis,Infinity)[0];
			// Split the sorted nodes in half. If we only have 1 node on a side, stop
			// dividing. Otherwise, add the range to the working stack.
			let leaf;
			if (worklo+1===sortdiv) {
				leaf=memi[worklo];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=worklo;
				memi[leaf+2]=sortdiv;
			}
			memi[work+1]=leaf;
			if (workhi-1===sortdiv) {
				leaf=memi[sortdiv];
			} else {
				leaf=treeidx;
				treeidx+=nodesize;
				memi[leaf+1]=sortdiv;
				memi[leaf+2]=workhi;
			}
			memi[work+2]=leaf;
		}
		// Set parents and bounding boxes.
		for (let n=leafstart-nodesize;n>=0;n-=nodesize) {
			let l=memi[n+1],r=memi[n+2],ndim=n+nodesize;
			memi[l]=n;l+=3;
			memi[r]=n;r+=3;
			let x,y;
			for (let i=n+3;i<ndim;i+=2) {
				x=memf[l++];y=memf[r++];
				memf[i  ]=x<y?x:y;
				x=memf[l++];y=memf[r++];
				memf[i+1]=x>y?x:y;
			}
		}
	}


	collide() {
		// Look at all leaf nodes and check for collision with all leaves to their right
		// in the tree.
		let atomcnt=this.atomcnt;
		if (atomcnt<=1) {return;}
		let nodesize=3+this.world.dim*2;
		let treeend=nodesize*(atomcnt*2-1);
		let memi=this.memi32;
		let memf=this.memf32;
		let atomarr=this.atomarr;
		let collide=PhyAtom.collide;
		// Randomize the order we process leaves.
		let rnd=this.world.rnd;
		for (let n=0,i=0;n<treeend;n+=nodesize) {
			if (memi[n+1]<0) {
				let j=treeend+(rnd.getu32()%(i+1));
				memi[treeend+(i++)]=memi[j];
				memi[j]=n;
			}
		}
		for (let i=0;i<atomcnt;i++) {
			let n=memi[treeend+i],prev=n,node=memi[n];
			let atom=atomarr[~memi[n+1]];
			let nbnd=n+3,ndim=n+nodesize;
			while (node>=0) {
				let next=memi[node  ];
				let left=memi[node+1];
				if (prev===next) {
					// Down - check for overlap.
					let u=nbnd,v=node+3;
					while (u<ndim && memf[u]<=memf[v+1] && memf[v]<=memf[u+1]) {u+=2;v+=2;}
					if (u===ndim) {
						if (left>=0) {next=left;}
						else {collide(atom,atomarr[~left]);}
					}
				} else if (prev===left) {
					// Up - go right or up again.
					next=memi[node+2];
				}
				prev=node;
				node=next;
			}
		}
	}

}


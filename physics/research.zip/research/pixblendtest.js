/*------------------------------------------------------------------------------


pixblendtest.js - v1.00

Copyright 2024 Alec Dee - MIT license - SPDX: MIT
deegen1.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


Tests for more efficient pixel blending algorithms.


*/
/* jshint esversion: 6   */
/* jshint bitwise: false */
/* jshint eqeqeq: true   */
/* jshint curly: true    */

function pixblendtest() {
	// expects alpha in [0,256], NOT [0,256).
	var samples=10000000*2;
	var arr0=new Uint32Array(samples);
	var rnd=new Random();
	for (var i=0;i<samples;i+=2) {
		arr0[i+0]=rnd.getu32();
		arr0[i+1]=rnd.modu32(257);
	}
	var arr=new Uint32Array(samples);
	var arr8=new Uint8Array(arr.buffer);
	var src=rnd.getu32();
	var src3=(src>>>24)&0xff;
	var src2=(src>>>16)&0xff;
	var src1=(src>>> 8)&0xff;
	var src0=(src>>> 0)&0xff;
	var dst,a;
	var lh,hh,lh2,hh2;
	arr.set(arr0);
	var hash0=1,t0=performance.now(),pos=0;
	for (var i=0;i<samples;i+=2) {
		a=arr[i+1];
		arr8[pos]=(arr8[pos]*a+src0*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src1*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src2*(256-a))>>>8;pos++;
		arr8[pos]=(arr8[pos]*a+src3*(256-a))>>>8;pos+=5;
		hash0=Math.imul(hash0,0x1645a3d3)^arr[i];
	}
	console.log(performance.now()-t0,hash0);
	arr.set(arr0);
	lh=src&0x00ff00ff;
	hh=(src>>>8)&0x00ff00ff;
	var hash1=1,t1=performance.now();
	for (var i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=((((dst&0x00ff00ff)*a+lh*(256-a))>>>8)&0x00ff00ff)+
		       ((((dst>>>8)&0x00ff00ff)*a+hh*(256-a))&0xff00ff00);
		hash1=Math.imul(hash1,0x1645a3d3)^arr[i];
	}
	console.log(performance.now()-t1,hash1);
	arr.set(arr0);
	lh=src&0x00ff00ff;
	lh2=lh<<8;
	hh=(src>>>8)&0x00ff00ff;
	hh2=hh<<8;
	var hash2=1,t2=performance.now();
	for (var i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((((dst&0x00ff00ff)-lh)*a+lh2)>>>8)&0x00ff00ff)+
		       (((((dst>>>8)&0x00ff00ff)-hh)*a+hh2)&0xff00ff00);
		hash2=Math.imul(hash2,0x1645a3d3)^arr[i];
	}
	console.log(performance.now()-t2,hash2);
	arr.set(arr0);
	lh=(src&0x00ff00ff)>>>0;
	hh=(src&0xff00ff00)>>>0;
	hh2=hh>>>8;
	var hash3=1,t3=performance.now();
	for (var i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)>>>8)-hh2,a)+hh)&0xff00ff00);
		hash3=Math.imul(hash3,0x1645a3d3)^arr[i];
	}
	console.log(performance.now()-t3,hash3);
	arr.set(arr0);
	lh=src&0x00ff00ff;
	hh=(src&0xff00ff00)>>>0;
	var hash4=1,t4=performance.now();
	for (var i=0;i<samples;i+=2) {
		a=arr[i+1];
		dst=arr[i];
		arr[i]=(((Math.imul((dst&0x00ff00ff)-lh,a)>>>8)+lh)&0x00ff00ff)+
		       ((Math.imul(((dst&0xff00ff00)-hh)>>>8,a)+hh)&0xff00ff00);
		hash4=Math.imul(hash4,0x1645a3d3)^arr[i];
	}
	console.log(performance.now()-t4,hash4);
}